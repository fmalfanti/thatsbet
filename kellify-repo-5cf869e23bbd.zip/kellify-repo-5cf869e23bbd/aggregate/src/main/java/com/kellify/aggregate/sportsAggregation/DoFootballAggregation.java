package com.kellify.aggregate.sportsAggregation;

import com.kellify.aggregate.util.*;
import com.kellify.aggregate.dbload.BetBrainDBConnector;

import com.kellify.common.SportTypes;
import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.util.DTOType;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.aggregation.Aggregation;
import com.kellify.fractionsmaker.aggregation.FootballAggregation;
import com.kellify.common.model.football.FootballBookmakerOdd;

import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;
import org.slf4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DoFootballAggregation {
    static public void meanAggregate(BetBrainDBConnector connector, BetBrainDBConnector historyconn, DbUbibetterConnector ubibetterConnector, Logger logger) throws SQLException {
        LoadFootballOdds loadFootballOdds = LoadFootballOdds.getInstance(connector.getDataSource());
        Connection conn = null;
        final Map<String, List<FootballBookmakerOdd>> entities=null;
        PreparedStatement psGetContinente = null;

        EventFootballProbability eventFootballProbability;
        Map<Long, EventFootballProbability> probabilityMap = new HashMap<>();

        FootballAggregation footballAggregation = Aggregation.getFootballInstance(entities, ubibetterConnector);

        try {
            String naz,mappa;
            double hmin;
            double amin;
            double dmin;
            double hmax;
            double amax;
            double dmax;
            double a,h,d;
            double pa,ph,pd,pb;
            String nazione = "";
            String continente = "undefined"; // nessun continente sulla tabella championshipDecode!!!

            double hh,aa,dd,ct;

            Map<String,Map<Integer,Matrici.HdaMatrix>> mappeFootball;
            Map<Long, List<OddsEntityFootball>> oddList = loadFootballOdds.newLoadEntities();

            Map<Integer,String> MappaBookmakers = loadFootballOdds.loadBookmakers();
            FootballDTO params = null;
            logger.info("match count:" + oddList.size());
            conn = historyconn.getDataSource().getConnection();

            psGetContinente = conn.prepareStatement(LoadFootballOdds.selectContinente);
            FootballProbabilitiesResult resultDb = null;
            FootballProbabilitiesResult resultKnn = null;
            FootballProbabilitiesResult resultMatrix = null;

            mappeFootball=ubibetterConnector.createHDAMapsFromStrings(SportTypes.FOOTBALL);
            //System.out.println("oddList.size:" + oddList.size());
            int printa,printh;

            for (Map.Entry<Long, List<OddsEntityFootball>> mapEntry : oddList.entrySet()) {
                hmin = amin = dmin = 1000;
                hmax = amax = dmax = 0;
                a=h=d=0;
                aa=dd=hh=0.0;
                printa=printh=0;
                continente = "undefined";
                for (OddsEntityFootball entity : mapEntry.getValue()) {

                    nazione = entity.getLocation();
                    continente = entity.getContinent();
                    switch (entity.getRole()) {
                        case "1":
                            if (printh==0) System.out.println("h:"+entity.getParticipant());
                            printh=1;
                            h = entity.getOdds();
                            break;
                        case "2":
                            if (printa==0) System.out.println("a:"+entity.getParticipant());
                            printa=1;
                            a = entity.getOdds();
                            break;
                        default:
                            d = entity.getOdds();
                            break;
                    }
                    if ((a*h*d)>0) {
                        pa=1.0/a;
                        ph=1.0/h;
                        pd=1.0/d;
                        pb=pa+ph+pd;
                        a=h=d=0;
                        pa/=pb;
                        ph/=pb;
                        pd/=pb;
                        amax=Math.max(amax,pa);
                        amin=Math.min(amin,pa);
                        hmax=Math.max(hmax,ph);
                        hmin=Math.min(hmin,ph);
                        dmax=Math.max(dmax,pd);
                        dmin=Math.min(dmin,pd);
                    }
                }
                amax=((int)Math.ceil(amax*100.))/100.;
                amin=((int)Math.floor(amin*100.))/100.;
                dmax=((int)Math.ceil(dmax*100.))/100.;
                dmin=((int)Math.floor(dmin*100.))/100.;
                hmax=((int)Math.ceil(hmax*100.))/100.;
                hmin=((int)Math.floor(hmin*100.))/100.;

// Fino qua uguale per tutti
                params = new FootballDTO(hmin, hmax, amin, amax, dmin, dmax, nazione, DTOType.PROBABILITY,continente);

                resultDb = footballAggregation.evaluateDb(params);
                resultKnn=footballAggregation.evaluateKnn(params,mappeFootball);
                resultMatrix=footballAggregation.evaluateMatrix(params,mappeFootball);
                logger.debug("resultDb:" + resultDb + ", resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix);
                double aaa = resultDb.getAway() + resultKnn.getAway() + resultMatrix.getAway();
                double ddd=resultDb.getDraw() +resultKnn.getDraw()+resultMatrix.getDraw();
                double hhh=resultDb.getHome() +resultKnn.getHome()+resultMatrix.getHome();
                ct = aaa+ddd+hhh;
                //System.out.println("count="+(aa + dd + hh));
// da qui uguale per tutti

                if (ct>10) {
                    ct = aaa + ddd + hhh;
                    pa = aaa / ct;
                    pd = ddd / ct;
                    ph = hhh / ct;
                    System.out.println(mapEntry.getKey()+"---------------------> A:" + pa + " D:" + pd + " H:" + ph);
                    eventFootballProbability = new EventFootballProbability(mapEntry.getKey(), ph, pa, pd);
                    probabilityMap.put(mapEntry.getKey(), eventFootballProbability);
                }
            }

            ubibetterConnector.FTRStatementInitTearDown();

            BookmakerFootballMatcher bookmakerMatcher= BookmakerFootballMatcher.getInstance(probabilityMap,oddList);
            List<EventFootballFractions> eventFootballFractionsList = bookmakerMatcher.matchBookmaker();
            loadFootballOdds = LoadFootballOdds.getInstance(historyconn.getDataSource());
            loadFootballOdds.truncateFractionTables();

            loadFootballOdds.insertFractions(eventFootballFractionsList,MappaBookmakers);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            ex.printStackTrace();
        } finally {
            if(connector != null) {
                connector.closeDataSource();
            }
            if (psGetContinente!=null) {
                psGetContinente.close();
            }
            if (conn!=null){
                conn.close();
            }
        }
    }





}
