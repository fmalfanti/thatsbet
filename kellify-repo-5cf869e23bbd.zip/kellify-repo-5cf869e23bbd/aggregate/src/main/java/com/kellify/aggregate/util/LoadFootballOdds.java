package com.kellify.aggregate.util;


//import org.apache.log4j.Logger;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoadFootballOdds {

    //private static final Logger logger = Logger.getLogger(LoadFootballOdds.class.getName());

    private final DataSource dataSource;
    private static final String truncateStoreProcedure = "{call TruncateFractionTables()}";
    public static final String selectFootballMatrici = "SELECT * FROM football_matrici";

    private static final String selectFootballOdds = "SELECT a.eventId,a.bettingOfferId,a.role,a.odds,a.providerId,a.bookmaker,a.participantName,a.eventName,a.location,a.date,a.lastChangedTime,b.Campionato FROM betbrain.FootballOdds a join betbrain.championshipDecode b on a.eventName=b.eventNameBetbrain and a.location=b.locationBetbrain order by a.eventId,a.bookmaker,a.role";
    private static final String selectNewFootballOdds = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent from football_odds_snapshot where platform_id=1 order by referrer_id,bookmaker_id,role";
    public static final String selectProbabilitiesNazione = "SELECT FTR FROM football_cluster WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ? AND Nazione = ?";
    public static final String selectCountProbabilitiesNazione = "SELECT count(*) FROM football_cluster WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ? AND Nazione = ?";
    public static final String selectProbabilitiesContinente = "SELECT FTR FROM football_cluster WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ? AND Continente = ?";
    public static final String selectCountProbabilitiesContinente = "SELECT count(*) FROM football_cluster WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ? AND Continente = ?";
    public static final String selectAllProbabilities = "SELECT FTR FROM football_cluster WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ?";
    public static final String selectContinente = "SELECT Continente from championshipDecode where Campionato=? and locationBetBrain=?";
    public static final String selectBookmakers = "SELECT id,descr from bookmakers";
    private static final String insertFractions = "INSERT INTO eventsBookmakersFractions (eventID,providerId,homeTeam,awayTeam,location,campionato,startTime,bookmaker,fh,fd,fa,ph,pd,pa,pbh,pbd,pba,delta,bettingOfferIdH,bettingOfferIdD,bettingOfferIdA,lastChangedTime) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private LoadFootballOdds(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static LoadFootballOdds getInstance(DataSource dataSource) {
        return new LoadFootballOdds(dataSource);
    }
    public Map<Long, List<OddsEntityFootball>> loadEntities() throws SQLException {
        Map<Long, List<OddsEntityFootball>> eventMap = new HashMap<>();
        List<OddsEntityFootball> entityList;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventiId;
        try {
            conn = dataSource.getConnection();
            ps=conn.prepareStatement(selectFootballOdds);
            rs=ps.executeQuery();
            while (rs.next()) {
                eventiId = rs.getLong(1);
                entityList = eventMap.computeIfAbsent(eventiId, k -> new ArrayList<>());
                OddsEntityFootball element = new OddsEntityFootball();
                element.setEventId(eventiId);
                element.setBettingOfferId(rs.getLong(2));
                element.setRole(rs.getString(3));
                element.setOdds(rs.getDouble(4));
                //element.setProviderId(rs.getLong(5));
                //element.setBookmaker(rs.getString(6));
                element.setParticipant(rs.getString(7));
                //element.setEventName(rs.getString(8));
                element.setLocation(rs.getString(9));
                element.setStartTime(rs.getTimestamp(10));
                //element.setLastChangedTime(rs.getTimestamp(11));
                element.setCampionato(rs.getString(12));
                //System.out.println("Location:"+element.getLocation()+ ", Campionato:"+element.getCampionato());
                entityList.add(element);
            }

        } finally {
            if (rs !=null) {
                rs.close();
            }
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return eventMap;
    }

    public Map<Integer,String> loadBookmakers() throws SQLException {
        Map <Integer,String> bookMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int indice=0;
        String book="";
        try {
            conn = dataSource.getConnection();
            ps=conn.prepareStatement(selectBookmakers);
            rs=ps.executeQuery();
            while (rs.next()) {
                indice=rs.getInt(1);

                book=bookMap.get(indice);

                if (book==null){
                    bookMap.put(indice,rs.getString(2));

                }
            }
        }finally {
            if (rs !=null) {
                rs.close();
            }
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return bookMap;
    }

    public Map<Long, List<OddsEntityFootball>> newLoadEntities() throws SQLException {
        Map<Long, List<OddsEntityFootball>> eventMap = new HashMap<>();
        List<OddsEntityFootball> entityList;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventiId;
        try {
            conn = dataSource.getConnection();
            ps=conn.prepareStatement(selectNewFootballOdds);
            rs=ps.executeQuery();
            while (rs.next()) {

                eventiId = rs.getLong(2);
                entityList = eventMap.computeIfAbsent(eventiId, k -> new ArrayList<>());
                OddsEntityFootball element = new OddsEntityFootball();
                element.setStartTime(rs.getTimestamp(1));
                element.setEventId(eventiId);
                element.setReferrerId(rs.getLong(3));
                element.setBettingOfferId(rs.getLong(4));
                element.setPlatformId(rs.getInt(5));
                element.setRole(rs.getString(6));
                element.setOdds(rs.getDouble(7));
                element.setBookmakerId(rs.getInt(8));
                element.setParticipant(rs.getString(9));
                element.setCampionato(rs.getString(10));
                element.setLocation(rs.getString(11));
                element.setContinente(rs.getString(12));;
                //System.out.println("Location:"+element.getLocation()+ ", Campionato:"+element.getCampionato());
                entityList.add(element);
            }

        } finally {
            if (rs !=null) {
                rs.close();
            }
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return eventMap;
    }

    public void truncateFractionTables() throws SQLException {
        Connection conn = null;
        CallableStatement cStmt=null;
        try {
            conn=dataSource.getConnection();
            cStmt=conn.prepareCall(truncateStoreProcedure);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }


    }


    public void insertFractions(List<EventFootballFractions> eventFootballFractionsList,Map<Integer,String>bookMap) throws SQLException {
        Connection conn = null;

        PreparedStatement ps = null;
        try {
            //"INSERT INTO eventsBookmakersFractions (eventID,providerId,homeTeam,awayTeam,location,campionato,startTime,bookmaker,fa,fh,fd) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            conn = dataSource.getConnection();

            ps=conn.prepareStatement(insertFractions);
            for(EventFootballFractions eventFootballFractions : eventFootballFractionsList) {
                //System.out.println("inseriti:"+count++);
                System.out.println(eventFootballFractions.toString());
                ps.setDouble(1, eventFootballFractions.getEventId());
                ps.setDouble(2, eventFootballFractions.getProviderId());
                ps.setString(3, eventFootballFractions.getHomeTeam());
                ps.setString(4, eventFootballFractions.getAwayTeam());
                ps.setString(5, eventFootballFractions.getLocation());
                ps.setString(6, eventFootballFractions.getCampionato());
                ps.setTimestamp(7, new Timestamp(eventFootballFractions.getStartTime().getTime()));
                ps.setString(8, bookMap.get(Integer.parseInt(eventFootballFractions.getBookmaker())));
                ps.setDouble(9, eventFootballFractions.getFh());
                ps.setDouble(10, eventFootballFractions.getFd());
                ps.setDouble(11, eventFootballFractions.getFa());
                ps.setInt(12, eventFootballFractions.getPh());
                ps.setInt(13, eventFootballFractions.getPd());
                ps.setInt(14, eventFootballFractions.getPa());
                ps.setInt(15, eventFootballFractions.getPbh());
                ps.setInt(16, eventFootballFractions.getPbd());
                ps.setInt(17, eventFootballFractions.getPba());
                ps.setDouble(18, eventFootballFractions.getDelta());
                ps.setDouble(19, eventFootballFractions.getBettingOfferIdH());
                ps.setDouble(20, eventFootballFractions.getBettingOfferIdD());
                ps.setDouble(21, eventFootballFractions.getBettingOfferIdA());
                ps.setTimestamp(22,new Timestamp(eventFootballFractions.getStartTime().getTime()));
                ps.executeUpdate();
            }
        } catch(Exception ex) {
            System.out.println(ex.getMessage());

        } finally {
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}
