package com.kellify.aggregate.util;

import java.util.Date;


public class OddsEntityTennis {
    private long eventId;
    private long bettingOfferId;
    private String role;
    private double odds;
    private long providerId;
    private String bookmaker;
    private String participant;
    private Date startTime;
    private String location;
    private String eventName;
    private Date lastChangedTime;

    String getEventName() {
        return eventName;
    }

    void setEventName(String eventName) {
        this.eventName = eventName;
    }

    long getEventId() {
        return eventId;
    }

    void setEventId(long eventId) {
        this.eventId = eventId;
    }

    long getBettingOfferId() {
        return bettingOfferId;
    }

    void setBettingOfferId(long bettingOfferId) {
        this.bettingOfferId = bettingOfferId;
    }

    public String getRole() {
        return role;
    }

    void setRole(String role) {
        this.role = role;
    }

    public double getOdds() {
        return odds;
    }

    void setOdds(double odds) {
        this.odds = odds;
    }

    long getProviderId() {
        return providerId;
    }

    void setProviderId(long providerId) {
        this.providerId = providerId;
    }

    String getBookmaker() {
        return bookmaker;
    }

    void setBookmaker(String bookmaker) {
        this.bookmaker = bookmaker;
    }

    public String getParticipant() {
        return participant;
    }

    void setParticipant(String participant) {
        this.participant = participant;
    }

    Date getStartTime() {
        return startTime;
    }

    void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public String getLocation() {
        return location;
    }

    void setLocation(String location) {
        this.location = location;
    }

    Date getLastChangedTime() {
        return lastChangedTime;
    }

    void setLastChangedTime(Date lastChangedTime) {
        this.lastChangedTime = lastChangedTime;
    }

    @Override
    public String toString() {
        return "OddsEntityTennis{" +
                "eventId=" + eventId +
                ", bettingOfferId=" + bettingOfferId +
                ", role='" + role + '\'' +
                ", odds=" + odds +
                ", providerId=" + providerId +
                ", bookmaker='" + bookmaker + '\'' +
                ", participant='" + participant + '\'' +
                ", startTime=" + startTime +
                ", location='" + location + '\'' +
                ", eventName='" + eventName + '\'' +
                ", lastChangedTime=" + lastChangedTime +
                '}';
    }
}
