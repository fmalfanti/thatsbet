package com.kellify.aggregate.util;

import java.util.Date;


public class OddsEntityFootball {
    private long eventId;
    private long bettingOfferId;
    private String role;
    private double odds;
    private long referrerId;
    private int bookmakerId;
    private String participant;
    private Date startTime;
    private String location;
    private int platformId;
    private String campionato;
    private String continente;
    //private Date lastChangedTime;



    long getEventId() {
        return eventId;
    }

    void setEventId(long eventId) {
        this.eventId = eventId;
    }
    long getReferrerId() {
        return referrerId;
    }

    void setReferrerId(long referrerId) {
        this.referrerId = referrerId;
    }

    long getBettingOfferId() {
        return bettingOfferId;
    }

    void setBettingOfferId(long bettingOfferId) {
        this.bettingOfferId = bettingOfferId;
    }

    public String getRole() {
        return role;
    }

    void setRole(String role) {
        this.role = role;
    }

    public double getOdds() {
        return odds;
    }

    void setOdds(double odds) {
        this.odds = odds;
    }

    public int getBookmakerId() {
        return bookmakerId;
    }

    void setBookmakerId(int bookmakerId) {
        this.bookmakerId = bookmakerId;
    }
    public int getPlatformId() {
        return platformId;
    }

    void setPlatformId(int platformId) {
        this.platformId = platformId;
    }

    public String getParticipant() {
        return participant;
    }

    void setParticipant(String participant) {
        this.participant = participant;
    }

    Date getStartTime() {
        return startTime;
    }

    void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public String getLocation() {
        return location;
    }

    void setLocation(String location) {
        this.location = location;
    }

    public String getCampionato() {
        return campionato;
    }

    void setCampionato(String campionato) {
        this.campionato = campionato;
    }
    void setContinente(String continente) {
        this.continente = continente;
    }
    public String getContinent() {
        return continente;
    }


    @Override
    public String toString() {
        return "OddsEntityFootball{" +
                "eventId=" + eventId +
                ", bettingOfferId=" + bettingOfferId +
                ", referrerId=" + referrerId +
                ", role='" + role + '\'' +
                ", odds=" + odds +
                ", bookmakerId='" + bookmakerId + '\'' +
                ", platformId='" + platformId + '\'' +
                ", participant='" + participant + '\'' +
                ", startTime=" + startTime +
                ", location='" + location + '\'' +

                ", campionato='" + campionato + '\'' +
                ", continente=" + continente +
                '}';
    }
}
