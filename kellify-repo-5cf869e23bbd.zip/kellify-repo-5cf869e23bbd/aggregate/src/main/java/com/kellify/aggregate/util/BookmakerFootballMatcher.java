package com.kellify.aggregate.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


public class BookmakerFootballMatcher {
    private static final Logger logger = LoggerFactory.getLogger(BookmakerFootballMatcher.class.getName());

    private final Map<Long, EventFootballProbability> probabilityMap;
    private final Map<Long, List<OddsEntityFootball>> entities;
    private static final double quotaPerc=0.05;
    private static final double probMax=0.55;

    private BookmakerFootballMatcher(Map<Long, EventFootballProbability> probabilityMap, Map<Long, List<OddsEntityFootball>> entities) {
        this.probabilityMap = probabilityMap;
        this.entities = entities;
    }
    public static BookmakerFootballMatcher getInstance(Map<Long, EventFootballProbability> probabilityMap, Map<Long, List<OddsEntityFootball>> entities) {
        return new BookmakerFootballMatcher(probabilityMap, entities);
    }

    public List<EventFootballFractions> matchBookmaker() {
        List<EventFootballFractions> eventFootballFractionsList = new ArrayList<>();
        long eventId;

        long bettingOfferIdH,bettingOfferIdD,bettingOfferIdA;
        double oh,od,oa;
        double aa,hh;
        double pa,pd,ph,pb;
        double fH,fD,fA;
        double da,dd,dh,dM;
        String homeTeam,awayTeam,location,campionato;
        Date startTime,lastChangedTime;
        EventFootballProbability eventFootballProbability;
        List<OddsEntityFootball> oddsEntities;
        EventFootballFractions eventFootballFractions;
        for (Map.Entry<Long, EventFootballProbability> mapEntry:probabilityMap.entrySet()) {
            eventId=mapEntry.getKey();
            eventFootballProbability =mapEntry.getValue();
            oddsEntities=entities.get(eventId);
            homeTeam=awayTeam="";
            oh=od=oa=0.0;
            bettingOfferIdH=bettingOfferIdA=bettingOfferIdD=0;
            //System.out.println(eventId);
            for (OddsEntityFootball oddsEntityFootball :oddsEntities) {
                //System.out.println(oddsEntityFootball.getLineId()+","+oddsEntityFootball.getProviderId());
                location= oddsEntityFootball.getLocation();
                campionato= oddsEntityFootball.getCampionato();
                startTime= oddsEntityFootball.getStartTime();
                switch (oddsEntityFootball.getRole()) {
                    case "1":
                        homeTeam= oddsEntityFootball.getParticipant();
                        oh = oddsEntityFootball.getOdds();
                        bettingOfferIdH= oddsEntityFootball.getBettingOfferId();
                        //lastChangedTime= oddsEntityFootball.getLastChangedTime();
                        break;
                    case "2":
                        awayTeam= oddsEntityFootball.getParticipant();
                        oa = oddsEntityFootball.getOdds();
                        bettingOfferIdA= oddsEntityFootball.getBettingOfferId();
                        //lastChangedTime= oddsEntityFootball.getLastChangedTime();
                        break;
                    default:
                        od = oddsEntityFootball.getOdds();
                        bettingOfferIdD= oddsEntityFootball.getBettingOfferId();
                        //lastChangedTime= oddsEntityFootball.getLastChangedTime();
                        break;
                }

                if ((oa*oh*od)>0) {
                    //System.out.println(oddsEntityFootball.getLineId()+","+oddsEntityFootball.getProviderId()+": oh="+oh+" od="+od+" oa="+oa);
                    pa=1.0/oa;
                    ph=1.0/oh;
                    pd=1.0/od;

                    pb=pa+ph+pd;
                    pa/=pb;
                    ph/=pb;
                    pd/=pb;
                    hh= eventFootballProbability.getHome();
                    dd= eventFootballProbability.getDraw();
                    aa= eventFootballProbability.getAway();
                    //System.out.println("H:"+eventFootballProbability.getHome()+" D:"+eventFootballProbability.getDraw()+"A:"+eventFootballProbability.getAway());
                    if (Math.max(aa,Math.max(hh,dd))>probMax) {
                        dM=Math.max(aa,Math.max(hh,dd));
                        //System.out.println("dentro IF: -> H:" + eventFootballProbability.getHome() + " D:" + eventFootballProbability.getDraw() + "A:" + eventFootballProbability.getAway());
                        if(((((Math.abs(aa - pa)) / pa) >=quotaPerc) && (aa==dM)) || ((((Math.abs(hh - ph)) / ph) >=quotaPerc) && (hh==dM)) || ((((Math.abs(dd - pd)) / pd) >=quotaPerc) && (dd==dM))){
                            fH = ((hh * oh) - 1.0) / (oh - 1.0);
                            fD = ((dd * od) - 1.0) / (od - 1.0);
                            fA = ((aa * oa) - 1.0) / (oa - 1.0);
                            oa = oh = od = 0;
                            if ((fH > 0) || (fA > 0) || (fD > 0)) {
                                //System.out.println("H:"+eventFootballProbability.getHome()+"/"+ph);
                                //System.out.println("D:"+eventFootballProbability.getDraw()+"/"+pd);
                                //System.out.println("A:"+eventFootballProbability.getAway()+"/"+pa);
                                //System.out.println(oddsEntityFootball.getBookmaker()+" " + campionato + " "+ location + " "+ homeTeam+" "+awayTeam+ " "+ startTime+ " "+fH+" "+fD+" "+fA+ " "+dM+ "-->"+eventId);
                                eventFootballFractions = new EventFootballFractions();
                                eventFootballFractions.setEventId(eventId);
                                //eventFootballFractions.setProviderId(oddsEntityFootball.getProviderId());
                                eventFootballFractions.setHomeTeam(homeTeam);
                                eventFootballFractions.setAwayTeam(awayTeam);
                                eventFootballFractions.setLocation(location);
                                eventFootballFractions.setCampionato(campionato);
                                eventFootballFractions.setStartTime(startTime);
                                eventFootballFractions.setBookmaker(((Integer) oddsEntityFootball.getBookmakerId()).toString());
                                eventFootballFractions.setFa(fA);
                                eventFootballFractions.setFh(fH);
                                eventFootballFractions.setFd(fD);
                                eventFootballFractions.setPh(Math.round(Math.round(100 * eventFootballProbability.getHome())));
                                eventFootballFractions.setPd(Math.round(Math.round(100 * eventFootballProbability.getDraw())));
                                eventFootballFractions.setPa(Math.round(Math.round(100 * eventFootballProbability.getAway())));
                                eventFootballFractions.setPbh(Math.round(Math.round(100 * ph)));
                                eventFootballFractions.setPbd(Math.round(Math.round(100 * pd)));
                                eventFootballFractions.setPba(Math.round(Math.round(100 * pa)));
                                eventFootballFractions.setDelta(dM);
                                eventFootballFractions.setBettingOfferIdH(bettingOfferIdH);
                                eventFootballFractions.setBettingOfferIdD(bettingOfferIdD);
                                eventFootballFractions.setBettingOfferIdA(bettingOfferIdA);
                                //eventFootballFractions.setLastChangedTime(lastChangedTime);
                                //System.out.println(eventFootballFractions.toString());
                                eventFootballFractionsList.add(eventFootballFractions);
                            }
                        }
                    }

                    oh=od=oa=0.0;
                }

            }
            //System.out.println();
        }
        return eventFootballFractionsList;
    }
}
