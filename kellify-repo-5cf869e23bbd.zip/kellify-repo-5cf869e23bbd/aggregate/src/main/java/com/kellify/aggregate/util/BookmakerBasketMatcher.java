package com.kellify.aggregate.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class BookmakerBasketMatcher {
    private static final Logger logger = LoggerFactory.getLogger(BookmakerBasketMatcher.class.getName());

    private final Map<Long, EventBasketProbability> probabilityMap;
    private final Map<Long, List<OddsEntityBasket>> entities;
    private static final double quotaPerc=0.10;

    private BookmakerBasketMatcher(Map<Long, EventBasketProbability> probabilityMap, Map<Long, List<OddsEntityBasket>> entities) {
        this.probabilityMap = probabilityMap;
        this.entities = entities;
    }
    public static BookmakerBasketMatcher getInstance(Map<Long, EventBasketProbability> probabilityMap, Map<Long, List<OddsEntityBasket>> entities) {
        return new BookmakerBasketMatcher(probabilityMap, entities);
    }

    public List<EventBasketFractions> matchBookmaker() {
        List<EventBasketFractions> eventFractionsList = new ArrayList<>();
        long eventId;
        double probMax=0.60;
        long bettingOfferIdH,bettingOfferIdA;
        double oh,oa;
        double aa,hh;
        double pa,ph,pb;
        double fH,fA;
        double dM;
        String homeTeam,awayTeam,location,campionato;
        Date startTime,lastChangedTime;
        EventBasketProbability eventProbability;
        List<OddsEntityBasket> oddsEntities;
        EventBasketFractions eventFractions;
        for (Map.Entry<Long, EventBasketProbability> mapEntry:probabilityMap.entrySet()) {
            eventId=mapEntry.getKey();
            eventProbability=mapEntry.getValue();
            oddsEntities=entities.get(eventId);
            homeTeam=awayTeam="";
            oh=oa=0.0;
            bettingOfferIdH=bettingOfferIdA=0;
            //System.out.println(eventId);
            for (OddsEntityBasket OddsEntityBasket :oddsEntities) {
                //System.out.println(footballOddsEntity.getLineId()+","+footballOddsEntity.getProviderId());
                location= OddsEntityBasket.getLocation();
                campionato= OddsEntityBasket.getEventName();
                startTime= OddsEntityBasket.getStartTime();
                switch (OddsEntityBasket.getRole()) {
                    case "Home":
                        homeTeam= OddsEntityBasket.getParticipant();
                        oh = OddsEntityBasket.getOdds();
                        bettingOfferIdH= OddsEntityBasket.getBettingOfferId();
                        lastChangedTime= OddsEntityBasket.getLastChangedTime();
                        break;
                    default:
                        awayTeam= OddsEntityBasket.getParticipant();
                        oa = OddsEntityBasket.getOdds();
                        bettingOfferIdA= OddsEntityBasket.getBettingOfferId();
                        lastChangedTime= OddsEntityBasket.getLastChangedTime();
                        break;
                }

                if ((oa*oh)>0) {
                    //System.out.println(footballOddsEntity.getLineId()+","+footballOddsEntity.getProviderId()+": oh="+oh+" od="+od+" oa="+oa);
                    pa=1.0/oa;
                    ph=1.0/oh;
                    pb=pa+ph;
                    pa/=pb;
                    ph/=pb;
                    hh=eventProbability.getHome();
                    aa=eventProbability.getAway();
                    //System.out.println("H:"+eventProbability.getHome()+" D:"+eventProbability.getDraw()+"A:"+eventProbability.getAway());
                    if (Math.max(aa,hh)>probMax) {
                        dM=Math.max(aa,hh);
                        //System.out.println("dentro IF: -> H:" + eventProbability.getHome() + " D:" + eventProbability.getDraw() + "A:" + eventProbability.getAway());
                        if(((((Math.abs(aa - pa)) / pa) >=quotaPerc) && (aa==dM)) || ((((Math.abs(hh - ph)) / ph) >=quotaPerc) && (hh==dM))){
                            fH = ((hh * oh) - 1.0) / (oh - 1.0);
                            fA = ((aa * oa) - 1.0) / (oa - 1.0);
                            oa = oh = 0;
                            if ((fH > 0) || (fA > 0) ) {
                                //System.out.println("H:"+eventProbability.getHome()+"/"+ph);
                                //System.out.println("D:"+eventProbability.getDraw()+"/"+pd);
                                //System.out.println("A:"+eventProbability.getAway()+"/"+pa);
                                //System.out.println(footballOddsEntity.getBookmaker()+" " + campionato + " "+ location + " "+ homeTeam+" "+awayTeam+ " "+ startTime+ " "+fH+" "+fD+" "+fA+ " "+dM+ "-->"+eventId);
                                eventFractions = new EventBasketFractions();
                                eventFractions.setEventId(eventId);
                                eventFractions.setProviderId(OddsEntityBasket.getProviderId());
                                eventFractions.setHomeTeam(homeTeam);
                                eventFractions.setAwayTeam(awayTeam);
                                eventFractions.setLocation(location);
                                eventFractions.setCampionato(campionato);
                                eventFractions.setStartTime(startTime);
                                eventFractions.setBookmaker(OddsEntityBasket.getBookmaker());
                                eventFractions.setFa(fA);
                                eventFractions.setFh(fH);
                                eventFractions.setPh(Math.round(Math.round(100 * eventProbability.getHome())));
                                eventFractions.setPa(Math.round(Math.round(100 * eventProbability.getAway())));
                                eventFractions.setPbh(Math.round(Math.round(100 * ph)));
                                eventFractions.setPba(Math.round(Math.round(100 * pa)));
                                eventFractions.setDelta(dM);
                                eventFractions.setBettingOfferIdH(bettingOfferIdH);
                                eventFractions.setBettingOfferIdA(bettingOfferIdA);
                                eventFractions.setLastChangedTime(lastChangedTime);
                                //System.out.println(eventFractions.toString());
                                eventFractionsList.add(eventFractions);
                            }
                        }
                    }


                }

            }
            //System.out.println();
        }
        return eventFractionsList;
    }
}
