package com.kellify.aggregate.util;


//import org.apache.log4j.Logger;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoadTennisOdds {

    //private static final Logger logger = Logger.getLogger(LoadFootballOdds.class.getName());

    private final DataSource dataSource;
    private static final String truncateStoreProcedure = "{call TruncateFractionTablesTennis()}";

    private static final String selectTennisOdds = "SELECT eventId,bettingOfferId,role,odds,providerId,bookmaker,participantName,eventName,location,date,lastChangedTime FROM TennisOdds";
    public static final String selectTennisMatrici = "SELECT * FROM tennis_matrici";
    public static final String selectWinnerTennisProbabilities = "SELECT COUNT(*) FROM tennis_cluster WHERE MW BETWEEN ? AND ? AND ML BETWEEN ? AND ?";
    public static final String selectLoserTennisProbabilities = "SELECT COUNT(*) FROM tennis_cluster WHERE ML BETWEEN ? AND ? AND MW BETWEEN ? AND ?";
    private static final String insertTennisFractions = "INSERT INTO eventsBookmakersFractionsTennis (eventID,providerId,homeTeam,awayTeam,location,campionato,startTime,bookmaker,fh,fa,ph,pa,pbh,pba,delta,bettingOfferIdH,bettingOfferIdA,lastChangedTime) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private LoadTennisOdds(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static LoadTennisOdds getInstance(DataSource dataSource) {
        return new LoadTennisOdds(dataSource);
    }

    public Map<Long, List<OddsEntityTennis>> loadEntities() throws SQLException {
        Map<Long, List<OddsEntityTennis>> eventMap = new HashMap<>();
        List<OddsEntityTennis> entityList;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventiId;
        try {
            conn = dataSource.getConnection();
            ps=conn.prepareStatement(selectTennisOdds);
            rs=ps.executeQuery();
            while (rs.next()) {
                eventiId = rs.getLong(1);
                //System.out.println("eventiId="+eventiId);
                entityList = eventMap.computeIfAbsent(eventiId, k -> new ArrayList<>());
                OddsEntityTennis element = new OddsEntityTennis();
                element.setEventId(eventiId);
                element.setBettingOfferId(rs.getLong(2));
                element.setRole(rs.getString(3));
                element.setOdds(rs.getDouble(4));
                element.setProviderId(rs.getLong(5));
                element.setBookmaker(rs.getString(6));
                element.setParticipant(rs.getString(7));
                element.setEventName(rs.getString(8));
                element.setLocation(rs.getString(9));
                element.setStartTime(rs.getTimestamp(10));
                element.setLastChangedTime(rs.getTimestamp(11));
                //System.out.println("Location:"+element.getLocation()+ ", Campionato:"+element.getCampionato());
                entityList.add(element);
            }

        } finally {
            if (rs !=null) {
                rs.close();
            }
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return eventMap;
    }

    public void truncateFractionTables() throws SQLException {
        Connection conn = null;
        CallableStatement cStmt=null;
        try {
            conn=dataSource.getConnection();
            cStmt=conn.prepareCall(truncateStoreProcedure);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }


    }


    public void insertFractions(List<EventTennisFractions> eventTennisFractionsList) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            //"INSERT INTO eventsBookmakersFractions (eventID,providerId,homeTeam,awayTeam,location,campionato,startTime,bookmaker,fa,fh,fd) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            conn = dataSource.getConnection();

            ps=conn.prepareStatement(insertTennisFractions);
            for(EventTennisFractions eventTennisFractions : eventTennisFractionsList) {
                //System.out.println("inseriti:"+count++);
                ps.setDouble(1, eventTennisFractions.getEventId());
                ps.setDouble(2, eventTennisFractions.getProviderId());
                ps.setString(3, eventTennisFractions.getHomeTeam());
                ps.setString(4, eventTennisFractions.getAwayTeam());
                ps.setString(5, eventTennisFractions.getLocation());
                ps.setString(6, eventTennisFractions.getCampionato());
                ps.setTimestamp(7, new Timestamp(eventTennisFractions.getStartTime().getTime()));
                ps.setString(8, eventTennisFractions.getBookmaker());
                ps.setDouble(9, eventTennisFractions.getFh());
                ps.setDouble(10, eventTennisFractions.getFa());
                ps.setInt(11, eventTennisFractions.getPh());
                ps.setInt(12, eventTennisFractions.getPa());
                ps.setInt(13, eventTennisFractions.getPbh());
                ps.setInt(14, eventTennisFractions.getPba());
                ps.setDouble(15, eventTennisFractions.getDelta());
                ps.setDouble(16, eventTennisFractions.getBettingOfferIdH());
                ps.setDouble(17, eventTennisFractions.getBettingOfferIdA());
                ps.setTimestamp(18,new Timestamp(eventTennisFractions.getLastChangedTime().getTime()));
                ps.executeUpdate();
            }
        } catch(Exception ex) {
            System.out.println(ex.getMessage());

        } finally {
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}
