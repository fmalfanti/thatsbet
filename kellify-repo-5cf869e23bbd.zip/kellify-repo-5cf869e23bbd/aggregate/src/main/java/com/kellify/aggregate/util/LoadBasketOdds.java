package com.kellify.aggregate.util;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoadBasketOdds {
    //private static final Logger logger = Logger.getLogger(LoadFootballOdds.class.getName());

    private final DataSource dataSource;
    private static final String truncateStoreProcedure = "{call TruncateFractionTablesTennis()}";

    private static final String selectBasketOdds = "SELECT eventId,bettingOfferId,role,odds,providerId,bookmaker,participantName,eventName,location,date,lastChangedTime FROM BasketOdds";
    public static final String selectBasketmatrici = "SELECT * FROM basket_matrici";
    public static final String selectAllBasketProbabilities = "SELECT FTR FROM basket_cluster WHERE MA BETWEEN ? AND ?  AND MH BETWEEN ? AND ?";

    private static final String insertBasketFractions = "INSERT INTO eventsBookmakersFractionsBasket (eventID,providerId,homeTeam,awayTeam,location,campionato,startTime,bookmaker,fh,fa,ph,pa,pbh,pba,delta,bettingOfferIdH,bettingOfferIdA,lastChangedTime) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private LoadBasketOdds(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static LoadBasketOdds getInstance(DataSource dataSource) {
        return new LoadBasketOdds(dataSource);
    }

    public Map<Long, List<OddsEntityBasket>> loadEntities() throws SQLException {
        Map<Long, List<OddsEntityBasket>> eventMap = new HashMap<>();
        List<OddsEntityBasket> entityList;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventiId;
        try {
            conn = dataSource.getConnection();
            ps=conn.prepareStatement(selectBasketOdds);
            rs=ps.executeQuery();
            while (rs.next()) {
                eventiId = rs.getLong(1);
                //System.out.println("eventiId="+eventiId);
                entityList = eventMap.computeIfAbsent(eventiId, k -> new ArrayList<>());
                OddsEntityBasket element = new OddsEntityBasket();
                element.setEventId(eventiId);
                element.setBettingOfferId(rs.getLong(2));
                element.setRole(rs.getString(3));
                element.setOdds(rs.getDouble(4));
                element.setProviderId(rs.getLong(5));
                element.setBookmaker(rs.getString(6));
                element.setParticipant(rs.getString(7));
                element.setEventName(rs.getString(8));
                element.setLocation(rs.getString(9));
                element.setStartTime(rs.getTimestamp(10));
                element.setLastChangedTime(rs.getTimestamp(11));
                //System.out.println("Location:"+element.getLocation()+ ", Campionato:"+element.getCampionato());
                entityList.add(element);
            }

        } finally {
            if (rs !=null) {
                rs.close();
            }
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return eventMap;
    }

    public void truncateFractionTables() throws SQLException {
        Connection conn = null;
        CallableStatement cStmt=null;
        try {
            conn=dataSource.getConnection();
            cStmt=conn.prepareCall(truncateStoreProcedure);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }


    }
    public void insertFractions(List<EventBasketFractions> eventBasketFractionsList) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            //"INSERT INTO eventsBookmakersFractions (eventID,providerId,homeTeam,awayTeam,location,campionato,startTime,bookmaker,fa,fh,fd) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            conn = dataSource.getConnection();

            ps=conn.prepareStatement(insertBasketFractions);
            for(EventBasketFractions EventBasketFractions : eventBasketFractionsList) {
                //System.out.println("inseriti:"+count++);
                ps.setDouble(1, EventBasketFractions.getEventId());
                ps.setDouble(2, EventBasketFractions.getProviderId());
                ps.setString(3, EventBasketFractions.getHomeTeam());
                ps.setString(4, EventBasketFractions.getAwayTeam());
                ps.setString(5, EventBasketFractions.getLocation());
                ps.setString(6, EventBasketFractions.getCampionato());
                ps.setTimestamp(7, new Timestamp(EventBasketFractions.getStartTime().getTime()));
                ps.setString(8, EventBasketFractions.getBookmaker());
                ps.setDouble(9, EventBasketFractions.getFh());
                ps.setDouble(10, EventBasketFractions.getFa());
                ps.setInt(11, EventBasketFractions.getPh());
                ps.setInt(12, EventBasketFractions.getPa());
                ps.setInt(13, EventBasketFractions.getPbh());
                ps.setInt(14, EventBasketFractions.getPba());
                ps.setDouble(15, EventBasketFractions.getDelta());
                ps.setDouble(16, EventBasketFractions.getBettingOfferIdH());
                ps.setDouble(17, EventBasketFractions.getBettingOfferIdA());
                ps.setTimestamp(18,new Timestamp(EventBasketFractions.getLastChangedTime().getTime()));
                ps.executeUpdate();
            }
        } catch(Exception ex) {
            System.out.println(ex.getMessage());

        } finally {
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}
