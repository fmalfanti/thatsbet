package com.kellify.aggregate.util;

import java.util.Date;


public class EventFootballFractions {
    private long eventId;
    private long providerId;
    private String homeTeam;
    private String awayTeam;
    private String location;
    private String campionato;
    private String bookmaker;
    private Date startTime;
    private double fh;
    private double fd;
    private double fa;
    private int ph;
    private int pd;
    private int pa;
    private int pbh;
    private int pbd;
    private int pba;
    private double delta;
    private long bettingOfferIdH;
    private long bettingOfferIdD;
    private long bettingOfferIdA;
    private Date lastChangedTime;

    long getEventId() {
        return eventId;
    }

    void setEventId(long eventId) {
        this.eventId = eventId;
    }

    long getProviderId() {
        return providerId;
    }

    void setProviderId(long providerId) {
        this.providerId = providerId;
    }

    String getHomeTeam() {
        return homeTeam;
    }

    void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }

    String getAwayTeam() {
        return awayTeam;
    }

    void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }

    String getLocation() {
        return location;
    }

    void setLocation(String location) {
        this.location = location;
    }

    String getCampionato() {
        return campionato;
    }

    void setCampionato(String campionato) {
        this.campionato = campionato;
    }

    String getBookmaker() {
        return bookmaker;
    }

    void setBookmaker(String bookmaker) {
        this.bookmaker = bookmaker;
    }

    Date getStartTime() {
        return startTime;
    }

    void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    double getFa() {
        return fa;
    }

    void setFa(double fa) {
        this.fa = fa;
    }

    double getFh() {
        return fh;
    }

    void setFh(double fh) {
        this.fh = fh;
    }

    double getFd() {
        return fd;
    }

    void setFd(double fd) {
        this.fd = fd;
    }

    double getDelta() {
        return delta;
    }

    void setDelta(double delta) {
        this.delta = delta;
    }

    public long getBettingOfferIdH() {
        return bettingOfferIdH;
    }

    public void setBettingOfferIdH(long bettingOfferIdH) {
        this.bettingOfferIdH = bettingOfferIdH;
    }

    public long getBettingOfferIdD() {
        return bettingOfferIdD;
    }

    public void setBettingOfferIdD(long bettingOfferIdD) {
        this.bettingOfferIdD = bettingOfferIdD;
    }

    public long getBettingOfferIdA() {
        return bettingOfferIdA;
    }

    public void setBettingOfferIdA(long bettingOfferIdA) {
        this.bettingOfferIdA = bettingOfferIdA;
    }

    public Date getLastChangedTime() {
        return lastChangedTime;
    }

    public void setLastChangedTime(Date lastChangedTime) {
        this.lastChangedTime = lastChangedTime;
    }

    public int getPh() {
        return ph;
    }

    public void setPh(int ph) {
        this.ph = ph;
    }

    public int getPd() {
        return pd;
    }

    public void setPd(int pd) {
        this.pd = pd;
    }

    public int getPa() {
        return pa;
    }

    public void setPa(int pa) {
        this.pa = pa;
    }

    public int getPbh() {
        return pbh;
    }

    public void setPbh(int pbh) {
        this.pbh = pbh;
    }

    public int getPbd() {
        return pbd;
    }

    public void setPbd(int pbd) {
        this.pbd = pbd;
    }

    public int getPba() {
        return pba;
    }

    public void setPba(int pba) {
        this.pba = pba;
    }

    @Override
    public String toString() {
        return "EventFootballFractions{" +
                "eventId=" + eventId +
                ", providerId=" + providerId +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", location='" + location + '\'' +
                ", campionato='" + campionato + '\'' +
                ", bookmaker='" + bookmaker + '\'' +
                ", startTime=" + startTime +
                ", fh=" + fh +
                ", fd=" + fd +
                ", fa=" + fa +
                ", ph=" + ph +
                ", pd=" + pd +
                ", pa=" + pa +
                ", pbh=" + pbh +
                ", pbd=" + pbd +
                ", pba=" + pba +
                ", delta=" + delta +
                ", bettingOfferIdH=" + bettingOfferIdH +
                ", bettingOfferIdD=" + bettingOfferIdD +
                ", bettingOfferIdA=" + bettingOfferIdA +
                ", lastChangedTime=" + lastChangedTime +
                '}';
    }
}
