package com.kellify.aggregate.util;

public class EventBasketProbability {
    private final long eventId;
    private final double home;
    private final double away;

    public EventBasketProbability(long eventId, double home, double away) {
        this.eventId = eventId;
        this.home = home;
        this.away = away;
    }

    public long getEventId() {
        return eventId;
    }

    double getHome() {
        return home;
    }

    double getAway() {
        return away;
    }

    @Override
    public String toString() {
        return "EventFootballProbability{" +
                "eventId=" + eventId +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
