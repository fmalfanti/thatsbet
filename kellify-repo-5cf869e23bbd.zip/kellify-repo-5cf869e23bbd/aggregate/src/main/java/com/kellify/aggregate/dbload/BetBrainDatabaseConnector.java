package com.kellify.aggregate.dbload;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;


public class BetBrainDatabaseConnector implements BetBrainDBConnector {
    private final String FILE_CONFIG_PATH;
    private HikariDataSource dataSource;

    private BetBrainDatabaseConnector(String fileConfigPath) {
        this.FILE_CONFIG_PATH = fileConfigPath;
        init();
    }

    private void init() {
        HikariConfig cfg = new HikariConfig(FILE_CONFIG_PATH);
        dataSource = new HikariDataSource(cfg);
    }

    public HikariDataSource getDataSource() {
        return dataSource;
    }

    public void closeDataSource() {
        if(dataSource != null) {
            dataSource.close();
        }
    }

    public static class BetBrainDatabaseConnectorFactory {
        private BetBrainDatabaseConnectorFactory() {}
        public static BetBrainDBConnector getInstance(String fileConfigPath) {
            return new BetBrainDatabaseConnector(fileConfigPath);
        }
    }
}
