package com.kellify.aggregate.util;


public class EventFootballProbability {
    private final long eventId;
    private final double home;
    private final double away;
    private final double draw;

    public EventFootballProbability(long eventId, double home, double away, double draw) {
        this.eventId = eventId;
        this.home = home;
        this.away = away;
        this.draw = draw;
    }

    public long getEventId() {
        return eventId;
    }

    double getHome() {
        return home;
    }

    double getAway() {
        return away;
    }

    double getDraw() {
        return draw;
    }

    @Override
    public String toString() {
        return "EventFootballProbability{" +
                "eventId=" + eventId +
                ", home=" + home +
                ", away=" + away +
                ", draw=" + draw +
                '}';
    }
}
