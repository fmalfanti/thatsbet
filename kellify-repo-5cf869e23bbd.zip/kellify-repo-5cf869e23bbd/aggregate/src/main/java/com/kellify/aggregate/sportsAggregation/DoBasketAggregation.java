package com.kellify.aggregate.sportsAggregation;

import com.kellify.aggregate.util.*;
import com.kellify.aggregate.dbload.BetBrainDBConnector;

import com.kellify.common.util.Matrici;
import org.slf4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DoBasketAggregation {

    static public void meanAggregate(BetBrainDBConnector connector, BetBrainDBConnector historyconn, Logger logger) throws SQLException {
        LoadBasketOdds loadBasketOdds = LoadBasketOdds.getInstance(connector.getDataSource());
        Connection conn = null;
        PreparedStatement psAll = null;
        PreparedStatement psMatrici;
        int[] countsDb;
        int[] countsMatrix;
        int[] countsKnn;
        String mappa;
        EventBasketProbability eventProbability;
        Map<Long, EventBasketProbability> probabilityMap = new HashMap<>();
        Map<Integer,Matrici.HAMatrix> MappaHA = new HashMap<>();
        try {

            System.out.println("Aggrego Basket media");
            double hmin;
            double amin;
            double hmax;
            double amax;

            double a,h;
            double pa,ph,pb;

            double hh,aa,ct;

            Map<Long, List<OddsEntityBasket>> oddList = loadBasketOdds.loadEntities();
            //System.out.println("match count:" + oddList.size());
            conn = historyconn.getDataSource().getConnection();
            psAll=conn.prepareStatement(LoadBasketOdds.selectAllBasketProbabilities);
            psMatrici=conn.prepareStatement(LoadBasketOdds.selectBasketmatrici);
            ResultSet rs;
            rs = psMatrici.executeQuery();
            while (rs.next()) {
                mappa = rs.getString(2);
                Matrici.createHAMapsFromStrings(MappaHA,mappa);
            }
            rs.close();
            //System.out.println(MappaWL.entrySet());
            for (Map.Entry<Long, List<OddsEntityBasket>> mapEntry:oddList.entrySet()) {
                hmin = amin = 1000;
                hmax = amax = 0;
                a=h=0;

                aa=hh=0.0;

                for (OddsEntityBasket entity : mapEntry.getValue()) {
                    switch (entity.getRole()) {
                        case "Home":
                            h = entity.getOdds();
                            break;
                        case "Away":
                            a = entity.getOdds();
                            break;
                    }
                    if ((a>=1) && (h>=1)) {
                        pa=1.0/a;
                        ph=1.0/h;
                        pb=pa+ph;
                        pa/=pb;
                        ph/=pb;
                        amax=Math.max(amax,pa);
                        amin=Math.min(amin,pa);
                        hmax=Math.max(hmax,ph);
                        hmin=Math.min(hmin,ph);
                    }

                }
// fino qui uguale per tutti

                countsDb=evaluatedb(hmin,hmax,amin,amax,psAll);
                countsMatrix=evaluateMatrix(hmin,hmax,MappaHA);
                countsKnn=evaluateKnn(hmin,hmax,MappaHA);
                aa=countsKnn[1]+countsMatrix[1]+countsDb[1];

                hh=countsKnn[0]+countsMatrix[0]+countsDb[0];

                if ((aa + hh)>10) {
                    ct = aa + hh;
                    pa = aa / ct;
                    ph = hh / ct;

                    //System.out.println(mapEntry.getKey()+"H:"+hmin+"-"+hmax+" A:"+amin+"-"+amax + "---------------------> H:" + ph + " A:" + pa);

                    eventProbability = new EventBasketProbability(mapEntry.getKey(), ph, pa);
                    probabilityMap.put(mapEntry.getKey(), eventProbability);
                }


            }

            //System.out.println("probabilityMap:" + probabilityMap);
            BookmakerBasketMatcher bookmakerMatcher=BookmakerBasketMatcher.getInstance(probabilityMap,oddList);
            List<EventBasketFractions> eventFractionsList = bookmakerMatcher.matchBookmaker();
            loadBasketOdds = LoadBasketOdds.getInstance(historyconn.getDataSource());
            loadBasketOdds.truncateFractionTables();
            loadBasketOdds.insertFractions(eventFractionsList);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        } finally {
            if(connector != null) {
                connector.closeDataSource();
            }
            if (psAll!=null) {
                psAll.close();
            }

            if (conn!=null){
                conn.close();
            }
        }
    }

    static int[]  evaluateMatrix(double hmin,double hmax,Map<Integer,Matrici.HAMatrix> MappaHA)  {
        int[] counts={0, 0};
        //System.out.println(MappaWL.entrySet());

        for (int i=(int) (hmin * 100); i <= (hmax * 100); i++) {
            if (MappaHA.get(i) != null) {
                counts[0]+=MappaHA.get(i).getH();
                counts[1]+=MappaHA.get(i).getA();
            }
        }
        if ((counts[0]+counts[1])<10) {
            counts[0]=0;
            counts[1]=0;
        }
        //System.out.println("MATRIX:  "+"hmin="+hmin+" hmax="+hmax+" ------> count="+counts[0]+" "+counts[1]);
        return counts;
    }

    static int[]  evaluateKnn(double hmin,double hmax,Map<Integer,Matrici.HAMatrix> MappaHA)  {
        int[] counts={0, 0};
        int count=0,knn=10000;
        int mh=(int)(100*(hmax+hmin)/2.0);
        //System.out.println(MappaWL.entrySet());
        if (count < knn) {
            for (int ind=0; ind < 4; ind++) {
                counts[0]=0;
                counts[1]=0;
                for (int i=mh - ind; i <= mh + ind; i++) {
                    if (MappaHA.get(i) != null) {
                        counts[0]+=MappaHA.get(i).getH();
                        counts[1]+=MappaHA.get(i).getA();
                    }
                }
                count=counts[0] + counts[1];
                if (count >= knn) {
                    ind=5;
                }
            }
        }

        if ((counts[0]+counts[1])<knn) {
            counts[0]=0;
            counts[1]=0;
        }
        //System.out.println("KNN:  "+"hmin="+hmin+" hmax="+hmax+" ------> count="+counts[0]+" "+counts[1]);
        return counts;
    }

    static int[]  evaluatedb(double hmin,double hmax,double amin,double amax,PreparedStatement psAll) throws SQLException {
        int[] counts={0, 0};
        ResultSet rsw;
        ResultSet rsl;

        psAll.setDouble(1,amin);
        psAll.setDouble(2,amax);
        psAll.setDouble(3,hmin);
        psAll.setDouble(4,hmax);
        rsw=psAll.executeQuery();

        while (rsw.next()){
            counts[1]=rsw.getInt(1);
        }
        rsw.close();

        psAll.setDouble(1,amin);
        psAll.setDouble(2,amax);
        psAll.setDouble(3,hmin);
        psAll.setDouble(4,hmax);
        rsl=psAll.executeQuery();

        while (rsl.next()){
            counts[0]=rsl.getInt(1);
        }
        rsl.close();
        if ((counts[0]+counts[1])<10) {
            counts[0]=0;
            counts[1]=0;
        }
        //System.out.println("DB:  "+"hmin="+hmin+" hmax="+hmax+" ------> count="+counts[0]+" "+counts[1]);
        return counts;
    }
}
