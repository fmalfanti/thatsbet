package com.kellify.aggregate.sportsAggregation;

import com.kellify.aggregate.util.*;
import com.kellify.aggregate.dbload.BetBrainDBConnector;

import com.kellify.common.model.tennis.TennisDTO;
import com.kellify.common.util.DTOType;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.aggregation.Aggregation;
import com.kellify.fractionsmaker.aggregation.TennisAggregation;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.tennis.TennisProbabilitiesResult;
import org.slf4j.Logger;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.kellify.common.model.tennis.TennisBookmakerOdd;

public class DoTennisAggregation {

    static public void meanAggregate(BetBrainDBConnector connector, BetBrainDBConnector historyconn, DbUbibetterConnector ubibetterConnector, Logger logger) throws SQLException {
        LoadTennisOdds loadTennisOdds = LoadTennisOdds.getInstance(connector.getDataSource());
        Connection conn = null;

        final Map<String, List<TennisBookmakerOdd>> entities=null;
        EventTennisProbability eventProbability;
        Map<Long, EventTennisProbability> probabilityMap = new HashMap<>();
        Map<Integer,Matrici.WLMatrix> MappaWL ;
        TennisAggregation tennisAggregation = Aggregation.getTennisInstance(entities,ubibetterConnector);
        try {

            System.out.println("Aggrego Tennis media");
            double hmin;
            double amin;
            double hmax;
            double amax;
            double a,h;
            double pa,ph,pb;
            double ct;

            Map<Long, List<OddsEntityTennis>> oddList = loadTennisOdds.loadEntities();
            System.out.println("match count:" + oddList.size());
            conn = historyconn.getDataSource().getConnection();
            TennisProbabilitiesResult resultDb = null;
            TennisProbabilitiesResult resultKnn = null;
            TennisProbabilitiesResult resultMatrix = null;

            MappaWL=ubibetterConnector.createWLMapsFromStrings();

            System.out.println(MappaWL.entrySet());
            for (Map.Entry<Long, List<OddsEntityTennis>> mapEntry:oddList.entrySet()) {
                hmin = amin = 1000;
                hmax = amax = 0;
                a=h=0;

                for (OddsEntityTennis entity : mapEntry.getValue()) {
                    switch (entity.getRole()) {
                        case "Home":
                            h = entity.getOdds();
                            break;
                        case "Away":
                            a = entity.getOdds();
                            break;
                    }
                    if ((a>=1) && (h>=1)) {
                        pa=1.0/a;
                        ph=1.0/h;
                        pb=pa+ph;
                        pa/=pb;
                        ph/=pb;
                        amax=Math.max(amax,pa);
                        amin=Math.min(amin,pa);
                        hmax=Math.max(hmax,ph);
                        hmin=Math.min(hmin,ph);
                    }
                    a=h=0;
                }
                amax=((int)Math.ceil(amax*100.))/100.;
                amin=((int)Math.floor(amin*100.))/100.;
                hmax=((int)Math.ceil(hmax*100.))/100.;
                hmin=((int)Math.floor(hmin*100.))/100.;

                /* fino qui uguale per tutti */
                TennisDTO params = new TennisDTO(hmin, hmax, amin, amax, null, DTOType.PROBABILITY,null);

                resultDb = tennisAggregation.evaluateDb(params);
                resultKnn=tennisAggregation.evaluateKnn(params,MappaWL);
                resultMatrix=tennisAggregation.evaluateMatrix(params,MappaWL);
                logger.debug("resultDb:" + resultDb + ", resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix);
                double hhh=resultDb.getHome() +resultKnn.getHome()+resultMatrix.getHome();
                double aaa = resultDb.getAway() + resultKnn.getAway() + resultMatrix.getAway();

                ct = aaa+hhh;


                if (ct>100) {

                    pa = aaa / ct;
                    ph = hhh / ct;

                    //System.out.println(mapEntry.getKey()+"H:"+hmin+"-"+hmax+" A:"+amin+"-"+amax + "---------------------> H:" + ph + " A:" + pa);

                    eventProbability = new EventTennisProbability(mapEntry.getKey(), ph, pa);
                    probabilityMap.put(mapEntry.getKey(), eventProbability);
                }


            }

            System.out.println("probabilityMap:" + probabilityMap);
            BookmakerTennisMatcher bookmakerMatcher=BookmakerTennisMatcher.getInstance(probabilityMap,oddList);
            List<EventTennisFractions> eventFractionsList = bookmakerMatcher.matchBookmaker();
            System.out.println("eventFractionsList.size():" + eventFractionsList.size());
            loadTennisOdds = LoadTennisOdds.getInstance(historyconn.getDataSource());
            loadTennisOdds.truncateFractionTables();
            loadTennisOdds.insertFractions(eventFractionsList);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        } finally {
            if(connector != null) {
                connector.closeDataSource();
            }

            if (conn!=null){
                conn.close();
            }
        }
    }


}
