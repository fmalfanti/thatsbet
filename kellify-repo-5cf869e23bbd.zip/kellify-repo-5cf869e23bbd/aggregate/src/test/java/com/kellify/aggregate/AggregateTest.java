package com.kellify.aggregate;

import com.kellify.aggregate.dbload.BetBrainDatabaseConnector;
import com.kellify.aggregate.dbload.BetBrainDBConnector;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AggregateTest {
    private static BetBrainDBConnector historyconn;
    private static BetBrainDBConnector betbrainconn;

    private static String historyConfFile="/history.properties";
    private static String betbrainConfFile="/betbrain.properties";

    public static final String selectAllM = "SELECT MA,MD,MH FROM football_history_clusters WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ?";
    public static final String selectAllProbabilities = "SELECT FTR FROM football_history_clusters WHERE MA BETWEEN ? AND ? AND MD BETWEEN ? AND ? AND MH BETWEEN ? AND ?";


    @BeforeClass
    public static void initHistoryDbConnection() {
        historyconn = BetBrainDatabaseConnector.BetBrainDatabaseConnectorFactory.getInstance(historyConfFile);
    }

    @BeforeClass
    public static void initBetbrainDbConnection() {
        betbrainconn = BetBrainDatabaseConnector.BetBrainDatabaseConnectorFactory.getInstance(betbrainConfFile);
    }


    @Test
    public void testGetInterval() throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs;
        String ftr;
        double ch,cd,ca;
        double ma,md,mh;
        int count=0;
        double hmin=0.2;
        double amin=0.3;
        double dmin=0.4;
        double hmax=0.3;
        double amax=0.4;
        double dmax=0.5;
        conn = historyconn.getDataSource().getConnection();
        ps=conn.prepareStatement(selectAllProbabilities);
        ch=cd=ca=0.0;
        try {
            ps.setDouble(1,amin);
            ps.setDouble(2,amax);
            ps.setDouble(3,dmin);
            ps.setDouble(4,dmax);
            ps.setDouble(5,hmin);
            ps.setDouble(6,hmax);
            rs=ps.executeQuery();
            while (rs.next()){
                ftr=rs.getString(1);
                count++;
                switch (ftr) {
                    case "H":
                        ch+=1.0;
                        break;
                    case "D":
                        cd+=1.0;
                        break;
                    default:
                        ca+=1.0;
                        break;
                }
            }
            rs.close();
            System.out.println("P(H)="+Math.round(ch/count*1000)/1000.0+" P(D)="+Math.round(cd/count*1000)/1000.0+" P(A)="+Math.round(ca/count*1000)/1000.0);
        } finally {
            if (ps!=null) {
                ps.close();
            }
            if (conn!=null){
                conn.close();
            }
        }
        conn = historyconn.getDataSource().getConnection();
        ps=conn.prepareStatement(selectAllM);
        try {
            ps.setDouble(1,amin);
            ps.setDouble(2,amax);
            ps.setDouble(3,dmin);
            ps.setDouble(4,dmax);
            ps.setDouble(5,hmin);
            ps.setDouble(6,hmax);
            rs=ps.executeQuery();
            amin=dmin=hmin=1.0;
            amax=dmax=hmax=0.0;
            while (rs.next()){
                ma=rs.getDouble(1);
                md=rs.getDouble(2);
                mh=rs.getDouble(3);
                amin=Math.min(amin,ma);
                amax=Math.max(amax,ma);
                dmin=Math.min(dmin,md);
                dmax=Math.max(dmax,md);
                hmin=Math.min(hmin,mh);
                hmax=Math.max(hmax,mh);
            }
            rs.close();
            System.out.println("Hmin="+hmin+" Hmax="+hmax+" Dmin="+dmin+" Dmax="+dmax+" Amin="+amin+" Amax="+amax);
        } finally {
            if (ps!=null) {
                ps.close();
            }
            if (conn!=null){
                conn.close();
            }
        }

        Assert.assertEquals(1.0, Math.round(ch/count*1000)/1000.0+Math.round(cd/count*1000)/1000.0+Math.round(ca/count*1000)/1000.0,0.01);
    }


}
