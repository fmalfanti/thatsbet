package com.kellify.aggregate;
import com.kellify.aggregate.dbload.*;

import com.kellify.aggregate.sportsAggregation.*;
import com.kellify.placebet.db.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;


public class DoAggregation {
    private static final Logger logger = LoggerFactory.getLogger(DoAggregation.class.getName());

    private static BetBrainDBConnector historyconn;
    private static BetBrainDBConnector bookmakerconnector;
    private static BetBrainDBConnector connector;
    private static DbUbibetterConnector ubibetterConnector;

    public static void main(String[] args) throws IOException, SQLException {
        String dbConfFile;
        String historyConfFile;
        String bookmakerConfFile;
        String dbPlacebetConfFile;
        String CONF_FILE_PATH;

        if(args.length == 0) {
            logger.warn("Not <conf_file_path> provided, using default");
            CONF_FILE_PATH =DoAggregation.class.getResource("/aggregation.properties").getFile();
        } else {
            CONF_FILE_PATH = args[0];
            if(!new File(CONF_FILE_PATH).exists()) {
                logger.warn("Config file" + CONF_FILE_PATH + " does not exists or is not readable, using default");
                CONF_FILE_PATH = DoAggregation.class.getResource("/aggregation.properties").getFile();
            } else {
                logger.info("Config file" + CONF_FILE_PATH + " found");
            }

        }



        Properties props = new Properties();
        props.load(new FileInputStream(CONF_FILE_PATH));

        dbConfFile = props.getProperty("db.conf.file");
        System.out.println(dbConfFile);
        if(dbConfFile == null || !new File(dbConfFile).exists()) {
            logger.warn("No dbload config file found, using default");
            dbConfFile = "/db.properties";
        }
        historyConfFile = props.getProperty("history.conf.file");
        if(historyConfFile == null || !new File(historyConfFile).exists()) {
            logger.warn("No dbHistory config file found, using default");
            historyConfFile = "/history.properties";
        }
        bookmakerConfFile = props.getProperty("bookmaker.betting.conf.file");
        if(bookmakerConfFile == null || !new File(bookmakerConfFile).exists()) {
            logger.warn("No bookmaker config file found, using default");
            bookmakerConfFile =  DoAggregation.class.getResource("/bookmaker.properties").getFile();
        }

        dbPlacebetConfFile = props.getProperty("db.placebet.conf.file");
        if(dbPlacebetConfFile == null || !new File(dbPlacebetConfFile).exists()) {
            logger.warn("No placebet config file found, using default");
            dbPlacebetConfFile =  DoAggregation.class.getResource("/dbplacebet.properties").getFile();
        }

        connector = BetBrainDatabaseConnector.BetBrainDatabaseConnectorFactory.getInstance(dbConfFile);

        historyconn = BetBrainDatabaseConnector.BetBrainDatabaseConnectorFactory.getInstance(historyConfFile);
        bookmakerconnector = BetBrainDatabaseConnector.BetBrainDatabaseConnectorFactory.getInstance(bookmakerConfFile);
        logger.info("Connected");

        Properties placebetConfig = new Properties();
        placebetConfig.load(new FileInputStream(dbPlacebetConfFile));
        //ubibetterConnector = DbUbibetterConnector.getInstance(placebetConfig);

        System.out.println("------------------------------------------------");
        //DoFootballAggregation.meanAggregate(bookmakerconnector,historyconn,ubibetterConnector,logger);
        //DoTennisAggregation.meanAggregate(connector,historyconn,ubibetterConnector,logger);
        //DoBasketAggregation.meanAggregate(connector,historyconn,logger);

        logger.info("process ended");
    }



}
