package com.kellify.aggregate;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Outliers {
    public static void main(String[] args) {
        List<Double> data = new ArrayList<Double>();
        data.add((double) 65);
        data.add((double) 70);
        data.add((double) 70);
        data.add((double) 71);
        data.add((double) 72);
        data.add((double) 83);
        Collections.sort(data);
        System.out.println(data);
        writeMeanMedian(data);
        //System.out.println(getOutliers(data));
    }

    public static void writeMeanMedian(List<Double> input) {
        double mean,median;
        List<Double> data;
        for (int i=0;i<input.size();i++){
            mean=median=0.0;

            data= new ArrayList<Double>();
            for (int j=0;j<input.size();j++){
                if (j!=i){
                    mean+=input.get(j);
                    data.add(input.get(j));
                } else {
                    System.out.println("Escludo "+input.get(j));
                }
            }
            Collections.sort(data);
            median=(data.get(data.size()-1)+data.get(0))/2;
            mean/=(input.size()-1);
            System.out.println("Escludo "+input.get(i) + " --> media= "+mean+", median= "+median);
        }
    }


    public static List<Double> getOutliers(List<Double> input) {
        List<Double> output = new ArrayList<Double>();
        List<Double> data1 = new ArrayList<Double>();
        List<Double> data2 = new ArrayList<Double>();
        if (input.size() % 2 == 0) {
            data1 = input.subList(0, input.size() / 2);
            data2 = input.subList(input.size() / 2, input.size());
        } else {
            data1 = input.subList(0, input.size() / 2);
            data2 = input.subList(input.size() / 2 + 1, input.size());
        }
        double q1 = getMedian(data1);
        double q3 = getMedian(data2);
        double iqr = q3 - q1;
        double lowerFence = q1 - 1.5 * iqr;
        double upperFence = q3 + 1.5 * iqr;
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i) < lowerFence || input.get(i) > upperFence)
                output.add(input.get(i));
        }
        return output;
    }

    private static double getMedian(List<Double> data) {
        if (data.size() % 2 == 0)
            return (data.get(data.size() / 2) + data.get(data.size() / 2 - 1)) / 2;
        else
            return data.get(data.size() / 2);
    }

}