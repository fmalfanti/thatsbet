package com.kellify.bettingkings.controller;

import com.kellify.bettingkings.model.Fraction;
import com.kellify.bettingkings.service.FractionService;
import com.kellify.bettingkings.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class OperationController {
    private static final Logger logger = LoggerFactory.getLogger(OperationController.class);

    @Autowired
    private FractionService fractionService;

    @Value("${bk.oddlimit}")
    private double oddlimit;

    @Value("${ranking.threshold}")
    private double rankingThreshold;

    @RequestMapping(value="/home", method = {RequestMethod.GET})
    public ModelAndView home() {
        ModelAndView modelAndView = new ModelAndView();

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        logger.debug("home - user:" + auth.getName());

        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        List<Fraction> fractionList = fractionService.fractionList(oddlimit, rankingThreshold);
        logger.debug("home - fractionList:" + fractionList);

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.FRACTION_LIST, fractionList);

        modelAndView.setViewName("home");
        return modelAndView;
    }
}
