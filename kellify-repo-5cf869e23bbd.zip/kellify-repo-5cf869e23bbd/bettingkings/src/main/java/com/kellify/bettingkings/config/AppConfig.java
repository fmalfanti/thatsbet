package com.kellify.bettingkings.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.catalina.connector.Connector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@ComponentScan
@EnableTransactionManagement
@PropertySource(value = {"application.properties"})
public class AppConfig {
    @Autowired
    private Environment env;

    @Value("${init-dbload:false}")
    private String initDatabase;

    @Value("${ds.data-source-class-name}")
    private String dsClassName;
    @Value("${ds.bookmakerbetting.hostname}")
    private String dbBookmakerbettingHostName;
    @Value("${ds.bookmakerbetting.portnumber}")
    private String dbBookmakerbettingPortNumber;
    @Value("${ds.bookmakerbetting.database}")
    private String dbBookmakerbettingDatabase;
    @Value("${ds.bookmakerbetting.username}")
    private String dbBookmakerbettingUsername;
    @Value("${ds.bookmakerbetting.password}")
    private String dbBookmakerbettingPasswd;

    @Value("${ds.bettingkings.hostname}")
    private String dbBettingkingsUserHostName;
    @Value("${ds.bettingkings.portnumber}")
    private String dbBettingkingsUserPortNumber;
    @Value("${ds.bettingkings.database}")
    private String dbBettingkingsUserDatabase;
    @Value("${ds.bettingkings.username}")
    private String dbBettingkingsUserUsername;
    @Value("${ds.bettingkings.password}")
    private String dbBettingkingsUserPasswd;

    @Value("${ds.maximum-pool-size}")
    private int dsMaxPoolSize;
    @Value("${ds.connection-timeout}")
    private long dsConnectionTimeout;
    @Value("${ds.connection-test-query}")
    private String dsTestQuery;
    @Value("${ds.minimum-idle}")
    private int dsMinIdle;
    @Value("${tomcat.ajp.port}")
    private int ajpPort;
    @Value("${tomcat.ajp.remoteauthentication}")
    private String remoteAuthentication;
    @Value("${tomcat.ajp.enabled}")
    private boolean tomcatAjpEnabled;

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer()
    {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean(name="jdbcTemplateBettingkings")
    public JdbcTemplate jdbcTemplateBettingKings(@Qualifier("bettingkingsDataSource") DataSource bettingkingsDataSource)
    {
        return new JdbcTemplate(bettingkingsDataSource);
    }
    @Bean(name="jdbcTemplateBookmakerbetting")
    public JdbcTemplate jdbcTemplateBookamkerBetting(@Qualifier("bookmakerbettingDataSource") DataSource bookmakerbettingDataSource)
    {
        return new JdbcTemplate(bookmakerbettingDataSource);
    }

    @Bean(name="bettingkingsDataSource")
    @Primary
    public DataSource bettingkingsDataSource() {
        HikariConfig config = new HikariConfig();
        config.setDataSourceClassName(dsClassName);
        config.addDataSourceProperty("serverName", dbBettingkingsUserHostName);
        config.addDataSourceProperty("portNumber", dbBettingkingsUserPortNumber);
        config.addDataSourceProperty("databaseName", dbBettingkingsUserDatabase);
        config.setUsername(dbBettingkingsUserUsername);
        config.setPassword(dbBettingkingsUserPasswd);

        config.setConnectionTimeout(dsConnectionTimeout);
        config.setMaximumPoolSize(dsMaxPoolSize);
        config.setMinimumIdle(dsMinIdle);
        config.setIdleTimeout(2 * 60 * 1000);
        config.setConnectionTestQuery(dsTestQuery);
        HikariDataSource ds = new HikariDataSource(config);
        return ds;
    }

    @Bean(name="bookmakerbettingDataSource")
    public DataSource bookmakerBettingDataSource() {
        HikariConfig config = new HikariConfig();
        config.setDataSourceClassName(dsClassName);
        config.addDataSourceProperty("serverName", dbBookmakerbettingHostName);
        config.addDataSourceProperty("portNumber", dbBookmakerbettingPortNumber);
        config.addDataSourceProperty("databaseName", dbBookmakerbettingDatabase);
        config.setUsername(dbBookmakerbettingUsername);
        config.setPassword(dbBookmakerbettingPasswd);

        config.setConnectionTimeout(dsConnectionTimeout);
        config.setMaximumPoolSize(dsMaxPoolSize);
        config.setMinimumIdle(dsMinIdle);
        config.setIdleTimeout(2 * 60 * 1000);
        config.setConnectionTestQuery(dsTestQuery);
        HikariDataSource ds = new HikariDataSource(config);
        return ds;
    }
    @Bean
    public EmbeddedServletContainerFactory servletContainer() {

        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();
        if (tomcatAjpEnabled)
        {
            Connector ajpConnector = new Connector("AJP/1.3");
            ajpConnector.setPort(ajpPort);
            ajpConnector.setSecure(false);
            ajpConnector.setAllowTrace(false);
            ajpConnector.setScheme("http");
            tomcat.addAdditionalTomcatConnectors(ajpConnector);
        }

        return tomcat;
    }
}
