package com.kellify.bettingkings.util;

public class Constants {
    private Constants() {}

    public static final String USER_REQUEST = "userName";
    public static final String FRACTION_LIST = "fractionList";
}
