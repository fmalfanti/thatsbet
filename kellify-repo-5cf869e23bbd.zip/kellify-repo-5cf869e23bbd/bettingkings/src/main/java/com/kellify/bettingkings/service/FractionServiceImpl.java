package com.kellify.bettingkings.service;

import com.kellify.bettingkings.model.Fraction;
import com.kellify.bettingkings.repository.BettingKingsRepository;
import com.kellify.bettingkings.repository.BookmakerBettingRespository;
import com.kellify.common.SportTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("eventsService")
public class FractionServiceImpl implements FractionService {
    private static final Logger logger = LoggerFactory.getLogger(FractionServiceImpl.class);


    @Autowired
    private BettingKingsRepository bettingKingsRepository;

    @Autowired
    private BookmakerBettingRespository bookmakerBettingRespository;

    @Override
    public List<Fraction> fractionList(double oddLimit, double rankingThreshold) {
        Map<Integer, String> platformMap = bookmakerBettingRespository.getPlatformMap();
        Map<Integer, String> bookmakerMap = bookmakerBettingRespository.getBookmakerMap();
        Map<Integer, Map<Integer, String>> championshipDecodeMap = bookmakerBettingRespository.getChampionshipDecodeMap();
        logger.debug("championshipDecodeMap:" + championshipDecodeMap);
        List<Fraction> fractions = bettingKingsRepository.fractionList(oddLimit);
        String label;
        for(Fraction fraction : fractions) {
            label = platformMap.get(fraction.getPlatformId());
            if(label != null) {
                fraction.setPlatformName(label);
            }
            label = bookmakerMap.get(fraction.getBookmakerId());
            if(label != null) {
                fraction.setBookmakerName(label);
            }
            if(fraction.getFraction() > rankingThreshold) {
                fraction.setRankingThreshold(Fraction.topRanking);
            }
            if(fraction.getSport() != SportTypes.TENNIS) {
                fraction.setChampionship(championshipDecodeMap.get(fraction.getSport().getNumVal()).get(Integer.parseInt(fraction.getChampionship())));
            }
        }
        return fractions;
    }
}
