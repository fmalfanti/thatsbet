package com.kellify.bettingkings.model;

import com.kellify.common.OddRole;
import com.kellify.common.SportTypes;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.Date;

public class Fraction {
    public static final String topRanking = "10%";
    public static final String bottomRanking = "5%";
    public static final int roundPlaces = 2;

    private final String homeTeam;
    private final String awayTeam;
    private String championship;
    private final String country;
    private final String continent;
    private final Date matchDate;
    private final int platformId;
    private String platformName;
    private final int bookmakerId;
    private String bookmakerName;
    private final OddRole role;
    private final double odd;
    private final double fraction;
    private final int prob;
    private final SportTypes sport;
    private String rankingThreshold = bottomRanking;

    private Fraction(FractionBuilder builder) {
        homeTeam = builder.homeTeam;
        awayTeam = builder.awayTeam;
        championship = builder.championship;
        country = builder.country;
        continent = builder.continent;
        matchDate = builder.matchDate;
        platformId = builder.platformId;
        bookmakerId = builder.bookmakerId;
        role = builder.role;
        odd = builder.odd;
        fraction = builder.fraction;
        prob = builder.prob;
        sport = builder.sport;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public String getChampionship() {
        return championship;
    }

    public String getCountry() {
        return country;
    }

    public String getContinent() {
        return continent;
    }

    public Date getMatchDate() {
        return matchDate;
    }

    public int getPlatformId() {
        return platformId;
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    public int getBookmakerId() {
        return bookmakerId;
    }

    public String getBookmakerName() {
        return bookmakerName;
    }

    public void setBookmakerName(String bookmakerName) {
        this.bookmakerName = bookmakerName;
    }

    public OddRole getRole() {
        return role;
    }

    public double getOdd() {
        return odd;
    }

    public double getFraction() {
        return fraction;
    }

    public int getProb() {
        return prob;
    }

    public String getRankingThreshold() {
        return rankingThreshold;
    }

    public void setRankingThreshold(String rankingThreshold) {
        this.rankingThreshold = rankingThreshold;
    }

    public SportTypes getSport() {
        return sport;
    }

    public void setChampionship(String championship) {
        this.championship = championship;
    }

    public double oddRounded() {
        BigDecimal bd = new BigDecimal(Double.toString(odd));
        bd = bd.setScale(roundPlaces, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    @Override
    public String toString() {
        return "Fraction{" +
                "homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", championship='" + championship + '\'' +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", matchDate=" + matchDate +
                ", platformId=" + platformId +
                ", platformName='" + platformName + '\'' +
                ", bookmakerId=" + bookmakerId +
                ", bookmakerName='" + bookmakerName + '\'' +
                ", role=" + role +
                ", odd=" + odd +
                ", fraction=" + fraction +
                ", prob=" + prob +
                ", sport=" + sport +
                ", rankingThreshold='" + rankingThreshold + '\'' +
                '}';
    }

    public static class FractionBuilder {
        private String homeTeam = "";
        private String awayTeam = "";
        private String championship;
        private String country;
        private String continent;
        private Date matchDate;
        private int platformId = 0;
        private int bookmakerId = 0;
        private OddRole role = OddRole.HOME;
        private double odd = 0.0;
        private double fraction = 0.0;
        private int prob = 0;
        private SportTypes sport;

        public FractionBuilder sHomeTeam(String homeTeam) {
            this.homeTeam = homeTeam;
            return this;
        }

        public FractionBuilder sAwayTeam(String awayTeam) {
            this.awayTeam = awayTeam;
            return this;
        }

        public FractionBuilder sChampionship(String championship) {
            this.championship = championship;
            return this;
        }

        public FractionBuilder sCountry(String country) {
            this.country = country;
            return this;
        }

        public FractionBuilder sContinent(String continent) {
            this.continent = continent;
            return this;
        }

        public FractionBuilder sMatchDate(Date matchDate) {
            this.matchDate = matchDate;
            return this;
        }

        public FractionBuilder sPlatformId(int platformId) {
            this.platformId = platformId;
            return this;
        }

        public FractionBuilder sBookmakerId(int bookmakerId) {
            this.bookmakerId = bookmakerId;
            return this;
        }

        public FractionBuilder sRole(OddRole role) {
            this.role = role;
            return this;
        }

        public FractionBuilder sOdd(double odd) {
            this.odd = odd;
            return this;
        }

        public FractionBuilder sFraction(double fraction) {
            this.fraction = fraction;
            return this;
        }

        public FractionBuilder sProb(int prob) {
            this.prob = prob;
            return this;
        }

        public FractionBuilder sSport(SportTypes sport) {
            this.sport = sport;
            return this;
        }

        public Fraction build() {
            return new Fraction(this);
        }
    }
}
