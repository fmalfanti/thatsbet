package com.kellify.bettingkings.service;


import com.kellify.bettingkings.model.User;

public interface UserService {
    public User findUserByUsername(String username);

}