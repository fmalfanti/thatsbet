package com.kellify.bettingkings.service;

import com.kellify.bettingkings.model.Fraction;

import java.util.List;

public interface FractionService {
    List<Fraction> fractionList(double oddLimit, double rankingThreshold);
}
