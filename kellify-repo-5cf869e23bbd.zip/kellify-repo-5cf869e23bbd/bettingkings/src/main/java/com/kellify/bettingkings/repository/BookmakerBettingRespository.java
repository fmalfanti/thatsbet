package com.kellify.bettingkings.repository;

import com.kellify.common.SportTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Repository
public class BookmakerBettingRespository {
    private static final Logger logger = LoggerFactory.getLogger(BookmakerBettingRespository.class);

    @Autowired
    @Qualifier("jdbcTemplateBookmakerbetting")
    private JdbcTemplate jdbcTemplateBookmakerBetting;

    private static final String PLATFORMS = "select id, descr from platforms";
    private static final String BOOKMAKERS = "select bookmaker_id,label from bookmaker_platform";

    private static final String FOOTBALL_CHAMPIONSHIP_DECODE = "select id,championship from football_championship_decode_pilot";
    private static final String BASKET_CHAMPIONSHIP_DECODE = "select id,championship from basket_championship_decode_pilot";
    private static final String BASEBALL_CHAMPIONSHIP_DECODE = "select id,championship from baseball_championship_decode_pilot";
    private static final String ICEHOCKEY_CHAMPIONSHIP_DECODE = "select id,championship from icehockey_championship_decode_pilot";

    public Map<Integer, String> getPlatformMap() {
        Map<Integer, String> platformMap = jdbcTemplateBookmakerBetting.query(PLATFORMS, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> platformMap = new HashMap<>();
                while(rs.next()) {
                    platformMap.putIfAbsent(rs.getInt("id"), rs.getString("descr"));
                }
                return platformMap;
            }
        });
        return platformMap;
    }

    public Map<Integer, String> getBookmakerMap() {
        Map<Integer, String> bMap = jdbcTemplateBookmakerBetting.query(BOOKMAKERS, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> bookmakerMap = new HashMap<>();
                while(rs.next()) {
                    bookmakerMap.putIfAbsent(rs.getInt("bookmaker_id"), rs.getString("label"));
                }
                return bookmakerMap;
            }
        });
        return bMap;
    }

    public Map<Integer, Map<Integer, String>> getChampionshipDecodeMap() {
        Map<Integer, String> footballMap = jdbcTemplateBookmakerBetting.query(FOOTBALL_CHAMPIONSHIP_DECODE, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> map = new HashMap<>();
                while(rs.next()) {
                    map.putIfAbsent(rs.getInt("id"), rs.getString("championship"));
                }
                return map;
            }
        });

        Map<Integer, String> basketMap = jdbcTemplateBookmakerBetting.query(BASKET_CHAMPIONSHIP_DECODE, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> map = new HashMap<>();
                while(rs.next()) {
                    map.putIfAbsent(rs.getInt("id"), rs.getString("championship"));
                }
                return map;
            }
        });

        Map<Integer, String> baseballMap = jdbcTemplateBookmakerBetting.query(BASEBALL_CHAMPIONSHIP_DECODE, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> map = new HashMap<>();
                while(rs.next()) {
                    map.putIfAbsent(rs.getInt("id"), rs.getString("championship"));
                }
                return map;
            }
        });

        Map<Integer, String> icehockeyMap = jdbcTemplateBookmakerBetting.query(ICEHOCKEY_CHAMPIONSHIP_DECODE, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> map = new HashMap<>();
                while(rs.next()) {
                    map.putIfAbsent(rs.getInt("id"), rs.getString("championship"));
                }
                return map;
            }
        });
        Map<Integer, Map<Integer, String>> championshipDecodeMap = new HashMap<>();
        championshipDecodeMap.put(SportTypes.FOOTBALL.getNumVal(), footballMap);
        championshipDecodeMap.put(SportTypes.BASKET.getNumVal(), basketMap);
        championshipDecodeMap.put(SportTypes.BASEBALL.getNumVal(), baseballMap);
        championshipDecodeMap.put(SportTypes.ICE_HOCKEY.getNumVal(), icehockeyMap);

        return championshipDecodeMap;
    }
}
