package com.kellify.bettingkings.repository;

import com.kellify.bettingkings.model.Fraction;
import com.kellify.common.OddRole;
import com.kellify.common.SportTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class BettingKingsRepository {
    private static final Logger logger = LoggerFactory.getLogger(BettingKingsRepository.class);

    @Autowired
    @Qualifier("jdbcTemplateBettingkings")
    private JdbcTemplate jdbcTemplateBettingkings;

    private static final String SELECT_FRACTION_DATA = "{call select_fraction()}";

    private static final String FRACTION_LIST = "select home_team,away_team,country,championship,continent,match_date,platform_id,bookmaker_id,role,odd,fraction,prob,sport from output_live order by prob desc,fraction desc";

    private static final String GET_PARAM_CONFIG = "select value from config where name=?";

    public String paramConfig(String name) {
        return jdbcTemplateBettingkings.queryForObject(GET_PARAM_CONFIG, new Object[] {name}, String.class);
    }

    public List<Fraction> fractionList(double oddLimit) {
        jdbcTemplateBettingkings.update(SELECT_FRACTION_DATA);
        return jdbcTemplateBettingkings.query(FRACTION_LIST, new FractionMapper());
    }

    private class FractionMapper implements RowMapper<Fraction> {

        @Override
        public Fraction mapRow(ResultSet rs, int rowNum) throws SQLException {
            Fraction.FractionBuilder builder = new Fraction.FractionBuilder();
            String homeTeam = rs.getString("home_team");
            String awayTeam = rs.getString("away_team");
            if(homeTeam == null) {
                homeTeam = "";
            }
            if(awayTeam == null) {
                awayTeam = "";
            }
            return builder
                    .sHomeTeam(homeTeam)
                    .sAwayTeam(awayTeam)
                    .sChampionship(rs.getString("championship"))
                    .sCountry(rs.getString("country"))
                    .sContinent(rs.getString("continent"))
                    .sMatchDate(rs.getTimestamp("match_date"))
                    .sPlatformId(rs.getInt("platform_id"))
                    .sBookmakerId(rs.getInt("bookmaker_id"))
                    .sRole(OddRole.getEnum(rs.getInt("role")))
                    .sOdd(rs.getDouble("odd"))
                    .sFraction(rs.getDouble("fraction"))
                    .sProb(rs.getInt("prob"))
                    .sSport(SportTypes.getEnum(rs.getInt("sport")))
                    .build();
        }
    }
}
