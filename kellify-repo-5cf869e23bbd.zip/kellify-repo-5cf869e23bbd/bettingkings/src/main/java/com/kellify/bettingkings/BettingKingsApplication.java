package com.kellify.bettingkings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BettingKingsApplication {
    public static void main(String[] args) {
        SpringApplication.run(BettingKingsApplication.class, args);
    }
}
