create view allsports_bkbookmakers_fraction as
select
  `ft`.`referrer_id`  AS `referrer_id`,
  `ft`.`home_team`    AS `home_team`,
  `ft`.`away_team`    AS `away_team`,
  `ft`.`country`      AS `country`,
  `ft`.`championship` AS `championship`,
  `ft`.`continent`    AS `continent`,
  `ft`.`match_date`   AS `match_date`,
  `ft`.`platform_id`  AS `platform_id`,
  `ft`.`bookmaker_id` AS `bookmaker_id`,
  `ft`.`fh`           AS `fh`,
  `ft`.`fa`           AS `fa`,
  `ft`.`fd`           AS `fd`,
  `ft`.`ph`           AS `ph`,
  `ft`.`pa`           AS `pa`,
  `ft`.`pd`           AS `pd`,
  `ft`.`pbh`          AS `pbh`,
  `ft`.`pba`          AS `pba`,
  `ft`.`pbd`          AS `pbd`,
  `ft`.`role`         AS `role`,
  `ft`.`odd`          AS `odd`,
  `ft`.`sport`        AS `sport`
from (((select
          `a`.`referrer_id`  AS `referrer_id`,
          `a`.`home_team`    AS `home_team`,
          `a`.`away_team`    AS `away_team`,
          `a`.`country`      AS `country`,
          `a`.`championship` AS `championship`,
          `a`.`continent`    AS `continent`,
          `a`.`match_date`   AS `match_date`,
          `a`.`platform_id`  AS `platform_id`,
          `a`.`bookmaker_id` AS `bookmaker_id`,
          `a`.`fh`           AS `fh`,
          `a`.`fa`           AS `fa`,
          `a`.`fd`           AS `fd`,
          `a`.`ph`           AS `ph`,
          `a`.`pa`           AS `pa`,
          `a`.`pd`           AS `pd`,
          `a`.`pbh`          AS `pbh`,
          `a`.`pba`          AS `pba`,
          `a`.`pbd`          AS `pbd`,
          `b`.`role`         AS `role`,
          `b`.`odd`          AS `odd`,
          case
          when role = 1 then fh
          when role = 2 then fa
          when role = 0 then fd
          end as fraction,
          case
          when role = 1  then ph
          when role = 2  then pa
          when role = 0  then pd
          end as prob,
          1                  AS `sport`
        from (`betting_kings`.`football_fraction` `a` left join `betting_kings`.`football_odds_snapshot` `b`
            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
        where `a`.`bookmaker_id` = `b`.`bookmaker_id` order by prob desc,fraction desc limit 4)
       union all (select
                    `a`.`referrer_id`  AS `referrer_id`,
                    `a`.`home_team`    AS `home_team`,
                    `a`.`away_team`    AS `away_team`,
                    `a`.`country`      AS `country`,
                    `a`.`championship` AS `championship`,
                    `a`.`continent`    AS `continent`,
                    `a`.`match_date`   AS `match_date`,
                    `a`.`platform_id`  AS `platform_id`,
                    `a`.`bookmaker_id` AS `bookmaker_id`,
                    `a`.`fh`           AS `fh`,
                    `a`.`fa`           AS `fa`,
                    -(1000)            AS `fd`,
                    `a`.`ph`           AS `ph`,
                    `a`.`pa`           AS `pa`,
                    -(1000)            AS `pd`,
                    `a`.`pbh`          AS `pbh`,
                    `a`.`pba`          AS `pba`,
                    -(1000)            AS `pbd`,
                    `b`.`role`         AS `role`,
                    `b`.`odd`          AS `odd`,
                    case
                    when role = 1 then fh
                    when role = 2 then fa
                    end as fraction,
                    case
                    when role = 1  then ph
                    when role = 2  then pa
                    end as prob,
                    3                  AS `sport`
                  from (`betting_kings`.`basket_fraction` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                      on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                  where `a`.`bookmaker_id` = `b`.`bookmaker_id` order by prob desc,fraction desc limit 4)
       union all (select
                    `a`.`referrer_id`  AS `referrer_id`,
                    `a`.`home_team`    AS `home_team`,
                    `a`.`away_team`    AS `away_team`,
                    `a`.`country`      AS `country`,
                    `a`.`championship` AS `championship`,
                    `a`.`continent`    AS `continent`,
                    `a`.`match_date`   AS `match_date`,
                    `a`.`platform_id`  AS `platform_id`,
                    `a`.`bookmaker_id` AS `bookmaker_id`,
                    `a`.`fh`           AS `fh`,
                    `a`.`fa`           AS `fa`,
                    -(1000)            AS `fd`,
                    `a`.`ph`           AS `ph`,
                    `a`.`pa`           AS `pa`,
                    -(1000)            AS `pd`,
                    `a`.`pbh`          AS `pbh`,
                    `a`.`pba`          AS `pba`,
                    -(1000)            AS `pbd`,
                    `b`.`role`         AS `role`,
                    `b`.`odd`          AS `odd`,
                    case
                    when role = 1 then fh
                    when role = 2 then fa
                    end as fraction,
                    case
                    when role = 1  then ph
                    when role = 2  then pa
                    end as prob,
                    5                  AS `sport`
                  from (`betting_kings`.`baseball_fraction` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                      on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                  where `a`.`bookmaker_id` = `b`.`bookmaker_id` order by prob desc,fraction desc limit 4)
       union all (select
                    `a`.`referrer_id`  AS `referrer_id`,
                    `a`.`home_team`    AS `home_team`,
                    `a`.`away_team`    AS `away_team`,
                    `a`.`country`      AS `country`,
                    `a`.`championship` AS `championship`,
                    `a`.`continent`    AS `continent`,
                    `a`.`match_date`   AS `match_date`,
                    `a`.`platform_id`  AS `platform_id`,
                    `a`.`bookmaker_id` AS `bookmaker_id`,
                    `a`.`fh`           AS `fh`,
                    `a`.`fa`           AS `fa`,
                    -(1000)            AS `fd`,
                    `a`.`ph`           AS `ph`,
                    `a`.`pa`           AS `pa`,
                    -(1000)            AS `pd`,
                    `a`.`pbh`          AS `pbh`,
                    `a`.`pba`          AS `pba`,
                    -(1000)            AS `pbd`,
                    `b`.`role`         AS `role`,
                    `b`.`odd`          AS `odd`,
                    case
                    when role = 1 then fh
                    when role = 2 then fa
                    end as fraction,
                    case
                    when role = 1  then ph
                    when role = 2  then pa
                    end as prob,
                    4                  AS `sport`
                  from
                    (`betting_kings`.`icehockeyHA_fraction` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                        on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                  where `a`.`bookmaker_id` = `b`.`bookmaker_id` order by prob desc,fraction desc limit 4)
       union all (select
                    `a`.`referrer_id`  AS `referrer_id`,
                    `a`.`home_team`    AS `home_team`,
                    `a`.`away_team`    AS `away_team`,
                    `a`.`country`      AS `country`,
                    `a`.`championship` AS `championship`,
                    NULL               AS `continent`,
                    `a`.`match_date`   AS `match_date`,
                    `a`.`platform_id`  AS `platform_id`,
                    `a`.`bookmaker_id` AS `bookmaker_id`,
                    `a`.`fh`           AS `fh`,
                    `a`.`fa`           AS `fa`,
                    -(1000)            AS `fd`,
                    `a`.`ph`           AS `ph`,
                    `a`.`pa`           AS `pa`,
                    -(1000)            AS `pd`,
                    `a`.`pbh`          AS `pbh`,
                    `a`.`pba`          AS `pba`,
                    -(1000)            AS `pbd`,
                    `b`.`role`         AS `role`,
                    `b`.`odd`          AS `odd`,
                    case
                    when role = 1 then fh
                    when role = 2 then fa
                    end as fraction,
                    case
                    when role = 1  then ph
                    when role = 2  then pa
                    end as prob,
                    2                  AS `sport`
                  from (`betting_kings`.`tennis_fraction` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                      on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                  where `a`.`bookmaker_id` = `b`.`bookmaker_id` order by prob desc,fraction desc limit 4)) `ft`
  join `betting_kings`.`bookmaker_bettingkings` `bb` on ((`ft`.`bookmaker_id` = `bb`.`id_bookmaker`)));





/* VECCHIA VERSIONE */
/*
create view allsports_bkbookmakers_fraction as
select
    `ft`.`referrer_id`  AS `referrer_id`,
    `ft`.`home_team`    AS `home_team`,
    `ft`.`away_team`    AS `away_team`,
    `ft`.`country`      AS `country`,
    `ft`.`championship` AS `championship`,
    `ft`.`continent`    AS `continent`,
    `ft`.`match_date`   AS `match_date`,
    `ft`.`platform_id`  AS `platform_id`,
    `ft`.`bookmaker_id` AS `bookmaker_id`,
    `ft`.`fh`           AS `fh`,
    `ft`.`fa`           AS `fa`,
    `ft`.`fd`           AS `fd`,
    `ft`.`ph`           AS `ph`,
    `ft`.`pa`           AS `pa`,
    `ft`.`pd`           AS `pd`,
    `ft`.`pbh`          AS `pbh`,
    `ft`.`pba`          AS `pba`,
    `ft`.`pbd`          AS `pbd`,
    `ft`.`role`         AS `role`,
    `ft`.`odd`          AS `odd`,
    `ft`.`sport`        AS `sport`
  from (((select
            `a`.`referrer_id`  AS `referrer_id`,
            `a`.`home_team`    AS `home_team`,
            `a`.`away_team`    AS `away_team`,
            `a`.`country`      AS `country`,
            `a`.`championship` AS `championship`,
            `a`.`continent`    AS `continent`,
            `a`.`match_date`   AS `match_date`,
            `a`.`platform_id`  AS `platform_id`,
            `a`.`bookmaker_id` AS `bookmaker_id`,
            `a`.`fh`           AS `fh`,
            `a`.`fa`           AS `fa`,
            `a`.`fd`           AS `fd`,
            `a`.`ph`           AS `ph`,
            `a`.`pa`           AS `pa`,
            `a`.`pd`           AS `pd`,
            `a`.`pbh`          AS `pbh`,
            `a`.`pba`          AS `pba`,
            `a`.`pbd`          AS `pbd`,
            `b`.`role`         AS `role`,
            `b`.`odd`          AS `odd`,
            1                  AS `sport`
          from (`betting_kings`.`football_fraction` `a` left join `betting_kings`.`football_odds_snapshot` `b`
              on ((`a`.`referrer_id` = `b`.`referrer_id`)))
          where (`a`.`bookmaker_id` = `b`.`bookmaker_id`))
         union all select
                     `a`.`referrer_id`  AS `referrer_id`,
                     `a`.`home_team`    AS `home_team`,
                     `a`.`away_team`    AS `away_team`,
                     `a`.`country`      AS `country`,
                     `a`.`championship` AS `championship`,
                     `a`.`continent`    AS `continent`,
                     `a`.`match_date`   AS `match_date`,
                     `a`.`platform_id`  AS `platform_id`,
                     `a`.`bookmaker_id` AS `bookmaker_id`,
                     `a`.`fh`           AS `fh`,
                     `a`.`fa`           AS `fa`,
                     -(1000)            AS `fd`,
                     `a`.`ph`           AS `ph`,
                     `a`.`pa`           AS `pa`,
                     -(1000)            AS `pd`,
                     `a`.`pbh`          AS `pbh`,
                     `a`.`pba`          AS `pba`,
                     -(1000)            AS `pbd`,
                     `b`.`role`         AS `role`,
                     `b`.`odd`          AS `odd`,
                     3                  AS `sport`
                   from (`betting_kings`.`basket_fraction` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                       on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                   where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)
         union all select
                     `a`.`referrer_id`  AS `referrer_id`,
                     `a`.`home_team`    AS `home_team`,
                     `a`.`away_team`    AS `away_team`,
                     `a`.`country`      AS `country`,
                     `a`.`championship` AS `championship`,
                     `a`.`continent`    AS `continent`,
                     `a`.`match_date`   AS `match_date`,
                     `a`.`platform_id`  AS `platform_id`,
                     `a`.`bookmaker_id` AS `bookmaker_id`,
                     `a`.`fh`           AS `fh`,
                     `a`.`fa`           AS `fa`,
                     -(1000)            AS `fd`,
                     `a`.`ph`           AS `ph`,
                     `a`.`pa`           AS `pa`,
                     -(1000)            AS `pd`,
                     `a`.`pbh`          AS `pbh`,
                     `a`.`pba`          AS `pba`,
                     -(1000)            AS `pbd`,
                     `b`.`role`         AS `role`,
                     `b`.`odd`          AS `odd`,
                     5                  AS `sport`
                   from (`betting_kings`.`baseball_fraction` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                       on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                   where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)
         union all select
                     `a`.`referrer_id`  AS `referrer_id`,
                     `a`.`home_team`    AS `home_team`,
                     `a`.`away_team`    AS `away_team`,
                     `a`.`country`      AS `country`,
                     `a`.`championship` AS `championship`,
                     `a`.`continent`    AS `continent`,
                     `a`.`match_date`   AS `match_date`,
                     `a`.`platform_id`  AS `platform_id`,
                     `a`.`bookmaker_id` AS `bookmaker_id`,
                     `a`.`fh`           AS `fh`,
                     `a`.`fa`           AS `fa`,
                     -(1000)            AS `fd`,
                     `a`.`ph`           AS `ph`,
                     `a`.`pa`           AS `pa`,
                     -(1000)            AS `pd`,
                     `a`.`pbh`          AS `pbh`,
                     `a`.`pba`          AS `pba`,
                     -(1000)            AS `pbd`,
                     `b`.`role`         AS `role`,
                     `b`.`odd`          AS `odd`,
                     4                  AS `sport`
                   from
                     (`betting_kings`.`icehockeyHA_fraction` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                         on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                   where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)
         union all select
                     `a`.`referrer_id`  AS `referrer_id`,
                     `a`.`home_team`    AS `home_team`,
                     `a`.`away_team`    AS `away_team`,
                     `a`.`country`      AS `country`,
                     `a`.`championship` AS `championship`,
                     NULL               AS `continent`,
                     `a`.`match_date`   AS `match_date`,
                     `a`.`platform_id`  AS `platform_id`,
                     `a`.`bookmaker_id` AS `bookmaker_id`,
                     `a`.`fh`           AS `fh`,
                     `a`.`fa`           AS `fa`,
                     -(1000)            AS `fd`,
                     `a`.`ph`           AS `ph`,
                     `a`.`pa`           AS `pa`,
                     -(1000)            AS `pd`,
                     `a`.`pbh`          AS `pbh`,
                     `a`.`pba`          AS `pba`,
                     -(1000)            AS `pbd`,
                     `b`.`role`         AS `role`,
                     `b`.`odd`          AS `odd`,
                     2                  AS `sport`
                   from (`betting_kings`.`tennis_fraction` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                       on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                   where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) `ft`
    join `betting_kings`.`bookmaker_bettingkings` `bb` on ((`ft`.`bookmaker_id` = `bb`.`id_bookmaker`)));
*/

/* NON USATE !!!!*/
/*
create view allsports_allbookmakers_fraction as
select
  `ft`.`referrer_id`  AS `referrer_id`,
  `ft`.`home_team`    AS `home_team`,
  `ft`.`away_team`    AS `away_team`,
  `ft`.`country`      AS `country`,
  `ft`.`championship` AS `championship`,
  `ft`.`continent`    AS `continent`,
  `ft`.`match_date`   AS `match_date`,
  `ft`.`platform_id`  AS `platform_id`,
  `ft`.`bookmaker_id` AS `bookmaker_id`,
  `ft`.`fh`           AS `fh`,
  `ft`.`fa`           AS `fa`,
  `ft`.`fd`           AS `fd`,
  `ft`.`ph`           AS `ph`,
  `ft`.`pa`           AS `pa`,
  `ft`.`pd`           AS `pd`,
  `ft`.`pbh`          AS `pbh`,
  `ft`.`pba`          AS `pba`,
  `ft`.`pbd`          AS `pbd`,
  `ft`.`role`         AS `role`,
  `ft`.`odd`          AS `odd`
from (((select
          `a`.`referrer_id`  AS `referrer_id`,
          `a`.`home_team`    AS `home_team`,
          `a`.`away_team`    AS `away_team`,
          `a`.`country`      AS `country`,
          `a`.`championship` AS `championship`,
          `a`.`continent`    AS `continent`,
          `a`.`match_date`   AS `match_date`,
          `a`.`platform_id`  AS `platform_id`,
          `a`.`bookmaker_id` AS `bookmaker_id`,
          `a`.`fh`           AS `fh`,
          `a`.`fa`           AS `fa`,
          `a`.`fd`           AS `fd`,
          `a`.`ph`           AS `ph`,
          `a`.`pa`           AS `pa`,
          `a`.`pd`           AS `pd`,
          `a`.`pbh`          AS `pbh`,
          `a`.`pba`          AS `pba`,
          `a`.`pbd`          AS `pbd`,
          `b`.`role`         AS `role`,
          `b`.`odd`          AS `odd`
        from (`betting_kings`.`football_fraction` `a` left join `betting_kings`.`football_odds_snapshot` `b`
            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
        where (`a`.`bookmaker_id` = `b`.`bookmaker_id`) and (a.bookmaker_id not in (select id_bookmaker from bookmaker_bettingkings)))
       union all select
                   `a`.`referrer_id`  AS `referrer_id`,
                   `a`.`home_team`    AS `home_team`,
                   `a`.`away_team`    AS `away_team`,
                   `a`.`country`      AS `country`,
                   `a`.`championship` AS `championship`,
                   `a`.`continent`    AS `continent`,
                   `a`.`match_date`   AS `match_date`,
                   `a`.`platform_id`  AS `platform_id`,
                   `a`.`bookmaker_id` AS `bookmaker_id`,
                   `a`.`fh`           AS `fh`,
                   `a`.`fa`           AS `fa`,
                   -(1000)            AS `fd`,
                   `a`.`ph`           AS `ph`,
                   `a`.`pa`           AS `pa`,
                   -(1000)            AS `pd`,
                   `a`.`pbh`          AS `pbh`,
                   `a`.`pba`          AS `pba`,
                   -(1000)            AS `pbd`,
                   `b`.`role`         AS `role`,
                   `b`.`odd`          AS `odd`
                 from (`betting_kings`.`basket_fraction` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                     on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                 where (`a`.`bookmaker_id` = `b`.`bookmaker_id`) and (a.bookmaker_id not in (select id_bookmaker from bookmaker_bettingkings))
       union all select
                   `a`.`referrer_id`  AS `referrer_id`,
                   `a`.`home_team`    AS `home_team`,
                   `a`.`away_team`    AS `away_team`,
                   `a`.`country`      AS `country`,
                   `a`.`championship` AS `championship`,
                   `a`.`continent`    AS `continent`,
                   `a`.`match_date`   AS `match_date`,
                   `a`.`platform_id`  AS `platform_id`,
                   `a`.`bookmaker_id` AS `bookmaker_id`,
                   `a`.`fh`           AS `fh`,
                   `a`.`fa`           AS `fa`,
                   -(1000)            AS `fd`,
                   `a`.`ph`           AS `ph`,
                   `a`.`pa`           AS `pa`,
                   -(1000)            AS `pd`,
                   `a`.`pbh`          AS `pbh`,
                   `a`.`pba`          AS `pba`,
                   -(1000)            AS `pbd`,
                   `b`.`role`         AS `role`,
                   `b`.`odd`          AS `odd`
                 from (`betting_kings`.`baseball_fraction` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                     on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                 where (`a`.`bookmaker_id` = `b`.`bookmaker_id`) and (a.bookmaker_id not in (select id_bookmaker from bookmaker_bettingkings))
       union all select
                   `a`.`referrer_id`  AS `referrer_id`,
                   `a`.`home_team`    AS `home_team`,
                   `a`.`away_team`    AS `away_team`,
                   `a`.`country`      AS `country`,
                   `a`.`championship` AS `championship`,
                   `a`.`continent`    AS `continent`,
                   `a`.`match_date`   AS `match_date`,
                   `a`.`platform_id`  AS `platform_id`,
                   `a`.`bookmaker_id` AS `bookmaker_id`,
                   `a`.`fh`           AS `fh`,
                   `a`.`fa`           AS `fa`,
                   -(1000)            AS `fd`,
                   `a`.`ph`           AS `ph`,
                   `a`.`pa`           AS `pa`,
                   -(1000)            AS `pd`,
                   `a`.`pbh`          AS `pbh`,
                   `a`.`pba`          AS `pba`,
                   -(1000)            AS `pbd`,
                   `b`.`role`         AS `role`,
                   `b`.`odd`          AS `odd`
                 from (`betting_kings`.`icehockeyHA_fraction` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                     on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                 where (`a`.`bookmaker_id` = `b`.`bookmaker_id`) and (a.bookmaker_id not in (select id_bookmaker from bookmaker_bettingkings))
       union all select
                   `a`.`referrer_id`  AS `referrer_id`,
                   `a`.`home_team`    AS `home_team`,
                   `a`.`away_team`    AS `away_team`,
                   `a`.`country`      AS `country`,
                   `a`.`championship` AS `championship`,
                   NULL               AS `continent`,
                   `a`.`match_date`   AS `match_date`,
                   `a`.`platform_id`  AS `platform_id`,
                   `a`.`bookmaker_id` AS `bookmaker_id`,
                   `a`.`fh`           AS `fh`,
                   `a`.`fa`           AS `fa`,
                   -(1000)            AS `fd`,
                   `a`.`ph`           AS `ph`,
                   `a`.`pa`           AS `pa`,
                   -(1000)            AS `pd`,
                   `a`.`pbh`          AS `pbh`,
                   `a`.`pba`          AS `pba`,
                   -(1000)            AS `pbd`,
                   `b`.`role`         AS `role`,
                   `b`.`odd`          AS `odd`
                 from (`betting_kings`.`tennis_fraction` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                     on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                 where (`a`.`bookmaker_id` = `b`.`bookmaker_id`) and (a.bookmaker_id not in (select id_bookmaker from bookmaker_bettingkings))) `ft`);


create view allsports_allbookmakers_avg as
select
    `tt`.`referrer_id` AS `referrer_id`,
    `tt`.`home_team`   AS `home_team`,
    `tt`.`away_team`   AS `away_team`,
    avg(`tt`.`prob`)   AS `avgprob`
  from (select
          `t`.`referrer_id`  AS `referrer_id`,
          `t`.`home_team`    AS `home_team`,
          `t`.`away_team`    AS `away_team`,
          `t`.`country`      AS `country`,
          `t`.`championship` AS `championship`,
          `t`.`continent`    AS `continent`,
          `t`.`match_date`   AS `match_date`,
          `t`.`platform_id`  AS `platform_id`,
          `t`.`bookmaker_id` AS `bookmaker_id`,
          `t`.`fh`           AS `fh`,
          `t`.`fa`           AS `fa`,
          `t`.`fd`           AS `fd`,
          `t`.`ph`           AS `ph`,
          `t`.`pa`           AS `pa`,
          `t`.`pd`           AS `pd`,
          `t`.`pbh`          AS `pbh`,
          `t`.`pba`          AS `pba`,
          `t`.`pbd`          AS `pbd`,
          `t`.`role`         AS `role`,
          `t`.`odd`          AS `odd`,
          `t`.`fraction`     AS `fraction`,
          `t`.`prob`         AS `prob`,
          `t`.`prob_book`    AS `prob_book`
        from (select
                `allsports_allbookmakers_fraction`.`referrer_id`      AS `referrer_id`,
                `allsports_allbookmakers_fraction`.`home_team`        AS `home_team`,
                `allsports_allbookmakers_fraction`.`away_team`        AS `away_team`,
                `allsports_allbookmakers_fraction`.`country`          AS `country`,
                `allsports_allbookmakers_fraction`.`championship`     AS `championship`,
                `allsports_allbookmakers_fraction`.`continent`        AS `continent`,
                `allsports_allbookmakers_fraction`.`match_date`       AS `match_date`,
                `allsports_allbookmakers_fraction`.`platform_id`      AS `platform_id`,
                `allsports_allbookmakers_fraction`.`bookmaker_id`     AS `bookmaker_id`,
                `allsports_allbookmakers_fraction`.`fh`               AS `fh`,
                `allsports_allbookmakers_fraction`.`fa`               AS `fa`,
                `allsports_allbookmakers_fraction`.`fd`               AS `fd`,
                `allsports_allbookmakers_fraction`.`ph`               AS `ph`,
                `allsports_allbookmakers_fraction`.`pa`               AS `pa`,
                `allsports_allbookmakers_fraction`.`pd`               AS `pd`,
                `allsports_allbookmakers_fraction`.`pbh`              AS `pbh`,
                `allsports_allbookmakers_fraction`.`pba`              AS `pba`,
                `allsports_allbookmakers_fraction`.`pbd`              AS `pbd`,
                `allsports_allbookmakers_fraction`.`role`             AS `role`,
                `allsports_allbookmakers_fraction`.`odd`              AS `odd`,
                (case when (`allsports_allbookmakers_fraction`.`role` = 1)
                  then `allsports_allbookmakers_fraction`.`fh`
                 when (`allsports_allbookmakers_fraction`.`role` = 2)
                   then `allsports_allbookmakers_fraction`.`fa`
                 when (`allsports_allbookmakers_fraction`.`role` = 0)
                   then `allsports_allbookmakers_fraction`.`fd` end)  AS `fraction`,
                (case when (`allsports_allbookmakers_fraction`.`role` = 1)
                  then `allsports_allbookmakers_fraction`.`ph`
                 when (`allsports_allbookmakers_fraction`.`role` = 2)
                   then `allsports_allbookmakers_fraction`.`pa`
                 when (`allsports_allbookmakers_fraction`.`role` = 0)
                   then `allsports_allbookmakers_fraction`.`pd` end)  AS `prob`,
                (case when (`allsports_allbookmakers_fraction`.`role` = 1)
                  then `allsports_allbookmakers_fraction`.`pbh`
                 when (`allsports_allbookmakers_fraction`.`role` = 2)
                   then `allsports_allbookmakers_fraction`.`pba`
                 when (`allsports_allbookmakers_fraction`.`role` = 0)
                   then `allsports_allbookmakers_fraction`.`pbd` end) AS `prob_book`
              from `betting_kings`.`allsports_allbookmakers_fraction`) `t`
        where (`t`.`fraction` > 0)) `tt`
  group by `tt`.`referrer_id`, `tt`.`home_team`, `tt`.`away_team`, `tt`.`role`;
  */

