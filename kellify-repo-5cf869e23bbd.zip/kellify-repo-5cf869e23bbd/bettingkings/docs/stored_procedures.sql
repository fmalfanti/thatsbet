create procedure truncate_football_fraction_tables()
  begin
    truncate table football_fraction;
  end;

create procedure truncate_basket_fraction_tables()
  begin
    truncate table basket_fraction;
  end;

create procedure truncate_tennis_fraction_tables()
  begin
    truncate table tennis_fraction;
  end;

create procedure truncate_baseball_fraction_tables()
  begin
  truncate table baseball_fraction;
  end;

create procedure truncate_icehockeyHA_fraction_tables()
  begin
    truncate table icehockeyHA_fraction;
  end;

create procedure check_and_launch_backup_fraction_tables ()
  begin
    declare _exists  tinyint(1) default 0;
    declare backup_routine varchar(50);

    set backup_routine = "backup_fraction_tables";

    select count(*) into _exists from information_schema.routines
    where routine_schema = database() and routine_name = backup_routine;
    if _exists = 1 then
      call backup_fraction_tables;
    end if;
  end;

  create procedure backup_fraction_tables()
  begin
    insert into output_archive (backup_date, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport)
      select now(),home_team,away_team,country,championship,continent,match_date,platform_id,bookmaker_id,fh,fa,fd,ph,pa,pd,pbh,pba,pbd,role,odd,fraction,prob,sport
      from output_live;

    truncate table output_live;
  end;


CREATE PROCEDURE select_fraction()
  begin

    DECLARE done INT DEFAULT FALSE;
    declare _referrer_id varchar(50) default '';
    declare _home_team varchar(100) default '';
    declare _away_team varchar(100) default '';
    declare _country varchar(100) default '';
    declare _championship varchar(100) default '';
    declare _continent varchar(100) default '';
    declare _match_date datetime;
    declare _platform_id int;
    declare _bookmaker_id int;
    declare _fa double;
    declare _fh double;
    declare _fd double;
    declare _pa int;
    declare _ph int;
    declare _pd int;
    declare _pba int;
    declare _pbh int;
    declare _pbd int;
    declare _role int;
    declare _odd double;
    declare _fraction double;
    declare _prob int;
    declare _sport int;

    declare _current_odd  double default 0;
    declare _current_prob int default 0;
    declare _oddLimit double default 1.5;
    declare _exists  smallint default 0;
    declare _threshold_inf int default 55;
    declare _threshold_sup int default 75;
    declare _isEmpty TINYINT DEFAULT 1;
    declare _count_by_threshold int default 0;
    declare _count_insert int default 0;

    DECLARE curTennis_over CURSOR FOR
      select * from (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        NULL                  AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        2                     AS `sport`
                      from (`betting_kings`.`tennis_fraction_bk_bookmakers` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t where `fraction`>0 and `prob`>= _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    DECLARE curTennis_under CURSOR FOR
      select * from (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        NULL                  AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        2                     AS `sport`
                      from (`betting_kings`.`tennis_fraction_bk_bookmakers` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t where `fraction`>0 and `prob`> _threshold_inf and `prob` < _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    declare curBaseball_over cursor for
      select * from (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        5                     AS `sport`
                      from (`betting_kings`.`baseball_fraction_bk_bookmakers` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t where `fraction`>0 and `prob`>= _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    declare curBaseball_under cursor for
      select * FROM (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        5                     AS `sport`
                      from `betting_kings`.`baseball_fraction_bk_bookmakers` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                          on `a`.`referrer_id` = `b`.`referrer_id`
                      where `a`.`bookmaker_id` = `b`.`bookmaker_id`) as t where `fraction`>0 and `prob`> _threshold_inf and `prob` < _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;


    declare curIceHockeyHA_over cursor for
      select * from (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        4                     AS `sport`
                      from (`betting_kings`.`icehockeyHA_fraction_bk_bookmakers` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t where `fraction`>0 and `prob`>= _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    declare curIceHockeyHA_under cursor for
      select * FROM (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        4                     AS `sport`
                      from `betting_kings`.`icehockeyHA_fraction_bk_bookmakers` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                          on `a`.`referrer_id` = `b`.`referrer_id`
                      where `a`.`bookmaker_id` = `b`.`bookmaker_id`) as t where `fraction`>0 and `prob`> _threshold_inf and `prob` < _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    declare curBasket_over cursor for
      select * from (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        3                     AS `sport`
                      from (`betting_kings`.`basket_fraction_bk_bookmakers` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where `a`.`bookmaker_id` = `b`.`bookmaker_id`) as t where `fraction`>0 and `prob`>= _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;
    declare curBasket_under cursor for
      select * FROM (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        -(1000)               AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        -(1000)               AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        -(1000)               AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa` end) AS `prob`,
                        3                     AS `sport`
                      from `betting_kings`.`basket_fraction_bk_bookmakers` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                          on `a`.`referrer_id` = `b`.`referrer_id`
                      where `a`.`bookmaker_id` = `b`.`bookmaker_id`) as t where `fraction`>0 and `prob`> _threshold_inf and `prob` < _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    declare curFootball_over cursor for
      select * from (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        `a`.`fd`              AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        `a`.`pd`              AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        `a`.`pbd`             AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa`
                         when (`b`.`role` = 0)
                           then `a`.`fd` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa`
                         when (`b`.`role` = 0)
                           then `a`.`pd` end) AS `prob`,
                        1                     AS `sport`
                      from (`betting_kings`.`football_fraction_bk_bookmakers` `a` left join `betting_kings`.`football_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where `a`.`bookmaker_id` = `b`.`bookmaker_id`) as t where `fraction`>0 and `prob`>= _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;

    declare curFootball_under cursor for
      select * FROM (
                      select
                        `a`.`referrer_id`     AS `referrer_id`,
                        `a`.`home_team`       AS `home_team`,
                        `a`.`away_team`       AS `away_team`,
                        `a`.`country`         AS `country`,
                        `a`.`championship`    AS `championship`,
                        `a`.`continent`       AS `continent`,
                        `a`.`match_date`      AS `match_date`,
                        `a`.`platform_id`     AS `platform_id`,
                        `a`.`bookmaker_id`    AS `bookmaker_id`,
                        `a`.`fh`              AS `fh`,
                        `a`.`fa`              AS `fa`,
                        `a`.`fd`              AS `fd`,
                        `a`.`ph`              AS `ph`,
                        `a`.`pa`              AS `pa`,
                        `a`.`pd`              AS `pd`,
                        `a`.`pbh`             AS `pbh`,
                        `a`.`pba`             AS `pba`,
                        `a`.`pbd`             AS `pbd`,
                        `b`.`role`            AS `role`,
                        `b`.`odd`             AS `odd`,
                        (case when (`b`.`role` = 1)
                          then `a`.`fh`
                         when (`b`.`role` = 2)
                           then `a`.`fa`
                         when (`b`.`role` = 0)
                           then `a`.`fd` end) AS `fraction`,
                        (case when (`b`.`role` = 1)
                          then `a`.`ph`
                         when (`b`.`role` = 2)
                           then `a`.`pa`
                         when (`b`.`role` = 0)
                           then `a`.`pd` end) AS `prob`,
                        1                     AS `sport`
                      from (`betting_kings`.`football_fraction_bk_bookmakers` `a` left join `betting_kings`.`football_odds_snapshot` `b`
                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                      where `a`.`bookmaker_id` = `b`.`bookmaker_id`) as t where `fraction`>0 and `prob`> _threshold_inf and `prob` < _threshold_sup
      order by `prob` desc, `fraction` desc, referrer_id;


    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    SELECT count(*) into _isEmpty FROM output_live;
    if _isEmpty=0 THEN
      /*select CAST(value as DECIMAL(4,2)) into _oddLimit from config where name='oddLimit';*/

      select count(*) into _count_by_threshold FROM (
                                                      select
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`fh`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`fa` end) AS `fraction`,
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`ph`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`pa` end) AS `prob`
                                                      from (`betting_kings`.`tennis_fraction_bk_bookmakers` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                                                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>=_threshold_sup;

      if _count_by_threshold > 0 THEN
        OPEN curTennis_over;
        read_loop: LOOP
          FETCH curTennis_over INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
          select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
          if _exists = 1 then
            select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
            if _current_prob = _prob and _current_odd < _odd then
              update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
            end if;
          else
            if _count_insert < 4 then
              insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
              set _count_insert = _count_insert + 1;
            else
              LEAVE read_loop;
            end if;
          end if;
          IF done THEN
            LEAVE read_loop;
          END IF;
        end loop;
        close curTennis_over;
      ELSE
        select count(*) into _count_by_threshold FROM (
                                                        select
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`fh`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`fa` end) AS `fraction`,
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`ph`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`pa` end) AS `prob`
                                                        from (`betting_kings`.`tennis_fraction_bk_bookmakers` `a` left join `betting_kings`.`tennis_odds_snapshot` `b`
                                                            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                        where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>_threshold_inf and prob < _threshold_sup;

        if _count_by_threshold > 0 THEN

          OPEN curTennis_under;
          read_loop: LOOP
            FETCH curTennis_under INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
            select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
            if _exists = 1 then
              select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
              if _current_prob = _prob and _current_odd < _odd then
                update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
              end if;
            else
              if _count_insert = 0 then
                insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
                set _count_insert = _count_insert + 1;
              else
                LEAVE read_loop;
              end if;
            end if;
            IF done THEN
              LEAVE read_loop;
            END IF;
          end loop;
          close curTennis_under;
        end if;
      END IF;

      set _count_insert = 0;
      set done = false;

      select count(*) into _count_by_threshold FROM (
                                                      select
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`fh`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`fa` end) AS `fraction`,
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`ph`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`pa` end) AS `prob`
                                                      from (`betting_kings`.`baseball_fraction_bk_bookmakers` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                                                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>=_threshold_sup;

      if _count_by_threshold > 0 THEN
        OPEN curBaseball_over;
        read_loop: LOOP
          FETCH curBaseball_over INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
          select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
          if _exists = 1 then
            select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
            if _current_prob = _prob and _current_odd < _odd then
              update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
            end if;
          else
            if _count_insert < 4 then
              insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
              set _count_insert = _count_insert + 1;
            else
              LEAVE read_loop;
            end if;
          end if;
          IF done THEN
            LEAVE read_loop;
          END IF;
        end loop;
        close curBaseball_over;
      ELSE
        select count(*) into _count_by_threshold FROM (
                                                        select
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`fh`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`fa` end) AS `fraction`,
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`ph`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`pa` end) AS `prob`
                                                        from (`betting_kings`.`baseball_fraction_bk_bookmakers` `a` left join `betting_kings`.`baseball_odds_snapshot` `b`
                                                            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                        where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>_threshold_inf and prob < _threshold_sup;

        if _count_by_threshold > 0 THEN

          OPEN curBaseball_under;
          read_loop: LOOP
            FETCH curBaseball_under INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
            select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
            if _exists = 1 then
              select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
              if _current_prob = _prob and _current_odd < _odd then
                update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
              end if;
            else
              if _count_insert = 0 then
                insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
                set _count_insert = _count_insert + 1;
              else
                LEAVE read_loop;
              end if;
            end if;
            IF done THEN
              LEAVE read_loop;
            END IF;
          end loop;
          close curBaseball_under;
        end if;
      END IF;

      set _count_insert = 0;
      set done = false;

      select count(*) into _count_by_threshold FROM (
                                                      select
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`fh`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`fa` end) AS `fraction`,
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`ph`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`pa` end) AS `prob`
                                                      from (`betting_kings`.`icehockeyHA_fraction_bk_bookmakers` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                                                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>=_threshold_sup;

      if _count_by_threshold > 0 THEN
        OPEN curIceHockeyHA_over;
        read_loop: LOOP
          FETCH curIceHockeyHA_over INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
          select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
          if _exists = 1 then
            select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
            if _current_prob = _prob and _current_odd < _odd then
              update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
            end if;
          else
            if _count_insert < 4 then
              insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
              set _count_insert = _count_insert + 1;
            else
              LEAVE read_loop;
            end if;
          end if;
          IF done THEN
            LEAVE read_loop;
          END IF;
        end loop;
        close curIceHockeyHA_over;
      ELSE
        select count(*) into _count_by_threshold FROM (
                                                        select
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`fh`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`fa` end) AS `fraction`,
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`ph`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`pa` end) AS `prob`
                                                        from (`betting_kings`.`icehockeyHA_fraction_bk_bookmakers` `a` left join `betting_kings`.`icehockey_odds_snapshot` `b`
                                                            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                        where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>_threshold_inf and prob < _threshold_sup;

        if _count_by_threshold > 0 THEN

          OPEN curIceHockeyHA_under;
          read_loop: LOOP
            FETCH curIceHockeyHA_under INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
            select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
            if _exists = 1 then
              select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
              if _current_prob = _prob and _current_odd < _odd then
                update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
              end if;
            else
              if _count_insert = 0 then
                insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
                set _count_insert = _count_insert + 1;
              else
                LEAVE read_loop;
              end if;
            end if;
            IF done THEN
              LEAVE read_loop;
            END IF;
          end loop;
          close curIceHockeyHA_under;
        end if;
      END IF;

      set _count_insert = 0;
      set done = false;

      select count(*) into _count_by_threshold FROM (
                                                      select
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`fh`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`fa` end) AS `fraction`,
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`ph`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`pa` end) AS `prob`
                                                      from (`betting_kings`.`basket_fraction_bk_bookmakers` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                                                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>=_threshold_sup;

      if _count_by_threshold > 0 THEN
        OPEN curBasket_over;
        read_loop: LOOP
          FETCH curBasket_over INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
          select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
          if _exists = 1 then
            select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
            if _current_prob = _prob and _current_odd < _odd then
              update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
            end if;
          else
            if _count_insert < 4 then
              insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
              set _count_insert = _count_insert + 1;
            else
              LEAVE read_loop;
            end if;
          end if;
          IF done THEN
            LEAVE read_loop;
          END IF;
        end loop;
        close curBasket_over;
      ELSE
        select count(*) into _count_by_threshold FROM (
                                                        select
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`fh`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`fa` end) AS `fraction`,
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`ph`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`pa` end) AS `prob`
                                                        from (`betting_kings`.`basket_fraction_bk_bookmakers` `a` left join `betting_kings`.`basket_odds_snapshot` `b`
                                                            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                        where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>_threshold_inf and prob < _threshold_sup;

        if _count_by_threshold > 0 THEN

          OPEN curBasket_under;
          read_loop: LOOP
            FETCH curBasket_under INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
            select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
            if _exists = 1 then
              select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
              if _current_prob = _prob and _current_odd < _odd then
                update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
              end if;
            else
              if _count_insert = 0 then
                insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
                set _count_insert = _count_insert + 1;
              else
                LEAVE read_loop;
              end if;
            end if;
            IF done THEN
              LEAVE read_loop;
            END IF;
          end loop;
          close curBasket_under;
        end if;
      END IF;

      set _count_insert = 0;
      set done = false;

      select count(*) into _count_by_threshold FROM (
                                                      select
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`fh`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`fa`
                                                         when (`b`.`role` = 0)
                                                           then `a`.`fd` end) AS `fraction`,
                                                        (case when (`b`.`role` = 1)
                                                          then `a`.`ph`
                                                         when (`b`.`role` = 2)
                                                           then `a`.`pa`
                                                         when (`b`.`role` = 0)
                                                           then `a`.`pd` end) AS `prob`
                                                      from (`betting_kings`.`football_fraction_bk_bookmakers` `a` left join `betting_kings`.`football_odds_snapshot` `b`
                                                          on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                      where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>=_threshold_sup;

      if _count_by_threshold > 0 THEN
        OPEN curFootball_over;
        read_loop: LOOP
          FETCH curFootball_over INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
          select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
          if _exists = 1 then
            select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
            if _current_prob = _prob and _current_odd < _odd then
              update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
            end if;
          else
            if _count_insert < 4 then
              insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
              set _count_insert = _count_insert + 1;
            else
              LEAVE read_loop;
            end if;
          end if;
          IF done THEN
            LEAVE read_loop;
          END IF;
        end loop;
        close curFootball_over;
      ELSE
        select count(*) into _count_by_threshold FROM (
                                                        select
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`fh`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`fa`
                                                           when (`b`.`role` = 0)
                                                             then `a`.`fd` end) AS `fraction`,
                                                          (case when (`b`.`role` = 1)
                                                            then `a`.`ph`
                                                           when (`b`.`role` = 2)
                                                             then `a`.`pa`
                                                           when (`b`.`role` = 0)
                                                             then `a`.`pd` end) AS `prob`
                                                        from (`betting_kings`.`football_fraction_bk_bookmakers` `a` left join `betting_kings`.`football_odds_snapshot` `b`
                                                            on ((`a`.`referrer_id` = `b`.`referrer_id`)))
                                                        where (`a`.`bookmaker_id` = `b`.`bookmaker_id`)) as t WHERE fraction>0 and prob>_threshold_inf and prob < _threshold_sup;

        if _count_by_threshold > 0 THEN

          OPEN curFootball_under;
          read_loop: LOOP
            FETCH curFootball_under INTO _referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport;
            select count(*) into _exists from output_live where referrer_id = _referrer_id and sport = _sport;
            if _exists = 1 then
              select odd,prob into _current_odd,_current_prob from output_live where referrer_id = _referrer_id and sport = _sport;
              if _current_prob = _prob and _current_odd < _odd then
                update output_live set home_team = _home_team, away_team = _away_team, country = _country, championship =_championship, continent = _continent, match_date = _match_date, platform_id = _platform_id, bookmaker_id = _bookmaker_id, fh = _fh, fa = _fa, fd = _fd, ph = _ph, pa = _pa, pd = _pd, pbh = _pbh, pba = _pba, pbd = _pbd, role = _role, odd = _odd, fraction = _fraction, prob = _prob, sport = _sport where referrer_id = _referrer_id  and sport = _sport;
              end if;
            else
              if _count_insert = 0 then
                insert into output_live (referrer_id, home_team, away_team, country, championship, continent, match_date, platform_id, bookmaker_id, fh, fa, fd, ph, pa, pd, pbh, pba, pbd, role, odd, fraction, prob, sport) values(_referrer_id, _home_team, _away_team, _country, _championship, _continent, _match_date, _platform_id, _bookmaker_id, _fh, _fa, _fd, _ph, _pa, _pd, _pbh, _pba, _pbd, _role, _odd, _fraction, _prob, _sport);
                set _count_insert = _count_insert + 1;
              else
                LEAVE read_loop;
              end if;
            end if;
            IF done THEN
              LEAVE read_loop;
            END IF;
          end loop;
          close curFootball_under;
        end if;
      END IF;
    END IF ;

  end;



