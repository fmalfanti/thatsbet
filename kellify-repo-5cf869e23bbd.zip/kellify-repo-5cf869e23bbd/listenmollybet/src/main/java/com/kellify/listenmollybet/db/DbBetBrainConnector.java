package com.kellify.listenmollybet.db;

import com.kellify.common.mollybet.EventMollybet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.List;
import java.util.Properties;

public class DbBetBrainConnector extends DbConnector {
    private static final Logger logger = LoggerFactory.getLogger(DbBetBrainConnector.class);
    private static final  String INSERT_OR_UPDATE_EVENT = " replace into mollybet_event values (?,?,?,?,?,?,?,?)";
    private static final  String REMOVE_EVENT = " delete from mollybet_event where event_id=? and sport=?";
    private static final  String REMOVE_EVENT_BEFORE_NOW = " delete from mollybet_event where match_date < NOW()";

    public DbBetBrainConnector(Properties config) {
        this.config = config;
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.betbrain"), config.getProperty("user.betbrain"), config.getProperty("password.betbrain"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;

    }

    public void insertOrUpdateEvent( List<EventMollybet>eventMollybets ) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_OR_UPDATE_EVENT);
            for( EventMollybet eventMollybet : eventMollybets){
                ps.setString(1, eventMollybet.getEventId());
                ps.setString(2, eventMollybet.getHomeTeam());
                ps.setString(3, eventMollybet.getAwayTeam());
                ps.setTimestamp(4, Timestamp.valueOf(eventMollybet.getStartTime()));
                ps.setInt(5, Integer.parseInt(eventMollybet.getChampionship_id()));
                ps.setString(6,eventMollybet.getChampionship_name());
                ps.setString(7,eventMollybet.getCountry());
                ps.setString(8,eventMollybet.getSportType());
                ps.execute();
            }


        } catch(SQLException ex) {
            logger.error(" event not inserted: " + eventMollybets.toString(), ex);
        }catch(IllegalStateException ex) {
            logger.error(" event not inserted: " + eventMollybets.toString(), ex);
            throw new SQLException(ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public void removeEventBeforeNow() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(REMOVE_EVENT_BEFORE_NOW);
                ps.execute();
        } catch(SQLException ex) {
            logger.error(" old event not removed " , ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void removeEvent( List<EventMollybet>eventMollybets ) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(REMOVE_EVENT);
            for( EventMollybet eventMollybet : eventMollybets){
                ps.setString(1, eventMollybet.getEventId());
                ps.setString(2, eventMollybet.getSportType());
                ps.execute();
            }


        } catch(SQLException ex) {
            logger.error(" event not inserted: " + eventMollybets.toString(), ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
}
