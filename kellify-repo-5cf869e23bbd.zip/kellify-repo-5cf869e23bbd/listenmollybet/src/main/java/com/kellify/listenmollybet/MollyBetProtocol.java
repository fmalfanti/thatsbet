package com.kellify.listenmollybet;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.mollybet.MollyBetLoginRequest;
import com.kellify.common.mollybet.MollyBetLoginResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class MollyBetProtocol {
    private static final Logger logger = LoggerFactory.getLogger(MollyBetProtocol.class);
    private Properties config;
    private ObjectMapper mapper = null;
    private int timeout = 5000; // default 5 seconds
    private ClientHttpRequestFactory clientHttpRequestFactory = null;
    private MollyBetLoginResponse loginResponse = null;

    public MollyBetLoginResponse getLoginResponse() throws Exception {
        if( loginResponse== null){
            login();
        }
        return loginResponse;
    }

    MollyBetProtocol(Properties config) {
        this.config = config;
        mapper = new ObjectMapper();
        clientHttpRequestFactory = getClientHttpRequestFactory();


    }


    private void login() throws Exception {
        String url = config.getProperty("provider.mollybet.serverUrl");
        logger.info("login at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
       // restTemplate.setErrorHandler(new MatchBookLoginErrorHandler());
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

        MollyBetLoginRequest loginRequest = new MollyBetLoginRequest(config.getProperty("provider.sportmarket.username"), config.getProperty("provider.sportmarket.password"));

        HttpEntity<?> entity = new HttpEntity<>(loginRequest, headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.POST,
                entity,
                String.class);

        int responseCode = ((ResponseEntity<String>) response).getStatusCodeValue();
        if(logger.isDebugEnabled()) {
            logger.debug("login response code:" + responseCode);
            logger.debug("login response:" + response.getBody());
        }
        String sessionToken = "";

        JsonNode root = mapper.readTree(response.getBody());
        if(responseCode != HttpStatus.OK.value()) {
            JsonNode errorNode = root.get("code");
            if(errorNode != null) {
                throw new Exception("response code:" + responseCode + "error type: "+ errorNode.toString());
            }
        }

        sessionToken =  root.get("data").asText();

        loginResponse = new MollyBetLoginResponse(sessionToken);
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        try {
            int confTimeout = Integer.parseInt(config.getProperty("provider.matchbook.http.timeout.seconds"));
            timeout = (int) TimeUnit.SECONDS.toMillis(confTimeout);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.matchbook.http.timeout.seconds was invalid, using default:" + timeout + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection timeout:" + timeout + " ms");
        }

        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return clientHttpRequestFactory;
    }
}
