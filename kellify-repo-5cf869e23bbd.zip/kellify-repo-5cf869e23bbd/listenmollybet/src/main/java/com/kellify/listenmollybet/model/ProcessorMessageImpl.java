package com.kellify.listenmollybet.model;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.mollybet.EventMollybet;
import com.kellify.listenmollybet.db.DbBetBrainConnector;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ProcessorMessageImpl implements ProcessorMessage {
    private static final Logger logger = LoggerFactory.getLogger(ProcessorMessageImpl.class);
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");
    private ObjectMapper mapper;
    private final Properties conf;
    private final Set<String> assetedSport;

    public ProcessorMessageImpl(Properties conf ) {
        this.conf = conf;
        this.assetedSport = acceptedSports();
    }


    @Override
    public Map<String, List<EventMollybet>> processMessage(String message) throws IOException {
        mapper = new ObjectMapper();
        Map<String, List<EventMollybet>> MollybetMap = new HashMap<>();
        JsonNode root = mapper.readTree(message);
        JsonNode data = root.get("data");
        ReadElement readElement = new ReadElement();
        for( JsonNode event : data) {
            String messageType = event.get(0).asText();
            if( !messageType.equals("event") && !messageType.equals("remove_event")) {
                continue;
            }
            JsonNode element = event.get(1);

            if( messageType.equals("event")){
                readElement.fillEventToUpdate(element);
            }
            else
            {
                readElement.fillEventToRemove(element);
            }
        }
        MollybetMap.put("toUpdate", readElement.getEventMollybetList());
        MollybetMap.put("toRemove", readElement.getEventMollybetListToRemove());
        logger.debug(" MollybetMap:  " + MollybetMap.toString());
        return MollybetMap;
    }

    @Override
    public void updateEvent(List<EventMollybet> mollybetList) throws SQLException {
        DbBetBrainConnector dbBetBrainConnector = new DbBetBrainConnector(conf);
        dbBetBrainConnector.insertOrUpdateEvent(mollybetList);
        dbBetBrainConnector.closeConnection();

    }

    @Override
    public void removeEvent(List<EventMollybet> mollybetList) throws SQLException {
        DbBetBrainConnector dbBetBrainConnector = new DbBetBrainConnector(conf);
        dbBetBrainConnector.removeEvent(mollybetList);
        dbBetBrainConnector.closeConnection();
    }


    private Set<String> acceptedSports(){
        Set<String> sportSet = new HashSet<>();
        String sportString = conf.getProperty("sport.types");
        String[] sportArray = sportString.split(",");
        for (String sp: sportArray ) {
            sportSet.add(sp.trim());
        }
        return sportSet;

    }



    private class ReadElement {
        List<EventMollybet> eventMollybetList;
        List<EventMollybet> eventMollybetListToRemove ;

        public ReadElement() {
            this.eventMollybetList = new ArrayList<>();
            this.eventMollybetListToRemove = new ArrayList<>();
        }

        public List<EventMollybet> getEventMollybetList() {
            return eventMollybetList;
        }

        public List<EventMollybet> getEventMollybetListToRemove() {
            return eventMollybetListToRemove;
        }

        void fillEventToUpdate(JsonNode node){
            String matchValid= conf.getProperty("match.status");
            String matchStatus = node.get("ir_status").asText();
            if( !matchStatus.equals(matchValid) ){
                return ;
            }
            EventMollybet eventMollybet;
            String sport = node.get("sport").asText();
            if( assetedSport.contains(sport)){
                String event_id = node.get("event_id").asText();
                String home = node.get("home").asText();
                if( home.isEmpty() || StringUtils.isBlank(home)) {
                    return;
                }
                String away = node.get("away").asText();
                if( away.isEmpty() || StringUtils.isBlank(away)) {
                    return;
                }
                String competition_id = "";
                if( node.has("competition_id")){
                    competition_id = node.get("competition_id").asText();
                }
                if( ( competition_id.isEmpty() || StringUtils.isBlank(competition_id))&& !sport.equals("tennis")){
                    return ;
                }

                String competition_name = node.get("competition_name").asText();
                String competition_country = node.get("competition_country").asText();
                String  matchDateString = node.get("start_time").asText();
                LocalDateTime matchDate = LocalDateTime.parse(matchDateString, formatter);
                eventMollybet = new EventMollybet(event_id, home, away, sport, competition_id, competition_country, competition_name, matchDate);
                eventMollybetList.add(eventMollybet);
            }

        }

        void fillEventToRemove(JsonNode node){
            String sport = node.get("sport").asText();
            EventMollybet eventMollybet;
            if( assetedSport.contains(sport)) {
                String event_id = node.get("event_id").asText();
                eventMollybet = new EventMollybet(event_id, sport);
                eventMollybetListToRemove.add(eventMollybet);
            }
        }
    }
}
