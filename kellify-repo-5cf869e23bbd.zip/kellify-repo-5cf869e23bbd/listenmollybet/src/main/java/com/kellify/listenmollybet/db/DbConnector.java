package com.kellify.listenmollybet.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public abstract class DbConnector {
    protected Properties config;
    protected Connection connection;

    public void closeConnection() {
        if(connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot close the database connection!", e);
            }
        }
    }
}
