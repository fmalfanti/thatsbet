package com.kellify.listenmollybet;

import java.io.*;
import java.lang.management.ManagementFactory;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

public class ShutdownHook {
    private final String lockPath;

    private File lockFile;
    private static FileChannel channel;
    private static FileLock lock;

    public ShutdownHook(String lockPath) {
        this.lockPath = lockPath;
    }


    public void initLock() throws IOException {
        lockFile = new File(lockPath);
        if (lockFile.exists()) {
            lockFile.delete();
        }

        channel = new RandomAccessFile(lockFile, "rw").getChannel();
        String vmName = ManagementFactory.getRuntimeMXBean().getName();
        String pid = vmName.substring(0, vmName.indexOf("@"));
        channel.write(ByteBuffer.wrap(pid.getBytes()));
        lock = channel.tryLock();
        if(lock == null)
        {
            channel.close();
            return;
        }

//        BufferedWriter writer = null;
//        try {
//            writer = new BufferedWriter(new FileWriter(lockFile));
//            writer.write("ShutdownHook");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                writer.close();
//            } catch (Exception e) {
//            }
//        }
        RealHook realHook = new RealHook();
        Runtime.getRuntime().addShutdownHook(realHook);
    }


    public void unlockFile() {
        try
        {
            if(lock != null)
            {
                lock.release();
                channel.close();
                lockFile.delete();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public static void main(String argv[]) throws InterruptedException, IOException {
        try {
            ShutdownHook sdHook = new ShutdownHook("c:/tmp/process.lock");
            sdHook.initLock();
            Thread.sleep(10000);
            System.out.println("Esco");
        }
        finally {}
    }



    class RealHook extends Thread {
        public void run() {
            unlockFile();
        }
    }
}
