package com.kellify.listenmollybet.model;

import com.kellify.common.mollybet.EventMollybet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public interface ProcessorMessage {
    Map<String, List<EventMollybet>> processMessage(String message) throws IOException;
    void updateEvent (List<EventMollybet> mollybetList ) throws SQLException;
    void removeEvent (List<EventMollybet> mollybetList ) throws SQLException;
    static ProcessorMessage getInstance(Properties conf){  return new  ProcessorMessageImpl(conf);  }
}
