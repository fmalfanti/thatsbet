package com.kellify.listenmollybet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.Properties;

public class WatchDog {
    private static final Logger logger = LoggerFactory.getLogger(WatchDog.class);

    public static void main(String [] args) {
        if (args.length == 0) {
            logger.error("Not <conf_file_path> provided");
            System.err.println("Not <conf_file_path> provided");
            System.exit(-1);
        }
        String confPath = args[0];
        File confFile = new File(confPath);
        if (!confFile.exists() || confFile.isDirectory() || !confFile.canRead()) {
            logger.error("Can't read File " + confPath);
            System.err.println("Can't read File " + confPath);
            System.exit(-2);
        }
        Properties conf = new Properties();
        try {
            conf.load(new FileInputStream(confPath));
            String lockFilePath = conf.getProperty("lock.file.path");
            CheckRunningProcess checkRunningProcess = new CheckRunningProcess(lockFilePath, args);
            checkRunningProcess.check();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
    }
}

class CheckRunningProcess {
    private static final Logger logger = LoggerFactory.getLogger(CheckRunningProcess.class);

    private final String lockFilePath;
    private final String [] args;

    CheckRunningProcess(String lockFilePath, String [] args) {
        this.lockFilePath = lockFilePath;
        this.args = args;
    }

    void check() throws IOException {
        boolean mustStart = processStatus();
        if(mustStart) {
            System.out.println("Process is restarting");
            logger.debug("Process is restarting");
            App.main(args);
        }
    }

    private boolean processStatus() throws IOException {
        File lockFile = new File(lockFilePath);
        if(!lockFile.exists()) {
            return true;
        }
        FileChannel channel = new RandomAccessFile(lockFile, "rw").getChannel();
        FileLock lock = channel.tryLock();
        if(lock != null) {
            System.out.println("Process is stopped");
            logger.debug("Process is stopped");
            lock.release();
            channel.close();
            lockFile.delete();
            return true;
        }
        System.out.println("Process is running");
        logger.debug("Process is running");
        return false;
    }
}
