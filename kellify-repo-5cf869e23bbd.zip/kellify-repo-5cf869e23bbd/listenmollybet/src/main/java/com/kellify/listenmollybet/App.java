package com.kellify.listenmollybet;

import com.kellify.listenmollybet.db.DbBetBrainConnector;
import com.kellify.common.mollybet.EventMollybet;
import com.kellify.listenmollybet.model.ProcessorMessage;
import org.glassfish.grizzly.ssl.SSLContextConfigurator;
import org.glassfish.grizzly.ssl.SSLEngineConfigurator;
import org.glassfish.tyrus.client.ClientManager;
import org.glassfish.tyrus.client.ClientProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.websocket.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.CountDownLatch;

public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class);

    private static CountDownLatch messageLatch;

    public static void main(String [] args){
        if( args.length == 0 ){
            logger.error( "Not <conf_file_path> provided");
            System.err.println( "Not <conf_file_path> provided" );
            System.exit(-1);
        }
        String confPath = args[0];
        File confFile = new File(confPath);
        if(!confFile.exists() || confFile.isDirectory() || !confFile.canRead() ){
            logger.error( "Can't read File " + confPath);
            System.err.println( "Can't read File " + confPath );
            System.exit(-2);
        }
        Properties conf = new Properties();
        try {
            conf.load(new FileInputStream(confPath));

            ShutdownHook sdHook = new ShutdownHook(conf.getProperty("lock.file.path"));
            sdHook.initLock();

            messageLatch = new CountDownLatch(1);
            ProcessorMessage processorMessage = ProcessorMessage.getInstance( conf );
            final ClientEndpointConfig cec = ClientEndpointConfig.Builder.create().build();

            ClientManager client = ClientManager.createClient();

            System.getProperties().put("javax.net.debug", "all");
            System.getProperties().put(SSLContextConfigurator.KEY_STORE_FILE, conf.getProperty("keystore.path"));
            //System.getProperties().put(SSLContextConfigurator.TRUST_STORE_FILE, "...");
            System.getProperties().put(SSLContextConfigurator.KEY_STORE_PASSWORD, conf.getProperty("keystore.passwd"));
            //System.getProperties().put(SSLContextConfigurator.TRUST_STORE_PASSWORD, "...");
            final SSLContextConfigurator defaultConfig = new SSLContextConfigurator();

            defaultConfig.retrieve(System.getProperties());

            SSLEngineConfigurator sslEngineConfigurator =
                    new SSLEngineConfigurator(defaultConfig, true, false, false);
            client.getProperties().put(ClientProperties.SSL_ENGINE_CONFIGURATOR, sslEngineConfigurator);
            DbBetBrainConnector betBrainConnector = new DbBetBrainConnector(conf);
            betBrainConnector.removeEventBeforeNow();
            betBrainConnector.closeConnection();
            MollyBetProtocol mollyBetProtocol = new MollyBetProtocol(conf);
            String token =  mollyBetProtocol.getLoginResponse().getToken();
            client.connectToServer(new Endpoint() {

                @Override
                public void onOpen(Session session, EndpointConfig config) {
                    session.addMessageHandler(new MessageHandler.Whole<String>() {

                        @Override
                        public void onMessage(String message) {
                            logger.debug("Received message: "+message);
                            try {
                                Map<String, List<EventMollybet>> mollyBetMap ;
                                mollyBetMap = processorMessage.processMessage(message);
                                if (!mollyBetMap.get("toUpdate").isEmpty()) {
                                    logger.debug(" Match to update: " + mollyBetMap.get("toUpdate").toString());
                                    processorMessage.updateEvent(mollyBetMap.get("toUpdate"));
                            }
                                if (!mollyBetMap.get("toRemove").isEmpty()) {
                                    logger.debug(" Match to remove: " + mollyBetMap.get("toRemove").toString());
                                    processorMessage.removeEvent(mollyBetMap.get("toRemove"));
                                }
                            }
                            catch (IOException|SQLException e) {
                                logger.error(e.getMessage(), e);
                            }
                        }
                    });
                }
            }, cec, new URI("wss://api.mollybet.com/v1/stream/?token=" + token));
            messageLatch.await();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
    }
}
