package com.kellify.getquote;

import org.junit.Test;

import java.util.concurrent.ConcurrentLinkedQueue;

public class PushTest {
    private class PushServer {

    }

    private class PushClient implements Runnable {
        final ConcurrentLinkedQueue<String> queue;

        private PushClient(ConcurrentLinkedQueue<String> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            PushWorker initDump = new PushWorker(queue);
            PushWorker worker = new PushWorker(queue);
            Thread initDumpThread = new Thread(initDump);
            Thread workerThread = new Thread(worker);

            initDumpThread.start();
            workerThread.start();

            try {
                Thread.currentThread().sleep(50000);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            initDump.stop();
            worker.stop();

            System.out.println("shitdowen");
        }
    }

    private class PushWorker implements Runnable {
        final ConcurrentLinkedQueue<String> queue;
        boolean isActive = false;

        private PushWorker(ConcurrentLinkedQueue<String> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            isActive = true;
            String str;
            System.out.println("Consumer Started:" + Thread.currentThread().getName());
            while(isActive) {
                while ((str = queue.poll()) != null) {
                    System.out.println("Removed: " + str + ",  " + Thread.currentThread().getName());
                }
            }
        }

        public void stop() {
            isActive = false;
        }
    }

    @Test
    public void pushTest() throws InterruptedException {
        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<String>();



        PushClient pushClient = new PushClient(queue);
        Thread puchClientThread = new Thread(pushClient);
        puchClientThread.start();


        int i=1;
        for (; i < 10; i++) {
            queue.add("String" + i);
            System.out.println("Added: String" + i);
            Thread.currentThread().sleep(200);
        }

        try {
            System.out.println("Wait");
            Thread.currentThread().sleep(5000);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        for (; i < 20; i++) {
            queue.add("String" + i);
            System.out.println("Added: String" + i);
            Thread.currentThread().sleep(200);
        }
    }
}
