package com.kellify.getquote;


import com.betbrain.sepc.connector.sdql.EntityChangeBatchProcessingMonitor;
import com.betbrain.sepc.connector.sdql.SEPCConnectorListener;
import com.betbrain.sepc.connector.sdql.SEPCPushConnector;
import com.betbrain.sepc.connector.sportsmodel.*;
import com.kellify.getquote.dbload.BetBrainDBConnector;
import com.kellify.getquote.dbload.BetBrainDatabaseConnector;
import com.kellify.getquote.dbload.BetbrainConnection;
import com.kellify.getquote.dbload.IBetBrainConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;

public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class.getName());

    private static long savedLastBatchId = 0;
    private static IBetBrainConnection conn;

    private static ConcurrentLinkedQueue<Object> queue = new ConcurrentLinkedQueue<>();

    public static void main(String[] args) throws Exception {
        if(args.length == 0) {
            logger.warn("Not <conf_file_path> provided, using default");
        }

        String CONF_FILE_PATH = args[0];
        if(!new File(CONF_FILE_PATH).exists()) {
            logger.warn("Config file" + CONF_FILE_PATH + " does not exists or is not readable, using default");
            CONF_FILE_PATH = "/app.properties";
        } else {
            logger.info("Config file" + CONF_FILE_PATH + " found");
        }
        Properties props = new Properties();
        props.load(new FileInputStream(CONF_FILE_PATH));

        String dbConfFile = props.getProperty("db.conf.file");
        if(dbConfFile == null || !new File(dbConfFile).exists()) {
            logger.warn("No dbload config file found, using default");
            dbConfFile = "/db.properties";
        }

        BetBrainDBConnector connector = BetBrainDatabaseConnector.BetBrainDatabaseConnectorFactory.getInstance(dbConfFile);

        conn = BetbrainConnection.BetbrainConnectionFactory.getInstance(connector.getDataSource());

        conn.truncateAllTables();


        EntityProcessWorker entityProcessWorker = new EntityProcessWorker(conn, queue);
        Thread entityProcessWorkerThread = new Thread(entityProcessWorker);
        entityProcessWorkerThread.start();

        // Step 1.
        SEPCPushConnector sepcPushConnector = new SEPCPushConnector(props.getProperty("publisherAppHost"), Integer.parseInt(props.getProperty("publisherAppPort")));

        // Step 3.
        sepcPushConnector.addConnectorListener(new BetBrainConnectorListener());

        // Step 5.
        sepcPushConnector.setEntityChangeBatchProcessingMonitor(new EntityChangeBatchProcessingMonitorTest());

        // Step6.
        logger.info("Subscription name:" + props.getProperty("subscription.name"));
        try {
            sepcPushConnector.start(props.getProperty("subscription.name"));
        } catch(Exception ex) {
            logger.error("Error:" + ex.getMessage(), ex);
            entityProcessWorker.stop();
        }

    }
    // Step 2.
    public static class BetBrainConnectorListener implements SEPCConnectorListener {
        private static final Logger logger = LoggerFactory.getLogger(BetBrainConnectorListener.class.getName());

        @Override
        public void notifyInitialDump(List<? extends Entity> entities) {
            logger.info("notifyInitialDump called");

            for (Entity entity : entities) {
                queue.add(entity);
//                try {
//                    conn.insertEntity(entity);
//                } catch (Exception e) {
//                    logger.error(e.getMessage(), e);
//                }
            }
            logger.info("Initial dump ended");
        }

        @Override
        public void notifyEntityUpdates(EntityChangeBatch entityChangeBatch) {
            List<EntityChange> entityChanges = entityChangeBatch.getEntityChanges();

            for (EntityChange entityChange : entityChanges) {
                queue.add(entityChange);
//                if (entityChange instanceof EntityCreate) {
//                    EntityCreate entityCreate = (EntityCreate) entityChange;
//                    Entity entity = entityCreate.getEntity();
//                    try {
//                        conn.insertEntity(entity);
//                    } catch (Exception e) {
//                        logger.error(e.getMessage(), e);
//                    }
//                } else if (entityChange instanceof EntityDelete) {
//
//                    EntityDelete delete = (EntityDelete) entityChange;
//                    long entityId = delete.getEntityId();
//                    Class<? extends Entity> entityClass = delete.getEntityClass();
//                    try {
//                        conn.deleteEntity(entityId,entityClass);
//                    } catch (Exception e) {
//                        logger.error(e.getMessage(), e);
//                    }
//
//                } else if (entityChange instanceof EntityUpdate) {
//
//                    EntityUpdate update = (EntityUpdate) entityChange;
//
//                    Class<? extends Entity> entityClass = update.getEntityClass();
//                    long entityId = update.getEntityId();
//
//                    List<String> propertyNames = update.getPropertyNames();
//                    List<Object> propertyValues = update.getPropertyValues();
//                    try {
//                        conn.updateEntity(entityId,entityClass,propertyNames,propertyValues);
//                    } catch (Exception e) {
//                        logger.error(e.getMessage(), e);
//                    }
//                }

            }
            savedLastBatchId = entityChangeBatch.getId();
        }
    }

    // Step 4.
    public static class EntityChangeBatchProcessingMonitorTest implements EntityChangeBatchProcessingMonitor {

        @Override
        public long getLastAppliedEntityChangeBatchId() {

            // In order to use resume feature, you will need to save the lastBatchId that you
            // received in BetBrainConnectorListener and return it in this method.
            // Otherwise, the resume feature will not work.

            // retrieve last batch id
            return retrieveLastBatchId();
        }

        private long retrieveLastBatchId() {
            return savedLastBatchId;
        }
    }
}
