package com.kellify.getquote.dbload;

import com.betbrain.sepc.connector.sportsmodel.*;

//import org.apache.log4j.Logger;

import javax.sql.DataSource;
import java.sql.*;
import java.util.List;


public class BetbrainConnection implements IBetBrainConnection {
    private final DataSource dataSource;
    private static final String truncateStoreProcedure = "{call TruncateAllTables()}";



    private static final String insertBettingOffer = "INSERT IGNORE INTO BettingOffer (id,providerId,sourceId,outcomeId,bettingTypeId,statusId,odds,lastChangedTime) VALUES (?,?,?,?,?,?,?,?)";
    private static final String insertFirstBettingOffer = "INSERT IGNORE INTO FirstBettingOffer (id,providerId,sourceId,outcomeId,bettingTypeId,statusId,odds,lastChangedTime) VALUES (?,?,?,?,?,?,?,?)";
    private static final String insertEvent = "INSERT IGNORE INTO Event (id,name,isComplete,sportId,templateId,promotionId,parentId,parentPartId,typeId,startTime) VALUES (?,?,?,?,?,?,?,?,?,?)";
    private static final String insertEventParticipantRelation = "INSERT IGNORE INTO EventParticipantRelation (id,name,eventId,eventPartId,participantId,participantRoleId,parentParticipantId) VALUES (?,?,?,?,?,?,?)";
    private static final String insertEventTemplate = "INSERT IGNORE INTO EventTemplate (id,name,eventTypeId,sportId,venueId,rootPartId) VALUES (?,?,?,?,?,?)";
    private static final String insertLocation = "INSERT IGNORE INTO Location (id,name,code,typeId) VALUES (?,?,?,?)";
    private static final String insertOutcome = "INSERT IGNORE INTO Outcome (id,isComplete,statusId,eventId,eventPartId,paramParticipantId1,paramParticipantId2,paramParticipantId3,typeId) VALUES (?,?,?,?,?,?,?,?,?)";
    private static final String insertParticipant = "INSERT IGNORE INTO Participant (id,name,countryId,typeId) VALUES (?,?,?,?)";
    private static final String insertParticipantRole = "INSERT IGNORE INTO ParticipantRole (id,name) VALUES (?,?)";
    private static final String insertProvider = "INSERT IGNORE INTO Provider (id,name,locationId,isBookmaker) VALUES (?,?,?,?)";
    /*
    private static final String insertBettingOfferStatus = "INSERT IGNORE INTO BettingOfferStatus (id,name) VALUES (?,?)";
    private static final String insertBettingType = "INSERT IGNORE INTO BettingType (id,name) VALUES (?,?)";
    private static final String insertCurrency = "INSERT IGNORE INTO Currency (id,name,code) VALUES (?,?,?)";
    private static final String insertEntityProperty = "INSERT IGNORE INTO EntityProperty (id,name,typeId,entityTypeId) VALUES (?,?,?,?)";
    private static final String insertEntityPropertyType = "INSERT IGNORE INTO EntityPropertyType (id,name) VALUES (?,?)";
    private static final String insertEntityType = "INSERT IGNORE INTO EntityType (id,name) VALUES (?,?)";
    private static final String insertEventPart = "INSERT IGNORE INTO EventPart (id,name,parentId,orderNum) VALUES (?,?,?,?)";
    private static final String insertEventPartDefaultUsage = "INSERT IGNORE INTO EventPartDefaultUsage (id,parentEventId,sportId,rootPartId) VALUES (?,?,?,?)";
    private static final String insertEventStatus = "INSERT IGNORE INTO EventStatus (id,name) VALUES (?,?)";
    private static final String insertEventType = "INSERT IGNORE INTO EventType (id,name) VALUES (?,?)";
    private static final String insertLocationRelation = "INSERT IGNORE INTO LocationRelation (id,fromLocationId,toLocationId,typeId) VALUES (?,?,?,?)";
    private static final String insertLocationRelationType = "INSERT IGNORE INTO LocationRelationType (id,name) VALUES (?,?)";
    private static final String insertLocationType = "INSERT IGNORE INTO LocationType (id,name,hasCode) VALUES (?,?,?)";
    private static final String insertOutcomeStatus = "INSERT IGNORE INTO OutcomeStatus (id,name) VALUES (?,?)";
    private static final String insertOutcomeType = "INSERT IGNORE INTO OutcomeType (id,name) VALUES (?,?)";
    private static final String insertOutcomeTypeBettingTypeRelation = "INSERT IGNORE INTO OutcomeTypeBettingTypeRelation (id,outcomeTypeId,bettingTypeId) VALUES (?,?,?)";
    private static final String insertParticipantRelation = "INSERT IGNORE INTO ParticipantRelation (id,fromParticipantId,toParticipantId,paramParticipantRoleId,typeId) VALUES (?,?,?,?,?)";
    private static final String insertParticipantRelationType = "INSERT IGNORE INTO ParticipantRelationType (id,name) VALUES (?,?)";
    private static final String insertParticipantType = "INSERT IGNORE INTO ParticipantType (id,name) VALUES (?,?)";
    private static final String insertParticipantUsage = "INSERT IGNORE INTO ParticipantUsage (id,sportId,participantId) VALUES (?,?,?)";
    private static final String insertProviderEventRelation = "INSERT IGNORE INTO ProviderEventRelation (id,providerId,eventId) VALUES (?,?,?)";
    private static final String insertSource = "INSERT IGNORE INTO Source (id,name,collectorId,providerId) VALUES (?,?,?,?)";
    private static final String insertSport = "INSERT IGNORE INTO Sport (id,name) VALUES (?,?)";
    */

    private static final String deleteBettingOffer = "DELETE FROM BettingOffer WHERE id=?";
    private static final String deleteFirstBettingOffer = "DELETE FROM FirstBettingOffer WHERE id=?";
    private static final String deleteEvent = "DELETE FROM Event WHERE id=?";
    private static final String deleteEventParticipantRelation = "DELETE FROM EventParticipantRelation WHERE id=?";
    private static final String deleteProvider = "DELETE FROM Provider WHERE id=?";
    private static final String deleteParticipantRole = "DELETE FROM ParticipantRole WHERE id=?";
    private static final String deleteParticipant = "DELETE FROM Participant WHERE id=?";
    private static final String deleteLocation = "DELETE FROM Location WHERE id=?";
    private static final String deleteEventType = "DELETE FROM EventType WHERE id=?";
    private static final String deleteEventTemplate = "DELETE FROM EventTemplate WHERE id=?";
    private static final String deleteOutcome = "DELETE FROM Outcome WHERE id=?";


    private BetbrainConnection(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void truncateAllTables() throws SQLException {
        Connection conn = null;
        CallableStatement cStmt=null;
        try {
            conn=dataSource.getConnection();
            cStmt=conn.prepareCall(truncateStoreProcedure);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }


    }

    @Override
    public void updateEntity(long entityId, Class<? extends Entity> entityClass, List<String> propertyNames, List<Object> propertyValues)  throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        String propertyName;
        StringBuilder stringBuilder = new StringBuilder();
        int i;
        try {
            conn = dataSource.getConnection();
            if (entityClass == BettingOffer.class) {
                stringBuilder.delete(0,stringBuilder.length());
                for (i=0;i<propertyNames.size();i++) {
                    propertyName=propertyNames.get(i);
                    if (propertyName.equals("odds")){
                        stringBuilder.append(propertyName).append("=").append(propertyValues.get(i)).append(",");
                    } else if (propertyName.equals("lastChangedTime")) {
                        stringBuilder.append(propertyName).append("='").append(propertyValues.get(i).toString()).append("',");
                    }
                }
                if (stringBuilder.length()>0) {
                    stringBuilder.delete(stringBuilder.length()-1,stringBuilder.length());
                    ps = conn.prepareStatement("UPDATE BettingOffer SET "+stringBuilder.toString()+" WHERE id="+entityId);
                    ps.executeUpdate();
                }
            } else if (entityClass == Event.class) {
                stringBuilder.delete(0,stringBuilder.length());
                for (i=0;i<propertyNames.size();i++) {
                    propertyName=propertyNames.get(i);
                    if (propertyName.equals("startTime")){
                        stringBuilder.append(propertyName).append("='").append(propertyValues.get(i).toString()).append("'");
                    }
                }
                if (stringBuilder.length()>0) {
                    ps = conn.prepareStatement("UPDATE Event SET " + stringBuilder.toString() + " WHERE id=" + entityId);
                    ps.executeUpdate();
                }
            }
        }finally {
            if (ps !=null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    public void insertEntity(Entity entity) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement psFirst = null;

        Participant participant;
        BettingOffer bettingOffer;
        Location location;
        Provider provider;
        EventTemplate eventTemplate;
        Event event;
        EventParticipantRelation eventParticipantRelation;
        Outcome outcome;
        /*
        Currency currency = null;
        LocationType locationType=null;
        LocationRelation locationRelation=null;
        BettingType bettingType = null;
        ParticipantUsage participantUsage = null;
        EventPart eventPart = null;
        EventPartDefaultUsage eventPartDefaultUsage = null;
        EntityProperty entityProperty = null;
        OutcomeTypeBettingTypeRelation outcomeTypeBettingTypeRelation = null;
        Source source = null;
        ParticipantRelation participantRelation = null;
        ProviderEventRelation providerEventRelation = null;
        */
        try {
            conn = dataSource.getConnection();
            if (entity instanceof BettingOffer) {
                double odd = 0.0;
                ps = conn.prepareStatement(insertBettingOffer);
                psFirst = conn.prepareStatement(insertFirstBettingOffer);
                bettingOffer = (BettingOffer) entity;
                odd = bettingOffer.getOdds() != null ? bettingOffer.getOdds() : 0.0;

                ps.setLong(1,bettingOffer.getId());
                ps.setLong(2,bettingOffer.getProviderId());
                ps.setLong(3,bettingOffer.getSourceId());
                ps.setLong(4,bettingOffer.getOutcomeId());
                ps.setLong(5,bettingOffer.getBettingTypeId());
                ps.setLong(6,bettingOffer.getStatusId());
                ps.setDouble(7,odd);
                if (bettingOffer.getLastChangedTime()!=null) {
                    ps.setTimestamp(8,new Timestamp(bettingOffer.getLastChangedTime().getTime()));
                } else {
                    ps.setNull(8, Types.DATE);
                }

                psFirst.setLong(1,bettingOffer.getId());
                psFirst.setLong(2,bettingOffer.getProviderId());
                psFirst.setLong(3,bettingOffer.getSourceId());
                psFirst.setLong(4,bettingOffer.getOutcomeId());
                psFirst.setLong(5,bettingOffer.getBettingTypeId());
                psFirst.setLong(6,bettingOffer.getStatusId());
                psFirst.setDouble(7,odd);
                if (bettingOffer.getLastChangedTime()!=null) {
                    psFirst.setTimestamp(8,new Timestamp(bettingOffer.getLastChangedTime().getTime()));
                } else {
                    psFirst.setNull(8, Types.DATE);
                }

                ps.executeUpdate();
                psFirst.executeUpdate();
            }
            /*
            else if (entity instanceof Sport){

                ps=conn.prepareStatement(insertSport);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof Currency){
                currency = (Currency) entity;
                ps=conn.prepareStatement(insertCurrency);
                ps.setLong(1,currency.getId());
                ps.setString(2,currency.getName() != null ? currency.getName() : "");
                ps.setString(3,currency.getCode() != null ? currency.getCode() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof LocationType){
                ps=conn.prepareStatement(insertLocationType);
                locationType = (LocationType) entity;
                ps.setLong(1,locationType.getId());
                ps.setString(2,locationType.getName() != null ? locationType.getName() : "");
                ps.setBoolean(3,locationType.getHasCode()!=null?locationType.getHasCode():false);
                rt=ps.executeUpdate();
            } */
            else if (entity instanceof Location){
                ps=conn.prepareStatement(insertLocation);
                location = (Location) entity;
                ps.setLong(1,location.getId());
                ps.setString(2,location.getName() != null ? location.getName() : "");
                ps.setString(3,location.getCode());
                ps.setLong(4,location.getTypeId());
                ps.executeUpdate();
            }
            /*else if (entity instanceof LocationRelationType){
                ps=conn.prepareStatement(insertLocationRelationType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof LocationRelation){
                ps=conn.prepareStatement(insertLocationRelation);
                locationRelation=(LocationRelation) entity;
                ps.setLong(1,locationRelation.getId());
                ps.setLong(2,locationRelation.getFromLocationId());
                ps.setLong(3,locationRelation.getToLocationId());
                ps.setLong(4,locationRelation.getTypeId());
                rt=ps.executeUpdate();
            }*/
            else if (entity instanceof Provider){
                ps=conn.prepareStatement(insertProvider);
                provider = (Provider) entity;
                ps.setLong(1,provider.getId());
                ps.setString(2,provider.getName() != null ? provider.getName() : "");
                ps.setLong(3,provider.getLocationId());
                ps.setBoolean(4,provider.getIsBookmaker());
                ps.executeUpdate();
            }
            /* else if (entity instanceof BettingType){
                ps=conn.prepareStatement(insertBettingType);
                bettingType = (BettingType) entity;
                ps.setLong(1,bettingType.getId());
                ps.setString(2,bettingType.getName() != null ? bettingType.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof ParticipantType){
                ps=conn.prepareStatement(insertParticipantType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } */
            else if (entity instanceof ParticipantRole){
                ps=conn.prepareStatement(insertParticipantRole);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                ps.executeUpdate();
            } else if (entity instanceof Participant){
                participant=(Participant) entity;
                ps=conn.prepareStatement(insertParticipant);
                ps.setLong(1,participant.getId());
                ps.setString(2,participant.getName() != null ? participant.getName() : "");
                ps.setLong(3,participant.getCountryId()!=null?participant.getCountryId(): 0);
                ps.setLong(4,participant.getTypeId());
                ps.executeUpdate();
            }
            /*else if (entity instanceof ParticipantUsage){
                ps=conn.prepareStatement(insertParticipantUsage);
                participantUsage= (ParticipantUsage) entity;
                ps.setLong(1,entity.getId());
                ps.setLong(2,participantUsage.getSportId());
                ps.setLong(3,participantUsage.getParticipantId());
                rt=ps.executeUpdate();
            } else if (entity instanceof EventType){
                ps=conn.prepareStatement(insertEventType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof EventPart){
                eventPart = (EventPart) entity;
                ps=conn.prepareStatement(insertEventPart);
                ps.setLong(1,eventPart.getId());
                ps.setString(2,eventPart.getName() != null ? eventPart.getName() : "");
                ps.setLong(3,eventPart.getParentId() != null ? eventPart.getParentId() : 0);
                ps.setLong(4,eventPart.getOrderNum());
                rt=ps.executeUpdate();
            } else if (entity instanceof EventStatus){
                ps=conn.prepareStatement(insertEventStatus);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } */
            else if (entity instanceof EventTemplate){
                eventTemplate = (EventTemplate) entity;
                ps=conn.prepareStatement(insertEventTemplate);
                ps.setLong(1,eventTemplate.getId());
                ps.setString(2,eventTemplate.getName() != null ? eventTemplate.getName() : "");
                ps.setLong(3,eventTemplate.getEventTypeId());
                ps.setLong(4,eventTemplate.getSportId());
                ps.setLong(5,eventTemplate.getVenueId() != null ? eventTemplate.getVenueId() : 0);
                ps.setLong(6,eventTemplate.getRootPartId() != null ? eventTemplate.getRootPartId() : 0);
                ps.executeUpdate();
            } else if (entity instanceof Event){
                event = (Event) entity;
                ps=conn.prepareStatement(insertEvent);
                ps.setLong(1,event.getId());
                ps.setString(2,event.getName() != null ? event.getName() : "");
                ps.setBoolean(3,event.getIsComplete());
                ps.setLong(4,event.getSportId());
                ps.setLong(5,event.getTemplateId() != null ? event.getTemplateId() : 0);
                ps.setLong(6,event.getPromotionId() != null ? event.getPromotionId() : 0);
                ps.setLong(7,event.getParentId() != null ? event.getParentId() : 0);
                ps.setLong(8,event.getParentPartId() != null ? event.getParentPartId() : 0);
                ps.setLong(9,event.getTypeId());
                if (event.getStartTime()!=null) {
                    ps.setTimestamp(10,new Timestamp(event.getStartTime().getTime()));
                } else {
                    ps.setNull(10, Types.DATE);
                }
                ps.executeUpdate();
            }
            /*else if (entity instanceof EventPartDefaultUsage){
                eventPartDefaultUsage = (EventPartDefaultUsage) entity;
                ps=conn.prepareStatement(insertEventPartDefaultUsage);
                ps.setLong(1,eventPartDefaultUsage.getId());
                ps.setLong(2,eventPartDefaultUsage.getParentEventId() != null ? eventPartDefaultUsage.getParentEventId() : 0);
                ps.setLong(3,eventPartDefaultUsage.getSportId() != null ? eventPartDefaultUsage.getSportId() : 0);
                ps.setLong(4,eventPartDefaultUsage.getRootPartId());
                rt=ps.executeUpdate();
            } else if (entity instanceof EntityType){
                ps=conn.prepareStatement(insertEntityType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof EntityPropertyType){
                ps=conn.prepareStatement(insertEntityPropertyType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof EntityProperty){
                entityProperty = (EntityProperty) entity;
                ps=conn.prepareStatement(insertEntityProperty);
                ps.setLong(1,entityProperty.getId());
                ps.setString(2,entityProperty.getName() != null ? entityProperty.getName() : "");
                ps.setLong(3,entityProperty.getTypeId());
                ps.setLong(4,entityProperty.getEntityTypeId());
                rt=ps.executeUpdate();
            } */
            else if (entity instanceof EventParticipantRelation){
                eventParticipantRelation = (EventParticipantRelation) entity;
                ps=conn.prepareStatement(insertEventParticipantRelation);
                ps.setLong(1,eventParticipantRelation.getId());
                ps.setString(2,eventParticipantRelation.getName() != null ? eventParticipantRelation.getName() : "");
                ps.setLong(3,eventParticipantRelation.getEventId());
                ps.setLong(4,eventParticipantRelation.getEventPartId());
                ps.setLong(5,eventParticipantRelation.getParticipantId());
                ps.setLong(6,eventParticipantRelation.getParticipantRoleId());
                ps.setLong(7,eventParticipantRelation.getParentParticipantId() != null ? eventParticipantRelation.getParentParticipantId() : 0);
                ps.executeUpdate();
            }
            /* else if (entity instanceof Source){
                source = (Source) entity;
                ps=conn.prepareStatement(insertSource);
                ps.setLong(1,source.getId());
                ps.setString(2,source.getName() != null ? source.getName() : "");
                ps.setLong(3,source.getCollectorId());
                ps.setLong(4,source.getProviderId());
                rt=ps.executeUpdate();
            } else if (entity instanceof ParticipantRelationType){
                ps=conn.prepareStatement(insertParticipantRelationType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof ParticipantRelation){
                participantRelation = (ParticipantRelation) entity;
                ps=conn.prepareStatement(insertParticipantRelation);
                ps.setLong(1,participantRelation.getId());
                ps.setLong(2,participantRelation.getFromParticipantId());
                ps.setLong(3,participantRelation.getToParticipantId());
                ps.setLong(4,participantRelation.getParamParticipantRoleId() != null ? participantRelation.getParamParticipantRoleId() : 0);
                ps.setLong(5,participantRelation.getTypeId());
                rt=ps.executeUpdate();
            } else if (entity instanceof ProviderEventRelation){
                providerEventRelation = (ProviderEventRelation) entity;
                ps=conn.prepareStatement(insertProviderEventRelation);
                ps.setLong(1,providerEventRelation.getId());
                ps.setLong(2,providerEventRelation.getProviderId());
                ps.setLong(3,providerEventRelation.getEventId());
                rt=ps.executeUpdate();
            } else if (entity instanceof OutcomeStatus){
                ps=conn.prepareStatement(insertOutcomeStatus);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof OutcomeType){
                ps=conn.prepareStatement(insertOutcomeType);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } else if (entity instanceof OutcomeTypeBettingTypeRelation){
                outcomeTypeBettingTypeRelation = (OutcomeTypeBettingTypeRelation) entity;
                ps=conn.prepareStatement(insertOutcomeTypeBettingTypeRelation);
                ps.setLong(1,outcomeTypeBettingTypeRelation.getId());
                ps.setLong(2,outcomeTypeBettingTypeRelation.getOutcomeTypeId());
                ps.setLong(3,outcomeTypeBettingTypeRelation.getBettingTypeId());
                rt=ps.executeUpdate();
            } else if (entity instanceof BettingOfferStatus){
                ps=conn.prepareStatement(insertBettingOfferStatus);
                ps.setLong(1,entity.getId());
                ps.setString(2,entity.getName() != null ? entity.getName() : "");
                rt=ps.executeUpdate();
            } */
            else if (entity instanceof Outcome){
                outcome = (Outcome) entity;
                ps=conn.prepareStatement(insertOutcome);
                ps.setLong(1,outcome.getId());
                ps.setBoolean(2,outcome.getIsComplete());
                ps.setLong(3,outcome.getStatusId());
                ps.setLong(4,outcome.getEventId());
                ps.setLong(5,outcome.getEventPartId());
                ps.setLong(6,outcome.getParamParticipantId1() != null ? outcome.getParamParticipantId1() : 0);
                ps.setLong(7,outcome.getParamParticipantId2() != null ? outcome.getParamParticipantId2() : 0);
                ps.setLong(8,outcome.getParamParticipantId3() != null ? outcome.getParamParticipantId3() : 0);
                ps.setLong(9,outcome.getTypeId());
                ps.executeUpdate();
            }
        } finally {
            if (ps !=null) {
                ps.close();
            }
            if (psFirst !=null) {
                psFirst.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    @Override
    public void deleteEntity(long entityId, Class<? extends Entity> entityClass) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement psFirst = null;
        try {
            conn = dataSource.getConnection();
            if (entityClass == BettingOffer.class) {
                ps = conn.prepareStatement(deleteBettingOffer);
                ps.setLong(1,entityId);

                psFirst = conn.prepareStatement(deleteFirstBettingOffer);
                psFirst.setLong(1,entityId);

                ps.executeUpdate();
                psFirst.executeUpdate();
            } else if (entityClass == Event.class) {
                ps = conn.prepareStatement(deleteEvent);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == EventParticipantRelation.class) {
                ps = conn.prepareStatement(deleteEventParticipantRelation);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == EventTemplate.class) {
                ps = conn.prepareStatement(deleteEventTemplate);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == EventType.class) {
                ps = conn.prepareStatement(deleteEventType);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == Location.class) {
                ps = conn.prepareStatement(deleteLocation);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == Outcome.class) {
                ps = conn.prepareStatement(deleteOutcome);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == Participant.class) {
                ps = conn.prepareStatement(deleteParticipant);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == ParticipantRole.class) {
                ps = conn.prepareStatement(deleteParticipantRole);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            } else if (entityClass == Provider.class) {
                ps = conn.prepareStatement(deleteProvider);
                ps.setLong(1,entityId);
                ps.executeUpdate();
            }
        } finally {
            if (ps !=null) {
                ps.close();
            }
            if (psFirst !=null) {
              psFirst.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    public static class BetbrainConnectionFactory {
        //private BetbrainConnectionFactory() {}

        public static IBetBrainConnection getInstance(DataSource dataSource) {
            return new BetbrainConnection(dataSource);
        }
    }
}