package com.kellify.getquote.dbload;

import com.betbrain.sepc.connector.sportsmodel.Entity;
import java.sql.SQLException;
import java.util.List;


public interface IBetBrainConnection {
    void insertEntity(Entity entity) throws SQLException;
    void deleteEntity(long entityId,Class <? extends Entity> entityClass) throws SQLException;
    void truncateAllTables() throws SQLException;
    void updateEntity(long entityId, Class<? extends Entity> entityClass, List<String> propertyNames, List<Object> propertyValues) throws SQLException;
}
