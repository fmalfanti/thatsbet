package com.kellify.getquote.dbload;

import com.zaxxer.hikari.HikariDataSource;


public interface BetBrainDBConnector {
    HikariDataSource getDataSource();
    void closeDataSource();
}
