package com.kellify.getquote;

import com.betbrain.sepc.connector.sportsmodel.*;
import com.kellify.getquote.dbload.IBetBrainConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public class EntityProcessWorker implements Runnable {
    private static final Logger logger = LoggerFactory.getLogger(EntityProcessWorker.class);
    private final IBetBrainConnection conn;
    private final ConcurrentLinkedQueue<Object> queueChange;
    private final EntityWorker worker1;
    private final EntityWorker worker2;

    public EntityProcessWorker(IBetBrainConnection conn, ConcurrentLinkedQueue<Object> queue) {
        this.conn = conn;
        this.queueChange = queue;
        worker1 = new EntityWorker(queueChange);
        worker2 = new EntityWorker(queueChange);
    }

    @Override
    public void run() {

        Thread workerThread1 = new Thread(worker1);
        Thread workerThread2 = new Thread(worker2);

        workerThread1.start();
        workerThread2.start();
    }

    public void stop() {
        worker1.stop();
        worker2.stop();
    }

    private class EntityWorker implements Runnable {
        private final ConcurrentLinkedQueue<Object> queue;
        boolean isActive = false;

        public EntityWorker(ConcurrentLinkedQueue<Object> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            isActive = true;
            logger.info("EntityWorker started:" + Thread.currentThread().getName());
            Object entityEntry;
            Entity entity;
            while(isActive) {
                while ((entityEntry = queue.poll()) != null) {
                    if (entityEntry instanceof Entity) {
                        try {
                            entity = (Entity) entityEntry;
                            conn.insertEntity(entity);
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    } else if (entityEntry instanceof EntityCreate) {
                        EntityCreate entityCreate = (EntityCreate) entityEntry;
                        entity = entityCreate.getEntity();
                        try {
                            conn.insertEntity(entity);
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    } else if (entityEntry instanceof EntityDelete) {

                        EntityDelete delete = (EntityDelete) entityEntry;
                        long entityId = delete.getEntityId();
                        Class<? extends Entity> entityClass = delete.getEntityClass();
                        try {
                            conn.deleteEntity(entityId,entityClass);
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }

                    } else if (entityEntry instanceof EntityUpdate) {

                        EntityUpdate update = (EntityUpdate) entityEntry;

                        Class<? extends Entity> entityClass = update.getEntityClass();
                        long entityId = update.getEntityId();

                        List<String> propertyNames = update.getPropertyNames();
                        List<Object> propertyValues = update.getPropertyValues();
                        try {
                            conn.updateEntity(entityId,entityClass,propertyNames,propertyValues);
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    }
                }
            }
        }

        public void stop() {
            logger.info("stoppin worker " + Thread.currentThread().getName());
            isActive = false;
        }
    }
}
