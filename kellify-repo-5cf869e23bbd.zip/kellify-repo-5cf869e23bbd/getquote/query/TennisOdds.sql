select e.id AS eventId,bo.id as bettingOfferId,ev.name AS eventName,lo.name AS location,p.name AS participantName,prt.name as role,
       bo.odds AS odds,bo.providerId AS providerId, pr.name as bookmaker, e.startTime AS date, bo.lastChangedTime as lastChangedTime from
  Event e join
  Outcome o on o.eventId = e.id  join
  Event ev on ev.id = e.parentId  join
  EventTemplate et on et.id = ev.templateId  join
  Location lo on lo.id = et.venueId  join
  BettingOffer bo on bo.outcomeId = o.id join
  Provider pr on pr.id = bo.providerId left join
  Participant p on p.id = o.paramParticipantId1  left join
  EventParticipantRelation epr on epr.participantId = p.id  and epr.eventId = e.id left join
  ParticipantRole prt on prt.id = epr.participantRoleId  where
  DATE(e.startTime)=CURDATE()  and  e.sportId = 3  and  o.eventPartId = 20  and  e.typeId = 1  and  o.typeId=10  order by bo.providerId,e.id
