package com.kellify.getjsonodds.model;

import java.time.LocalDateTime;

public class JsonMatch {
    private final String Id;
    private final String HomeTeam;
    private final String AwayTeam;
    private final LocalDateTime MatchTime;
    private final String Campionato;
    private final String Nation;
    private final String Continent;
    private final Double MeanHomeProb;
    private final Double MeanAwayProb;



    public JsonMatch(String Id, String HomeTeam, String AwayTeam, LocalDateTime MatchTime, String Campionato, String Nation, String Continent, Double MeanHomeProb, Double MeanAwayProb) {
        this.Id = Id;
        this.HomeTeam = HomeTeam;
        this.AwayTeam = AwayTeam;
        this.MatchTime = MatchTime;
        this.Campionato = Campionato;
        this.Nation = Nation;
        this.Continent = Continent;
        this.MeanHomeProb = MeanHomeProb;
        this.MeanAwayProb = MeanAwayProb;
    }

    public String getId() {
        return Id;
    }

    public LocalDateTime getMatchTime() {
        return MatchTime;
    }

    public String getHomeTeam() {
        return HomeTeam;
    }

    public String getAwayTeam() {
        return AwayTeam;
    }

    public String getCampionato() {
        return Campionato;
    }

    public String getNation() {
        return Nation;
    }

    public String getContinent() {
        return Continent;
    }

    public Double getMeanHomeProb() {
        return MeanHomeProb;
    }

    public Double getMeanAwayProb() {
        return MeanAwayProb;
    }

    @Override
    public String toString() {
        return "JsonMatch{" +
                "Id='" + Id + '\'' +
                ", HomeTeam='" + HomeTeam + '\'' +
                ", AwayTeam='" + AwayTeam + '\'' +
                ", MatchTime='" + MatchTime + '\'' +
                ", Campionato='" + Campionato + '\'' +
                ", Nation='" + Nation + '\'' +
                ", Continent='" + Continent + '\'' +
                ", MeanHomeProb=" + MeanHomeProb +
                ", MeanAwayProb=" + MeanAwayProb +
                '}';
    }
}

