package com.kellify.getjsonodds.model;


import com.kellify.common.SportTypes;
import com.kellify.getjsonodds.db.DbUbibetterConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class JsonOddsConnectorImpl implements JsonOddsConnector {
    private static final Logger logger = LoggerFactory.getLogger(JsonOddsConnectorImpl.class);

    private Properties config;
    private DbUbibetterConnector dbUbibetterConnector;
    private List<SportTypes> sportTypes;
    private JsonOddsConnectorImpl(Properties config, DbUbibetterConnector dbUbibetterConnector) {
        this.config = config;
        this.dbUbibetterConnector=dbUbibetterConnector;
        this.sportTypes=new ArrayList<>();
        sportTypes.add(SportTypes.MMA);
        sportTypes.add(SportTypes.BASEBALL);
        sportTypes.add(SportTypes.BASKET);
        sportTypes.add(SportTypes.ICE_HOCKEY);
        sportTypes.add(SportTypes.AMERICAN_FOOTBALL);
    }

    public static JsonOddsConnector getInstance(Properties config,  DbUbibetterConnector dbUbibetterConnector) {
        return new JsonOddsConnectorImpl(config,dbUbibetterConnector);
    }

    @Override
    public void Odds( String UpdateOrInsert) throws Exception {

        JsonOddsProtocol protocol = new JsonOddsProtocol(config);
        for(SportTypes sport : sportTypes){
            if( UpdateOrInsert.equals("0")){
                List<JsonMatch> feeds = protocol.responseBody(sport);
                dbUbibetterConnector.insertOdds(feeds, sport);
                //            System.out.println("feeds!" + feeds);
            }
            else if( UpdateOrInsert.equals("1") ){
                //            System.out.println("result!" + result);
                List<JsonResult> result = protocol.resultBody(sport);
                dbUbibetterConnector.updateResult(result,sport);


                List<ClusterIdOdds> basket = dbUbibetterConnector.BasketCluster();
                List<ClusterIdOdds> baseball = dbUbibetterConnector.BaseballCluster();
                List<ClusterIdOdds> ice_hockey = dbUbibetterConnector.Ice_HockeyCluster();
                List<ClusterIdOdds> american_football = dbUbibetterConnector.American_footballCluster();
                List<ClusterIdOdds> mma = dbUbibetterConnector.MmaCluster();

                dbUbibetterConnector.insertClusterBasket(basket);
                dbUbibetterConnector.insertClusterBaseball(baseball);
                dbUbibetterConnector.insertClusterIceHockey(ice_hockey);
                dbUbibetterConnector.insertClusterAmericanFootball(american_football);
                dbUbibetterConnector.insertClusterMma(mma);

                dbUbibetterConnector.deleteBasket_cluster_JsonOdds();
                dbUbibetterConnector.deleteBaseball_cluster_JsonOdds();
                dbUbibetterConnector.deleteIceHockey_cluster_JsonOdds();
                dbUbibetterConnector.deleteAmericanFootball_cluster_JsonOdds();
                dbUbibetterConnector.deleteMma_cluster_JsonOdds();
            }
        }

    }

    public List<ClusterIdOdds> IdMatch(List<JsonMatch> jsonMatchList, List<JsonResult>  JsonResult) throws Exception {
            List<ClusterIdOdds> clusterIdOdds= new ArrayList<>();

            for(JsonMatch e : jsonMatchList) {
                for (JsonResult ee : JsonResult) {
                    if (e.getId().equals(ee.getId())){
                        ClusterIdOdds clusterIdOdds1=new ClusterIdOdds(e.getId(), e.getMatchTime(), e.getCampionato(), e.getNation(), e.getContinent(), e.getHomeTeam(), e.getAwayTeam(), ee.getHomeScore(), ee.getAwayScore(), ee.getScore(), e.getMeanAwayProb(), e.getMeanHomeProb(), 10 );
                        clusterIdOdds.add(clusterIdOdds1);
                    }
                }
            }

        return clusterIdOdds;
    }

}
