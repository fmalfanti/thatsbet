package com.kellify.getjsonodds.model;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.SportTypes;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ProviderResultResponse {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[yyyy-MM-dd'T'HH:mm:ss]");

    private final String response;
    private final SportTypes sportTypes;
    private final ObjectMapper mapper;
    private static final String FINISH = "Finished";

    public ProviderResultResponse(String response, SportTypes sportTypes) {
        this.response = response;
        this.sportTypes = sportTypes;
        mapper = new ObjectMapper();
    }

    public List<JsonResult> sportResultMatches() throws Exception {
        List<JsonResult> resultList = new ArrayList<>();

        JsonNode root = mapper.readTree(response);

        for(JsonNode nodo : root) {
            boolean isFinal = nodo.get("Final").asBoolean();
            String finished=nodo.get("FinalType").asText();

            if (!isFinal || !finished.equalsIgnoreCase(FINISH) ) {
                continue;
            }
            String id = nodo.get("ID").asText();
            String binaryScore = nodo.get("BinaryScore").asText();
            Double homeScore = nodo.get("HomeScore").asDouble();
            Double awayScore = nodo.get("AwayScore").asDouble();

            switch (sportTypes) {
                case BASKET:
                    JsonResult jsonResultBasket = new JsonResult(id, homeScore, awayScore, readResult(binaryScore));
                    resultList.add(jsonResultBasket);
                    break;
                case MMA:
                    JsonResult jsonResultMma = new JsonResult(id, homeScore, awayScore, readResult(binaryScore));
                    resultList.add(jsonResultMma);
                    break;
                case BASEBALL:
                    JsonResult jsonResultBaseball = new JsonResult(id, homeScore, awayScore, readResult(binaryScore));
                    resultList.add(jsonResultBaseball);
                    break;
                case AMERICAN_FOOTBALL:
                    JsonResult jsonResultAmerican_football = new JsonResult(id, homeScore, awayScore, readResult(binaryScore));
                    resultList.add(jsonResultAmerican_football);
                    break;
                case ICE_HOCKEY:
                    JsonResult jsonResultIce_hockey = new JsonResult(id, homeScore, awayScore, readResult(binaryScore));
                    resultList.add(jsonResultIce_hockey);
                    break;
                case BOX:
                    JsonResult jsonResultBox = new JsonResult(id, homeScore, awayScore, readResult(binaryScore));
                    resultList.add(jsonResultBox);
                    break;
            }

        }
      //  System.out.println("resultList" + resultList);

        return resultList;


    }
    private String readResult(String binaryScore) {
        String[] tokens = binaryScore.split("-");
        String resultFinal;
        int home = Integer.parseInt(tokens[0]);
        int away = Integer.parseInt(tokens[1]);

        if ( home > away )
             resultFinal="H";
        else if ( away > home )
             resultFinal="A";
        else resultFinal="error";


        return resultFinal;

    }
}
