package com.kellify.getjsonodds.model;

import java.time.LocalDateTime;

public class ClusterIdOdds   {
    private final String Id;
    private final LocalDateTime MatchDate;
    private final String Campionato;
    private final String Nazione;
    private final String Continente;
    private final String HomeTeam;
    private final String AwayTeam;
    private final Double HomeScore;
    private final Double AwayScore;
    private final String Score;
    private final Double MeanAway;
    private final Double MeanHome;
    private final int NumberBookmakers;

    public ClusterIdOdds(String Id, LocalDateTime MatchDate, String Campionato, String Nazione, String Continente, String HomeTeam, String AwayTeam, Double HomeScore, Double AwayScore, String Score, Double MeanAway, Double MeanHome, int NumberBookmakers ) {
        this.Id = Id;
        this.MatchDate = MatchDate;
        this.Campionato = Campionato;
        this.Nazione = Nazione;
        this.Continente = Continente;
        this.HomeTeam = HomeTeam;
        this.AwayTeam = AwayTeam;
        this.HomeScore = HomeScore;
        this.AwayScore = AwayScore;
        this.Score = Score;
        this.MeanAway = MeanAway;
        this.MeanHome = MeanHome;
        this.NumberBookmakers =NumberBookmakers;
    }

    public String getId() {
        return Id;
    }

    public LocalDateTime getMatchDate() {
        return MatchDate;
    }

    public String getCampionato() {
        return Campionato;
    }

    public String getNazione() {
        return Nazione;
    }

    public String getContinente() {
        return Continente;
    }

    public String getHomeTeam() {
        return HomeTeam;
    }

    public String getAwayTeam() {
        return AwayTeam;
    }

    public Double getHomeScore() {
        return HomeScore;
    }

    public Double getAwayScore() {
        return AwayScore;
    }

    public String getScore() {
        return Score;
    }

    public Double getMeanAway() {
        return MeanAway;
    }

    public Double getMeanHome() {
        return MeanHome;
    }

    public int getNumberBookmakers() {
        return NumberBookmakers;
    }

    @Override
    public String toString() {
        return "ClusterIdOdds{" +
                "Id='" + Id + '\'' +
                ", MatchDate=" + MatchDate +
                ", Campionato='" + Campionato + '\'' +
                ", Nazione='" + Nazione + '\'' +
                ", Continente='" + Continente + '\'' +
                ", HomeTeam='" + HomeTeam + '\'' +
                ", AwayTeam='" + AwayTeam + '\'' +
                ", HomeScore=" + HomeScore +
                ", AwayScore=" + AwayScore +
                ", Score='" + Score + '\'' +
                ", MeanAway=" + MeanAway +
                ", MeanHome=" + MeanHome +
                ", NumberBookmakers=" + NumberBookmakers +
                '}';
    }
}
