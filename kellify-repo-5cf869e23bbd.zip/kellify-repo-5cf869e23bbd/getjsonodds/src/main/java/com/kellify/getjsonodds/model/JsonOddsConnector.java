package com.kellify.getjsonodds.model;

public interface JsonOddsConnector {
     void Odds( String UpdateOrInsert) throws Exception;
}
