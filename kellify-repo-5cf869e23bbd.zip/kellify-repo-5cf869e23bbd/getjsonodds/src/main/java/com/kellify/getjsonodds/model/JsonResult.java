package com.kellify.getjsonodds.model;

public class JsonResult {
    private final String Id;
    private final Double HomeScore;
    private final Double AwayScore;
    private final String Score;


    public JsonResult(String Id, Double HomeScore, Double AwayScore, String Score) {
        this.Id = Id;
        this.HomeScore = HomeScore;
        this.AwayScore = AwayScore;
        this.Score = Score;
    }

    public String getId() {
        return Id;
    }

    public Double getHomeScore() {
        return HomeScore;
    }

    public Double getAwayScore() {
        return AwayScore;
    }

    public String getScore() {
        return Score;
    }

    @Override
    public String toString() {
        return "JsonResult{" +
                "Id='" + Id + '\'' +
                ", HomeScore=" + HomeScore +
                ", AwayScore=" + AwayScore +
                ", Score='" + Score + '\'' +
                '}';
    }
}


