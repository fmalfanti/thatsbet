package com.kellify.getjsonodds.model;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.SportTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class JsonOddsProtocol {
    private static final Logger logger = LoggerFactory.getLogger(JsonOddsProtocol.class);
    private Properties config;
    private ObjectMapper mapper = null;
    private ClientHttpRequestFactory clientHttpRequestFactory = null;
    private int timeout = 5000; // default 5 seconds
    private int connectionRetry = 1;
    private int connectionRetryMilliSeconds = 5000; // default 5 seconds
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[yyyy-MM-dd'T'HH:mm:ss]");

    JsonOddsProtocol(Properties config) {
        this.config = config;
        mapper = new ObjectMapper();
        clientHttpRequestFactory = getClientHttpRequestFactory();
        connectionRetry = getConnectionRetry();
        connectionRetryMilliSeconds = getConnectionRetryMilliSeconds();
    }

    List<JsonMatch> responseBody(SportTypes sportType) throws IOException {
        List<JsonMatch> feedsResponse = null;
        int counter = 1;
        for(; counter <= connectionRetry; counter++) {
            try {
                feedsResponse = getFeeds(sportType);
                System.out.println("feedsResponse: "+feedsResponse);
                logger.debug("communication successful at attempt:" + counter);
                break;
            } catch (Exception e) {
                logger.warn("communication failed:" + e.getMessage());
                logger.warn("retry ..");
                if (counter == connectionRetry) {
                    throw new RuntimeException("communication reached max attempts");
                }
                try {
                    Thread.sleep(connectionRetryMilliSeconds);
                } catch (InterruptedException e1) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        return feedsResponse;
    }


    public List<JsonResult> resultBody(SportTypes sportType) throws IOException {
        List<JsonResult> resultResponse = new ArrayList<>();
        int counter = 1;
        for(; counter <= connectionRetry; counter++) {
            try {
                resultResponse = getResult(sportType);
                System.out.println("resultResponse: "+resultResponse);
                logger.debug("communication successful at attempt:" + counter);
                break;
            } catch (Exception e) {
                logger.warn("communication failed:" + e.getMessage());
                logger.warn("retry ..");
                if (counter == connectionRetry) {
                    throw new RuntimeException("communication reached max attempts");
                }
                try {
                    Thread.sleep(connectionRetryMilliSeconds);
                } catch (InterruptedException e1) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        return resultResponse;
    }

    private int getConnectionRetry() {
        int connectionRetry = 1;
        try {
            connectionRetry = Integer.parseInt(config.getProperty("provider.jsonodds.http.timeout.retry"));
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.jsonodds.http.timeout.retry was invalid, using default:" + connectionRetry);
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection retry:" + connectionRetry);
        }
        return connectionRetry;
    }
    private int getConnectionRetryMilliSeconds() {
        int connectionRetryMilliSeconds = 5000;
        try {
            int confConnectionRetrySeconds = Integer.parseInt(config.getProperty("provider.jsonodds.http.timeout.retry.wait.seconds"));
            connectionRetryMilliSeconds = (int)TimeUnit.SECONDS.toMillis(confConnectionRetrySeconds);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.jsonodds.http.timeout.retry.wait.seconds was invalid, using default:" + connectionRetryMilliSeconds + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection retry wait:" + connectionRetryMilliSeconds + " ms");
        }
        return connectionRetryMilliSeconds;
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        try {
            int confTimeout = Integer.parseInt(config.getProperty("provider.jsonodds.http.timeout.seconds"));
            timeout = (int)TimeUnit.SECONDS.toMillis(confTimeout);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.jsonodds.http.timeout.seconds was invalid, using default:" + timeout + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection timeout:" + timeout + " ms");
        }



        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return clientHttpRequestFactory;
    }

    private List<JsonMatch> getFeeds(SportTypes sportType) throws Exception {
            List<JsonMatch> matchList=new ArrayList<>();
        String url = config.getProperty("provider.jsonodds.jsonOddsAddress") + config.getProperty("provider.jsonodds.getfeedsUrlService");
        logger.info("get feeds at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        //headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(config.getProperty("provider.jsonodds.keyName"), config.getProperty("provider.jsonodds.keyValue"));
        String sportTypeUrlParam;
        List<String> SportTypeUrlParam1 = new ArrayList<>();

        switch(sportType) {
            case MMA:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.mma.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case BASKET:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.basket.nba.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.basket.wnba.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.basket.ncaab.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case BASEBALL:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.mlb.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lmp.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.npb.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.kbo.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lmb.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lidom.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lvbp.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case ICE_HOCKEY:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.nhl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.khl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.ahl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.shl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.hall.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case AMERICAN_FOOTBALL:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.american_football.ncaaf.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.american_football.nfl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.american_football.cfl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
//            case BOX:
//                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.box.value");
//                SportTypeUrlParam1.add(sportTypeUrlParam);
//                break;

            default:
                throw new Exception("Sport type " + sportType + " not allowed");
        }

        //url += "/"+SportTypeUrlParam1;
        String currentUrl;
        for( String champioship : SportTypeUrlParam1 ){
            currentUrl = url + "/"+champioship ;
           // System.out.println("url prima: "+ currentUrl);
           // System.out.println("leggi url:" + url );

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(currentUrl)
                    .queryParam(config.getProperty("provider.jsonodds.queryParam.oddsFormat"), config.getProperty("provider.jsonodds.queryParam.oddsFormat.value"))
                    .queryParam(config.getProperty("provider.jsonodds.queryParam.oddsType"), config.getProperty("provider.jsonodds.queryParam.oddsType.value"));

            HttpEntity<?> entity = new HttpEntity<>(headers);
            System.out.println(builder.build().encode().toUri());
            HttpEntity<String> response =null;
            try {
                response = restTemplate.exchange(
                        builder.build().encode().toUri(),
                        HttpMethod.GET,
                        entity,
                        String.class);
                System.out.println("getFeeds response:" + response.getBody());
            } catch(Exception ex) {
                ex.printStackTrace();
            }

            if(logger.isDebugEnabled()) {
                logger.debug("getFeeds response:" + response.getBody());
            }
            ProviderResponse providerResponse=new ProviderResponse(response.getBody(),sportType);
            matchList.addAll(providerResponse.sportMatches());
        }
        return matchList;


//        JsonNode root = mapper.readTree(response.getBody());
//        int code = root.get("Sport").asInt();
//        System.out.println("code="+code);
//        String matchDateString=root.get("MatchTime").asText();
//        LocalDateTime matchDate = LocalDateTime.parse(matchDateString, formatter);
//
//        System.out.println("matchDate="+matchDate);
//
//        if(code != 11) {
//            throw new Exception("Error while reading feeds");
//        }

    }


    private List<JsonResult> getResult(SportTypes sportType) throws Exception {
        String url = config.getProperty("provider.jsonodds.jsonOddsAddress") + config.getProperty("provider.jsonodds.getfeedsUrlServiceResult");
        /* System.out.println("get feeds at url " + url + " .......");  */
        List<JsonResult> matchList=new ArrayList<>();
        logger.info("get feeds at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        //headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(config.getProperty("provider.jsonodds.keyName"), config.getProperty("provider.jsonodds.keyValue"));


        String sportTypeUrlParam;
        List<String> SportTypeUrlParam1 = new ArrayList<>();

        switch (sportType) {
            case MMA:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.mma.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case BASKET:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.basket.nba.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.basket.wnba.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.basket.ncaab.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case BASEBALL:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.mlb.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lmp.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.npb.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.kbo.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lmb.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lidom.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.baseball.lvbp.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
            break;
            case ICE_HOCKEY:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.nhl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.khl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.ahl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.shl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.ice_hockey.hall.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
            case AMERICAN_FOOTBALL:
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.american_football.ncaaf.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.american_football.nfl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.american_football.cfl.value");
                SportTypeUrlParam1.add(sportTypeUrlParam);
                break;
//            case BOX:
//                sportTypeUrlParam = config.getProperty("provider.jsonodds.queryParam.sportsType.box.value");
//                SportTypeUrlParam1.add(sportTypeUrlParam);
//                break;

            default:
                throw new Exception("Sport type " + sportType + " not allowed");
        }

        String currentUrl;
        for (String champioship : SportTypeUrlParam1) {
            currentUrl = url + "/" + champioship;
           // System.out.println("url prima: " + currentUrl);
           // System.out.println("leggi url:" + url);


            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(currentUrl)
                    .queryParam(config.getProperty("provider.jsonodds.queryParam.oddsFormat"), config.getProperty("provider.jsonodds.queryParam.oddsFormat.value"))
                    .queryParam(config.getProperty("provider.jsonodds.queryParam.oddsType"), config.getProperty("provider.jsonodds.queryParam.oddsType.value"));

            HttpEntity<?> entity = new HttpEntity<>(headers);

            HttpEntity<String> responseResult = null;
            try {
                responseResult = restTemplate.exchange(
                        builder.build().encode().toUri(),
                        HttpMethod.GET,
                        entity,
                        String.class);
                System.out.println("getResult :" + responseResult.getBody());
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            if (logger.isDebugEnabled()) {
                logger.debug("getResult :" + responseResult.getBody());
            }
            ProviderResultResponse providerResponse = new ProviderResultResponse(responseResult.getBody(), sportType);
            matchList.addAll(providerResponse.sportResultMatches());
        }

        return matchList;

    }
}
