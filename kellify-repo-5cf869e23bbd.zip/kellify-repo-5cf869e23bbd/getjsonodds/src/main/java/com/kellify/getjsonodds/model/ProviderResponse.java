package com.kellify.getjsonodds.model;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.SportTypes;
import com.kellify.common.ChampionshipTypes;
import java.time.LocalDateTime;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ProviderResponse {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[yyyy-MM-dd'T'HH:mm:ss]");
    private final String response;
    private final SportTypes sportTypes;
    private final ObjectMapper mapper;

    public ProviderResponse(String response, SportTypes sportTypes) {
        this.response = response;
        this.sportTypes = sportTypes;
        mapper = new ObjectMapper();
    }

    public List<JsonMatch> sportMatches() throws Exception {
        List<JsonMatch> matchList = new ArrayList<>();
        Double meanHomeProb;
        Double meanAwayProb;

        JsonNode root = mapper.readTree(response);

        for(JsonNode nodo : root) {
            String id = nodo.get("ID").asText();
            String homeTeam = nodo.get("HomeTeam").asText();
            String awayTeam = nodo.get("AwayTeam").asText();
            String matchDateString = nodo.get("MatchTime").asText();
            Integer championship=nodo.get("Sport").asInt();

           if(nodo.has("Sport")) {
               String campionato = ChampionshipTypes.getStringEnum(championship);
               LocalDateTime matchDate = LocalDateTime.parse(matchDateString, formatter);

               JsonNode odds = nodo.get("Odds");
               Double homeodds = odds.get(0).get("MoneyLineHome").asDouble();
               Double awayodds = odds.get(0).get("MoneyLineAway").asDouble();

               if( homeodds!= 0 && awayodds!= 0 ) {
                   meanHomeProb = ((1 / homeodds) / (1 / homeodds + 1 / awayodds));
                   meanAwayProb = ((1 / awayodds) / (1 / homeodds + 1 / awayodds));



               switch (sportTypes) {
                   case BASKET:
                       JsonMatch jsonMatchBasket = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "USA", "NorthAmerica", meanHomeProb, meanAwayProb);
                       matchList.add(jsonMatchBasket);
                       break;
                   case MMA:
                       JsonMatch jsonMatchMma = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "World", "World", meanHomeProb, meanAwayProb);
                       matchList.add(jsonMatchMma);
                       break;
                   case AMERICAN_FOOTBALL:
                       switch (campionato) {
                           case "nfl": {
                               JsonMatch jsonMatchAmerican_football = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "USA", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchAmerican_football);
                               break;
                           }
                           case "cfl": {
                               JsonMatch jsonMatchAmerican_football = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Canada", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchAmerican_football);
                               break;
                           }
                           case "ncaaf": {
                               JsonMatch jsonMatchAmerican_football = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "USA", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchAmerican_football);
                               break;
                           }
                       }
                       break;
                   case BASEBALL:
                       switch (campionato) {
                           case "lmp": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Messico", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                           case "mlb": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "USA", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                           case "npb": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Giappone", "Asia", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                           case "kbo": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Korea", "Asia", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                           case "lmb": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Messico", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                           case "lidom": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Repubblica Domenicana", "CentralAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                           case "lvbp": {
                               JsonMatch jsonMatchBaseball = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Venezuela", "CentralAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchBaseball);
                               break;
                           }
                       }
                       break;
                   case ICE_HOCKEY:
                       switch (campionato) {
                           case "nhl": {
                               JsonMatch jsonMatchIce_hockey = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "USA", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchIce_hockey);
                               break;
                           }
                           case "khl": {
                               JsonMatch jsonMatchIce_hockey = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "World", "World", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchIce_hockey);
                               break;
                           }
                           case "ahl": {
                               JsonMatch jsonMatchIce_hockey = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "USA", "NorthAmerica", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchIce_hockey);
                               break;
                           }
                           case "shl": {
                               JsonMatch jsonMatchIce_hockey = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Svezia", "Europe", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchIce_hockey);
                               break;
                           }
                           case "hall": {
                               JsonMatch jsonMatchIce_hockey = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "Svezia", "Europe", meanHomeProb, meanAwayProb);
                               matchList.add(jsonMatchIce_hockey);
                               break;
                           }
                       }
                       break;
                   case BOX:
                       JsonMatch jsonMatchBox = new JsonMatch(id, homeTeam, awayTeam, matchDate, campionato, "World", "World", meanHomeProb, meanAwayProb);
                       matchList.add(jsonMatchBox);
                       break;
               }

           }
           }
        }
        return matchList;

    }

}
