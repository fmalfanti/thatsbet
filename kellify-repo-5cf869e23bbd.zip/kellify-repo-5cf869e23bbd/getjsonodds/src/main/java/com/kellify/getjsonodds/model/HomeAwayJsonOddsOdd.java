package com.kellify.getjsonodds.model;

import java.util.Objects;

public class HomeAwayJsonOddsOdd {
    private final String id;
    private final String name;
    private final double away;
    private final double home;

    public HomeAwayJsonOddsOdd(String id, String name, double away, double home) {
        this.id = id;
        this.name = name;
        this.away = away;
        this.home = home;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getAway() {
        return away;
    }

    public double getHome() {
        return home;
    }

    @Override
    public String toString() {
        return "HomeAwayJsonOddsOdd{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", away=" + away +
                ", home=" + home +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HomeAwayJsonOddsOdd that = (HomeAwayJsonOddsOdd) o;
        return Double.compare(that.away, away) == 0 &&
                Double.compare(that.home, home) == 0 &&
                Objects.equals(id, that.id) &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, away, home);
    }
}
