//package com.kellify.getjsonodds.decoder;
//
//
//import com.kellify.com.kellify.fractionsmaker.common.Platforms;
//import com.kellify.mergeplatform.asianodds88.model.BasketAsianOdds88Match;
//import com.kellify.mergeplatform.asianodds88.model.FootballAsianOdds88Match;
//import com.kellify.mergeplatform.com.kellify.fractionsmaker.common.ChampionshipDecode;
//import com.kellify.mergeplatform.com.kellify.fractionsmaker.common.MatchDecodeState;
//import com.kellify.mergeplatform.com.kellify.fractionsmaker.common.Util;
//import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
//import com.kellify.mergeplatform.model.MatchWithContinent;
//import org.apache.commons.lang3.tuple.ImmutablePair;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.sql.SQLException;
//import java.time.LocalDateTime;
//import java.time.temporal.ChronoUnit;
//import java.util.List;
//import java.util.Map;
//
//public class MatchDecode {
//    private static final Logger logger = LoggerFactory.getLogger(MatchDecode.class);
//
//    private final Map<String, List<MatchWithContinent>> betbrainMatchesMap;
//    private final Map<String, ChampionshipDecode> championshipLocationMap;
//    private final DbBookmakerBettingConnector bbConnector;
//
//    public MatchDecode(Map<String, List<MatchWithContinent>> footballBetbrainMatchesMap, Map<String, ChampionshipDecode> championshipLocationMap, DbBookmakerBettingConnector bbConnector) {
//        this.betbrainMatchesMap = footballBetbrainMatchesMap;
//        this.championshipLocationMap = championshipLocationMap;
//        this.bbConnector = bbConnector;
//    }
//    // FOOTBALL
//    public ImmutablePair<MatchDecodeState, FootballAsianOdds88Match> decodeFootball(FootballAsianOdds88Match providerMatch) throws SQLException {
//        if(betbrainMatchesMap == null || championshipLocationMap == null) {
//            return null;
//        }
//        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
//        if(campionatoLocation != null) {
//            providerMatch.setLeagueName(campionatoLocation.getChampionship());
//            providerMatch.setCountry(campionatoLocation.getLocation());
//            providerMatch.setContinent(campionatoLocation.getContinent());
//        }
//
//        String providerHomeTeam = providerMatch.getHomeTeam();
//        String providerAwayTeam = providerMatch.getAwayTeam();
//        providerHomeTeam = bbConnector.footballTeamDecode(providerHomeTeam, Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
//        providerAwayTeam = bbConnector.footballTeamDecode(providerAwayTeam, Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
//
//        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
//        String[] tokensProvider = homeAndAwayProvider.split(" ");
//
//        String mapKey = Util.makeMapKey(providerMatch.getLeagueName(), providerMatch.getCountry(), providerMatch.getMatchDate());
//
//        List<MatchWithContinent> betbrainMatch = betbrainMatchesMap.get(mapKey);
//        if(betbrainMatch != null) {
//            for (MatchWithContinent bbMatch : betbrainMatch) {
//                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
//                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
//                        //betbrainMatch.remove(bbMatch);
//                        return new ImmutablePair<>(MatchDecodeState.OK, buildFootballMatch(bbMatch, providerMatch));
//                    }
//                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam) && bbMatch.getOddRole() != providerMatch.getOddRole() ){
//                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
//                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
//                    }
//                    if(bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getOddRole() != providerMatch.getOddRole() ){
//                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
//                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
//                    }
//                    // try a tokens decodeFootball
//                    String homeAndAwayBetBrain = bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
//                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");
//                    if (matchMatch(tokensBetBrain, tokensProvider)) {
//                        //betbrainMatch.remove(bbMatch);
//                        logger.debug("match successful decoded:" + providerMatch);
//                        try {
//                            insertFootballTokensDecodedTeam(bbMatch, providerMatch);
//                        } catch (SQLException ex) {
//                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
//                        }
//                        return new ImmutablePair<>(MatchDecodeState.OK, buildFootballMatch(bbMatch, providerMatch));
//                    }
//                }
//            }
//            logger.warn("match not decoded:" + providerMatch);
//            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
//        }
//        logger.warn("match has not entry in map:" + providerMatch);
//        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
//    }
//
//    // BASKET
//    public ImmutablePair<MatchDecodeState, BasketAsianOdds88Match> decodeBasket(BasketAsianOdds88Match providerMatch) throws SQLException {
//        if(championshipLocationMap == null || championshipLocationMap == null) {
//            return null;
//        }
//        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
//        if(campionatoLocation != null) {
//            providerMatch.setLeagueName(campionatoLocation.getChampionship());
//            providerMatch.setCountry(campionatoLocation.getLocation());
//            providerMatch.setContinent(campionatoLocation.getContinent());
//        }
//
//        String providerHomeTeam = providerMatch.getHomeTeam();
//        String providerAwayTeam = providerMatch.getAwayTeam();
//        providerHomeTeam = bbConnector.basketTeamDecode(providerHomeTeam, Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
//        providerAwayTeam = bbConnector.basketTeamDecode(providerAwayTeam, Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
//
//        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
//        String[] tokensProvider = homeAndAwayProvider.split(" ");
//
//        String mapKey = Util.makeMapKey(providerMatch.getLeagueName(), providerMatch.getCountry(), providerMatch.getMatchDate());
//
//        List<MatchWithContinent> betbrainMatch = betbrainMatchesMap.get(mapKey);
//        if(betbrainMatch != null) {
//            for (MatchWithContinent bbMatch : betbrainMatch) {
//                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
//                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
//                        //betbrainMatch.remove(bbMatch);
//                        return new ImmutablePair<>(MatchDecodeState.OK, buildBasketMatch(bbMatch, providerMatch));
//                    }
//                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam) && bbMatch.getOddRole() != providerMatch.getOddRole() ){
//                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
//                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
//                    }
//                    if(bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getOddRole() != providerMatch.getOddRole() ){
//                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
//                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
//                    }
//                    // try a tokens decodeFootball
//                    String homeAndAwayBetBrain = bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
//                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");
//                    if (matchMatch(tokensBetBrain, tokensProvider)) {
//                        //betbrainMatch.remove(bbMatch);
//                        logger.debug("match successful decoded:" + providerMatch);
//                        try {
//                            insertBasketTokensDecodedTeam(bbMatch, providerMatch);
//                        } catch (SQLException ex) {
//                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
//                        }
//                        return new ImmutablePair<>(MatchDecodeState.OK, buildBasketMatch(bbMatch, providerMatch));
//                    }
//                }
//            }
//            logger.warn("match not decoded:" + providerMatch);
//            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
//        }
//        logger.warn("match has not entry in map:" + providerMatch);
//        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
//    }
//
//    private void insertFootballTokensDecodedTeam(MatchWithContinent bbMatch, FootballAsianOdds88Match providerMatch) throws SQLException {
//        //logger.debug("bbMatch.getHomeTeam():" + bbMatch.getHomeTeam() + ", bbMatch.getAwayTeam():" + bbMatch.getAwayTeam() + ", providerMatch.getHomeTeam():" + providerMatch.getHomeTeam() + ", providerMatch.getAwayTeam():" + providerMatch.getAwayTeam());
//        if(!bbMatch.getAwayTeam().equalsIgnoreCase(providerMatch.getAwayTeam())) {
//            bbConnector.insertFootballTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
//        }
//        if(!bbMatch.getHomeTeam().equalsIgnoreCase(providerMatch.getHomeTeam())) {
//            bbConnector.insertFootballTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
//        }
//    }
//
//    private FootballAsianOdds88Match buildFootballMatch(MatchWithContinent bbMatch, FootballAsianOdds88Match providerMatch) {
//        FootballAsianOdds88Match footballAsianOdds88Match = new FootballAsianOdds88Match(bbMatch.getId(), providerMatch.getId(), bbMatch.getHomeTeam(), bbMatch.getAwayTeam(), bbMatch.getLeagueName(), bbMatch.getMatchDate(), bbMatch.getBettingType(),bbMatch.getOddRole());
//        footballAsianOdds88Match.setCountry(providerMatch.getCountry());
//        footballAsianOdds88Match.setContinent(providerMatch.getContinent());
//        footballAsianOdds88Match.setOdds(providerMatch.getOdds());
//        footballAsianOdds88Match.setOddRole(providerMatch.getOddRole());
//        return footballAsianOdds88Match;
//    }
//
//    private BasketAsianOdds88Match buildBasketMatch(MatchWithContinent bbMatch, BasketAsianOdds88Match providerMatch) {
//        BasketAsianOdds88Match basketAsianOdds88Match = new BasketAsianOdds88Match(bbMatch.getId(), providerMatch.getId(), bbMatch.getHomeTeam(), bbMatch.getAwayTeam(), bbMatch.getLeagueName(), bbMatch.getMatchDate(), bbMatch.getBettingType(),bbMatch.getOddRole());
//        basketAsianOdds88Match.setCountry(providerMatch.getCountry());
//        basketAsianOdds88Match.setContinent(providerMatch.getContinent());
//        basketAsianOdds88Match.setOdds(providerMatch.getOdds());
//        basketAsianOdds88Match.setOddRole(providerMatch.getOddRole());
//        return basketAsianOdds88Match;
//    }
//
//    private void insertBasketTokensDecodedTeam(MatchWithContinent bbMatch, BasketAsianOdds88Match providerMatch) throws SQLException {
//       // logger.debug("bbMatch.getHomeTeam():" + bbMatch.getHomeTeam() + ", bbMatch.getAwayTeam():" + bbMatch.getAwayTeam() + ", providerMatch.getHomeTeam():" + providerMatch.getHomeTeam() + ", providerMatch.getAwayTeam():" + providerMatch.getAwayTeam());
//        if(!bbMatch.getAwayTeam().equalsIgnoreCase(providerMatch.getAwayTeam())) {
//            bbConnector.insertBasketTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
//        }
//        if(!bbMatch.getHomeTeam().equalsIgnoreCase(providerMatch.getHomeTeam())) {
//            bbConnector.insertBasketTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
//        }
//    }
//
//    private boolean matchesSameLeagueSameDate(MatchWithContinent bbMatch, MatchWithContinent providerMatch) {
//        LocalDateTime providerMatchDate = providerMatch.getMatchDate();
//        LocalDateTime bbMatchDate = bbMatch.getMatchDate();
//
//        return bbMatch.getLeagueName().equalsIgnoreCase(providerMatch.getLeagueName()) &&
//                bbMatchDate.truncatedTo(ChronoUnit.DAYS).isEqual(providerMatchDate.truncatedTo(ChronoUnit.DAYS));
//    }
//
//    private boolean matchMatch(String[] tokensBetBrain, String[] tokensProvider) {
//        // 0.30 = n/100*60/2
//        int minLengthToken = 2;
//        int realNumToken = 0;
//        String tk1;
//        String tk2;
//        for(int i=0; i<tokensBetBrain.length; i++) {
//            tk1 = tokensBetBrain[i];
//            if(tk1.length() <= minLengthToken) {
//                continue;
//            }
//            realNumToken++;
//        }
//        for(int i=0; i<tokensProvider.length; i++) {
//            tk2 = tokensProvider[i];
//            if(tk2.length() <= minLengthToken) {
//                continue;
//            }
//            realNumToken++;
//        }
//
//        int quorum = (int)((double)(realNumToken)*0.3)+1;
//
//        int counterMatch = 0;
//
//        for(int i=0; i<tokensBetBrain.length; i++) {
//            tk1 = tokensBetBrain[i];
//            if(tk1.length() <= minLengthToken) {
//                continue;
//            }
//            for(int j=0; j<tokensProvider.length; j++) {
//                tk2 = tokensProvider[j];
//                if(tk2.length() <= minLengthToken) {
//                    continue;
//                }
//                if(tk1.equalsIgnoreCase(tk2)) {
//                    counterMatch++;
//                    if(counterMatch == quorum) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false;
//    }
//}
