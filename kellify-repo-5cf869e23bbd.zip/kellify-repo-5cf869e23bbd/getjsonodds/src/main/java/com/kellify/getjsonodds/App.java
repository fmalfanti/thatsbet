package com.kellify.getjsonodds;

import com.kellify.getjsonodds.db.DbUbibetterConnector;
import com.kellify.getjsonodds.model.JsonOddsConnector;
import com.kellify.getjsonodds.model.JsonOddsConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import static com.kellify.getjsonodds.db.DbUbibetterConnector.*;

public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class.getName());
    public static void main(String[] args) throws Exception {
        File confFile;
/*
        String CONF_FILE_PATH;
//System.out.println("args.length:"+args.length);

        if(args.length == 0) {
            logger.warn("Not <conf_file_path> provided, using default");
            CONF_FILE_PATH = App.class.getResource("/appInsert.properties").getFile();
        } else {
           // System.out.println("args[0]:"+args[0]);
            CONF_FILE_PATH = App.class.getResource(args[0]).getFile();
            if(!new File(CONF_FILE_PATH).exists()) {
                logger.warn("Config file" + CONF_FILE_PATH + " does not exists or is not readable, using defbetbrain@ubibetterault");
                CONF_FILE_PATH = App.class.getResource("/appInsert.properties").getFile();
            } else {
                logger.info("Config file " + CONF_FILE_PATH + " found");
            }

        }
*/
        if(args.length == 0) {
            logger.warn("Not <conf_file_path> provided, using default");
            App app = new App();
            confFile = new File(app.getClass().getClassLoader().getResource("appInsert.properties").getFile());
        } else {
            confFile = new File(args[0]);
            if(!confFile.exists()) {
                logger.warn("Config file" + args[0] + " does not exists or is not readable, using default");
                App app = new App();
                confFile = new File(app.getClass().getClassLoader().getResource("appInsert.properties").getFile());
            } else {
                logger.info("Config file " + args[0] + " found");
            }

        }


        Properties config = new Properties();
        config.load(new FileInputStream(confFile));


        String dbConfFile = config.getProperty("db.conf.file");
        if (dbConfFile == null || !new File(dbConfFile).exists()) {
            logger.warn("No dbload config file found, using default");
            dbConfFile = "/db.properties";
        }

        DbUbibetterConnector ubibetterConnector = getInstance(config);

        //System.out.println("dbConfFile="+dbConfFile + "ubibetterConnector " + ubibetterConnector);
        JsonOddsConnector jsonoddsConnector = JsonOddsConnectorImpl.getInstance(config,ubibetterConnector);
        String UpdateOrInsert = config.getProperty("provider.jsonodds.http.insertOrupdate");
        jsonoddsConnector.Odds( UpdateOrInsert );

    }
}