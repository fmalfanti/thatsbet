package com.kellify.getjsonodds.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;

import java.time.LocalDateTime;

public class MatchWithContinent extends Match {

    protected String continent;

    public MatchWithContinent(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType, OddRole oddRole) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType,oddRole);
        this.leagueName = leagueName;
    }

    public MatchWithContinent(String id, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, String referrerId, String country, BettingType bettingType, OddRole oddRole) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType,oddRole);
        this.country = country;
        this.leagueName = leagueName;
    }


    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }


    @Override
    public String toString() {
        return "MatchWithContinent{" +
                "continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", oddRole=" + oddRole +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
