package com.kellify.getjsonodds.db;
import com.kellify.common.SportTypes;
import com.kellify.getjsonodds.model.ClusterIdOdds;
import com.kellify.getjsonodds.model.JsonMatch;
import com.kellify.getjsonodds.model.JsonResult;

import java.sql.*;
import java.util.*;

public class DbUbibetterConnector extends DbConnector{
    private static final String INSERT_BASKET_QUOTE = "insert into basket_cluster_JsonOdds( Id, MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String INSERT_BASEBALL_QUOTE = "insert into baseball_cluster_JsonOdds( Id, MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String INSERT_ICE_HOCKEY_QUOTE = "insert into icehockey_cluster_JsonOdds( Id, MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String INSERT_AMERICANFOOTBALL_QUOTE = "insert into americanfootball_cluster_JsonOdds( Id, MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String INSERT_MMA_QUOTE = "insert into mma_cluster_JsonOdds( Id, MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String UPDATE_RESULT_BASKET = "update basket_cluster_JsonOdds set FTHG=?,FTAG=?,FTR=? where id=?";
    private static final String UPDATE_RESULT_BASEBALL = "update baseball_cluster_JsonOdds set FTHG=?,FTAG=?,FTR=? where id=?";
    private static final String UPDATE_RESULT_ICE_HOCKEY = "update icehockey_cluster_JsonOdds set FTHG=?,FTAG=?,FTR=? where id=?";
    private static final String UPDATE_RESULT_AMERICANFOOTBALL = "update americanfootball_cluster_JsonOdds set FTHG=?,FTAG=?,FTR=? where id=?";
    private static final String UPDATE_RESULT_MMA = "update mma_cluster_JsonOdds set FTHG=?,FTAG=?,FTR=? where id=?";

    private static final String SELECT_BASKET_CLUSTER = "select Id, MatchDate, UPPER(Campionato) AS Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM from basket_cluster_JsonOdds where FTR IS NOT null";
    private static final String INSERT_BASKET_CLUSTER = "insert into basket_cluster( MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String DELETE_BASKET_CLUSTER = "delete from basket_cluster_JsonOdds where FTR IS NOT null";
    private static final String SELECT_BASEBALL_CLUSTER = "select Id, MatchDate, UPPER(Campionato) AS Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM from baseball_cluster_JsonOdds where FTR IS NOT null";
    private static final String INSERT_BASEBALL_CLUSTER = "insert into baseball_cluster( MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String DELETE_BASEBALL_CLUSTER = "delete from baseball_cluster_JsonOdds where FTR IS NOT null";
    private static final String SELECT_ICE_HOCKEY_CLUSTER = "select Id, MatchDate, UPPER(Campionato) AS Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM from icehockey_cluster_JsonOdds where FTR IS NOT null";
    private static final String INSERT_ICE_HOCKEY_CLUSTER = "insert into icehockey_cluster( MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String DELETE_ICE_HOCKEY_CLUSTER = "delete from icehockey_cluster_JsonOdds where FTR IS NOT null";
    private static final String SELECT_AMERICAN_FOOTBALL_CLUSTER = "select Id, MatchDate, UPPER(Campionato) AS Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM from americanfootball_cluster_JsonOdds where FTR IS NOT null";
    private static final String INSERT_AMERICAN_FOOTBALL_CLUSTER = "insert into americanfootball_cluster( MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String DELETE_AMERICAN_FOOTBALL_CLUSTER = "delete from americanfootball_cluster_JsonOdds where FTR IS NOT null";
    private static final String SELECT_MMA_CLUSTER = "select Id, MatchDate, UPPER(Campionato) AS Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM from mma_cluster_JsonOdds where FTR IS NOT null";
    private static final String INSERT_MMA_CLUSTER = "insert into mma_cluster( MatchDate, Campionato, Nazione, Continente, HomeTeam, Awayteam, FTHG, FTAG, FTR, MA, MH, NM) values (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String DELETE_MMA_CLUSTER = "delete from mma_cluster_JsonOdds where FTR IS NOT null";

    private DbUbibetterConnector(Properties config) {
        this.config = config;
    }

    public static DbUbibetterConnector getInstance(Properties config) {
        return new DbUbibetterConnector(config);
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

 public void insertOdds(List<JsonMatch> odds, SportTypes sportTypes) throws SQLException {
        //System.out.println("odds.size() = "+odds.size());
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;

     try {
         switch (sportTypes){
             case BASKET:
                 ps = connection.prepareStatement(INSERT_BASKET_QUOTE);
                 break;
             case BASEBALL:
                 ps = connection.prepareStatement(INSERT_BASEBALL_QUOTE);
                 break;
             case ICE_HOCKEY:
                 ps = connection.prepareStatement(INSERT_ICE_HOCKEY_QUOTE);
                 break;
             case AMERICAN_FOOTBALL:
                 ps = connection.prepareStatement(INSERT_AMERICANFOOTBALL_QUOTE);
                 break;
             case MMA:
                 ps = connection.prepareStatement(INSERT_MMA_QUOTE);
                 break;
         }
            JsonMatch odd;
            for(int i=0; i<odds.size(); i++) {
                odd = odds.get(i);
                ps.setString(1, odd.getId() );
                ps.setTimestamp(2, Timestamp.valueOf(odd.getMatchTime()));
                ps.setString(3, odd.getCampionato() );
                ps.setString(4, odd.getNation() );
                ps.setString(6, odd.getHomeTeam() );
                ps.setString(7, odd.getAwayTeam() );
                ps.setInt(8, 0 );                   /* punteggio home */
                ps.setInt(9, 0 );                   /* punteggio away */
                ps.setString(10, null );            /* risultato finale */
                ps.setDouble(11, odd.getMeanAwayProb() );
                ps.setDouble(12, odd.getMeanHomeProb() );
                if(odd.getContinent() == null) {
                    ps.setNull(5, Types.VARCHAR);
                } else {
                   ps.setString(5, odd.getContinent() );
                }
                ps.setInt(13, 10 );
                try {
                    ps.executeUpdate();
                }
                catch(Exception ex) {
                    System.out.print(ex.getMessage());
                    System.out.print("odd not inserted:" + odd);
                }
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public void updateResult( List<JsonResult> results, SportTypes sportTypes) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            switch (sportTypes) {
                case BASKET:
                    ps = connection.prepareStatement(UPDATE_RESULT_BASKET);
                    break;
                case BASEBALL:
                    ps = connection.prepareStatement(UPDATE_RESULT_BASEBALL);
                    break;
                case ICE_HOCKEY:
                    ps = connection.prepareStatement(UPDATE_RESULT_ICE_HOCKEY);
                    break;
                case AMERICAN_FOOTBALL:
                    ps = connection.prepareStatement(UPDATE_RESULT_AMERICANFOOTBALL);
                    break;
                case MMA:
                    ps = connection.prepareStatement(UPDATE_RESULT_MMA);
                    break;
            }

          for (JsonResult jsonResult: results) {
                ps.setDouble(1, jsonResult.getHomeScore());
                ps.setDouble(2, jsonResult.getAwayScore());
                ps.setString(3, jsonResult.getScore());
                ps.setString(4, jsonResult.getId());

                ps.addBatch();
            }
            ps.executeBatch();
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }


    //
    // INSERT IN SPORT_CLUSTER:
    //


    //BASKET
    public List<ClusterIdOdds> BasketCluster() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ClusterIdOdds> entityList =  new ArrayList<>();
        ClusterIdOdds element;
        try {
            ps = connection.prepareStatement(SELECT_BASKET_CLUSTER);
            rs = ps.executeQuery();

            while(rs.next()) {
                element = new ClusterIdOdds(
                        rs.getString("Id"),
                        rs.getTimestamp("MatchDate").toLocalDateTime(),
                        rs.getString("Campionato" ),
                        rs.getString("Nazione"),
                        rs.getString("Continente"),
                        rs.getString("HomeTeam"),
                        rs.getString("AwayTeam"),
                        rs.getDouble("FTHG"),
                        rs.getDouble("FTAG"),
                        rs.getString("FTR"),
                        rs.getDouble("MA"),
                        rs.getDouble("MH"),
                        rs.getInt("NM"));
//                System.out.println("element:____" + element );
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityList;
    }

    public void insertClusterBasket(List<ClusterIdOdds> odds) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = connection.prepareStatement(INSERT_BASKET_CLUSTER);
        ClusterIdOdds odd;
        for(int i=0; i<odds.size(); i++) {
            odd = odds.get(i);
            ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDate()));
            ps.setString(2, odd.getCampionato() );
            ps.setString(3, odd.getNazione() );
            ps.setString(4, odd.getContinente() );
            ps.setString(5, odd.getHomeTeam() );
            ps.setString(6, odd.getAwayTeam() );
            ps.setDouble(7, odd.getHomeScore() );
            ps.setDouble(8, odd.getAwayScore() );
            ps.setString(9, odd.getScore() );
            ps.setDouble(10, odd.getMeanAway() );
            ps.setDouble(11, odd.getMeanHome() );
            ps.setInt(12, odd.getNumberBookmakers() );
            try {
                ps.executeUpdate();
            }
            catch(Exception ex) {
                System.out.print(ex.getMessage());
                System.out.print("odd not inserted:" + odd);
            }
        }

    }

    public void deleteBasket_cluster_JsonOdds() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(DELETE_BASKET_CLUSTER);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //BASEBALL
    public List<ClusterIdOdds> BaseballCluster() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ClusterIdOdds> entityList =  new ArrayList<>();
        ClusterIdOdds element;
        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_CLUSTER);
            rs = ps.executeQuery();

            while(rs.next()) {
                element = new ClusterIdOdds(
                        rs.getString("Id"),
                        rs.getTimestamp("MatchDate").toLocalDateTime(),
                        rs.getString("Campionato" ),
                        rs.getString("Nazione"),
                        rs.getString("Continente"),
                        rs.getString("HomeTeam"),
                        rs.getString("AwayTeam"),
                        rs.getDouble("FTHG"),
                        rs.getDouble("FTAG"),
                        rs.getString("FTR"),
                        rs.getDouble("MA"),
                        rs.getDouble("MH"),
                        rs.getInt("NM"));
//                System.out.println("element:____" + element );
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityList;
    }

    public void insertClusterBaseball(List<ClusterIdOdds> odds) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = connection.prepareStatement(INSERT_BASEBALL_CLUSTER);
        ClusterIdOdds odd;
        for(int i=0; i<odds.size(); i++) {
            odd = odds.get(i);
            ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDate()));
            ps.setString(2, odd.getCampionato() );
            ps.setString(3, odd.getNazione() );
            ps.setString(4, odd.getContinente() );
            ps.setString(5, odd.getHomeTeam() );
            ps.setString(6, odd.getAwayTeam() );
            ps.setDouble(7, odd.getHomeScore() );
            ps.setDouble(8, odd.getAwayScore() );
            ps.setString(9, odd.getScore() );
            ps.setDouble(10, odd.getMeanAway() );
            ps.setDouble(11, odd.getMeanHome() );
            ps.setInt(12, odd.getNumberBookmakers() );
            try {
                ps.executeUpdate();
            }
            catch(Exception ex) {
                System.out.print(ex.getMessage());
                System.out.print("odd not inserted:" + odd);
            }
        }

    }

    public void deleteBaseball_cluster_JsonOdds() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(DELETE_BASEBALL_CLUSTER);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //ICE_HOCKEY
    public List<ClusterIdOdds> Ice_HockeyCluster() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ClusterIdOdds> entityList =  new ArrayList<>();
        ClusterIdOdds element;
        try {
            ps = connection.prepareStatement(SELECT_ICE_HOCKEY_CLUSTER);
            rs = ps.executeQuery();

            while(rs.next()) {
                element = new ClusterIdOdds(
                        rs.getString("Id"),
                        rs.getTimestamp("MatchDate").toLocalDateTime(),
                        rs.getString("Campionato" ),
                        rs.getString("Nazione"),
                        rs.getString("Continente"),
                        rs.getString("HomeTeam"),
                        rs.getString("AwayTeam"),
                        rs.getDouble("FTHG"),
                        rs.getDouble("FTAG"),
                        rs.getString("FTR"),
                        rs.getDouble("MA"),
                        rs.getDouble("MH"),
                        rs.getInt("NM"));
//                System.out.println("element:____" + element );
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityList;
    }

    public void insertClusterIceHockey(List<ClusterIdOdds> odds) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = connection.prepareStatement(INSERT_ICE_HOCKEY_CLUSTER);
        ClusterIdOdds odd;
        for(int i=0; i<odds.size(); i++) {
            odd = odds.get(i);
            ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDate()));
            ps.setString(2, odd.getCampionato() );
            ps.setString(3, odd.getNazione() );
            ps.setString(4, odd.getContinente() );
            ps.setString(5, odd.getHomeTeam() );
            ps.setString(6, odd.getAwayTeam() );
            ps.setDouble(7, odd.getHomeScore() );
            ps.setDouble(8, odd.getAwayScore() );
            ps.setString(9, odd.getScore() );
            ps.setDouble(10, odd.getMeanAway() );
            ps.setDouble(11, odd.getMeanHome() );
            ps.setInt(12, odd.getNumberBookmakers() );
            try {
                ps.executeUpdate();
            }
            catch(Exception ex) {
                System.out.print(ex.getMessage());
                System.out.print("odd not inserted:" + odd);
            }
        }

    }

    public void deleteIceHockey_cluster_JsonOdds() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(DELETE_ICE_HOCKEY_CLUSTER);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //AMERICAN_FOOTBALL
    public List<ClusterIdOdds> American_footballCluster() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ClusterIdOdds> entityList =  new ArrayList<>();
        ClusterIdOdds element;
        try {
            ps = connection.prepareStatement(SELECT_AMERICAN_FOOTBALL_CLUSTER);
            rs = ps.executeQuery();

            while(rs.next()) {
                element = new ClusterIdOdds(
                        rs.getString("Id"),
                        rs.getTimestamp("MatchDate").toLocalDateTime(),
                        rs.getString("Campionato" ),
                        rs.getString("Nazione"),
                        rs.getString("Continente"),
                        rs.getString("HomeTeam"),
                        rs.getString("AwayTeam"),
                        rs.getDouble("FTHG"),
                        rs.getDouble("FTAG"),
                        rs.getString("FTR"),
                        rs.getDouble("MA"),
                        rs.getDouble("MH"),
                        rs.getInt("NM"));
//                System.out.println("element:____" + element );
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityList;
    }

    public void insertClusterAmericanFootball(List<ClusterIdOdds> odds) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = connection.prepareStatement(INSERT_AMERICAN_FOOTBALL_CLUSTER);
        ClusterIdOdds odd;
        for(int i=0; i<odds.size(); i++) {
            odd = odds.get(i);
            ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDate()));
            ps.setString(2, odd.getCampionato() );
            ps.setString(3, odd.getNazione() );
            ps.setString(4, odd.getContinente() );
            ps.setString(5, odd.getHomeTeam() );
            ps.setString(6, odd.getAwayTeam() );
            ps.setDouble(7, odd.getHomeScore() );
            ps.setDouble(8, odd.getAwayScore() );
            ps.setString(9, odd.getScore() );
            ps.setDouble(10, odd.getMeanAway() );
            ps.setDouble(11, odd.getMeanHome() );
            ps.setInt(12, odd.getNumberBookmakers() );
            try {
                ps.executeUpdate();
            }
            catch(Exception ex) {
                System.out.print(ex.getMessage());
                System.out.print("odd not inserted:" + odd);
            }
        }

    }

    public void deleteAmericanFootball_cluster_JsonOdds() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(DELETE_AMERICAN_FOOTBALL_CLUSTER);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //MMA
    public List<ClusterIdOdds> MmaCluster() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ClusterIdOdds> entityList =  new ArrayList<>();
        ClusterIdOdds element;
        try {
            ps = connection.prepareStatement(SELECT_MMA_CLUSTER);
            rs = ps.executeQuery();

            while(rs.next()) {
                element = new ClusterIdOdds(
                        rs.getString("Id"),
                        rs.getTimestamp("MatchDate").toLocalDateTime(),
                        rs.getString("Campionato" ),
                        rs.getString("Nazione"),
                        rs.getString("Continente"),
                        rs.getString("HomeTeam"),
                        rs.getString("AwayTeam"),
                        rs.getDouble("FTHG"),
                        rs.getDouble("FTAG"),
                        rs.getString("FTR"),
                        rs.getDouble("MA"),
                        rs.getDouble("MH"),
                        rs.getInt("NM"));
//                System.out.println("element:____" + element );
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityList;
    }

    public void insertClusterMma(List<ClusterIdOdds> odds) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = connection.prepareStatement(INSERT_MMA_CLUSTER);
        ClusterIdOdds odd;
        for(int i=0; i<odds.size(); i++) {
            odd = odds.get(i);
            ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDate()));
            ps.setString(2, odd.getCampionato() );
            ps.setString(3, odd.getNazione() );
            ps.setString(4, odd.getContinente() );
            ps.setString(5, odd.getHomeTeam() );
            ps.setString(6, odd.getAwayTeam() );
            ps.setDouble(7, odd.getHomeScore() );
            ps.setDouble(8, odd.getAwayScore() );
            ps.setString(9, odd.getScore() );
            ps.setDouble(10, odd.getMeanAway() );
            ps.setDouble(11, odd.getMeanHome() );
            ps.setInt(12, odd.getNumberBookmakers() );
            try {
                ps.executeUpdate();
            }
            catch(Exception ex) {
                System.out.print(ex.getMessage());
                System.out.print("odd not inserted:" + odd);
            }
        }

    }

    public void deleteMma_cluster_JsonOdds() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(DELETE_MMA_CLUSTER);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }


}
