package com.kellify.common;

import org.junit.Assert;
import org.junit.Test;

public class OddRoleTest {
    @Test
    public void valueOfTest() {
        OddRole expetcted = OddRole.AWAY;

        OddRole oddRole = OddRole.valueOf("away".toUpperCase());

        Assert.assertEquals(expetcted, oddRole);
    }

    @Test
    public void valuesTest() {
        OddRole expetcted = OddRole.HOME;
        int awayInt = expetcted.getNumVal();
        System.out.println(awayInt);
        OddRole oddRole = OddRole.getEnum(awayInt);

        Assert.assertEquals(expetcted, oddRole);
    }
}
