package com.kellify.common;

import org.junit.Assert;
import org.junit.Test;

public class BettingTypeTest {
    @Test
    public void valueOfTest() {
        BettingType expetcted = BettingType.HOME_DRAW_AWAY;

        BettingType oddRole = BettingType.valueOf("HOME_DRAW_AWAY".toUpperCase());

        Assert.assertEquals(expetcted, oddRole);
    }

    @Test
    public void valuesTest() {
        BettingType expetcted = BettingType.HOME_DRAW_AWAY;
        int awayInt = expetcted.getNumVal();
        System.out.println(awayInt);
        BettingType oddRole = BettingType.getEnum(awayInt);

        Assert.assertEquals(expetcted, oddRole);
    }
}
