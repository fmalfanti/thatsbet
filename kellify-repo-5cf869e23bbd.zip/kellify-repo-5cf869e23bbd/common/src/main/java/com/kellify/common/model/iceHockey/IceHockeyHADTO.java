package com.kellify.common.model.iceHockey;

import com.kellify.common.model.DTO;
import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.common.util.DTOType;

public class IceHockeyHADTO extends DTO {
    protected ProbabilitiesQueryType type = ProbabilitiesQueryType.COUNTRY;
    protected final String continent;

    public IceHockeyHADTO(double homeMin, double homeMax, double awayMin, double awayMax, String country, DTOType dtoType, String continent) {
        super(homeMin, homeMax, awayMin, awayMax, country,dtoType);
        this.continent = continent;
    }

    public ProbabilitiesQueryType getType() {
        return type;
    }

    public void setType(ProbabilitiesQueryType type) {
        this.type = type;
    }

    public String getContinent() {
        return continent;
    }

    @Override
    public String toString() {
        return "IceHockeyHADTO{" +
                "type=" + type +
                ", continent='" + continent + '\'' +
                ", homeMin=" + homeMin +
                ", homeMax=" + homeMax +
                ", awayMin=" + awayMin +
                ", awayMax=" + awayMax +
                ", country='" + country + '\'' +
                '}';
    }
}
