package com.kellify.common.util;

import java.util.Collections;
import java.util.List;

public class MathUtil {


    public static double smoothStep(double prob,double probmax){
        double r=50.0;
        if ((prob>1)||(prob<0)){
            return 0.0;
        } else {
            return Math.exp(r*prob)/(Math.exp(r*probmax)+Math.exp(r*prob));
        }
    }

    public static double median(List<Double> myList) {
        Collections.sort(myList);
        int n = myList.size() / 2;
        double m;
        if(myList.size() % 2 == 0) {
            m = (myList.get(n) + myList.get(n-1))/2;
        }else{
            m = myList.get(n);
        }
        return m;
    }

}
