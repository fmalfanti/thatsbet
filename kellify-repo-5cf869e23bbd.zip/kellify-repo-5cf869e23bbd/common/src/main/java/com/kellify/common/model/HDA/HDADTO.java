package com.kellify.common.model.HDA;

import com.kellify.common.model.DTO;
import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.common.util.DTOType;

public class HDADTO extends DTO {
    protected ProbabilitiesQueryType type = ProbabilitiesQueryType.COUNTRY;
    protected final double drawMin;
    protected final double drawMax;
    protected final String continent;

    public HDADTO(double homeMin, double homeMax, double awayMin, double awayMax, double drawMin, double drawMax, String country, DTOType dtoType, String continent) {
        super(homeMin, homeMax, awayMin, awayMax, country,dtoType);
        this.drawMin = drawMin;
        this.drawMax = drawMax;
        this.continent = continent;
    }

    public ProbabilitiesQueryType getType() {
        return type;
    }

    public void setType(ProbabilitiesQueryType type) {
        this.type = type;
    }

    public double getDrawMin() {
        return drawMin;
    }

    public double getDrawMax() {
        return drawMax;
    }

    public String getContinent() {
        return continent;
    }

    @Override
    public String toString() {
        return "HDADTO{" +
                "type=" + type +
                ", drawMin=" + drawMin +
                ", drawMax=" + drawMax +
                ", continent='" + continent + '\'' +
                ", homeMin=" + homeMin +
                ", homeMax=" + homeMax +
                ", awayMin=" + awayMin +
                ", awayMax=" + awayMax +
                ", type=" + dtoType.getNumVal() +
                ", country='" + country + '\'' +
                '}';
    }
}
