package com.kellify.common.matchbook;

import com.kellify.common.SportTypes;

public enum SportIds {
    TENNIS(9),
    BASEBALL(3),
    BASKET(4),
    ICE_HOCKEY(6),
    FOOTBALL(15),
    AMERICAN_FOOTBALL(1);

    private int numVal;

    SportIds(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static int convertFromSportTypes(SportTypes sportType) {
        switch(sportType) {
            case TENNIS:
                return SportIds.TENNIS.getNumVal();
            case BASEBALL:
                return SportIds.BASEBALL.getNumVal();
            case BASKET:
                return SportIds.BASKET.getNumVal();
            case ICE_HOCKEY:
                return SportIds.ICE_HOCKEY.getNumVal();
            case FOOTBALL:
                return SportIds.FOOTBALL.getNumVal();
            case AMERICAN_FOOTBALL:
                return SportIds.AMERICAN_FOOTBALL.getNumVal();
            default:
                throw new IllegalArgumentException("sport type " + sportType + " not allowed");
        }
    }

    public static SportTypes convertToSportTypes(int sportId) {
        switch(sportId) {
            case 9:
                return SportTypes.TENNIS;
            case 3:
                return SportTypes.BASEBALL;
            case 4:
                return SportTypes.BASKET;
            case 6:
                return SportTypes.ICE_HOCKEY;
            case 15:
                return SportTypes.FOOTBALL;
            case 1:
                return SportTypes.AMERICAN_FOOTBALL;
            default:
                throw new IllegalArgumentException("sport id " + sportId + " not allowed");
        }
    }


    public static String convertToBetType (int sportId) {
        switch(sportId) {
            case 1:
            case 9:
            case 3:
            case 4:
                return "money_line";
            case 6:
            case 15:
                return "one_x_two";
            default:
            throw new IllegalArgumentException("sport id " + sportId + " not allowed");
        }
    }
}
