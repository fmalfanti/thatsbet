package com.kellify.common;

public enum ChampionshipTypes {
    mlb(0),
    nba(1),
    ncaab(2),
    ncaaf(3),
    nfl(4),
    nhl(5),
    wnba(8),
    mma(11),
    khl(14),
    ahl(15),
    shl(16),
    hall(17),
    lmp(18),
    npb(19),
    kbo(20),
    golf(21),
    wbc(23),
    cfl(24),
    lmb(25),
    lidom(26),
    lvbp(27);


    private int numVal;

    ChampionshipTypes(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static ChampionshipTypes getEnum(int numVal) {
        switch(numVal) {
            case 0:
                return ChampionshipTypes.mlb;
            case 1:
                return ChampionshipTypes.nba;
            case 2:
                return ChampionshipTypes.ncaab;
            case 3:
                return ChampionshipTypes.ncaaf;
            case 4:
                return ChampionshipTypes.nfl;
            case 5:
                return ChampionshipTypes.nhl;
            case 8:
                return ChampionshipTypes.wnba;
            case 11:
                return ChampionshipTypes.mma;
            case 14:
                return ChampionshipTypes.khl;
            case 15:
                return ChampionshipTypes.ahl;
            case 16:
                return ChampionshipTypes.shl;
            case 17:
                return ChampionshipTypes.hall;
            case 18:
                return ChampionshipTypes.lmp;
            case 19:
                return ChampionshipTypes.npb;
            case 20:
                return ChampionshipTypes.kbo;
            case 21:
                return ChampionshipTypes.golf;
            case 23:
                return ChampionshipTypes.wbc;
            case 24:
                return ChampionshipTypes.cfl;
            case 25:
                return ChampionshipTypes.lmb;
            case 26:
                return ChampionshipTypes.lidom;
            case 27:
                return ChampionshipTypes.lvbp;
            default:
                throw new IllegalArgumentException();
        }
    }
    public static String getStringEnum(int numVal) {
        switch(numVal) {
            case 0:
                return "mlb";
            case 1:
                return "nba";
            case 2:
                return "ncaab";
            case 3:
                return "ncaaf";
            case 4:
                return "nfl";
            case 5:
                return "nhl";
            case 8:
                return "wnba";
            case 11:
                return "mma";
            case 14:
                return "khl";
            case 15:
                return "ahl";
            case 16:
                return "shl";
            case 17:
                return "hall";
            case 18:
                return "lmp";
            case 19:
                return "npb";
            case 20:
                return "kbo";
            case 21:
                return "golf";
            case 23:
                return "wbc";
            case 24:
                return "cfl";
            case 25:
                return "lmb";
            case 26:
                return "lidom";
            case 27:
                return "lvbp";


            default:
                throw new IllegalArgumentException();
        }
    }
}
