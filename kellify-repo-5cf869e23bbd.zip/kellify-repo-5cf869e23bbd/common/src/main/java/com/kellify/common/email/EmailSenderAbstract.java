package com.kellify.common.email;

import com.kellify.common.Platforms;
import org.slf4j.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;

public abstract class EmailSenderAbstract implements EmailSender {
    protected final Properties config;
    protected final Platforms platform;

    protected EmailSenderAbstract(Properties config, Platforms platform) {
        this.config = config;
        this.platform = platform;
    }

    @Override
    public boolean sendEmailGenericMessage(String subject, String body, Logger logger) throws UnsupportedEncodingException, MessagingException {
        if(subject == null || body == null) {
            return false;
        }
        MimeMessage message = buildGenericMimeMessage(subject);
        message.setContent(body, "text/html");
        Transport.send(message);
        logger.info("generic message was sent to " + config.getProperty("email.tos"));
        return true;
    }

    private MimeMessage buildGenericMimeMessage(String subject) throws UnsupportedEncodingException, MessagingException {
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", config.getProperty("smtp.server.name"));
        properties.setProperty("mail.smtp.port", config.getProperty("smtp.server.port"));

        Session session = Session.getDefaultInstance(properties, null);
        MimeMessage message = new MimeMessage(session);
        message.setSentDate(new Date());
        message.setFrom(new InternetAddress(config.getProperty("email.from")));
        message.setSubject(subject, "UTF-8");
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(config.getProperty("email.tos")));

        return message;
    }

    public boolean sendEmailGenericMessageBalance(String subject, String body, Logger logger) throws UnsupportedEncodingException, MessagingException {
        if(subject == null || body == null) {
            return false;
        }
        MimeMessage message = buildGenericMimeMessageBalance(subject);
        message.setContent(body, "text/html");
        Transport.send(message);
        logger.info("generic message was sent to " + config.getProperty("email.balance"));
        return true;
    }

    private MimeMessage buildGenericMimeMessageBalance(String subject) throws UnsupportedEncodingException, MessagingException {
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", config.getProperty("smtp.server.name"));
        properties.setProperty("mail.smtp.port", config.getProperty("smtp.server.port"));

        Session session = Session.getDefaultInstance(properties, null);
        MimeMessage message = new MimeMessage(session);
        message.setSentDate(new Date());
        message.setFrom(new InternetAddress(config.getProperty("email.from")));
        message.setSubject(subject, "UTF-8");
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(config.getProperty("email.balance")));

        return message;
    }

    public boolean sendEmailGenericMessageOnlyPlayed(String subject, String body, Logger logger) throws UnsupportedEncodingException, MessagingException {
        if(subject == null || body == null) {
            return false;
        }
        MimeMessage message = buildGenericMimeMessageOnlyPlayed(subject);
        message.setContent(body, "text/html");
        Transport.send(message);
        logger.info("generic message was sent to " + config.getProperty("email.match.to.bet"));
        return true;
    }

    private MimeMessage buildGenericMimeMessageOnlyPlayed(String subject) throws UnsupportedEncodingException, MessagingException {
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", config.getProperty("smtp.server.name"));
        properties.setProperty("mail.smtp.port", config.getProperty("smtp.server.port"));

        Session session = Session.getDefaultInstance(properties, null);
        MimeMessage message = new MimeMessage(session);
        message.setSentDate(new Date());
        message.setFrom(new InternetAddress(config.getProperty("email.from")));
        message.setSubject(subject, "UTF-8");
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(config.getProperty("email.match.to.bet")));

        return message;
    }
}
