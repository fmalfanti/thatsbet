package com.kellify.common.model;

import com.kellify.common.SportTypes;

import java.util.Map;

public class BookmakerAttributes {
    private final int id;
    private final String label;
    private Map<SportTypes,Integer> historyMap;
    private int platformId;

    public BookmakerAttributes(int id, String label) {
        this.id = id;
        this.label = label;
    }

    public int getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public Map<SportTypes, Integer> getHistoryMap() {
        return historyMap;
    }

    public void setHistoryMap(Map<SportTypes, Integer> historyMap) {
        this.historyMap = historyMap;
    }

    public int getPlatformId() {
        return platformId;
    }

    public void setPlatformId(int platformId) {
        this.platformId = platformId;
    }

    @Override
    public String toString() {
        return "BookmakerAttributes{" +
                "id=" + id +
                ", label='" + label + '\'' +
                ", historyMap=" + historyMap +
                ", platformId=" + platformId +
                '}';
    }
}
