package com.kellify.common.model.tennis;

import com.kellify.common.model.DTO;
import com.kellify.common.util.DTOType;

public class TennisDTO extends DTO {

    public TennisDTO(double homeMin, double homeMax, double awayMin, double awayMax, String country, DTOType dtoType, String Bookmaker) {
        super(homeMin, homeMax, awayMin, awayMax, country,dtoType);
    }


}
