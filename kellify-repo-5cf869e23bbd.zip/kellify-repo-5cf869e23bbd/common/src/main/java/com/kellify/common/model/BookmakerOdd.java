package com.kellify.common.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;

import java.time.LocalDateTime;

public class BookmakerOdd {
    protected final String eventId;
    protected final String referrerId;
    protected final String oddId;
    protected final int platformId;
    protected final OddRole role;
    protected final double odd;
    protected final int bookmaker;
    protected final String team;
    protected final String championShip;
    protected final String country;
    protected final String continent;
    protected final LocalDateTime matchDateM;
    protected String bookmakerDescr;
    protected final BettingType bettingType;

    public BookmakerOdd(String eventId, String referrerId, String oddId, int platformId, OddRole role, double odd, int bookmaker, String team, String championShip, String country, String continent, LocalDateTime matchDateM, BettingType bettingType) {
        this.eventId = eventId;
        this.referrerId = referrerId;
        this.oddId = oddId;
        this.platformId = platformId;
        this.role = role;
        this.odd = odd;
        this.bookmaker = bookmaker;
        this.team = team;
        this.championShip = championShip;
        this.country = country;
        this.continent = continent;
        this.matchDateM = matchDateM;
        this.bettingType = bettingType;
    }
    public BookmakerOdd(String eventId, String referrerId, String oddId, int platformId, OddRole role, double odd, int bookmaker, String team, String championShip, String country, LocalDateTime matchDateM, BettingType bettingType) {
        this.eventId = eventId;
        this.referrerId = referrerId;
        this.oddId = oddId;
        this.platformId = platformId;
        this.role = role;
        this.odd = odd;
        this.bookmaker = bookmaker;
        this.team = team;
        this.championShip = championShip;
        this.country = country;
        this.continent = null;
        this.matchDateM = matchDateM;
        this.bettingType = bettingType;
    }

    public String getBookmakerDescr() {
        return bookmakerDescr;
    }

    public void setBookmakerDescr(String bookmakerDescr) {
        this.bookmakerDescr = bookmakerDescr;
    }

    public String getEventId() {
        return eventId;
    }

    public String getReferrerId() {
        return referrerId;
    }

    public String getOddId() {
        return oddId;
    }

    public int getPlatformId() {
        return platformId;
    }

    public OddRole getRole() {
        return role;
    }

    public double getOdd() {
        return odd;
    }

    public int getBookmaker() {
        return bookmaker;
    }

    public String getTeam() {
        return team;
    }

    public String getChampionShip() {
        return championShip;
    }

    public String getCountry() {
        return country;
    }

    public String getContinent() {
        return continent;
    }

    public LocalDateTime getMatchDateM() {
        return matchDateM;
    }

    public BettingType getBettingType() {
        return bettingType;
    }

    @Override
    public String toString() {
        return "BookmakerOdd{" +
                "eventId='" + eventId + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", oddId='" + oddId + '\'' +
                ", platformId=" + platformId +
                ", role=" + role +
                ", odd=" + odd +
                ", bookmaker=" + bookmaker +
                ", team='" + team + '\'' +
                ", championShip='" + championShip + '\'' +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", matchDateM=" + matchDateM +
                ", bookmakerDescr='" + bookmakerDescr + '\'' +
                ", bettingType='" + bettingType + '\'' +
                '}';
    }
}
