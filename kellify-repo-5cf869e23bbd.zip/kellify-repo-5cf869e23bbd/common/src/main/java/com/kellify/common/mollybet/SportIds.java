package com.kellify.common.mollybet;

import com.kellify.common.SportTypes;

public enum SportIds {
    TENNIS ("tennis"),
    BASKET("basket"),
    ICE_HOCKEY("ih"),
    FOOTBALL("fb"),
    AMERICAN_FOOTBALL("af");

    private String value;

    SportIds(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static String convertFromSportTypes(SportTypes sportType) {
        switch(sportType) {
            case TENNIS:
                return SportIds.TENNIS.getValue();
            case BASKET:
                return SportIds.BASKET.getValue();
            case ICE_HOCKEY:
                return SportIds.ICE_HOCKEY.getValue();
            case FOOTBALL:
                return SportIds.FOOTBALL.getValue();
            case AMERICAN_FOOTBALL:
                return SportIds.AMERICAN_FOOTBALL.getValue();
            default:
                throw new IllegalArgumentException("sport type " + sportType + " not allowed");
        }
    }

    public static SportTypes convertToSportTypes(String sportValue) {
        switch(sportValue) {
            case "tennis":
                return SportTypes.TENNIS;
            case "basket":
                return SportTypes.BASKET;
            case "ih":
                return SportTypes.ICE_HOCKEY;
            case "fb":
                return SportTypes.FOOTBALL;
            case "af":
                return SportTypes.AMERICAN_FOOTBALL;
            default:
                throw new IllegalArgumentException("sport id " + sportValue + " not allowed");
        }
    }
}
