package com.kellify.common.matchbook;

public class MatchBookLoginResponse {
    private final String token;

    public MatchBookLoginResponse(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    @Override
    public String toString() {
        return "MatchBookLoginResponse{" +
                "token='" + token + '\'' +
                '}';
    }
}
