package com.kellify.common.model.HA;

import com.kellify.common.SportTypes;
import com.kellify.common.model.DTO;
import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.common.util.DTOType;

public class HADTO extends DTO {
    protected ProbabilitiesQueryType type = ProbabilitiesQueryType.COUNTRY;
    protected final String continent;
    protected final SportTypes sportType;

    public HADTO(SportTypes sportType, double homeMin, double homeMax, double awayMin, double awayMax, String country, DTOType dtoType, String continent) {
        super(homeMin, homeMax, awayMin, awayMax, country,dtoType);
        this.sportType=sportType;
        this.continent = continent;

    }

    public ProbabilitiesQueryType getType() {
        return type;
    }

    public void setType(ProbabilitiesQueryType type) {
        this.type = type;
    }

    public String getContinent() {
        return continent;
    }
    public SportTypes getSportType() {
        return sportType;
    }
    public String getSport() {
        return sportType.getStringEnum(sportType.getNumVal());
    }

    @Override
    public String toString() {
        return "HADTO{" +
                "type=" + type +
                ", continent='" + continent + '\'' +
                ", sport='" + sportType.toString() + '\'' +
                ", homeMin=" + homeMin +
                ", homeMax=" + homeMax +
                ", awayMin=" + awayMin +
                ", awayMax=" + awayMax +
                ", country='" + country + '\'' +
                '}';
    }
}
