package com.kellify.common.model.HA;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.model.BookmakerOdd;

import java.time.LocalDateTime;

public class HABookmakerOdd extends BookmakerOdd {

    public HABookmakerOdd(String eventId, String referrerId, String oddId, int platformId, OddRole role, double odd, int bookmaker, String team, String championShip, String country, String continent, LocalDateTime matchDateM, BettingType bettingType) {
        super(eventId, referrerId, oddId, platformId, role, odd, bookmaker, team, championShip, country, continent, matchDateM, bettingType);
    }

    @Override
    public String toString() {
        return "HABookmakerOdd{" +
                "eventId='" + eventId + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", oddId='" + oddId + '\'' +
                ", platformId=" + platformId +
                ", role=" + role +
                ", odd=" + odd +
                ", bookmaker=" + bookmaker +
                ", team='" + team + '\'' +
                ", championShip='" + championShip + '\'' +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", matchDateM=" + matchDateM +
                ", bookmakerDescr='" + bookmakerDescr + '\'' +
                ", bettingType=" + bettingType +
                '}';
    }
}
