package com.kellify.common.model;

import com.kellify.common.util.DTOType;

public class AsianOddsBasketDTO extends DTOSinglePoint {
    public AsianOddsBasketDTO(int bookmakerId, double home, double away, String country, String continent, DTOType dtoType) {
        super(bookmakerId, home, away, country, continent, dtoType);
    }
}
