package com.kellify.common.model.tennis;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.model.BookmakerOdd;

import java.time.LocalDateTime;

public class TennisBookmakerOdd extends BookmakerOdd {

    public TennisBookmakerOdd(String eventId, String referrerId, String oddId, int platformId, OddRole role, double odd, int bookmaker, String team, String championShip, String country, LocalDateTime matchDateM, BettingType bettingType) {
        super(eventId, referrerId, oddId, platformId, role, odd, bookmaker, team, championShip, country, matchDateM, bettingType);
    }

    @Override
    public String toString() {
        return "TennisBookmakerOdd{" +
                "eventId='" + eventId + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", oddId='" + oddId + '\'' +
                ", platformId=" + platformId +
                ", role=" + role +
                ", odd=" + odd +
                ", bookmaker=" + bookmaker +
                ", team='" + team + '\'' +
                ", championShip='" + championShip + '\'' +
                ", country='" + country + '\'' +
                ", matchDateM=" + matchDateM +
                ", bookmakerDescr='" + bookmakerDescr + '\'' +
                ", bettingType='" + bettingType + '\'' +
                '}';
    }

    public TennisBookmakerOdd copy() {
        TennisBookmakerOdd cp = new TennisBookmakerOdd(eventId, referrerId, oddId, platformId, role, odd, bookmaker, team, championShip, country, matchDateM, bettingType);
        cp.setBookmakerDescr(bookmakerDescr);
        return cp;
    }
}
