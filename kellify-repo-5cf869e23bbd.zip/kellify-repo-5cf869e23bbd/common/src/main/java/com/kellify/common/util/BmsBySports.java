package com.kellify.common.util;

public class BmsBySports {
    private BmsBySports() {}
    public static String [] AmericanFootballBms = {"bet-at-home_op_ha_","10bet_op_ha_","marathon_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","bwin_op_ha_","unibet_op_ha_"};
    public static String [] BaseballBms = {"10bet_op_ha_","marathon_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","bwin_op_ha_","unibet_op_ha_"};
    public static String [] BasketBms = {"matchbook_op_ha_","tonybet_op_ha_","marathon_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","bwin_op_ha_","unibet_op_ha_","bet-at-home_op_ha_"};
    public static String [] FootballBms = {"B365","BS","BW","GB","IW","LB","PSC","PS","SB","SJ","SO","SY","VC","WH"};
    public static String [] TennisBms = {"B365","EX","LB","PS","SJ","UB","IW","CB","SB","BEW","GB"};
    public static String [] IceHockeyHABms = {"matchbook_op_ha_","marathon_op_ha_","tonybet_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","unibet_op_ha_","bwin_op_ha_","10bet_op_ha_"};
    public static String [] IceHockeyHDABms = {"marathon_op_ml_","tonybet_op_ml_","unibet_op_ml_","bet365_op_ml_","bwin_op_ha_","bet-at-home_op_ml_","10bet_op_ml_","pinn_op_ml_"};
    public static String [] MatchYear = {"2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018"};

}

