package com.kellify.common.model.mma;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.model.BookmakerOdd;

import java.time.LocalDateTime;

public class MmaBookmakerOdd extends BookmakerOdd {

    public MmaBookmakerOdd(String eventId, String referrerId, String oddId, int platformId, OddRole role, double odd, int bookmaker, String team, String championShip, String country, String continent, LocalDateTime matchDateM, BettingType bettingType) {
        super(eventId, referrerId, oddId, platformId, role, odd, bookmaker, team, championShip, country, continent, matchDateM, bettingType);
    }

    @Override
    public String toString() {
        return "MmaBookmakerOdd{" +
                "eventId='" + eventId + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", oddId='" + oddId + '\'' +
                ", platformId=" + platformId +
                ", role=" + role +
                ", odd=" + odd +
                ", bookmaker=" + bookmaker +
                ", team='" + team + '\'' +
                ", championShip='" + championShip + '\'' +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", matchDateM=" + matchDateM +
                ", bookmakerDescr='" + bookmakerDescr + '\'' +
                ", bettingType=" + bettingType +
                '}';
    }

    public MmaBookmakerOdd copy() {
        MmaBookmakerOdd cp = new MmaBookmakerOdd(eventId, referrerId, oddId, platformId, role, odd, bookmaker, team, championShip, country, continent, matchDateM, bettingType);
        cp.setBookmakerDescr(bookmakerDescr);
        return cp;
    }
}
