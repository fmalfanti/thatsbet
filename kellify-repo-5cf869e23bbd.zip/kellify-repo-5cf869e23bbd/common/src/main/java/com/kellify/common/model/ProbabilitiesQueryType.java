package com.kellify.common.model;

public enum ProbabilitiesQueryType {
    COUNTRY,
    CONTINENT,
    ALL
}
