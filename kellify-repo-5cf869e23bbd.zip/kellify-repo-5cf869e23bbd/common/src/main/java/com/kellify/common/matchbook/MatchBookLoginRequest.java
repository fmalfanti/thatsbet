package com.kellify.common.matchbook;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.kellify.common.matchbook.util.MatchBookLoginSerializer;

@JsonSerialize(using = MatchBookLoginSerializer.class)
public class MatchBookLoginRequest {
    private final String username;
    private final String password;

    public MatchBookLoginRequest(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return "MatchBookLoginRequest{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
