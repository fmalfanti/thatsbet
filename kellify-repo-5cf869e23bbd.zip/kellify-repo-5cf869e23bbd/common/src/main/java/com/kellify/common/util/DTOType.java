package com.kellify.common.util;

public enum DTOType {
    PROBABILITY(1),
    ODD(2);


    private int numVal;

    DTOType(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static DTOType getEnum(int numVal) {
        switch(numVal) {
            case 1:
                return DTOType.PROBABILITY;
            case 2:
                return DTOType.ODD;
            default:
                throw new IllegalArgumentException();
        }
    }
}
