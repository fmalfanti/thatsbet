package com.kellify.common.model;

import com.kellify.common.util.DTOType;

public class DTOSinglePoint {
    protected final int bookmakerId;
    protected final double home;
    protected final double away;
    protected final String country;
    protected final String continent;
    protected final DTOType dtoType;

    public DTOSinglePoint(int bookmakerId, double home, double away, String country, String continent, DTOType dtoType) {
        this.bookmakerId = bookmakerId;
        this.home = home;
        this.away = away;
        this.country = country;
        this.continent = continent;
        this.dtoType = dtoType;
    }

    public double getHome() {
        return home;
    }

    public double getAway() {
        return away;
    }

    public String getCountry() {
        return country;
    }

    public DTOType getDtoType() {
        return dtoType;
    }

    public int getBookmakerId() {
        return bookmakerId;
    }

    public String getContinent() {
        return continent;
    }

    @Override
    public String toString() {
        return "DTOSinglePoint{" +
                "bookmakerId=" + bookmakerId +
                ", home=" + home +
                ", away=" + away +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", dtoType=" + dtoType +
                '}';
    }
}
