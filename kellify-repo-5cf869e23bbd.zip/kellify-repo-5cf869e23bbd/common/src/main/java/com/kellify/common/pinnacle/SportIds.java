package com.kellify.common.pinnacle;

import com.kellify.common.SportTypes;

public enum SportIds {
    TENNIS(33),
    BASEBALL(3),
    BASKET(3),
    ICE_HOCKEY(19),
    FOOTBALL(29),
    AMERICAN_FOOTBALL(15);

    private int numVal;

    SportIds(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static int convertFromSportTypes(SportTypes sportType) {
        switch(sportType) {
            case TENNIS:
                return SportIds.TENNIS.getNumVal();
            case BASEBALL:
                return SportIds.BASEBALL.getNumVal();
            case BASKET:
                return SportIds.BASKET.getNumVal();
            case ICE_HOCKEY:
                return SportIds.ICE_HOCKEY.getNumVal();
            case FOOTBALL:
                return SportIds.FOOTBALL.getNumVal();
            case AMERICAN_FOOTBALL:
                return SportIds.AMERICAN_FOOTBALL.getNumVal();
            default:
                return SportIds.TENNIS.getNumVal();
        }
    }


}
