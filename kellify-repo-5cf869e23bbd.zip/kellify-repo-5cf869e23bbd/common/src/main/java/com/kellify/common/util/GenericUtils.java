package com.kellify.common.util;

import com.kellify.common.model.BookmakerOdd;

import java.util.List;

public class GenericUtils {
    private GenericUtils() {}

    public static String getMatchTeams(List<? extends BookmakerOdd> odds) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        for(BookmakerOdd odd : odds) {
            sb.append("[")
                    .append(odd.getTeam())
                    .append(" - ")
                    .append(odd.getRole())
                    .append(" - ")
                    .append(odd.getOdd())
                    .append(" - ")
                    .append(odd.getBookmaker())
                    .append("]");
        }
        sb.append("}");
        return sb.toString();
    }
}
