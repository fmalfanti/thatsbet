package com.kellify.common.email;

import org.slf4j.Logger;

import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

public interface EmailSender {
    boolean sendEmailGenericMessage(String subject, String body, Logger logger) throws UnsupportedEncodingException, MessagingException;
    boolean sendEmailGenericMessageBalance(String subject, String body, Logger logger) throws UnsupportedEncodingException, MessagingException;
    boolean sendEmailGenericMessageOnlyPlayed(String subject, String body, Logger logger) throws UnsupportedEncodingException, MessagingException;
}
