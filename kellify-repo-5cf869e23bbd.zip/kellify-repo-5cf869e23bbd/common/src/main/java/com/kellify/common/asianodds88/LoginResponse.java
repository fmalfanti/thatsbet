package com.kellify.common.asianodds88;

public class LoginResponse {
    private final String key;
    private final String token;
    private final String serviceUrl;

    public LoginResponse(String key, String token, String serviceUrl) {
        this.key = key;
        this.token = token;
        this.serviceUrl = serviceUrl;
    }

    public String getKey() {
        return key;
    }

    public String getToken() {
        return token;
    }

    public String getServiceUrl() {
        return serviceUrl;
    }
}
