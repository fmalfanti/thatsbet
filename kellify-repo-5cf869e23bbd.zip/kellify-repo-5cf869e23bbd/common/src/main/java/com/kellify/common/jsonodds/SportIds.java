package com.kellify.common.jsonodds;

import com.kellify.common.SportTypes;

public enum SportIds {
    MMA(1),
    BASKET(2);

    private int numVal;

    SportIds(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static int convertFromSportTypes(SportTypes sportType) {
        switch(sportType) {
            case BASKET:
                return SportIds.BASKET.getNumVal();
            default:
                return SportIds.MMA.getNumVal();
        }
    }

    public static SportTypes convertToSportTypes(int sportId) {
        switch(sportId) {
            case 1:
                return SportTypes.MMA;
            case 2:
                return SportTypes.BASKET;
            default:
                throw new IllegalArgumentException("sport id " + sportId + " not allowed");
        }
    }
}
