package com.kellify.common.mollybet;

import com.kellify.common.SportTypes;

import java.time.LocalDateTime;

public class EventMollybet {
    private String eventId;
    private String homeTeam;
    private String awayTeam;
    private String sportType;
    private String championship_id;
    private String country;
    private String championship_name;
    private LocalDateTime startTime;

    public EventMollybet(String event_id, String home, String away, String sport, String competition_id, String competition_country, String competition_name, LocalDateTime matchDate) {
        this.eventId = event_id;
        this.homeTeam =  home;
        this.awayTeam = away;
        this.sportType = sport;
        this.championship_id = competition_id;
        this.country = competition_country;
        this.championship_name = competition_name;
        this.startTime = matchDate;
    }

    public EventMollybet(String event_id, String sport) {
        this.eventId = event_id;
        this.sportType = sport;
    }

    public String getEventId() {
        return eventId;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public String getSportType() {
        return sportType;
    }

    public String getChampionship_id() {
        return championship_id;
    }

    public String getCountry() {
        return country;
    }

    public String getChampionship_name() {
        return championship_name;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    @Override
    public String toString() {
        return "EventMollybet{" +
                "eventId='" + eventId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", sportType=" + sportType +
                ", championship_id=" + championship_id +
                ", country='" + country + '\'' +
                ", championship_name='" + championship_name + '\'' +
                ", startTime=" + startTime +
                '}';
    }
}
