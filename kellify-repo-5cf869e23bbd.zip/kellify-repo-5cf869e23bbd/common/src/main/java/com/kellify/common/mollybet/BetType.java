package com.kellify.common.mollybet;

public enum BetType {
    TENNIS_HOME ("for,tset,all,vwhole,p1"),
    TENNIS_AWAY ("for,tset,all,vwhole,p2"),
    BET_HOME ("for,h"),
    BET_AWAY ("for,a"),
    BET_DRAW ("for,d"),
    HDP_HOME ("against,a"),
    HDP_AWAY ("against,h");

    private String value;

    BetType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static BetType getEnum(String value) {
        switch(value) {
            case "for,tset,all,vwhole,p1":
                return BetType.TENNIS_HOME;
            case "for,tset,all,vwhole,p2":
                return BetType.TENNIS_AWAY;
            case "for,h":
                return BetType.BET_HOME;
            case "for,a":
                return BetType.BET_AWAY;
            case "for,d":
                return BetType.BET_DRAW;
            case "against,a":
                return BetType.HDP_HOME;
            case "against,h":
                return BetType.HDP_AWAY;
            default:
                throw new IllegalArgumentException();
        }
    }

}
