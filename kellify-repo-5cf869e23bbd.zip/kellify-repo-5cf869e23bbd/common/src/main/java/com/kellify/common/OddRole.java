package com.kellify.common;

import javax.management.relation.Role;

public enum OddRole {
    DRAW(0),
    HOME(1),
    AWAY(2),
    HDP_HOME(3), // 0.5, 1X
    HDP_AWAY(4);
    ; // -0.5, X2

    private int numVal;

    OddRole(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static OddRole getEnum(int numVal) {
        switch(numVal) {
            case 0:
                return DRAW;
            case 1:
                return HOME;
            case 2:
                return AWAY;
            case 3:
                return HDP_HOME;
            case 4:
                return HDP_AWAY;

            default:
                throw new IllegalArgumentException();
        }
    }

    public static OddRole getString(String rolestring) {
        switch(rolestring) {
            case "Home":
                return HOME;
            case "Away":
                return AWAY;
            case "Draw":
                return DRAW;
            default:
                throw new IllegalArgumentException();
        }
    }

    public static OddRole mapRoleForAsianHDP(OddRole role) {
        switch(role) {
            case HOME:
                return HDP_HOME;
            case AWAY:
                return HDP_AWAY;
            default:
                throw new IllegalArgumentException();
        }
    }

}
