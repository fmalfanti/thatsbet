package com.kellify.common.asianodds88;

import com.kellify.common.SportTypes;

public enum SportIds {
    FOOTBALL(1),
    BASKET(2),
    TENNIS(3),
    BASEBALL(4);

    private int numVal;

    SportIds(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static int convertFromSportTypes(SportTypes sportType) {
        switch(sportType) {
            case BASKET:
                return SportIds.BASKET.getNumVal();
            case FOOTBALL:
                return SportIds.FOOTBALL.getNumVal();
            case TENNIS:
                return SportIds.TENNIS.getNumVal();
            case BASEBALL:
                return SportIds.BASEBALL.getNumVal();
            default:
                throw new IllegalArgumentException("sportType " + sportType + " not allowed");
        }
    }

    public static SportTypes convertToSportTypes(int sportId) {
        switch(sportId) {
            case 1:
                return SportTypes.FOOTBALL;
            case 2:
                return SportTypes.BASKET;
            case 3:
                return SportTypes.TENNIS;
            case 4:
                return SportTypes.BASEBALL;
            default:
                throw new IllegalArgumentException("sport id " + sportId + " not allowed");
        }
    }
}
