package com.kellify.common;

public enum Platforms {
    BETBRAIN(1),
    ASIANODDS88(2),
    PINNACLE(3),
    MATCHBOOK(4),
    JSONODDS(5),
    MOLLYBET( 6),
    SPORTMARKET( 7);

    private int numVal;

    Platforms(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static Platforms getEnum(int numVal) {
        switch (numVal) {
            case 1:
               return BETBRAIN;
            case 2:
                return ASIANODDS88;
            case 3:
                return PINNACLE;
            case 4:
                return MATCHBOOK;
            case 5:
                return JSONODDS;
            case 6:
                return MOLLYBET;
            case 7:
                return SPORTMARKET;
            default:
                throw new IllegalArgumentException();
        }
    }
}
