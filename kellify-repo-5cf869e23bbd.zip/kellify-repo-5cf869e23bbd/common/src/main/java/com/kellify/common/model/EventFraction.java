package com.kellify.common.model;

import com.kellify.common.BettingType;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;

import java.time.LocalDateTime;

public class EventFraction implements Cloneable{
    private String referrerId;
    private String eventId;
    private String oddId;
    private int platformId;
    private String homeTeam;
    private String awayTeam;
    private BettingType bettingType;
    private SportTypes sportType;
    private String country;
    private String continent;
    private String championship;
    private int bookmakerId;
    private String bookmakerLabel;
    private LocalDateTime startTime;
    private double fh;
    private double fd;
    private double fa;
    private int ph;
    private int pd;
    private int pa;
    private int pbh;
    private int pbd;
    private int pba;
    private double delta;
    private String bettingOfferIdH;
    private String bettingOfferIdD;
    private String bettingOfferIdA;

    public SportTypes getSportType() {
        return sportType;
    }

    public void setSportType(SportTypes sportType) {
        this.sportType = sportType;
    }

    public BettingType getBettingType() {
        return bettingType;
    }

    public void setBettingType(BettingType bettingType) {
        this.bettingType = bettingType;
    }

    public String getReferrerId() {
        return referrerId;
    }

    public void setReferrerId(String referrerId) {
        this.referrerId = referrerId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public int getPlatformId() {
        return platformId;
    }

    public void setPlatformId(int platformId) {
        this.platformId = platformId;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public String getChampionship() {
        return championship;
    }

    public void setChampionship(String championship) {
        this.championship = championship;
    }

    public int getBookmakerId() {
        return bookmakerId;
    }

    public void setBookmakerId(int bookmakerId) {
        this.bookmakerId = bookmakerId;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public double getFh() {
        return fh;
    }

    public void setFh(double fh) {
        this.fh = fh;
    }

    public double getFd() {
        return fd;
    }

    public void setFd(double fd) {
        this.fd = fd;
    }

    public double getFa() {
        return fa;
    }

    public String getOddId() {
        return oddId;
    }

    public void setOddId(String oddId) {
        this.oddId = oddId;
    }

    public void setFa(double fa) {
        this.fa = fa;
    }

    public int getPh() {
        return ph;
    }

    public void setPh(int ph) {
        this.ph = ph;
    }

    public int getPd() {
        return pd;
    }

    public void setPd(int pd) {
        this.pd = pd;
    }

    public int getPa() {
        return pa;
    }

    public void setPa(int pa) {
        this.pa = pa;
    }

    public int getPbh() {
        return pbh;
    }

    public void setPbh(int pbh) {
        this.pbh = pbh;
    }

    public int getPbd() {
        return pbd;
    }

    public void setPbd(int pbd) {
        this.pbd = pbd;
    }

    public int getPba() {
        return pba;
    }

    public void setPba(int pba) {
        this.pba = pba;
    }

    public double getDelta() {
        return delta;
    }

    public void setDelta(double delta) {
        this.delta = delta;
    }

    public String getBettingOfferIdH() {
        return bettingOfferIdH;
    }

    public void setBettingOfferIdH(String bettingOfferIdH) {
        this.bettingOfferIdH = bettingOfferIdH;
    }

    public String getBettingOfferIdD() {
        return bettingOfferIdD;
    }

    public void setBettingOfferIdD(String bettingOfferIdD) {
        this.bettingOfferIdD = bettingOfferIdD;
    }

    public String getBettingOfferIdA() {
        return bettingOfferIdA;
    }

    public void setBettingOfferIdA(String bettingOfferIdA) {
        this.bettingOfferIdA = bettingOfferIdA;
    }

    public String getBookmakerLabel() {
        return bookmakerLabel;
    }

    public void setBookmakerLabel(String bookmakerLabel) {
        this.bookmakerLabel = bookmakerLabel;
    }

    @Override
    public String toString() {
        return "EventFraction{" +
                "referrerId='" + referrerId + '\'' +
                ", eventId='" + eventId + '\'' +
                ", oddId='" + oddId + '\'' +
                ", platformId=" + platformId +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", bettingType=" + bettingType +
                ", sportType=" + sportType +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", championship='" + championship + '\'' +
                ", bookmakerId=" + bookmakerId +
                ", bookmakerLabel='" + bookmakerLabel + '\'' +
                ", startTime=" + startTime +
                ", fh=" + fh +
                ", fd=" + fd +
                ", fa=" + fa +
                ", ph=" + ph +
                ", pd=" + pd +
                ", pa=" + pa +
                ", pbh=" + pbh +
                ", pbd=" + pbd +
                ", pba=" + pba +
                ", delta=" + delta +
                ", bettingOfferIdH='" + bettingOfferIdH + '\'' +
                ", bettingOfferIdD='" + bettingOfferIdD + '\'' +
                ", bettingOfferIdA='" + bettingOfferIdA + '\'' +
                '}';
    }
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

}