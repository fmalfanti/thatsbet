package com.kellify.common.model.americanFootball;

import com.kellify.common.BettingType;

import java.time.LocalDateTime;

public class EventAmericanFootballFraction {
    private String referrerId;
    private String eventId;
    private String oddId;
    private int platformId;
    private String homeTeam;
    private String awayTeam;
    private BettingType bettingType;
    private String country;
    private String continent;
    private String championship;
    private int bookmakerId;
    private String bookmakerLabel;
    private LocalDateTime startTime;
    private double fh;
    private double fa;
    private int confidence;
    private int ph;
    private int pa;
    private int pbh;
    private int pba;
    private double delta;
    private String bettingOfferIdH;
    private String bettingOfferIdA;

    public BettingType getBettingType() {
        return bettingType;
    }

    public void setBettingType(BettingType bettingType) {
        this.bettingType = bettingType;
    }

    public String getReferrerId() {
        return referrerId;
    }

    public void setReferrerId(String referrerId) {
        this.referrerId = referrerId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public int getPlatformId() {
        return platformId;
    }

    public void setPlatformId(int platformId) {
        this.platformId = platformId;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public String getChampionship() {
        return championship;
    }

    public void setChampionship(String championship) {
        this.championship = championship;
    }

    public int getBookmakerId() {
        return bookmakerId;
    }

    public void setBookmakerId(int bookmakerId) {
        this.bookmakerId = bookmakerId;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public double getFh() {
        return fh;
    }

    public void setFh(double fh) {
        this.fh = fh;
    }

    public double getFa() {
        return fa;
    }

    public String getOddId() {
        return oddId;
    }

    public void setOddId(String oddId) {
        this.oddId = oddId;
    }

    public void setFa(double fa) {
        this.fa = fa;
    }

    public int getPh() {
        return ph;
    }

    public void setPh(int ph) {
        this.ph = ph;
    }

    public int getConfidence() {
        return confidence;
    }

    public void setConfidence(int confidence) {
        this.confidence = confidence;
    }

    public int getPa() {
        return pa;
    }

    public void setPa(int pa) {
        this.pa = pa;
    }

    public int getPbh() {
        return pbh;
    }

    public void setPbh(int pbh) {
        this.pbh = pbh;
    }

    public int getPba() {
        return pba;
    }

    public void setPba(int pba) {
        this.pba = pba;
    }

    public double getDelta() {
        return delta;
    }

    public void setDelta(double delta) {
        this.delta = delta;
    }

    public String getBettingOfferIdH() {
        return bettingOfferIdH;
    }

    public void setBettingOfferIdH(String bettingOfferIdH) {
        this.bettingOfferIdH = bettingOfferIdH;
    }

    public String getBettingOfferIdA() {
        return bettingOfferIdA;
    }

    public void setBettingOfferIdA(String bettingOfferIdA) {
        this.bettingOfferIdA = bettingOfferIdA;
    }

    public String getBookmakerLabel() {
        return bookmakerLabel;
    }

    public void setBookmakerLabel(String bookmakerLabel) {
        this.bookmakerLabel = bookmakerLabel;
    }

    @Override
    public String toString() {
        return "EventAmericanFootballFraction{" +
                "referrerId='" + referrerId + '\'' +
                ", eventId='" + eventId + '\'' +
                ", oddId='" + oddId + '\'' +
                ", platformId=" + platformId +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", bettingType=" + bettingType +
                ", country='" + country + '\'' +
                ", continent='" + continent + '\'' +
                ", championship='" + championship + '\'' +
                ", bookmakerId=" + bookmakerId +
                ", bookmakerLabel='" + bookmakerLabel + '\'' +
                ", startTime=" + startTime +
                ", confidence=" + confidence +
                ", fh=" + fh +
                ", fa=" + fa +
                ", ph=" + ph +
                ", pa=" + pa +
                ", pbh=" + pbh +
                ", pba=" + pba +
                ", delta=" + delta +
                ", bettingOfferIdH='" + bettingOfferIdH + '\'' +
                ", bettingOfferIdA='" + bettingOfferIdA + '\'' +
                '}';
    }
}
