package com.kellify.common.mollybet;

    public class MollyBetLoginResponse {
        private final String token;

        public MollyBetLoginResponse(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }

        @Override
        public String toString() {
            return "MollyBetLoginResponse{" +
                    "token='" + token + '\'' +
                    '}';
        }
    }
