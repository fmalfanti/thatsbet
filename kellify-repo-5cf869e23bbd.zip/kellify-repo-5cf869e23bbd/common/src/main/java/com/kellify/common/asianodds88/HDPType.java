package com.kellify.common.asianodds88;

public enum HDPType {
    HOME(0.5),
    AWAY(-0.5);

    private double numVal;

    HDPType(double numVal) {
        this.numVal = numVal;
    }

    public double getNumVal() {
        return numVal;
    }

    public static double convertFromHDPType(HDPType sportType) {
        switch (sportType) {
            case HOME:
                return HDPType.HOME.getNumVal();
            case AWAY:
                return HDPType.AWAY.getNumVal();
            default:
                return HDPType.HOME.getNumVal();
        }
    }
}
