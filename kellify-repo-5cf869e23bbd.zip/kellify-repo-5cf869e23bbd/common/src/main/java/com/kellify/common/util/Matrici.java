package com.kellify.common.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Matrici {

    public static class HdaMatrix {
        private int H;
        private int D;
        private int A;

        public int getH() {
            return H;
        }

        public void setH(int h) {
            H = h;
        }

        public int getD() {
            return D;
        }

        public void setD(int d) {
            D = d;
        }

        public int getA() {
            return A;
        }

        public void setA(int a) {
            A = a;
        }

        public void add (String ftr) {
            switch (ftr) {
                case "H":
                    H += 1;
                    break;
                case "D":
                    D += 1;
                    break;
                default:
                    A += 1;
                    break;
            }
        }
        public void addweight (String ftr, int num) {
            switch (ftr) {
                case "H":
                    H += 1 * num;
                    break;
                case "D":
                    D += 1 * num;
                    break;
                default:
                    A += 1 * num;
                    break;
            }
        }
        public void addFromString(String mappina) {
            if(mappina != null && mappina.length() > 0) {
                String[] tokens = mappina.split(";");
                H=new Integer(tokens[0]);
                D=new Integer(tokens[1]);
                A=new Integer(tokens[2]);
            }
        }

    }

    public static class WLMatrix {
        private int W=0;
        private int L=0;

        public void add (int pW,int pL) {

            if (pW>pL) {
                W+=1;
            }
            if (pL>pW) {
                L += 1;
            }

        }
        public void addweight (int pW,int pL, int num) {

            if (pW>pL) {
                W+=1 * num;
            }
            if (pL>pW) {
                L += 1 * num;
            }

        }
        public void addFromString(String mappina) {
            if(mappina != null && mappina.length() > 0) {
                String[] tokens = mappina.split(";");
                W=new Integer(tokens[0]);
                L=new Integer(tokens[1]);
            }
        }

        public int getW() {
            return W;
        }

        public void setW(int w) {
            W=w;
        }

        public int getL() {
            return L;
        }

        public void setL(int l) {
            L=l;
        }
    }

    public static class MappaFootball {
        public Map<Integer,HdaMatrix> FMatrici = null;

        public Map<Integer, HdaMatrix> getFMatrici() {
            return FMatrici;
        }

        public void setFMatrici(Map<Integer, HdaMatrix> FMatrici) {
            this.FMatrici = FMatrici;
        }
    }
    public static class MappaHDA {
        public Map<Integer,HdaMatrix> FMatrici = null;

        public Map<Integer, HdaMatrix> getFMatrici() {
            return FMatrici;
        }

        public void setFMatrici(Map<Integer, HdaMatrix> FMatrici) {
            this.FMatrici = FMatrici;
        }
    }

    public static class MappaHA {
        public Map<Integer,HAMatrix> FMatrici = null;

        public Map<Integer, HAMatrix> getFMatrici() {
            return FMatrici;
        }

        public void setFMatrici(Map<Integer, HAMatrix> FMatrici) {
            this.FMatrici = FMatrici;
        }
    }
    public static class MappaWL {
        public Map<Integer,WLMatrix> FMatrici = null;

        public Map<Integer, WLMatrix> getFMatrici() {
            return FMatrici;
        }

        public void setFMatrici(Map<Integer, WLMatrix> FMatrici) {
            this.FMatrici = FMatrici;
        }
    }
    public static String MapToDbHDA(Map<Integer,HdaMatrix> MappaFootball) {
        StringBuilder sb = new StringBuilder();
        for ( int i:MappaFootball.keySet()) {
            sb.append(i).append("=").append(MappaFootball.get(i).getH()).append(";").append(MappaFootball.get(i).getD()).append(";").append(MappaFootball.get(i).getA()).append(":");
        }
        return sb.toString();
    }

    public static String MapToDbWL(Map<Integer,Matrici.WLMatrix> MappaWL) {
        StringBuilder sb = new StringBuilder();
        for ( int i:MappaWL.keySet()) {
            sb.append(i).append("=").append(MappaWL.get(i).getW()).append(";").append(MappaWL.get(i).getL()).append(":");
        }
        return sb.toString();
    }
    public static String MapToDbHA(Map<Integer,Matrici.HAMatrix> MappaHA) {
        StringBuilder sb = new StringBuilder();
        for ( int i:MappaHA.keySet()) {
            sb.append(i).append("=").append(MappaHA.get(i).getH()).append(";").append(MappaHA.get(i).getA()).append(":");
        }
        return sb.toString();
    }

    public static Map<String,Map<Integer,HdaMatrix>> createHDAMapsFromStrings(PreparedStatement psMatrici) throws SQLException {
        Map<String,Map<Integer,HdaMatrix>> MappeFootball = new HashMap<>();
        Map<Integer,HdaMatrix> useNationMap = null;
        HdaMatrix punto = null;
        int indice;
        String nazione, mappa;
        ResultSet rs;

        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione=rs.getString(1);
            mappa=rs.getString(2);
            if (MappeFootball.get(nazione) == null) {
                MappeFootball.put(nazione, new HashMap<>());
            }
            useNationMap=MappeFootball.get(nazione);
            if (mappa != null && mappa.length() > 0) {
                String[] tokens=mappa.split(":");
                int idxEq=0;
                for (String token : tokens) {
                    idxEq=token.indexOf("=");
                    if (idxEq > 0) {
                        //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                        indice=new Integer(token.substring(0, idxEq));
                        punto=useNationMap.get(indice);
                        if (punto == null) {
                            punto=new HdaMatrix();
                        }
                        punto.addFromString(token.substring(idxEq + 1));
                        useNationMap.put(indice, punto);
                    }
                }
            }
        }
        return MappeFootball;
    }



    public static void createFootballMapsFromStrings(Map<String,Map<Integer,HdaMatrix>> MappeFootball, String nazione, String mappa) {
        Map<Integer,HdaMatrix> useNationMap = null;
        HdaMatrix punto = null;
        int indice;
        if (MappeFootball.get(nazione)==null) {
            MappeFootball.put(nazione,new HashMap<>());
        }
        useNationMap=MappeFootball.get(nazione);
        if(mappa != null && mappa.length() > 0) {
            String[] tokens = mappa.split(":");
            int idxEq = 0;
            for(String token : tokens) {
                idxEq = token.indexOf("=");
                if(idxEq > 0) {
                    //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                    indice=new Integer(token.substring(0,idxEq));
                    punto=useNationMap.get(indice);
                    if (punto==null) {
                        punto=new HdaMatrix();
                    }
                    punto.addFromString(token.substring(idxEq+1));
                    useNationMap.put(indice,punto);
                }
            }
        }

    }

    public static Map<Integer,Matrici.WLMatrix> createWLMapsFromStrings(PreparedStatement psMatrici) throws SQLException  {
        Map<Integer,Matrici.WLMatrix> MappaWL = new HashMap();
        String mappa;
        String nazione;
        Matrici.WLMatrix punto;
        int indice;
        ResultSet rs;

        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione=rs.getString(1);
            mappa=rs.getString(2);
            if (mappa != null && mappa.length() > 0) {
                String[] tokens=mappa.split(":");
                int idxEq=0;
                for (String token : tokens) {
                    idxEq=token.indexOf("=");
                    if (idxEq > 0) {
                        //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                        indice=new Integer(token.substring(0, idxEq));
                        punto=MappaWL.get(indice);
                        if (punto == null) {
                            punto=new Matrici.WLMatrix();
                        }
                        punto.addFromString(token.substring(idxEq + 1));
                        MappaWL.put(indice, punto);
                    }
                }
            }
        }
        return MappaWL;
    }

    public static void createHAMapsFromStrings(Map<Integer,Matrici.HAMatrix> MappaHA,String mappa) {

        Matrici.HAMatrix punto = null;
        int indice;


        if(mappa != null && mappa.length() > 0) {
            String[] tokens = mappa.split(":");
            int idxEq = 0;
            for(String token : tokens) {
                idxEq = token.indexOf("=");
                if(idxEq > 0) {
                    //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                    indice=new Integer(token.substring(0,idxEq));
                    punto=MappaHA.get(indice);
                    if (punto==null) {
                        punto=new Matrici.HAMatrix();
                    }
                    punto.addFromString(token.substring(idxEq+1));
                    MappaHA.put(indice,punto);
                }
            }
        }

    }

    public static class HAMatrix {
        private int H=0;
        private int A=0;

        public void add (String ftr) {
            switch (ftr) {
                case "H":
                    H += 1;
                    break;
                case "A":
                    A += 1;
                    break;
            }

        }

        public void addFromString(String mappina) {
            if(mappina != null && mappina.length() > 0) {
                String[] tokens = mappina.split(";");
                H=new Integer(tokens[0]);
                A=new Integer(tokens[1]);
            }
        }
        public int getH() { return H; }
        public void setH(int h) {H = h; }

        public int getA() {
            return A;
        }

        public void setA(int a) {
            A = a;
        }


    }
}
