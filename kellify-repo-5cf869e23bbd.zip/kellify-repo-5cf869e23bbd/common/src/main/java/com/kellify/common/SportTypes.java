package com.kellify.common;

public enum SportTypes {
    FOOTBALL(1),
    TENNIS(2),
    BASKET(3),
    ICE_HOCKEY(4),
    BASEBALL(5),
    AMERICAN_FOOTBALL(6),
    ICE_HOCKEY_HDA(7),
    MMA(8),
    BOX(9),
    GOLF(10);

    private int numVal;

    SportTypes(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static SportTypes getEnum(int numVal) {
        switch(numVal) {
            case 1:
                return SportTypes.FOOTBALL;
            case 2:
                return SportTypes.TENNIS;
            case 3:
                return SportTypes.BASKET;
            case 4:
                return SportTypes.ICE_HOCKEY;
            case 5:
                return SportTypes.BASEBALL;
            case 6:
                return SportTypes.AMERICAN_FOOTBALL;
            case 7:
                return SportTypes.ICE_HOCKEY_HDA;
            case 8:
                return SportTypes.MMA;
            case 9:
                return SportTypes.BOX;
            case 10:
                return SportTypes.GOLF;
            default:
                throw new IllegalArgumentException();
        }
    }
    public static String getStringEnum(int numVal) {
        switch(numVal) {
            case 1:
                return "football";
            case 2:
                return "tennis";
            case 3:
                return "basket";
            case 4:
                return "icehockey";
            case 5:
                return "baseball";
            case 6:
                return "americanfootball";
            case 7:
                return "icehockeyhda";
            case 8:
                return "mma";
            case 9:
                return "box";
            case 10:
                return "golf";
            default:
                throw new IllegalArgumentException();
        }
    }
}
