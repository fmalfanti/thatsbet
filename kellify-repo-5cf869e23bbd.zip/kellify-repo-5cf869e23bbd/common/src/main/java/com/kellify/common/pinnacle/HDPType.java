package com.kellify.common.pinnacle;

public enum HDPType {
    HOME(0.5),
    AWAY(-0.5),
    REFUND(0);

    private double numVal;

    HDPType(double numVal) {
        this.numVal = numVal;
    }

    public double getNumVal() {
        return numVal;
    }

    public static double convertFromHDPType(HDPType sportType) {
        switch(sportType) {
            case HOME:
                return HDPType.HOME.getNumVal();
            case AWAY:
                return HDPType.AWAY.getNumVal();
            case REFUND:
                return HDPType.REFUND.getNumVal();
            default:
                return HDPType.HOME.getNumVal();
        }
    }
}
