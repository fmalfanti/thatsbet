package com.kellify.common;

public enum BettingType {
    HOME_DRAW_AWAY(1),
    HOME_AWAY(2),
    OVER_UNDER(3),
    ASIAN_HDP(4);

    private int numVal;

    BettingType(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public static BettingType getEnum(int numVal) {
        switch(numVal) {
            case 1:
                return BettingType.HOME_DRAW_AWAY;
            case 2:
                return BettingType.HOME_AWAY;
            case 3:
                return BettingType.OVER_UNDER;
            case 4:
                return BettingType.ASIAN_HDP;
            default:
                throw new IllegalArgumentException();
        }

    }
}
