package com.kellify.common.matchbook.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;

public class MatchBookLoginErrorHandler implements ResponseErrorHandler {
    private HttpStatus statusCode = HttpStatus.OK;

    @Override
    public boolean hasError(ClientHttpResponse clientHttpResponse) throws IOException {
        return clientHttpResponse.getStatusCode() == HttpStatus.OK;
    }

    @Override
    public void handleError(ClientHttpResponse clientHttpResponse) throws IOException {
        statusCode = clientHttpResponse.getStatusCode();
    }

    public HttpStatus getStatusCode() {
        return statusCode;
    }
}
