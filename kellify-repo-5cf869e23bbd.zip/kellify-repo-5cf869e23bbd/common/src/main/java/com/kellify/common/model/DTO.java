package com.kellify.common.model;

import com.kellify.common.util.DTOType;

public class DTO {
    protected final double homeMin;
    protected final double homeMax;
    protected final double awayMin;
    protected final double awayMax;
    protected String country;
    protected final DTOType dtoType;

    public DTO(double homeMin, double homeMax, double awayMin, double awayMax, String country,DTOType dtoType) {
        this.homeMin = homeMin;
        this.homeMax = homeMax;
        this.awayMin = awayMin;
        this.awayMax = awayMax;
        this.country = country;
        this.dtoType = dtoType;
    }

    public double getHomeMin() {
        return homeMin;
    }

    public double getHomeMax() {
        return homeMax;
    }

    public double getAwayMin() {
        return awayMin;
    }

    public double getAwayMax() {
        return awayMax;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "DTO{" +
                "homeMin=" + homeMin +
                ", homeMax=" + homeMax +
                ", awayMin=" + awayMin +
                ", awayMax=" + awayMax +
                ", type=" + dtoType.getNumVal() +
                ", country='" + country + '\'' +
                '}';
    }
}
