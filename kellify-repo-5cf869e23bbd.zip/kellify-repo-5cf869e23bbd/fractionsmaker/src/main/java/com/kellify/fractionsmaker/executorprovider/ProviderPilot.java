package com.kellify.fractionsmaker.executorprovider;

import com.kellify.common.SportTypes;
import com.kellify.fractionsmaker.common.ChampionshipDecode;

import java.sql.SQLException;
import java.util.Map;

public interface ProviderPilot {
    void init() throws SQLException;
    Map<String, ?> pilotMatches(SportTypes sportType) throws SQLException;
    Map<String, Integer> bettingTypeDecodeMap();
    Map<String, ChampionshipDecode> championshipDecodeMap(SportTypes sportType) throws SQLException;
    void createOddsSnapshot() throws SQLException;
}
