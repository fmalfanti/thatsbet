package com.kellify.fractionsmaker.aggregation;


import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;
import com.kellify.fractionsmaker.oddreduce.ProbabiltyMapImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class FootballAggregationImpl implements FootballAggregation{
    private static final Logger logger = LoggerFactory.getLogger(ProbabiltyMapImpl.class);

    private final Map<String, List<FootballBookmakerOdd>> entities;
    private final DbUbibetterConnector ubibetterConnector;

    FootballAggregationImpl(Map<String, List<FootballBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        this.entities = entities;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public FootballProbabilitiesResult evaluateDb(FootballDTO params) throws SQLException {
        FootballProbabilitiesResult result=null;
        result = ubibetterConnector.getFTR(params);
        return result;
    }
    @Override
    public FootballProbabilitiesResult evaluateOddDb(FootballDTO params) throws SQLException {
        FootballProbabilitiesResult result=null;
        result = ubibetterConnector.getFTR(params);
        return result;
    }
    @Override
    public FootballProbabilitiesResult evaluateKnn(FootballDTO params, Map<String,Map<Integer,Matrici.HdaMatrix>> MappaHDA) {
        int hh=0,aa=0,dd=0;
        int knn=10000;
        int count=0;
        int confidence=5;
        String[] parametri={params.getCountry(), params.getContinent(), "World"};
        Matrici.HdaMatrix punto;
        Map<Integer, Matrici.HdaMatrix> useNationMap;
        int ma=(int)(100*(params.getAwayMax()+params.getAwayMin())/2.0);
        int mh=(int)(100*(params.getHomeMax()+params.getHomeMin())/2.0);

        for (String parametro : parametri) {
            if (count < knn) {
                useNationMap= MappaHDA.get(parametro);
                if (useNationMap != null) {
                    for (int ind=0; ind < 4; ind++) {
                        confidence-=ind;
                        hh=0;
                        aa=0;
                        dd=0;
                        for (int i=mh - ind; i <= mh + ind; i++) {
                            for (int j=ma - ind; j <= ma + ind; j++) {
                                punto=useNationMap.get(i * 101 + j);
                                if (punto != null) {
                                    hh += punto.getH();
                                    dd += punto.getD();
                                    aa += punto.getA();
                                }
                            }
                        }
                        count=hh+dd+aa;
                        if (count >= knn) {
                            ind=5;
                        }
                    }
                }
            }
        }
        //System.out.println("count="+count);
        return new FootballProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());
    }
    @Override
    public FootballProbabilitiesResult evaluateMatrix(FootballDTO params, Map<String,Map<Integer,Matrici.HdaMatrix>> MappaHDA){
        int hh=0,aa=0,dd=0;
        FootballProbabilitiesResult result=null;
        int count=0;
        int confidence=7;
        String[] parametri={params.getCountry(), params.getContinent(),"World"};
        Matrici.HdaMatrix punto;
        Map<Integer,Matrici.HdaMatrix> useNationMap;

        for (String parametro:parametri) {
            confidence-=2;
            if (count <= 10) {
                hh=0;
                aa=0;
                dd=0;
                useNationMap= MappaHDA.get(parametro);
                if (useNationMap != null) {
                    for (int i=(int) (100 * params.getHomeMin()); i <= 100 * params.getHomeMax(); i++) {
                        for (int j=(int) (100 * params.getAwayMin()); j <= 100 * params.getAwayMax(); j++) {

                            punto=useNationMap.get(i * 101 + j);
                            if (punto != null) {
                                hh+=punto.getH();
                                dd+=punto.getD();
                                aa+=punto.getA();
                            }
                        }
                    }
                }
                count=hh+dd+aa;
            }
        }
        //System.out.println("count="+count);
        return new FootballProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());

    }

    @Override
    public FootballProbabilitiesResult evaluateMatrixPerBookmaker(FootballDTO params, List<double[]> homeAwayProbabilityList, Map<String, Map<Integer, Matrici.HdaMatrix>> MappaHDA) {
        int hh=0,aa=0,dd=0;
        int count=0;
        int confidence=7;
        String[] parametri={params.getCountry(), params.getContinent(),"World"};
        Matrici.HdaMatrix punto;
        Map<Integer,Matrici.HdaMatrix> useNationMap;
        int home = 0;
        int away = 0;
        for (String parametro:parametri) {
            confidence-=2;
            if (count <= 10) {
                hh=0;
                aa=0;
                dd=0;
                useNationMap= MappaHDA.get(parametro);
                if (useNationMap != null) {
                    for(double[] homeProbability : homeAwayProbabilityList) {
                        home = (int)(homeProbability[0] * 100);
                        away = (int)(homeProbability[1] * 100);
                        punto = useNationMap.get(home * 101 + away);
                        if (punto != null) {
                            hh+=punto.getH();
                            dd+=punto.getD();
                            aa+=punto.getA();
                        }
                    }
                }
                count=hh+dd+aa;
            }
        }
        //System.out.println("count="+count);
        return new FootballProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());

    }
}
