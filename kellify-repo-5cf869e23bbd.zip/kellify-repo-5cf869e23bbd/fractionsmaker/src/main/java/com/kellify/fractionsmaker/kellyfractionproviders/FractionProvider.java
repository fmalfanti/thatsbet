package com.kellify.fractionsmaker.kellyfractionproviders;

import java.sql.SQLException;

public interface FractionProvider {
    void execute() throws SQLException;
}
