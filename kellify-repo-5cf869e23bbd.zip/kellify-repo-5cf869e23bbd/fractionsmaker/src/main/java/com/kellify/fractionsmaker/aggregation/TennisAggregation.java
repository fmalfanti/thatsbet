package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.tennis.TennisDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.model.tennis.TennisProbabilitiesResult;

import java.sql.SQLException;
import java.util.Map;

public interface TennisAggregation {
    TennisProbabilitiesResult evaluateDb(TennisDTO params) throws SQLException;
    TennisProbabilitiesResult evaluateKnn(TennisDTO params, Map<Integer, Matrici.WLMatrix> MappaWL);
    TennisProbabilitiesResult evaluateMatrix(TennisDTO params, Map<Integer, Matrici.WLMatrix> MappaWL);
}
