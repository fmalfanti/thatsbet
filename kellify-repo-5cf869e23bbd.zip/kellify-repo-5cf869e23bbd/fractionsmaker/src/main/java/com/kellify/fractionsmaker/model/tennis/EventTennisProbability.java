package com.kellify.fractionsmaker.model.tennis;


import com.kellify.fractionsmaker.model.EventProbability;

public class EventTennisProbability extends EventProbability {
    public EventTennisProbability(String eventId, double confidence, double home, double away) {
        super(eventId, confidence, home, away);
    }

    @Override
    public String toString() {
        return "EventTennisProbability{" +
                "eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
