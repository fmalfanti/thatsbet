package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.americanfootball.EventAmericanFootballProbability;
import com.kellify.fractionsmaker.model.baseball.EventBaseballProbability;
import com.kellify.fractionsmaker.model.basket.EventBasketProbability;
import com.kellify.fractionsmaker.model.football.EventFootballProbability;
import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHAProbability;
import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHDAProbability;
import com.kellify.fractionsmaker.model.tennis.EventTennisProbability;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface ProbabilityMap {
    Map<String, EventFootballProbability> footballReduce(Map<String, List<FootballBookmakerOdd>> entities) throws SQLException;
    Map<String, EventTennisProbability> tennisReduce(Map<String, List<TennisBookmakerOdd>> entities) throws SQLException;
    Map<String, EventBasketProbability> basketReduce(Map<String, List<BasketBookmakerOdd>> entities) throws SQLException;
    Map<String, EventBaseballProbability> baseballReduce(Map<String, List<BaseballBookmakerOdd>> entities) throws SQLException;
    Map<String, EventAmericanFootballProbability> americanfootballReduce(Map<String, List<AmericanFootballBookmakerOdd>> entities) throws SQLException;
    Map<String, EventIceHockeyHAProbability> iceHockeyHaReduce(Map<String, List<IceHockeyBookmakerOdd>> entities) throws SQLException;
    Map<String, EventIceHockeyHDAProbability> iceHockeyHdaReduce(Map<String, List<IceHockeyBookmakerOdd>> entities) throws SQLException;
    static ProbabilityMap getReducer(DbUbibetterConnector ubibetterConnector) {
        return new ProbabiltyMapImpl(ubibetterConnector);
    }
}
