package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;

import java.util.List;
import java.util.Map;

public class Aggregation {
    private Aggregation() {}

    public static FootballAggregation getFootballInstance(Map<String, List<FootballBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new FootballAggregationImpl(entities, ubibetterConnector);
    }

    public static TennisAggregation getTennisInstance(Map<String, List<TennisBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new TennisAggregationImpl(entities, ubibetterConnector);
    }

    public static BasketAggregation getBasketInstance(Map<String, List<BasketBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new BasketAggregationImpl(entities, ubibetterConnector);
    }
    public static BaseballAggregation getBaseballInstance(Map<String, List<BaseballBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new BaseballAggregationImpl(entities, ubibetterConnector);
    }
    public static IceHockeyHAAggregation getIceHockeyHAInstance(Map<String, List<IceHockeyBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new IceHockeyHAAggregationImpl(entities, ubibetterConnector);
    }
    public static IceHockeyHDAAggregation getIceHockeyHDAInstance(Map<String, List<IceHockeyBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new IceHockeyHDAAggregationImpl(entities, ubibetterConnector);
    }
    public static AmericanFootballAggregation getAmericanFootballInstance(Map<String, List<AmericanFootballBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        return new AmericanFootballAggregationImpl(entities, ubibetterConnector);
    }
}
