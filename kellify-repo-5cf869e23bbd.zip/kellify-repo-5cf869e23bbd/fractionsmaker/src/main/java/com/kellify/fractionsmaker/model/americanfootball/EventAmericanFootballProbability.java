package com.kellify.fractionsmaker.model.americanfootball;

import com.kellify.fractionsmaker.model.EventProbability;

public class EventAmericanFootballProbability  extends EventProbability {
    public EventAmericanFootballProbability(String eventId, double confidence, double home, double away) {
        super(eventId, confidence, home, away);
    }

    @Override
    public String toString() {
        return "EventAmericanFootballProbability{" +
                "eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
