package com.kellify.fractionsmaker.common;

public enum MatchDecodeState {
    OK,
    NOT_DECODED,
    NOT_IN_MAP,
    NOT_SAME_ROLE
}
