package com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot;

import com.kellify.common.SportTypes;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.PilotFractionProvider;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.americanfootball.EventAmericanFootballProbability;
import com.kellify.fractionsmaker.oddreduce.ProbabilityMap;
import com.kellify.fractionsmaker.oddreduce.ProbabilityMapFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class BetBrainAmericanFootballPilotFraction implements PilotFractionProvider {
    private static final Logger logger = LoggerFactory.getLogger(BetBrainAmericanFootballPilotFraction.class);

    private final DbBettingUserConnector bettingUserConnector;
    private final DbUbibetterConnector ubibetterConnector;

    public BetBrainAmericanFootballPilotFraction(DbBettingUserConnector bettingUserConnector, DbUbibetterConnector ubibetterConnector) {
        this.bettingUserConnector = bettingUserConnector;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public Map<String, ? extends EventProbability> probabilityMap() throws SQLException {
        Map<String, List<AmericanFootballBookmakerOdd>>americanfootballEntitiesForProbabilities = bettingUserConnector.loadAmericanFootballEntitiesForProbabilities();
        ProbabilityMapFilter filter = new ProbabilityMapFilter<>(americanfootballEntitiesForProbabilities);
        americanfootballEntitiesForProbabilities = filter.filter();

        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventAmericanFootballProbability> americanFootballProbabilityMap = oddReducer.americanfootballReduce(americanfootballEntitiesForProbabilities);
        logger.debug("americanFootballProbabilityMap:" + americanFootballProbabilityMap);
        return americanFootballProbabilityMap;
    }

    @Override
    public SportTypes sport() {
        return SportTypes.AMERICAN_FOOTBALL;
    }
}
