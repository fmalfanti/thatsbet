package com.kellify.fractionsmaker.model;

import com.kellify.common.BettingType;

import java.time.LocalDateTime;

public class MatchWithContinent extends Match {

    protected String continent;

    public MatchWithContinent(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType);
        this.leagueName = leagueName;
    }

    public MatchWithContinent(String id, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, String referrerId, String country, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType);
        this.country = country;
        this.leagueName = leagueName;
    }


    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }


    @Override
    public String toString() {
        return "MatchWithContinent{" +
                "continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
