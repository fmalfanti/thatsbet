package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyHDADTO;
import com.kellify.common.util.DTOType;
import com.kellify.common.util.GenericUtils;
import com.kellify.common.util.Matrici;

import com.kellify.fractionsmaker.aggregation.IceHockeyHDAAggregation;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHDAProbability;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHdaProbabilitiesResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class IceHockeyHdaEventProbabilityMakerImlp implements  EventProbabilityMaker {
    private static final Logger logger = LoggerFactory.getLogger(IceHockeyHdaEventProbabilityMakerImlp.class);

    private final Map.Entry<String, List<IceHockeyBookmakerOdd>> mapEntry;
    private final Map<String,Map<Integer,Matrici.HdaMatrix>> mappaHDA;
    private final IceHockeyHDAAggregation iceHockeyHDAAggregation;

    public IceHockeyHdaEventProbabilityMakerImlp(Map.Entry<String, List<IceHockeyBookmakerOdd>> mapEntry, Map<String, Map<Integer, Matrici.HdaMatrix>> mappaHDA, IceHockeyHDAAggregation iceHockeyHDAAggregation) {
        this.mapEntry = mapEntry;
        this.mappaHDA = mappaHDA;
        this.iceHockeyHDAAggregation = iceHockeyHDAAggregation;
    }

    @Override
    public EventProbability buildEventProbability() throws SQLException {
        double hmin = 1000;
        double amin = 1000;
        double dmin = 1000;
        double hmax = 0;
        double amax = 0;
        double dmax = 0;
        double hmaxInf;
        double hminSup;
        double amaxInf;
        double aminSup;
        double dmaxInf;
        double dminSup;
        double Adistance;
        double Ddistance;
        double Hdistance;
        int first;
        int second;
        int third;
        int limitFuoriSoglia = 0;
        double percLimitFuoriSoglia = 0.1;
        double a = 0;
        double h = 0;
        double d = 0;
        double ct = 0;
        double pa, ph, pd, pb;
        String country = null;
        String continent = null;
        List<double[]> homeAwayProbabilityList = new ArrayList<>();
        List<double[]> homeDrawAwayProbabilityList = new ArrayList<>();
        IceHockeyHDADTO params = null;

        IceHockeyHdaProbabilitiesResult resultKnn = null;
        IceHockeyHdaProbabilitiesResult resultDb = null;
        IceHockeyHdaProbabilitiesResult resultMatrix = null;


        for (IceHockeyBookmakerOdd entity : mapEntry.getValue()) {
            country = entity.getCountry();
            continent = entity.getContinent();
            switch (entity.getRole()) {
                case HOME:
                    h = entity.getOdd();
                    break;
                case AWAY:
                    a = entity.getOdd();
                    break;
                default:
                    d = entity.getOdd();
                    break;
            }
            if ((a * h * d) > 0) {
                pa = 1.0 / a;
                ph = 1.0 / h;
                pd = 1.0 / d;
                pb = pa + ph + pd;
                pa /= pb;
                ph /= pb;
                pd /= pb;
                amax = Math.max(amax, pa);
                amin = Math.min(amin, pa);
                hmax = Math.max(hmax, ph);
                hmin = Math.min(hmin, ph);
                dmax = Math.max(dmax, pd);
                dmin = Math.min(dmin, pd);
                homeAwayProbabilityList.add(new double[]{ph, pa});
                homeDrawAwayProbabilityList.add(new double[]{ph, pd, pa});
                a = h = d = 0;
            }

        }
        limitFuoriSoglia = (int) (homeDrawAwayProbabilityList.size() * percLimitFuoriSoglia);
        first = second = third = 0;
        hminSup = hmin * 1.1;
        hmaxInf = hmax * 0.9;
        Hdistance = (hmax - hmin) / hmax;
        Iterator<double[]> it = null;
        double[] element;
        boolean toRemove = true;
        if (Hdistance > 0.1) {
            //logger.debug(" hmin=" + hmin + "and hmax=" + hmax + "hminSup" + hminSup + " hmaxInf" + hmaxInf);
            it = homeDrawAwayProbabilityList.iterator();
            while (it.hasNext()) {
                element = it.next();
                //System.out.println(element[0] + " hmin=" + hmin + " and hmax=" + hmax + "and hminSup" + hminSup + "and hmaxInf " + hmaxInf + "fuorisoglia" + fuorisoglia);
                if (element[0] < hmaxInf) {
                    first++;
                    continue;
                }
                if (element[0] > hmaxInf && element[0] < hminSup) {
                    second++;
                    continue;
                }
                if (element[0] > hminSup) {
                    third++;
                    continue;
                }
            }

            if (first + second <= limitFuoriSoglia) {
                hmin = hminSup;
                toRemove = false;
            }
            if (first + third <= limitFuoriSoglia) {
                hmax = hminSup;
                hmin = hmaxInf;
                toRemove = false;
            }
            if (second + third <= limitFuoriSoglia) {
                hmax = hmaxInf;
                toRemove = false;
            }
            //logger.debug("DOPO hmin=" + hmin + "and hmax=" + hmax + "hminSup" + hminSup + " hmaxInf" + hmaxInf);
            if (toRemove) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Match icehochey_hda removed");
                    return null;
                }
            }

        }

        dminSup = dmin * 1.1;
        dmaxInf = dmax * 0.9;
        first = second = third = 0;
        Ddistance = (dmax - dmin) / dmax;
        toRemove = true;
        it = homeDrawAwayProbabilityList.iterator();
        while (it.hasNext()) {
            element = it.next();
            if (Ddistance > 0.1) {
                logger.debug(" dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                if (element[1] < dmaxInf) {
                    first++;
                    continue;
                }
                if (element[1] > dmaxInf && element[0] < dminSup) {
                    second++;
                    continue;
                }
                if (element[1] >dminSup ) {
                    third++;
                    continue;
                }
            }
            if (first + second <= limitFuoriSoglia) {
                dmin = dminSup;
                //logger.debug("DOPO first + second dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                toRemove = false;
            }
            if (first + third <= limitFuoriSoglia) {
                dmax = dminSup;
                dmin = dmaxInf;
                //logger.debug("DOPO first + third  dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                toRemove = false;
            }
            if (second + third <= limitFuoriSoglia) {
                dmax = dmaxInf;
                //logger.debug("DOPO second + third dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                toRemove = false;
            }
            //logger.debug("DOPO dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
            if (toRemove) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Match icehochey_hda removed");
                    return null;
                }
            }

        }
        aminSup = amin * 1.1;
        amaxInf = amax * 0.9;
        first = second = third = 0;
        toRemove = true;
        it = homeDrawAwayProbabilityList.iterator();
        Adistance = (amax - amin) / amax;
        while (it.hasNext()) {
            element = it.next();
            if (Adistance > 0.1) {
                //logger.debug(" amin=" + amin + "and amax=" + amax + "aminSup" + aminSup + " amaxInf" + amaxInf);
                if (element[2] < amaxInf ) {
                    first++;
                    continue;
                }
                if (element[2] > aminSup) {
                    third++;
                    continue;
                }
                if (element[2] > amaxInf && element[0] < aminSup) {
                    third++;
                    continue;
                }
            }
            if (first + second <= limitFuoriSoglia) {
                amin = aminSup;
                toRemove = false;
            }
            if (first + third <= limitFuoriSoglia) {
                amax = aminSup;
                amin = amaxInf;
                toRemove = false;
            }
            if (second + third <= limitFuoriSoglia) {
                amax = hmaxInf;
                toRemove = false;
            }
            //logger.debug("DOPO amin=" + amin + "and amax=" + amax + "aminSup" + aminSup + " amaxInf" + amaxInf);
            if (toRemove) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Match icehochey_hda removed");
                    return null;
                }
            }

        }
//            hmin =dmin= amin = 1000;
//            hmax =dmax= amax = 0;
//            for(int i=0;i<homeDrawAwayProbabilityList.size();i++) {
//                amax=Math.max(amax,homeDrawAwayProbabilityList.get(i)[2]);
//                amin=Math.min(amin,homeDrawAwayProbabilityList.get(i)[2]);
//                hmax=Math.max(hmax,homeDrawAwayProbabilityList.get(i)[0]);
//                hmin=Math.min(hmin,homeDrawAwayProbabilityList.get(i)[0]);
//                dmax=Math.max(dmax,homeDrawAwayProbabilityList.get(i)[1]);
//                dmin=Math.min(dmin,homeDrawAwayProbabilityList.get(i)[1]);
//            }

        amax = ((int) Math.ceil(amax * 100.)) / 100.;
        amin = ((int) Math.floor(amin * 100.)) / 100.;
        dmax = ((int) Math.ceil(dmax * 100.)) / 100.;
        dmin = ((int) Math.floor(dmin * 100.)) / 100.;
        hmax = ((int) Math.ceil(hmax * 100.)) / 100.;
        hmin = ((int) Math.floor(hmin * 100.)) / 100.;
        if (logger.isDebugEnabled()) {
            logger.debug(GenericUtils.getMatchTeams(mapEntry.getValue()) + " - hmin:" + hmin + ", hmax:" + hmax + ", amin:" + amin + ", amax:" + amax + ", dmin:" + dmin + ", dmax:" + dmax + ", homeDrawAwayProbabilityList:" + homeDrawAwayProbabilityList.size());
        }

        params = new IceHockeyHDADTO(hmin, hmax, amin, amax, dmin, dmax, country, DTOType.PROBABILITY, continent);

        resultDb = iceHockeyHDAAggregation.evaluateDb(params);
        resultKnn = iceHockeyHDAAggregation.evaluateKnn(params, mappaHDA);
        resultMatrix = iceHockeyHDAAggregation.evaluateMatrix(params, mappaHDA);
        //logger.debug("resultMatrixPerBookmaker:" + resultMatrixPerBookmaker + ", resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix);
        logger.debug("icehockeyHDA resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix + ", resultDb:" + resultDb);
        double aa =  resultKnn.getAway() + resultMatrix.getAway() + resultDb.getAway();
        double dd =  resultKnn.getDraw() + resultMatrix.getDraw() + resultDb.getDraw();
        double hh = resultKnn.getHome() + resultMatrix.getHome() + resultDb.getHome();
        double confidence = ( resultKnn.getConfidence() + resultMatrix.getConfidence() + resultDb.getConfidence()) / 3;
//            logger.debug("football resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix+ ", resultDb:" + resultDb);
//            double aa = resultKnn.getAway() + resultMatrix.getAway()+ resultDb.getAway();
//            double dd = resultKnn.getDraw() + resultMatrix.getDraw()+resultDb.getDraw();
//            double hh =  resultKnn.getHome() + resultMatrix.getHome()+resultDb.getHome();
//            double confidence = ( resultKnn.getConfidence() + resultMatrix.getConfidence()+ resultDb.getConfidence())/3;

        ct = aa + dd + hh;
        if (ct > 100) {

            pa = aa / ct;
            pd = dd / ct;
            ph = hh / ct;
            if (logger.isDebugEnabled()) {
                logger.debug(GenericUtils.getMatchTeams(mapEntry.getValue()) + " - ct:" + ct + ", pa:" + pa + ", pd:" + pd + ", ph:" + ph);
            }
            return new EventIceHockeyHDAProbability(mapEntry.getKey(), confidence, ph, pa, pd);
        }
        return null;
    }
}
