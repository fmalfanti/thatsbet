package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.model.iceHockey.IceHockeyHDADTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHdaProbabilitiesResult;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface IceHockeyHDAAggregation {
    IceHockeyHdaProbabilitiesResult evaluateDb(IceHockeyHDADTO params) throws SQLException;
    IceHockeyHdaProbabilitiesResult evaluateOddDb(IceHockeyHDADTO params) throws SQLException;
    IceHockeyHdaProbabilitiesResult evaluateKnn(IceHockeyHDADTO params, Map<String, Map<Integer, Matrici.HdaMatrix>> MappaHDA);
    IceHockeyHdaProbabilitiesResult evaluateMatrix(IceHockeyHDADTO params, Map<String, Map<Integer, Matrici.HdaMatrix>> MappaHDA);
}
