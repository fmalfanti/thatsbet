package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.util.DTOType;
import com.kellify.common.util.GenericUtils;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.aggregation.FootballAggregation;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.football.EventFootballProbability;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FootballEventProbabilityMakerImpl implements  EventProbabilityMaker {
    private static final Logger logger = LoggerFactory.getLogger(FootballEventProbabilityMakerImpl.class);

    private final Map.Entry<String, List<FootballBookmakerOdd>> mapEntry;
    private final Map<String,Map<Integer,Matrici.HdaMatrix>> mappeFootball;
    private final Map<String,Map<Integer,Matrici.HdaMatrix>> mappeFootballWeight;
    private final FootballAggregation footballAggregation;

    public FootballEventProbabilityMakerImpl(Map.Entry<String, List<FootballBookmakerOdd>> mapEntry, Map<String, Map<Integer, Matrici.HdaMatrix>> mappeFootball, Map<String, Map<Integer, Matrici.HdaMatrix>> mappeFootballWeight, FootballAggregation footballAggregation) {
        this.mapEntry = mapEntry;
        this.mappeFootball = mappeFootball;
        this.mappeFootballWeight = mappeFootballWeight;
        this.footballAggregation = footballAggregation;
    }

    @Override
    public EventProbability buildEventProbability() throws SQLException {
        double hmin = 1000;
        double amin = 1000;
        double dmin = 1000;
        double hmax = 0;
        double amax = 0;
        double dmax = 0;
        double hmaxInf;
        double hminSup;
        double amaxInf;
        double aminSup;
        double dmaxInf;
        double dminSup;
        double Adistance;
        double Ddistance;
        double Hdistance;
        int first;
        int second;
        int third;
        int limitFuoriSoglia = 0;
        double percLimitFuoriSoglia = 0.1;
        double a = 0;
        double h = 0;
        double d = 0;
        double ct = 0;
        double pa, ph, pd, pb;
        String country = null;
        String continent = null;
        List<double[]> homeAwayProbabilityList = new ArrayList<>();
        List<double[]> homeDrawAwayProbabilityList = new ArrayList<>();
        FootballDTO params = null;
        FootballProbabilitiesResult resultMatrixPerBookmaker = null;

        FootballProbabilitiesResult resultKnn = null;
        FootballProbabilitiesResult resultDb = null;
        FootballProbabilitiesResult resultMatrix = null;
        FootballProbabilitiesResult resultMatrixWeight = null;


        for (FootballBookmakerOdd entity : mapEntry.getValue()) {
            country = entity.getCountry();
            continent = entity.getContinent();
            switch (entity.getRole()) {
                case HOME:
                    h = entity.getOdd();
                    break;
                case AWAY:
                    a = entity.getOdd();
                    break;
                default:
                    d = entity.getOdd();
                    break;
            }
            if ((a * h * d) > 0) {
                pa = 1.0 / a;
                ph = 1.0 / h;
                pd = 1.0 / d;
                pb = pa + ph + pd;
                pa /= pb;
                ph /= pb;
                pd /= pb;
                amax = Math.max(amax, pa);
                amin = Math.min(amin, pa);
                hmax = Math.max(hmax, ph);
                hmin = Math.min(hmin, ph);
                dmax = Math.max(dmax, pd);
                dmin = Math.min(dmin, pd);
                homeAwayProbabilityList.add(new double[]{ph, pa});
                homeDrawAwayProbabilityList.add(new double[]{ph, pd, pa});
                a = h = d = 0;
            }

        }
        limitFuoriSoglia = (int) (homeDrawAwayProbabilityList.size() * percLimitFuoriSoglia);
        first = second = third = 0;
        hminSup = hmin * 1.1;
        hmaxInf = hmax * 0.9;
        Hdistance = (hmax - hmin) / hmax;
        Iterator<double[]> it = null;
        double[] element;
        boolean toRemove = true;
        if (Hdistance > 0.1) {
            it = homeDrawAwayProbabilityList.iterator();
            while (it.hasNext()) {
                element = it.next();
                if (element[0] < hmaxInf) {
                    first++;
                    continue;
                }
                if (element[0] > hmaxInf && element[0] < hminSup) {
                    second++;
                    continue;
                }
                if (element[0] > hminSup) {
                    third++;
                    continue;
                }
            }

            if (first + second <= limitFuoriSoglia) {
                hmin = hminSup;
                toRemove = false;
            }
            if (first + third <= limitFuoriSoglia) {
                hmax = hminSup;
                hmin = hmaxInf;
                toRemove = false;
            }
            if (second + third <= limitFuoriSoglia) {
                hmax = hmaxInf;
                toRemove = false;
            }
            if (toRemove) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Match football removed");
                }
                return null;
            }

        }
        dminSup = dmin * 1.1;
        dmaxInf = dmax * 0.9;
        first = second = third = 0;
        Ddistance = (dmax - dmin) / dmax;
        toRemove = true;
        it = homeDrawAwayProbabilityList.iterator();
        while (it.hasNext()) {
            element = it.next();
            if (Ddistance > 0.1) {
                logger.debug(" dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                if (element[1] < dmaxInf) {
                    first++;
                    continue;
                }
                if (element[1] > dmaxInf && element[0] < dminSup) {
                    second++;
                    continue;
                }
                if (element[1] >dminSup ) {
                    third++;
                    continue;
                }
            }
            if (first + second <= limitFuoriSoglia) {
                dmin = dminSup;
                //logger.debug("DOPO first + second dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                toRemove = false;
            }
            if (first + third <= limitFuoriSoglia) {
                dmax = dminSup;
                dmin = dmaxInf;
                //logger.debug("DOPO first + third  dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                toRemove = false;
            }
            if (second + third <= limitFuoriSoglia) {
                dmax = dmaxInf;
                //logger.debug("DOPO second + third dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
                toRemove = false;
            }
            //logger.debug("DOPO dmin=" + dmin + "and dmax=" + dmax + "dminSup" + dminSup + " dmaxInf" + dmaxInf);
            if (toRemove) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Match football removed");
                }
                return null;
            }

        }
        aminSup = amin * 1.1;
        amaxInf = amax * 0.9;
        first = second = third = 0;
        toRemove = true;
        it = homeDrawAwayProbabilityList.iterator();
        Adistance = (amax - amin) / amax;
        while (it.hasNext()) {
            element = it.next();
            if (Adistance > 0.1) {
                //logger.debug(" amin=" + amin + "and amax=" + amax + "aminSup" + aminSup + " amaxInf" + amaxInf);
                if (element[2] < amaxInf ) {
                    first++;
                    continue;
                }
                if (element[2] > aminSup) {
                    third++;
                    continue;
                }
                if (element[2] > amaxInf && element[0] < aminSup) {
                    third++;
                    continue;
                }
            }
            if (first + second <= limitFuoriSoglia) {
                amin = aminSup;
                toRemove = false;
            }
            if (first + third <= limitFuoriSoglia) {
                amax = aminSup;
                amin = amaxInf;
                toRemove = false;
            }
            if (second + third <= limitFuoriSoglia) {
                amax = hmaxInf;
                toRemove = false;
            }
            //logger.debug("DOPO amin=" + amin + "and amax=" + amax + "aminSup" + aminSup + " amaxInf" + amaxInf);
            if (toRemove) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Match football removed");
                }
                return null;
            }

        }
//            hmin =dmin= amin = 1000;
//            hmax =dmax= amax = 0;
//            for(int i=0;i<homeDrawAwayProbabilityList.size();i++) {
//                amax=Math.max(amax,homeDrawAwayProbabilityList.get(i)[2]);
//                amin=Math.min(amin,homeDrawAwayProbabilityList.get(i)[2]);
//                hmax=Math.max(hmax,homeDrawAwayProbabilityList.get(i)[0]);
//                hmin=Math.min(hmin,homeDrawAwayProbabilityList.get(i)[0]);
//                dmax=Math.max(dmax,homeDrawAwayProbabilityList.get(i)[1]);
//                dmin=Math.min(dmin,homeDrawAwayProbabilityList.get(i)[1]);
//            }

        amax = ((int) Math.ceil(amax * 100.)) / 100.;
        amin = ((int) Math.floor(amin * 100.)) / 100.;
        dmax = ((int) Math.ceil(dmax * 100.)) / 100.;
        dmin = ((int) Math.floor(dmin * 100.)) / 100.;
        hmax = ((int) Math.ceil(hmax * 100.)) / 100.;
        hmin = ((int) Math.floor(hmin * 100.)) / 100.;
        if (logger.isDebugEnabled()) {
            logger.debug(GenericUtils.getMatchTeams(mapEntry.getValue()) + " - hmin:" + hmin + ", hmax:" + hmax + ", amin:" + amin + ", amax:" + amax + ", dmin:" + dmin + ", dmax:" + dmax + ", homeAwayProbabilityList:" + homeAwayProbabilityList);
        }

        params = new FootballDTO(hmin, hmax, amin, amax, dmin, dmax, country, DTOType.PROBABILITY, continent);

        resultMatrixPerBookmaker = footballAggregation.evaluateMatrixPerBookmaker(params, homeAwayProbabilityList, mappeFootball);
        resultDb = footballAggregation.evaluateDb(params);
        resultKnn = footballAggregation.evaluateKnn(params, mappeFootball);
        resultMatrix = footballAggregation.evaluateMatrix(params, mappeFootball);
        resultMatrixWeight = footballAggregation.evaluateMatrix(params, mappeFootballWeight);
        //logger.debug("resultMatrixPerBookmaker:" + resultMatrixPerBookmaker + ", resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix);
        logger.debug("football resultMatrixPerBookmaker:" + resultMatrixPerBookmaker + ", resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix + ", resultDb:" + resultDb + ", resultMatrixWeight:" + resultMatrixWeight);
        double aa = resultMatrixPerBookmaker.getAway() + resultKnn.getAway() + resultMatrix.getAway() + resultDb.getAway()+resultMatrixWeight.getAway();
        double dd = resultMatrixPerBookmaker.getDraw() + resultKnn.getDraw() + resultMatrix.getDraw() + resultDb.getDraw()+resultMatrixWeight.getDraw();
        double hh = resultMatrixPerBookmaker.getHome() + resultKnn.getHome() + resultMatrix.getHome() + resultDb.getHome()+resultMatrixWeight.getHome();
        double confidence = (resultMatrixPerBookmaker.getConfidence() + resultKnn.getConfidence() + resultMatrix.getConfidence() + resultDb.getConfidence()) / 4;
//            logger.debug("football resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix+ ", resultDb:" + resultDb);
//            double aa = resultKnn.getAway() + resultMatrix.getAway()+ resultDb.getAway();
//            double dd = resultKnn.getDraw() + resultMatrix.getDraw()+resultDb.getDraw();
//            double hh =  resultKnn.getHome() + resultMatrix.getHome()+resultDb.getHome();
//            double confidence = ( resultKnn.getConfidence() + resultMatrix.getConfidence()+ resultDb.getConfidence())/3;

        ct = aa + dd + hh;
        if (ct > 100) {
            pa = aa / ct;
            pd = dd / ct;
            ph = hh / ct;
            logger.debug(GenericUtils.getMatchTeams(mapEntry.getValue()) + " - MAGGIORE 100:" + ct + ", pa:" + pa + ", pd:" + pd + ", ph:" + ph);

//            if (logger.isDebugEnabled()) {
//                logger.debug(GenericUtils.getMatchTeams(mapEntry.getValue()) + " - ct:" + ct + ", pa:" + pa + ", pd:" + pd + ", ph:" + ph);
//            }
            return new EventFootballProbability(mapEntry.getKey(), confidence, ph, pa, pd);
        }
        return null;
    }
}
