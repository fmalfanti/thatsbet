package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.AsianOddsBasketDTO;
import com.kellify.common.model.HA.HADTO;
import com.kellify.common.model.basket.BasketDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.model.basket.BasketProbabilitiesResult;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface BasketAggregation {
    BasketProbabilitiesResult evaluateDb(HADTO params) throws SQLException;
    BasketProbabilitiesResult evaluateKnn(HADTO params, Map<String, Map<Integer, Matrici.HAMatrix>> mappaHA);
    BasketProbabilitiesResult evaluateMatrix(HADTO params, Map<String, Map<Integer, Matrici.HAMatrix>> mappaHA);
    BasketProbabilitiesResult evaluateMatrixPerBookmaker(BasketDTO params, List<Double> homeProbabilityList, Map<String, Map<Integer, Matrici.HAMatrix>> mappaHA);
    BasketProbabilitiesResult evaluateDbSingleBookmaker(AsianOddsBasketDTO params, Map<String, Map<Integer, Matrici.HAMatrix>> mappaHA);
}
