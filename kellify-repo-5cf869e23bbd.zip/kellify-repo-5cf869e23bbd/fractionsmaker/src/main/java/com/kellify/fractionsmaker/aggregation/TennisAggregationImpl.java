package com.kellify.fractionsmaker.aggregation;


import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.common.model.tennis.TennisDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.tennis.TennisProbabilitiesResult;
import com.kellify.fractionsmaker.oddreduce.ProbabiltyMapImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class TennisAggregationImpl implements TennisAggregation {
    private static final Logger logger = LoggerFactory.getLogger(ProbabiltyMapImpl.class);

    private final Map<String, List<TennisBookmakerOdd>> entities;
    private final DbUbibetterConnector ubibetterConnector;

    TennisAggregationImpl(Map<String, List<TennisBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        this.entities = entities;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public TennisProbabilitiesResult evaluateDb(TennisDTO params) throws SQLException {
        TennisProbabilitiesResult result=null;
        result= ubibetterConnector.getResults(params);
        return result;
    }
    @Override
    public TennisProbabilitiesResult evaluateKnn(TennisDTO params, Map<Integer, Matrici.WLMatrix> MappaWL) {
        TennisProbabilitiesResult result=null;
        int confidence=5;
        int ll=0,ww=0;
        int knn=500;
        int count=0;
        //String[] parametri={params.getCountry(), params.getContinent(), "World"};
        Matrici.HdaMatrix punto;
        int mh=(int)(100*(params.getHomeMax()+params.getHomeMin())/2.0);

        if (count < knn) {
                    for (int ind=0; ind < 4; ind++) {
                        ww=0;
                        ll=0;
                        for (int i=mh - ind; i <= mh + ind; i++) {
                                if (MappaWL.get(i) != null) {
                                    ww+=MappaWL.get(i).getW();
                                    ll+=MappaWL.get(i).getL();
                                }
                        }
                        count=ww+ll;
                        if (count >= knn) {
                            ind=5;
                        }
                    }
                }

        //System.out.println("count="+count);
        return new TennisProbabilitiesResult(count,confidence, ww,ll);
    }
    @Override
    public TennisProbabilitiesResult evaluateMatrix(TennisDTO params, Map<Integer, Matrici.WLMatrix> MappaWL){
        int ww=0,ll=0;
        int confidence=5;
        TennisProbabilitiesResult result=null;
        int count=0;
        for (int i=(int) (100 * params.getHomeMin()); i <= 100 * params.getHomeMax(); i++) {
                if (MappaWL.get(i) != null) {
                    ww+=MappaWL.get(i).getW();
                    ll+=MappaWL.get(i).getL();
                }
        }
        count=ww+ll;
        if (count<10) {
            ww=0;
            ll=0;
        }

        //System.out.println("count="+count);
        return new TennisProbabilitiesResult(count,confidence, ww,ll);

    }

}

