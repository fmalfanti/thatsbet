package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.HA.HADTO;
import com.kellify.common.model.americanFootball.AmericanFootballDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.model.americanfootball.AmericanFootballProbabilitiesResult;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface AmericanFootballAggregation {
    AmericanFootballProbabilitiesResult evaluateDb(HADTO params) throws SQLException;
    AmericanFootballProbabilitiesResult evaluateKnn(HADTO params, Map<String, Map<Integer, Matrici.HAMatrix>> mappaHA);
    AmericanFootballProbabilitiesResult evaluateMatrix(HADTO params, Map<String, Map<Integer, Matrici.HAMatrix>> mappaHA);
}
