package com.kellify.fractionsmaker.executorprovider;

public interface Provider {
    void execute() throws Exception;
    String name();
}
