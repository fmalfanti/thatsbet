package com.kellify.fractionsmaker.model.hda;

import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.fractionsmaker.model.ProbabilitiesResult;

public class HdaProbabilitiesResult extends ProbabilitiesResult {
    protected final double draw;
    private final ProbabilitiesQueryType type;

    public HdaProbabilitiesResult(int count, double confidence, double home, double away, double draw, ProbabilitiesQueryType type) {
        super(count, confidence, home, away);
        this.draw = draw;
        this.type = type;
    }

    public double getDraw() {
        return draw;
    }

    public ProbabilitiesQueryType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "HdaProbabilitiesResult{" +
                "type=" + type +
                ", count=" + count +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                ", draw=" + draw +
                '}';
    }
}
