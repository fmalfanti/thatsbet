package com.kellify.fractionsmaker.model.icehockey;

import com.kellify.fractionsmaker.model.EventProbability;

public class EventIceHockeyHDAProbability extends EventProbability{
    private final double draw;

    public EventIceHockeyHDAProbability(String eventId, double confidence, double home, double away, double draw) {
        super(eventId, confidence, home, away);
        this.draw = draw;
    }

    public double getDraw() { return draw; }

    @Override
    public String toString() {
        return "EventIceHockeyHDAProbability{" +
                "draw=" + draw +
                ", eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}

