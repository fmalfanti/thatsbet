package com.kellify.fractionsmaker.model.basket;


import com.kellify.fractionsmaker.model.EventProbability;

public class EventBasketProbability extends EventProbability {

    public EventBasketProbability(String eventId, double confidence, double home, double away) {
        super(eventId, confidence, home, away);
    }

    @Override
    public String toString() {
        return "EventBasketProbability{" +
                "eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
