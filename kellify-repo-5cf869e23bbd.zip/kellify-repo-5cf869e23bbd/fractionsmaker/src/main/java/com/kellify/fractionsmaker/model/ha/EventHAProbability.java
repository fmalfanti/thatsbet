package com.kellify.fractionsmaker.model.ha;


import com.kellify.fractionsmaker.model.EventProbability;

public class EventHAProbability extends EventProbability {

    public EventHAProbability(String eventId, double home, double away, double confidence) {
        super(eventId, home, away, confidence);
    }
}
