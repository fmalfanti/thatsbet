package com.kellify.fractionsmaker.model.hda;

import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.fractionsmaker.model.EventProbability;


public class EventHDAProbability  extends EventProbability {
    private final double draw;

    public EventHDAProbability(String eventId, double confidence, double home, double away, double draw) {
        super(eventId, confidence, home, away);
        this.draw = draw;
    }

    public double getDraw() { return draw; }

    @Override
    public String toString() {
        return "EventHDAProbability{" +
                "draw=" + draw +
                ", eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
