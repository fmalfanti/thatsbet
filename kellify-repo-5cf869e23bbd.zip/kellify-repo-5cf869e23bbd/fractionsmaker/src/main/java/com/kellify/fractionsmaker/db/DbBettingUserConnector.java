package com.kellify.fractionsmaker.db;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.BookmakerOdd;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.americanFootball.EventAmericanFootballFraction;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.baseball.EventBaseballFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.basket.EventBasketFraction;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.iceHockey.EventIceHockeyHAFraction;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.tennis.EventTennisFraction;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.print.DocFlavor;
import java.sql.*;
import java.util.*;

public class DbBettingUserConnector extends DbConnector {
    private static final Logger logger = LoggerFactory.getLogger(DbBettingUserConnector.class);

    // maybe backup fraction data
    private static final String CHECK_AND_BACKUP_FRACTION_DATA = "{call check_and_launch_backup_fraction_tables()}";
    private static final String BACKUP_ALL_FRACTION_DATA = "{call backup_all_fraction()}";

    // Football
    private static final String SELECT_FOOTBALL_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from football_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 order by referrer_id,bookmaker_id,role";
    private static final String SELECT_FOOTBALL_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from football_odds_snapshot where bookmaker_enabled=1 order by platform_id,referrer_id,bookmaker_id,role";
//    private static final String TRUNCATE_FOOTBALL_FRACTION_TABLES = "{call truncate_football_fraction_tables()}";
    private static final String TRUNCATE_FOOTBALL_QUOTE = "truncate table football_fraction";

    private static final String INSERT_FOOTBALL_FRACTION = "insert into football_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fd,fa,ph,pd,pa,pbh,pbd,pba,delta,id_betting_home,id_betting_draw,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    // Tennis
    private static final String SELECT_TENNIS_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,betting_type from tennis_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 and event_id='9555349272924160' order by referrer_id,bookmaker_id,role ";
    private static final String SELECT_TENNIS_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,betting_type from tennis_odds_snapshot where bookmaker_enabled=1 order by platform_id,referrer_id,bookmaker_id,role";
//    private static final String TRUNCATE_TENNIS_FRACTION_TABLES = "{call truncate_tennis_fraction_tables()}";
    private static final String TRUNCATE_TENNIS_QUOTE = "truncate table tennis_fraction";

    private static final String INSERT_TENNIS_FRACTION = "insert into tennis_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    // Basket
    private static final String SELECT_BASKET_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from basket_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 order by referrer_id,bookmaker_id,role";
    private static final String SELECT_BASKET_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from basket_odds_snapshot order by platform_id,referrer_id,bookmaker_id,role";
//    private static final String TRUNCATE_BASKET_FRACTION_TABLES = "{call truncate_basket_fraction_tables()}";
    private static final String TRUNCATE_BASKET_QUOTE = "truncate table basket_fraction";
    private static final String INSERT_BASKET_FRACTION = "insert into basket_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    // Baseball
    private static final String SELECT_BASEBALL_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from baseball_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 order by referrer_id,bookmaker_id,role";
    private static final String SELECT_BASEBALL_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from baseball_odds_snapshot where bookmaker_enabled=1 order by platform_id,referrer_id,bookmaker_id,role";
//    private static final String TRUNCATE_BASEBALL_FRACTION_TABLES = "{call truncate_baseball_fraction_tables()}";
    private static final String TRUNCATE_BASEBALL_QUOTE = "truncate table baseball_fraction";
    private static final String INSERT_BASEBALL_FRACTION = "insert into baseball_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    // AmericanFootball
    private static final String SELECT_AMERICANFOOTBALL_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from americanfootball_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 order by referrer_id,bookmaker_id,role";
    private static final String SELECT_AMERICANFOOTBALL_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from americanfootball_odds_snapshot where bookmaker_enabled=1 order by platform_id,referrer_id,bookmaker_id,role";
//    private static final String TRUNCATE_AMERICANFOOTBALL_FRACTION_TABLES = "{call truncate_americanfootball_fraction_tables()}";
    private static final String TRUNCATE_AMERICAN_FOOTBALL_QUOTE = "truncate table americanfootball_fraction";
    private static final String INSERT_AMERICANFOOTBALL_FRACTION = "insert into americanfootball_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

       //IceHockeyHA
    private static final String SELECT_ICEHOCKEY_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from icehockey_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 order by referrer_id,bookmaker_id,role";
    private static final String SELECT_ICEHOCKEY_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from icehockey_odds_snapshot where bookmaker_enabled=1 order by platform_id,referrer_id,bookmaker_id,role";
//    private static final String TRUNCATE_ICEHOCKEY_HA_FRACTION_TABLES = "{call truncate_icehockeyHA_fraction_tables()}";
    private static final String TRUNCATE_ICE_HOCKEY_HA_QUOTE = "truncate table icehockeyHA_fraction";
    private static final String INSERT_ICEHOCKEY_HA_FRACTION = "insert into icehockeyHA_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    //IceHockeyHDA
    private static final String SELECT_ICEHOCKEY_HDA_ODDS_FOR_PROBABILITIES_PILOT = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from icehockey_odds_snapshot where platform_id=" + Platforms.BETBRAIN.getNumVal() + " and bookmaker_enabled=1 order by referrer_id,bookmaker_id,role";
    private static final String SELECT_ICEHOCKEY_HDA_ODDS_FOR_KELLY_ALL = "select match_date,event_id,referrer_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type from icehockey_odds_snapshot where bookmaker_enabled=1 order by platform_id,referrer_id,bookmaker_id,role";
    private static final String TRUNCATE_ICEHOCKEY_HDA_FRACTION_TABLES = "{call truncate_icehockeyHDA_fraction_tables()}";
    private static final String INSERT_ICEHOCKEY_HDA_FRACTION = "insert into icehockeyHDA_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fd,fa,ph,pd,pa,pbh,pbd,pba,delta,id_betting_home,id_betting_draw,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public DbBettingUserConnector(Properties config) {
        this.config = config;
    }

    public static DbBettingUserConnector getInstance(Properties config) {
        return new DbBettingUserConnector(config);
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bettinguser"), config.getProperty("user.bettinguser"), config.getProperty("password.bettinguser"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

    public void checkAndBackupFractionTables() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        CallableStatement cStmt = null;
        try {
            cStmt = connection.prepareCall(CHECK_AND_BACKUP_FRACTION_DATA);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
        }
    }

    public void backupAllFractionTables() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        CallableStatement cStmt = null;
        try {
            cStmt = connection.prepareCall(BACKUP_ALL_FRACTION_DATA);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
        }
    }

    public Map<String, List<FootballBookmakerOdd>> loadFootballEntitiesForProbabilities() throws SQLException {
        Map<String, List<FootballBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<FootballBookmakerOdd> entityList;
        FootballBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_ODDS_FOR_PROBABILITIES_PILOT);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new FootballBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public Map<String, List<FootballBookmakerOdd>> loadFootballEntitiesForKelly() throws SQLException {
        Map<String, List<FootballBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<FootballBookmakerOdd> entityList;
        FootballBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new FootballBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventFootballFraction(List<EventFraction> footballFractionList) throws SQLException {
        if(footballFractionList == null || footballFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_FOOTBALL_FRACTION);
            for(EventFraction fraction : footballFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                ps.setInt(10, fraction.getBookmakerId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFd());
                ps.setDouble(14, fraction.getFa());
                ps.setInt(15, fraction.getPh());
                ps.setInt(16, fraction.getPd());
                ps.setInt(17, fraction.getPa());
                ps.setInt(18, fraction.getPbh());
                ps.setInt(19, fraction.getPbd());
                ps.setInt(20, fraction.getPba());
                ps.setDouble(21, fraction.getDelta());
                ps.setString(22, fraction.getBettingOfferIdH());
                ps.setString(23, fraction.getBettingOfferIdD());
                ps.setString(24, fraction.getBettingOfferIdA());
                ps.setInt(25, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

//    public void truncateFootballFractionTables() throws SQLException {
//        if(connection == null) {
//            getConnection();
//        }
//        CallableStatement cStmt = null;
//        try {
//            cStmt = connection.prepareCall(TRUNCATE_FOOTBALL_FRACTION_TABLES);
//            cStmt.execute();
//        } finally {
//            if (cStmt !=null) {
//                cStmt.close();
//            }
//        }
//    }

    public void truncateFootballFractionTables() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_FOOTBALL_QUOTE);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //tennis
    public Map<String, List<TennisBookmakerOdd>> loadTennisEntitiesForProbabilities() throws SQLException {
        Map<String, List<TennisBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<TennisBookmakerOdd> entityList;
        TennisBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_TENNIS_ODDS_FOR_PROBABILITIES_PILOT);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new TennisBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"), OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public Map<String, List<TennisBookmakerOdd>> loadTennisEntitiesForKelly() throws SQLException {
        Map<String, List<TennisBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<TennisBookmakerOdd> entityList;
        TennisBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_TENNIS_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new TennisBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"), OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventTennisFraction(List<EventTennisFraction> tennisFractionList) throws SQLException {
        if(tennisFractionList == null || tennisFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        String reffered_id;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_TENNIS_FRACTION);

            for(EventTennisFraction fraction : tennisFractionList) {
                reffered_id = fraction.getReferrerId();
                ps.setString(1,reffered_id);
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getChampionship());
                ps.setInt(9, fraction.getBookmakerId());
                ps.setTimestamp(10, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(11, fraction.getFh());
                ps.setDouble(12, fraction.getFa());
                ps.setInt(13, fraction.getPh());
                ps.setInt(14, fraction.getPa());
                ps.setInt(15, fraction.getPbh());
                ps.setInt(16, fraction.getPba());
                ps.setDouble(17, fraction.getDelta());
                ps.setString(18, fraction.getBettingOfferIdH());
                ps.setString(19, fraction.getBettingOfferIdA());
                ps.setInt(20, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

//    public void truncateTennisFractionTables() throws SQLException {
//        if(connection == null) {
//            getConnection();
//        }
//        CallableStatement cStmt = null;
//        try {
//            cStmt = connection.prepareCall(TRUNCATE_TENNIS_FRACTION_TABLES);
//            cStmt.execute();
//        } finally {
//            if (cStmt !=null) {
//                cStmt.close();
//            }
//        }
//    }
public void truncateTennisFractionTables() throws SQLException {
    if(connection == null) {
        getConnection();
    }
    Statement st = null;
    try {
        st = connection.createStatement();
        st.execute(TRUNCATE_TENNIS_QUOTE);
    } finally {
        if(st != null) {
            st.close();
        }
    }
}

    // basket
    public Map<String, List<BasketBookmakerOdd>> loadBasketEntitiesForProbabilities() throws SQLException {
        Map<String, List<BasketBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<BasketBookmakerOdd> entityList;
        BasketBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_BASKET_ODDS_FOR_PROBABILITIES_PILOT);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new BasketBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public Map<String, List<BasketBookmakerOdd>> loadBasketEntitiesForKelly() throws SQLException {
        Map<String, List<BasketBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<BasketBookmakerOdd> entityList;
        BasketBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_BASKET_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new BasketBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventBasketFraction(List<EventBasketFraction> basketFractionList) throws SQLException {
        if(basketFractionList == null || basketFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASKET_FRACTION);
            for(EventBasketFraction fraction : basketFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                ps.setInt(10, fraction.getBookmakerId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

//    public void truncateBasketFractionTables() throws SQLException {
//        if(connection == null) {
//            getConnection();
//        }
//        CallableStatement cStmt = null;
//        try {
//            cStmt = connection.prepareCall(TRUNCATE_BASKET_FRACTION_TABLES);
//            cStmt.execute();
//        } finally {
//            if (cStmt !=null) {
//                cStmt.close();
//            }
//        }
//    }
public void truncateBasketFractionTables() throws SQLException {
    if(connection == null) {
        getConnection();
    }
    Statement st = null;
    try {
        st = connection.createStatement();
        st.execute(TRUNCATE_BASKET_QUOTE);
    } finally {
        if(st != null) {
            st.close();
        }
    }
}

    // baseball
    public Map<String, List<BaseballBookmakerOdd>> loadBaseballEntitiesForProbabilities() throws SQLException {
        Map<String, List<BaseballBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<BaseballBookmakerOdd> entityList;
        BaseballBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_ODDS_FOR_PROBABILITIES_PILOT);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new BaseballBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public Map<String, List<BaseballBookmakerOdd>> loadBaseballEntitiesForKelly() throws SQLException {
        Map<String, List<BaseballBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<BaseballBookmakerOdd> entityList;
        BaseballBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new BaseballBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventBaseballFraction(List<EventBaseballFraction> baseballFractionList) throws SQLException {
        if(baseballFractionList == null || baseballFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASEBALL_FRACTION);
            for(EventBaseballFraction fraction : baseballFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                ps.setInt(10, fraction.getBookmakerId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

//    public void truncateBaseballFractionTables() throws SQLException {
//        if(connection == null) {
//            getConnection();
//        }
//        CallableStatement cStmt = null;
//        try {
//            cStmt = connection.prepareCall(TRUNCATE_BASEBALL_FRACTION_TABLES);
//            cStmt.execute();
//        } finally {
//            if (cStmt !=null) {
//                cStmt.close();
//            }
//        }
//    }
public void truncateBaseballFractionTables() throws SQLException {
    if(connection == null) {
        getConnection();
    }
    Statement st = null;
    try {
        st = connection.createStatement();
        st.execute(TRUNCATE_BASEBALL_QUOTE);
    } finally {
        if(st != null) {
            st.close();
        }
    }
}


    // americanfootball

   public Map<String, List<AmericanFootballBookmakerOdd>> loadAmericanFootballEntitiesForProbabilities() throws SQLException {
       Map<String, List<AmericanFootballBookmakerOdd>> entityMap = new HashMap<>();
       if(connection == null) {
           getConnection();
       }
       PreparedStatement ps = null;
       ResultSet rs = null;
       List<AmericanFootballBookmakerOdd> entityList;
       AmericanFootballBookmakerOdd element;
       String referrerId;
       try {
           ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_ODDS_FOR_PROBABILITIES_PILOT);
           rs = ps.executeQuery();
           while(rs.next()) {
               referrerId= rs.getString("referrer_id");
               entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
               element = new AmericanFootballBookmakerOdd(
                       rs.getString("event_id"),
                       referrerId,
                       rs.getString("odd_id"),
                       rs.getInt("platform_id"),
                       OddRole.getEnum(rs.getInt("role")),
                       rs.getDouble("odd"),
                       rs.getInt("bookmaker_id"),
                       rs.getString("team"),
                       rs.getString("championship"),
                       rs.getString("country"),
                       rs.getString("continent"),
                       rs.getTimestamp("match_date").toLocalDateTime(),
                       BettingType.getEnum(rs.getInt("betting_type")));
               entityList.add(element);
           }
       } finally {
           if(rs != null) {
               rs.close();
           }
           if(ps != null) {
               ps.close();
           }
       }
       return entityMap;
   }

    public Map<String, List<AmericanFootballBookmakerOdd>> loadAmericanFootballEntitiesForKelly() throws SQLException {
        Map<String, List<AmericanFootballBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<AmericanFootballBookmakerOdd> entityList;
        AmericanFootballBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new AmericanFootballBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventAmericanFootballFraction(List<EventAmericanFootballFraction> ameericanfootballFractionList) throws SQLException {
        if(ameericanfootballFractionList == null || ameericanfootballFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_AMERICANFOOTBALL_FRACTION);
            for(EventAmericanFootballFraction fraction : ameericanfootballFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                ps.setInt(10, fraction.getBookmakerId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

//    public void setTruncateAmericanfootballFractionTables() throws SQLException {
//        if(connection == null) {
//            getConnection();
//        }
//        CallableStatement cStmt = null;
//        try {
//            cStmt = connection.prepareCall(TRUNCATE_AMERICANFOOTBALL_FRACTION_TABLES);
//            cStmt.execute();
//        } finally {
//            if (cStmt !=null) {
//                cStmt.close();
//            }
//        }
//    }

    public void setTruncateAmericanfootballFractionTables() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_AMERICAN_FOOTBALL_QUOTE);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //hockey
    public Map<String, List<IceHockeyBookmakerOdd>> loadIceHockeyEntitiesForProbabilities() throws SQLException {
        Map<String, List<IceHockeyBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<IceHockeyBookmakerOdd> entityList;
        IceHockeyBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_ODDS_FOR_PROBABILITIES_PILOT);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new IceHockeyBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public Map<String, List<IceHockeyBookmakerOdd>> loadIceHockeyEntitiesForKelly() throws SQLException {
        Map<String, List<IceHockeyBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<IceHockeyBookmakerOdd> entityList;
        IceHockeyBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new IceHockeyBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventiceHockeyHAFraction(List<EventIceHockeyHAFraction> iceHockeyFractionList) throws SQLException {
        if(iceHockeyFractionList == null || iceHockeyFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_ICEHOCKEY_HA_FRACTION);
            for(EventIceHockeyHAFraction fraction : iceHockeyFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                ps.setInt(10, fraction.getBookmakerId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

//    public void truncateIceHockeyHAFractionTables() throws SQLException {
//        if(connection == null) {
//            getConnection();
//        }
//        CallableStatement cStmt = null;
//        try {
//            cStmt = connection.prepareCall(TRUNCATE_ICEHOCKEY_HA_FRACTION_TABLES);
//            cStmt.execute();
//        } finally {
//            if (cStmt !=null) {
//                cStmt.close();
//            }
//        }
//    }

    public void truncateIceHockeyHAFractionTables() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_ICE_HOCKEY_HA_QUOTE);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //hockeyHDA
    public Map<String, List<IceHockeyBookmakerOdd>> loadIceHockeyHDAEntitiesForProbabilities() throws SQLException {
        Map<String, List<IceHockeyBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<IceHockeyBookmakerOdd> entityList;
        IceHockeyBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_HDA_ODDS_FOR_PROBABILITIES_PILOT);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new IceHockeyBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public Map<String, List<IceHockeyBookmakerOdd>> loadIceHockeyHDAEntitiesForKelly() throws SQLException {
        Map<String, List<IceHockeyBookmakerOdd>> entityMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<IceHockeyBookmakerOdd> entityList;
        IceHockeyBookmakerOdd element;
        String referrerId;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_HDA_ODDS_FOR_KELLY_ALL);
            rs = ps.executeQuery();
            while(rs.next()) {
                referrerId= rs.getString("referrer_id");
                entityList = entityMap.computeIfAbsent(referrerId, k -> new ArrayList<>());
                element = new IceHockeyBookmakerOdd(
                        rs.getString("event_id"),
                        referrerId,
                        rs.getString("odd_id"),
                        rs.getInt("platform_id"),
                        OddRole.getEnum(rs.getInt("role")),
                        rs.getDouble("odd"),
                        rs.getInt("bookmaker_id"),
                        rs.getString("team"),
                        rs.getString("championship"),
                        rs.getString("country"),
                        rs.getString("continent"),
                        rs.getTimestamp("match_date").toLocalDateTime(),
                        BettingType.getEnum(rs.getInt("betting_type")));
                entityList.add(element);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return entityMap;
    }

    public void insertEventiceHockeyHDAFraction(List<EventFraction> iceHockeyFractionList) throws SQLException {
        if(iceHockeyFractionList == null || iceHockeyFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_ICEHOCKEY_HDA_FRACTION);
            for(EventFraction fraction : iceHockeyFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                ps.setInt(10, fraction.getBookmakerId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFd());
                ps.setDouble(14, fraction.getFa());
                ps.setInt(15, fraction.getPh());
                ps.setInt(16, fraction.getPd());
                ps.setInt(17, fraction.getPa());
                ps.setInt(18, fraction.getPbh());
                ps.setInt(19, fraction.getPbd());
                ps.setInt(20, fraction.getPba());
                ps.setDouble(21, fraction.getDelta());
                ps.setString(22, fraction.getBettingOfferIdH());
                ps.setString(23, fraction.getBettingOfferIdD());
                ps.setString(24, fraction.getBettingOfferIdA());
                ps.setInt(25, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public void truncateIceHockeyHDAFractionTables() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        CallableStatement cStmt = null;
        try {
            cStmt = connection.prepareCall(TRUNCATE_ICEHOCKEY_HDA_FRACTION_TABLES);
            cStmt.execute();
        } finally {
            if (cStmt !=null) {
                cStmt.close();
            }
        }
    }

    private static final String TRUNCATE_FOOTBALL_SNAPSHOT = "truncate table football_odds_snapshot";
    private static final String INSERT_FOOTBALL_SNAPSHOT = "insert into football_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_TENNIS_SNAPSHOT = "truncate table tennis_odds_snapshot";
    private static final String INSERT_TENNIS_SNAPSHOT = "insert into tennis_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_BASKET_SNAPSHOT = "truncate table basket_odds_snapshot";
    private static final String INSERT_BASKET_SNAPSHOT = "insert into basket_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_BASEBALL_SNAPSHOT = "truncate table baseball_odds_snapshot";
    private static final String INSERT_BASEBALL_SNAPSHOT = "insert into baseball_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_ICEHOCKEY_SNAPSHOT = "truncate table icehockey_odds_snapshot";
    private static final String INSERT_ICEHOCKEY_SNAPSHOT = "insert into icehockey_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_AMERICANFOOTBALL_SNAPSHOT = "truncate table americanfootball_odds_snapshot";
    private static final String INSERT_AMERICANFOOTBALL_SNAPSHOT = "insert into americanfootball_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";


    public void truncateFootballSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_FOOTBALL_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    public void insertFootballOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_FOOTBALL_SNAPSHOT);
            FootballBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (FootballBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                //ps.setInt(8, bookmakerMap.get(odd.getBookmakerDescr()));
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.FOOTBALL));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    // basket
    public void truncateBasketSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_BASKET_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }
    public void insertBasketOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASKET_SNAPSHOT);
            BasketBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (BasketBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.BASKET));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    // tennis
    public void truncateTennisSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_TENNIS_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    public void insertTennisOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_TENNIS_SNAPSHOT);
            TennisBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (TennisBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                ps.setInt(12, odd.getBettingType().getNumVal());
                ps.setInt(13, bookmakerAttributes.getHistoryMap().get(SportTypes.TENNIS));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {
                    logger.error("odd not inserted:" + odd);
                    logger.error(ex.getMessage(), ex);
                }
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    // baseball
    public void insertBaseballOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASEBALL_SNAPSHOT);
            BaseballBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (BaseballBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.BASEBALL));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void truncateBaseballSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_BASEBALL_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }
    // americanfootball
    public void insertAmericanFootballOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_AMERICANFOOTBALL_SNAPSHOT);
            AmericanFootballBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (AmericanFootballBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.AMERICAN_FOOTBALL));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void truncateAmericanFootballSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_AMERICANFOOTBALL_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    // icehockey
    public void insertIcehockeyOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_ICEHOCKEY_SNAPSHOT);
            IceHockeyBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (IceHockeyBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.ICE_HOCKEY));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void truncateIcehockeySnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_ICEHOCKEY_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }
}
