package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.HDA.HDADTO;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyHDADTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHaProbabilitiesResult;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHdaProbabilitiesResult;
import com.kellify.fractionsmaker.oddreduce.ProbabiltyMapImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class IceHockeyHDAAggregationImpl implements IceHockeyHDAAggregation{

    private static final Logger logger = LoggerFactory.getLogger(ProbabiltyMapImpl.class);

    private final Map<String, List<IceHockeyBookmakerOdd>> entities;
    private final DbUbibetterConnector ubibetterConnector;

    IceHockeyHDAAggregationImpl(Map<String, List<IceHockeyBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        this.entities = entities;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public IceHockeyHdaProbabilitiesResult evaluateDb(IceHockeyHDADTO params) throws SQLException {
        IceHockeyHdaProbabilitiesResult result=null;
        result = ubibetterConnector.getFTRHDA(params);
        return result;
    }
    @Override
    public IceHockeyHdaProbabilitiesResult evaluateOddDb(IceHockeyHDADTO params) throws SQLException {
        IceHockeyHdaProbabilitiesResult result=null;
        result = ubibetterConnector.getFTRHDA(params);
        return result;
    }
    @Override
    public IceHockeyHdaProbabilitiesResult evaluateKnn(IceHockeyHDADTO params, Map<String,Map<Integer,Matrici.HdaMatrix>> MappaHDA) {
        int hh=0,aa=0,dd=0;
        int knn=10000;
        int count=0;
        int confidence=5;
        String[] parametri={params.getCountry(), params.getContinent(), "World"};
        Matrici.HdaMatrix punto;
        Map<Integer, Matrici.HdaMatrix> useNationMap;
        int ma=(int)(100*(params.getAwayMax()+params.getAwayMin())/2.0);
        int mh=(int)(100*(params.getHomeMax()+params.getHomeMin())/2.0);

        for (String parametro : parametri) {
            if (count < knn) {
                useNationMap=MappaHDA.get(parametro);
                if (useNationMap != null) {
                    for (int ind=0; ind < 4; ind++) {
                        confidence-=ind;
                        hh=0;
                        aa=0;
                        dd=0;
                        for (int i=mh - ind; i <= mh + ind; i++) {
                            for (int j=ma - ind; j <= ma + ind; j++) {
                                punto=useNationMap.get(i * 101 + j);
                                if (punto != null) {
                                    hh += punto.getH();
                                    dd += punto.getD();
                                    aa += punto.getA();
                                }
                            }
                        }
                        count=hh+dd+aa;
                        if (count >= knn) {
                            ind=5;
                        }
                    }
                }
            }
        }
        //System.out.println("count="+count);
        return new IceHockeyHdaProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());
    }
    @Override
    public IceHockeyHdaProbabilitiesResult evaluateMatrix(IceHockeyHDADTO params, Map<String,Map<Integer,Matrici.HdaMatrix>> MappaHDA){
        int hh=0,aa=0,dd=0;
        IceHockeyHdaProbabilitiesResult result=null;
        int count=0;
        int confidence=7;
        String[] parametri={params.getCountry(), params.getContinent(),"World"};
        Matrici.HdaMatrix punto;
        Map<Integer,Matrici.HdaMatrix> useNationMap;

        for (String parametro:parametri) {
            confidence-=2;
            if (count <= 10) {
                hh=0;
                aa=0;
                dd=0;
                useNationMap=MappaHDA.get(parametro);
                if (useNationMap != null) {
                    for (int i=(int) (100 * params.getHomeMin()); i <= 100 * params.getHomeMax(); i++) {
                        for (int j=(int) (100 * params.getAwayMin()); j <= 100 * params.getAwayMax(); j++) {

                            punto=useNationMap.get(i * 101 + j);
                            if (punto != null) {
                                hh+=punto.getH();
                                dd+=punto.getD();
                                aa+=punto.getA();
                            }
                        }
                    }
                }
                count=hh+dd+aa;
            }
        }
        //System.out.println("count="+count);
        return new IceHockeyHdaProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());

    }
}
