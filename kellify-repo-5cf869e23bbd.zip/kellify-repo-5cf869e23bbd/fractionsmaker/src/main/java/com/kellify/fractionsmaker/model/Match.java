package com.kellify.fractionsmaker.model;

import com.kellify.common.BettingType;

import java.time.LocalDateTime;

public abstract class Match {
    protected final String id;
    protected final String referrerId;
    protected final String homeTeam;
    protected final String awayTeam;
    protected final LocalDateTime matchDate;
    protected final BettingType bettingType;
    protected String leagueName;
    protected String country;

    protected Match(String id, String referrerId, String homeTeam, String awayTeam, LocalDateTime matchDate, BettingType bettingType) {
        this.id = id;
        this.referrerId = referrerId;
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.matchDate = matchDate;
        this.bettingType = bettingType;
    }

    public String getId() {
        return id;
    }

    public String getReferrerId() {
        return referrerId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public LocalDateTime getMatchDate() {
        return matchDate;
    }

    public String getLeagueName() {
        return leagueName;
    }

    public void setLeagueName(String leagueName) {
        this.leagueName = leagueName;
    }

    public BettingType getBettingType() {
        return bettingType;
    }


    @Override
    public String toString() {
        return "Match{" +
                "id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
