package com.kellify.fractionsmaker.model.icehockey;

import com.kellify.common.BettingType;
import com.kellify.fractionsmaker.model.MatchWithContinent;

import java.time.LocalDateTime;

public class IceHockeyMatch extends MatchWithContinent {
    public IceHockeyMatch(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
    }

    public IceHockeyMatch(String id, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, String referrerId, String country, BettingType bettingType) {
        super(id, homeTeam, awayTeam, leagueName, matchDate, referrerId, country, bettingType);
    }

    @Override
    public String toString() {
        return "IceHockeyMatch{" +
                "continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
