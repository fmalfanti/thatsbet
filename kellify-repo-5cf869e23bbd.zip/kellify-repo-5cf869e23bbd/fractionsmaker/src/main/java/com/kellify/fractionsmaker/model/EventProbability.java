package com.kellify.fractionsmaker.model;

public class EventProbability {
    protected final String eventId;
    protected final double confidence;
    protected final double home;
    protected final double away;

    public EventProbability(String eventId, double confidence, double home, double away) {
        this.eventId = eventId;
        this.confidence = confidence;
        this.home = home;
        this.away = away;
    }

    public String getEventId() {
        return eventId;
    }

    public double getHome() {
        return home;
    }

    public double getAway() {
        return away;
    }

    public double getConfidence() {
        return confidence;
    }

    @Override
    public String toString() {
        return "EventProbability{" +
                "eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
