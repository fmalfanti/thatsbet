package com.kellify.fractionsmaker.model.ha;


import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.fractionsmaker.model.ProbabilitiesResult;

public class HAProbabilitiesResult extends ProbabilitiesResult {
    private final ProbabilitiesQueryType type;

    public HAProbabilitiesResult(int count, int confidence, double home, double away, ProbabilitiesQueryType type) {
        super(count, confidence, home, away);
        this.type = type;
    }



    public ProbabilitiesQueryType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "HAProbabilitiesResult{" +
                "type=" + type +
                ", count=" + count +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
