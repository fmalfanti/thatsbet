package com.kellify.fractionsmaker.kellyfractionproviders.impl;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.util.MathUtil;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.FractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.PilotFractionProvider;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.football.EventFootballProbability;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.*;

public class FootballFractionProvider implements FractionProvider {
    private static final Logger logger = LoggerFactory.getLogger(FootballFractionProvider.class);

    private final double QUOTAPERC;
    private final double PROBMAX;
    private final DbBettingUserConnector bettingUserConnector;
    private final PilotFractionProvider pilotFractionProvider;
    private final Properties config;

    public FootballFractionProvider(DbBettingUserConnector bettingUserConnector, PilotFractionProvider pilotFractionProvider, Properties config) {
        this.bettingUserConnector = bettingUserConnector;
        this.pilotFractionProvider = pilotFractionProvider;
        this.config = config;
        double qPerc = 0.0;
        try {
            qPerc = Double.parseDouble(config.getProperty("football.quotaperc"));
        } catch(NumberFormatException ex) {
            qPerc = 0.05;
        }
        QUOTAPERC = qPerc;
        double pMax = 0.0;
        try {
            pMax = Double.parseDouble(config.getProperty("football.probmax"));
        } catch(NumberFormatException ex) {
            qPerc = 0.55;
        }
        PROBMAX = pMax;
    }

    @Override
    public void execute() throws SQLException {
        Map<String, List<FootballBookmakerOdd>> footballEntitiesForKelly = bettingUserConnector.loadFootballEntitiesForKelly();
        logger.debug("footballEntitiesForKelly size:" + footballEntitiesForKelly.size());
        List<EventFraction> eventList = new ArrayList<>();
        Map<String, ? extends EventProbability> probabilityMap = pilotFractionProvider.probabilityMap();
        EventFootballProbability probability;
        List<FootballBookmakerOdd> oddList;
        String referrerId;
        String bettingOfferIdH,bettingOfferIdD,bettingOfferIdA;
        String homeTeam,awayTeam;
        double oh,od,oa;
        double aa,hh,dd,dm;
        double pa,pd,ph,pb;
        double fh,fd,fa;
        EventFraction fraction;
        Iterator<String> keysIterator = probabilityMap.keySet().iterator();
        while(keysIterator.hasNext()) {
            referrerId = keysIterator.next();
            probability = (EventFootballProbability)probabilityMap.get(referrerId);
            homeTeam=awayTeam="";
            oh=od=oa=0.0;
            bettingOfferIdH=bettingOfferIdA=bettingOfferIdD="";

            oddList = footballEntitiesForKelly.get(referrerId);
            logger.debug("oddList:" + oddList.toString());
            if(oddList == null) {
                continue;
            }
            for(FootballBookmakerOdd odd : oddList) {
                switch (odd.getRole()) {
                    case HOME:
                        homeTeam = odd.getTeam();
                        oh = odd.getOdd();
                        bettingOfferIdH = odd.getOddId();
                        break;
                    case AWAY:
                        awayTeam = odd.getTeam();
                        oa = odd.getOdd();
                        bettingOfferIdA = odd.getOddId();
                        break;
                    case DRAW:
                        od = odd.getOdd();
                        bettingOfferIdD = odd.getOddId();
                        break;
                 }
                if(logger.isDebugEnabled()) {
                    logger.debug("team:" + odd.getTeam() + ", role:" + odd.getRole()+", platform:"+odd.getPlatformId()+", bookmaker:"+odd.getBookmaker()+", odd:"+odd.getOdd());
                }
                if ((oa*oh*od) > 0) {
                    if(logger.isDebugEnabled()) {
                        logger.debug("oa:" + oa+", oh:"+oh+", od:"+od);
                    }
                    pa = 1.0/oa;
                    ph = 1.0/oh;
                    pd = 1.0/od;
                    pb = pa+ph+pd;
                    pa /= pb;
                    ph /= pb;
                    pd /= pb;
                    hh = probability.getHome();
                    dd = probability.getDraw();
                    aa = probability.getAway();
                    dm = Math.max(aa,Math.max(hh,dd));
                    if (MathUtil.smoothStep(dm , PROBMAX)>0.1) {
                        if(((((Math.abs(aa - pa)) / pa) >= QUOTAPERC) && (aa == dm))
                                || ((((Math.abs(hh - ph)) / ph) >= QUOTAPERC) && (hh == dm))
                                || ((((Math.abs(dd - pd)) / pd) >= QUOTAPERC) && (dd == dm))) {
                            fh = MathUtil.smoothStep(dm , PROBMAX)*((hh * oh) - 1.0) / (oh - 1.0);
                            fd = MathUtil.smoothStep(dm , PROBMAX)*((dd * od) - 1.0) / (od - 1.0);
                            fa = MathUtil.smoothStep(dm , PROBMAX)*((aa * oa) - 1.0) / (oa - 1.0);
                            if ((fh > 0) || (fa > 0) || (fd > 0)) {
                                if(logger.isDebugEnabled()) {
                                    logger.debug("fa:"+fa+", fh:"+fh+", fd:"+fd+", probability.getHome():"+probability.getHome()+", probability.getDraw():"+probability.getDraw()+", probability.getAway():"+probability.getAway());
                                }
                                fraction = new EventFraction();
                                fraction.setReferrerId(referrerId);
                                fraction.setEventId(odd.getEventId());
                                fraction.setOddId(odd.getOddId());
                                fraction.setPlatformId(odd.getPlatformId());
                                fraction.setHomeTeam(homeTeam);
                                fraction.setAwayTeam(awayTeam);
                                fraction.setChampionship(odd.getChampionShip());
                                fraction.setCountry(odd.getCountry());
                                fraction.setContinent(odd.getContinent());
                                fraction.setBookmakerId(odd.getBookmaker());
                                fraction.setStartTime(odd.getMatchDateM());
                                fraction.setFa(fa);
                                fraction.setFh(fh);
                                fraction.setFd(fd);
                                fraction.setPh(Math.round(Math.round(100 * probability.getHome())));
                                fraction.setPd(Math.round(Math.round(100 * probability.getDraw())));
                                fraction.setPa(Math.round(Math.round(100 * probability.getAway())));
                                fraction.setPbh(Math.round(Math.round(100 * ph)));
                                fraction.setPbd(Math.round(Math.round(100 * pd)));
                                fraction.setPba(Math.round(Math.round(100 * pa)));
                                fraction.setDelta(dm);
                                fraction.setBettingOfferIdH(bettingOfferIdH);
                                fraction.setBettingOfferIdA(bettingOfferIdA);
                                fraction.setBettingOfferIdD(bettingOfferIdD);
                                fraction.setBettingType(odd.getBettingType());
                                eventList.add(fraction);

                            }
                        }
                    }
                    oa = oh = od = 0;
                }
            }
        }
        logger.debug(eventList.toString());
        bettingUserConnector.truncateFootballFractionTables();
        bettingUserConnector.insertEventFootballFraction(eventList);
    }
}
