package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.Platforms;
import com.kellify.common.model.BookmakerOdd;

import java.util.*;
import java.util.stream.Collectors;

public class ProbabilityMapFilter<T> {

    private final Map<String, List<T>> entitiesForKelly;

    public ProbabilityMapFilter(Map<String, List<T>> entitiesForKelly) {
        this.entitiesForKelly = entitiesForKelly;
    }

    public Map<String, List<T>> filter() {
        Map<String, List<T>> entities = new HashMap<>();

        List<T> matches;
        for(String referrerId : entitiesForKelly.keySet()) {
            matches = entitiesForKelly.get(referrerId);
            entities.put(referrerId, reduceValidToMatches(matches));
        }

        return entities;
    }

    private List<T> reduceValidToMatches(List<T> matches) {
        List<T> rightMatches = new ArrayList<>();

        List<T> sampleOddPilot = matches.stream().filter(e -> ((BookmakerOdd)e).getPlatformId() == Platforms.BETBRAIN.getNumVal()).collect(Collectors.toList());

        boolean broken = false;
        for(T oddObj : matches) {
            BookmakerOdd odd = (BookmakerOdd)oddObj;
            if(odd.getPlatformId() == Platforms.BETBRAIN.getNumVal()) {
                rightMatches.add(oddObj);
                continue;
            }
            broken = false;
            for(T sOdd : sampleOddPilot) {
                if (odd.getRole() == ((BookmakerOdd)sOdd).getRole() && !odd.getTeam().equals(((BookmakerOdd)sOdd).getTeam())) {
                    broken = true;
                    break;
                }

            }
            if(!broken) {
                rightMatches.add(oddObj);
            }
        }
        return rightMatches;
    }
}
