package com.kellify.fractionsmaker.model.icehockey;


import com.kellify.fractionsmaker.model.EventProbability;

public class EventIceHockeyHAProbability extends EventProbability {
    public EventIceHockeyHAProbability(String eventId, double confidence, double home, double away) {
        super(eventId, confidence, home, away);
    }

    @Override
    public String toString() {
        return "EventIceHockeyHAProbability{" +
                "eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
