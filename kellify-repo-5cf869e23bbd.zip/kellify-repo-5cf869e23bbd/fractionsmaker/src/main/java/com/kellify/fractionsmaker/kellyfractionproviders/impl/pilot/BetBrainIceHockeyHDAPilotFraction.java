package com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot;

import com.kellify.common.SportTypes;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.PilotFractionProvider;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHDAProbability;
import com.kellify.fractionsmaker.oddreduce.ProbabilityMap;
import com.kellify.fractionsmaker.oddreduce.ProbabilityMapFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class BetBrainIceHockeyHDAPilotFraction implements PilotFractionProvider {
    private static final Logger logger = LoggerFactory.getLogger(BetBrainIceHockeyHDAPilotFraction.class);

    private final DbBettingUserConnector bettingUserConnector;
    private final DbUbibetterConnector ubibetterConnector;

    public BetBrainIceHockeyHDAPilotFraction(DbBettingUserConnector bettingUserConnector, DbUbibetterConnector ubibetterConnector) {
        this.bettingUserConnector = bettingUserConnector;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public Map<String, ? extends EventProbability> probabilityMap() throws SQLException {
        Map<String, List<IceHockeyBookmakerOdd>> iceHockeyHDAEntitiesForProbabilities = bettingUserConnector.loadIceHockeyHDAEntitiesForProbabilities();
        ProbabilityMapFilter filter = new ProbabilityMapFilter<>(iceHockeyHDAEntitiesForProbabilities);
        iceHockeyHDAEntitiesForProbabilities = filter.filter();

        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventIceHockeyHDAProbability> iceHockeyHDAProbabilityMap = oddReducer.iceHockeyHdaReduce(iceHockeyHDAEntitiesForProbabilities);
        logger.debug("iceHockeyHDAProbabilityMap:" + iceHockeyHDAProbabilityMap);
        return iceHockeyHDAProbabilityMap;
    }

    @Override
    public SportTypes sport() {
        return SportTypes.ICE_HOCKEY_HDA;
    }
}
