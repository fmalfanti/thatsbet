package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.SportTypes;
import com.kellify.common.model.HA.HADTO;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyHADTO;
import com.kellify.common.util.DTOType;
import com.kellify.common.util.GenericUtils;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.aggregation.IceHockeyHAAggregation;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.baseball.EventBaseballProbability;
import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHAProbability;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHaProbabilitiesResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class IceHockeyHaEventProbabilityMakerImlp implements  EventProbabilityMaker {
    private static final Logger logger = LoggerFactory.getLogger(IceHockeyHaEventProbabilityMakerImlp.class);

    private final Map.Entry<String, List<IceHockeyBookmakerOdd>> mapEntry;
    Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA;
    private final IceHockeyHAAggregation iceHockeyHAAggregation;

    public IceHockeyHaEventProbabilityMakerImlp(Map.Entry<String, List<IceHockeyBookmakerOdd>> mapEntry,  Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA, IceHockeyHAAggregation iceHockeyHAAggregation) {
        this.mapEntry = mapEntry;
        this.mappaHA = mappaHA;
        this.iceHockeyHAAggregation = iceHockeyHAAggregation;
    }

    @Override
    public EventProbability buildEventProbability() throws SQLException {
        double hmin = 1000;
        double amin = 1000;
        double hmax = 0;
        double amax = 0;
        double hmaxInf;
        double hminSup;
        double amaxInf;
        double aminSup;
        double Adistance;
        double Hdistance;
        int first;
        int second;
        int third;
        int limitFuoriSoglia = 0;
        double percLimitFuoriSoglia = 0.1;
        double a = 0;
        double h = 0;
        double ct = 0;
        double pa, ph, pb;
        String country = null;
        String continent = null;
        List<double[]> homeAwayProbabilityList = new ArrayList<>();
        HADTO params = null;

        IceHockeyHaProbabilitiesResult resultKnn = null;
        IceHockeyHaProbabilitiesResult resultDb = null;
        IceHockeyHaProbabilitiesResult resultMatrix = null;

        for (IceHockeyBookmakerOdd entity : mapEntry.getValue()) {
            country = entity.getCountry();
            continent = entity.getContinent();
            switch (entity.getRole()) {
                case HOME:
                    h = entity.getOdd();
                    break;
                default:
                    a = entity.getOdd();
                    break;
            }
            if ((a>=1) && (h>=1)) {
                pa=1.0/a;
                ph=1.0/h;
                pb=pa+ph;
                pa/=pb;
                ph/=pb;
                amax=Math.max(amax,pa);
                amin=Math.min(amin,pa);
                hmax=Math.max(hmax,ph);
                hmin=Math.min(hmin,ph);
                homeAwayProbabilityList.add(new double[]{ph, pa});
                a=h=0;
            }
        }
        limitFuoriSoglia = (int)(homeAwayProbabilityList.size()*percLimitFuoriSoglia);
        //System.out.println("homeAwayProbabilityList tennis" +  homeAwayProbabilityList.size() + "limitFuoriSoglia: " +limitFuoriSoglia);

        if((amin<0.5) && (amax>0.5)) {
            if(logger.isDebugEnabled()) {
                logger.debug("Match icehockey_ha removed: amin="+amin+" and amax="+amax);
            }
            return null;
        }
//        else {
//            hminSup = hmin * 1.1;
//            hmaxInf = hmax * 0.9;
//            first=second=third= 0;
//            Hdistance=(hmax-hmin)/hmax;
//            boolean toRemove = true;
//            double[] element;
//            Iterator<double[]> it = homeAwayProbabilityList.iterator();
//            if (Hdistance > 0.1) {
//                while (it.hasNext()) {
//                    element = it.next();
//                    if (element[0] <hmaxInf) {
//                        first++;
//                        continue;
//                    }
//                    if (element[0] > hmaxInf && element[0] < hminSup) {
//                        second++;
//                        continue;
//                    }
//                    if (element[0] > hminSup) {
//                        third++;
//                        continue;
//                    }
//                }
//
//
//                if (first + second <= limitFuoriSoglia) {
//                    hmin = hminSup;
//                    toRemove = false;
//
//                }
//                if (first + third <= limitFuoriSoglia) {
//                    hmax = hminSup;
//                    hmin = hmaxInf;
//                    toRemove = false;
//
//                }
//                if (second + third <= limitFuoriSoglia) {
//                    hmax = hmaxInf;
//                    toRemove = false;
//                }
//                if (toRemove) {
//                    if (logger.isDebugEnabled()) {
//                        logger.debug("Match icehockey_ha removed");
//                        return null;
//                    }
//                }
//            }
//
//            aminSup = amin * 1.1;
//            amaxInf = amax * 0.9;
//            toRemove = true;
//            Adistance=(amax-amin)/amax;;
//            first=second=third= 0;
//            it = homeAwayProbabilityList.iterator();
//            if (Adistance > 0.1) {
//                while (it.hasNext()) {
//                    element=it.next();
//                    if (element[1] < amaxInf) {
//                        first++;
//                        continue;
//                    }
//                    if (element[1] > aminSup) {
//                        third++;
//                        continue;
//                    }
//                    if (element[1] > amaxInf && element[1] < aminSup) {
//                        second++;
//                        continue;
//                    }
//                }
//                if (first + second <= limitFuoriSoglia) {
//                    amin = aminSup;
//                    toRemove = false;
//                }
//                if (first + third <= limitFuoriSoglia) {
//                    amax = aminSup;
//                    amin = amaxInf;
//                    toRemove = false;
//                }
//                if (second + third <= limitFuoriSoglia) {
//                    amax = amaxInf;
//                    toRemove = false;
//                }
//                if (toRemove) {
//                    if (logger.isDebugEnabled()) {
//                        logger.debug("Match icehockey_ha removed");
//                        return null;
//                    }
//                }
//            }
//        }
        amax=((int)Math.ceil(amax*100.))/100.;
        amin=((int)Math.floor(amin*100.))/100.;
        hmax=((int)Math.ceil(hmax*100.))/100.;
        hmin=((int)Math.floor(hmin*100.))/100.;

        if(logger.isDebugEnabled()) {
            logger.debug(GenericUtils.getMatchTeams(mapEntry.getValue()) + " - hmin:" + hmin + ", hmax:" + hmax + ", amin:" + amin + ", amax:" + amax);
        }
        params =new HADTO(SportTypes.ICE_HOCKEY, hmin, hmax, amin, amax, country, DTOType.PROBABILITY, continent);

        resultDb = iceHockeyHAAggregation.evaluateDb(params);
        resultKnn = iceHockeyHAAggregation.evaluateKnn(params, mappaHA);
        resultMatrix = iceHockeyHAAggregation.evaluateMatrix(params, mappaHA);
        if(logger.isDebugEnabled()) {
            logger.debug("icehockey_ha resultDb:" + resultDb + ", resultKnn:" + resultKnn + ", resultMatrix:" + resultMatrix);
        }
        double hh = resultDb.getHome() + resultKnn.getHome()+resultMatrix.getHome();
        double aa = resultDb.getAway() + resultKnn.getAway() + resultMatrix.getAway();
        double confidence = (resultDb.getConfidence() + resultKnn.getConfidence() + resultMatrix.getConfidence())/3;

        ct = aa+hh;

        if (ct>100) {
            pa = aa / ct;
            ph = hh / ct;

            return new EventIceHockeyHAProbability(mapEntry.getKey(), confidence, ph, pa);

        }

        return null;
    }

}
