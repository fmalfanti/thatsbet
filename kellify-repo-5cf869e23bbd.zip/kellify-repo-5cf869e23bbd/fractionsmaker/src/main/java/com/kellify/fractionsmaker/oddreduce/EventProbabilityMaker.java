package com.kellify.fractionsmaker.oddreduce;

import com.kellify.fractionsmaker.model.EventProbability;

import java.sql.SQLException;

public interface EventProbabilityMaker {
    EventProbability buildEventProbability() throws SQLException;
}
