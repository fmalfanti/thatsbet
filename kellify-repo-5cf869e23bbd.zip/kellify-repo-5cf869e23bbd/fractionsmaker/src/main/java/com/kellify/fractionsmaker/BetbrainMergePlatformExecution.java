package com.kellify.fractionsmaker;


import com.kellify.fractionsmaker.db.DBBetbrainConnector;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbBookmakerBettingConnector;
import com.kellify.fractionsmaker.executorprovider.BetBrainProviderPilot;
import com.kellify.fractionsmaker.executorprovider.Provider;
import com.kellify.fractionsmaker.executorprovider.ProviderPilot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

import java.util.List;
import java.util.Properties;

public class BetbrainMergePlatformExecution {
    private static final Logger logger = LoggerFactory.getLogger(BetbrainMergePlatformExecution.class);
    private final Properties config;
    private List<Provider> providers;

    public BetbrainMergePlatformExecution(Properties config) {
        this.config = config;
    }


    private ProviderPilot initProviderPilot(DBBetbrainConnector betbrainConnector, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) throws SQLException {
        BetBrainProviderPilot providerPilot = new BetBrainProviderPilot(betbrainConnector, bbConnector, bettingUserConnector);
        providerPilot.init();
        return providerPilot;
    }

    public void run() {
        DbBookmakerBettingConnector bbConnector = null;
        DBBetbrainConnector betbrainConnector = null;
        DbBettingUserConnector bettingUserConnector = null;

        try {
            bbConnector = new DbBookmakerBettingConnector(config);
            betbrainConnector = new DBBetbrainConnector(config);
            bettingUserConnector = new DbBettingUserConnector(config);

            bettingUserConnector.truncateFootballSnapshot();
            bettingUserConnector.truncateTennisSnapshot();
            bettingUserConnector.truncateBasketSnapshot();
            bettingUserConnector.truncateBaseballSnapshot();
            bettingUserConnector.truncateAmericanFootballSnapshot();
            bettingUserConnector.truncateIcehockeySnapshot();

            ProviderPilot providerPilot = initProviderPilot(betbrainConnector, bbConnector, bettingUserConnector);
            providerPilot.createOddsSnapshot();

        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        } finally {
            if(bbConnector != null) {
                bbConnector.closeConnection();;
            }
            if(betbrainConnector != null) {
                betbrainConnector.closeConnection();;
            }
            if(bettingUserConnector != null) {
                bettingUserConnector.closeConnection();;
            }
        }
    }
}
