package com.kellify.fractionsmaker;

import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.FractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.PilotFractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.*;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class FractionsMakerExecution {
    private static final Logger logger = LoggerFactory.getLogger(FractionsMakerExecution.class);

    private final Properties config;

    public FractionsMakerExecution(Properties config) {
        this.config = config;
    }


    public void run() {
        DbUbibetterConnector ubibetterConnector = null;
        DbBettingUserConnector bettingUserConnector = null;
        try {
            // Merge platform
            BetbrainMergePlatformExecution betbrainMergePlatformExecution = new BetbrainMergePlatformExecution(config);
            betbrainMergePlatformExecution.run();

            ubibetterConnector = DbUbibetterConnector.getInstance(config);
            bettingUserConnector = DbBettingUserConnector.getInstance(config);

//            bettingUserConnector.backupAllFractionTables();
//            bettingUserConnector.checkAndBackupFractionTables();

            PilotFractionProvider pilotFraction = null;
            FractionProvider fractionProvider = null;

//            // FOOTBALL
//            pilotFraction = new BetBrainFootballPilotFraction(ubibetterConnector, bettingUserConnector);
//            fractionProvider = new FootballFractionProvider(bettingUserConnector, pilotFraction, config);
//            fractionProvider.execute();

            // TENNIS
            pilotFraction = new BetBrainTennisPilotFraction(bettingUserConnector, ubibetterConnector);
            fractionProvider = new TennisFractionProvider(bettingUserConnector, pilotFraction, config);
            fractionProvider.execute();

//             //BASKET
//            pilotFraction = new BetBrainBasketPilotFraction(ubibetterConnector, bettingUserConnector);
//            fractionProvider = new BasketFractionProvider(bettingUserConnector, pilotFraction, config);
//            fractionProvider.execute();
//
//            // BASEBALL
//            pilotFraction = new BetBrainBaseballPilotFraction(bettingUserConnector, ubibetterConnector);
//            fractionProvider = new BaseballFractionProvider(bettingUserConnector, pilotFraction, config);
//            fractionProvider.execute();
//
//            // AMERICANFOOTBALL
//            pilotFraction = new BetBrainAmericanFootballPilotFraction(bettingUserConnector, ubibetterConnector);
//            fractionProvider = new AmericanFootballFractionProvider(bettingUserConnector, pilotFraction, config);
//            fractionProvider.execute();
//
//            //HOCKEY_HA
//            pilotFraction = new BetBrainIceHockeyPilotFraction(bettingUserConnector, ubibetterConnector);
//            fractionProvider = new IceHockeyHAFractionProvider(bettingUserConnector, pilotFraction, config);
//            fractionProvider.execute();

            // HOCKEY_HDA
//            pilotFraction = new BetBrainIceHockeyHDAPilotFraction(bettingUserConnector, ubibetterConnector);
//            fractionProvider = new IceHockeyHDAFractionProvider(bettingUserConnector, pilotFraction, config);
//            fractionProvider.execute();
//            bettingUserConnector.backupAllFractionTables();

        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        } finally {
            if(ubibetterConnector != null) {
                ubibetterConnector.closeConnection();;
            }
            if(bettingUserConnector != null) {
                bettingUserConnector.closeConnection();;
            }
        }
    }
}
