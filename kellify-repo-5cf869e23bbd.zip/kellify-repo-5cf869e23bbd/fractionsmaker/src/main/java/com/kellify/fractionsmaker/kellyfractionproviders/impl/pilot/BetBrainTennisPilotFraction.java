package com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot;

import com.kellify.common.SportTypes;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.PilotFractionProvider;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.tennis.EventTennisProbability;
import com.kellify.fractionsmaker.oddreduce.ProbabilityMap;

import com.kellify.fractionsmaker.oddreduce.ProbabilityMapFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class BetBrainTennisPilotFraction implements PilotFractionProvider {
    private static final Logger logger = LoggerFactory.getLogger(BetBrainTennisPilotFraction.class);

    private final DbBettingUserConnector bettingUserConnector;
    private final DbUbibetterConnector ubibetterConnector;

    public BetBrainTennisPilotFraction(DbBettingUserConnector bettingUserConnector, DbUbibetterConnector ubibetterConnector) {
        this.bettingUserConnector = bettingUserConnector;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public Map<String, ? extends EventProbability> probabilityMap() throws SQLException {
        Map<String, List<TennisBookmakerOdd>> tennisEntitiesForProbabilities = bettingUserConnector.loadTennisEntitiesForProbabilities();
        ProbabilityMapFilter filter = new ProbabilityMapFilter<>(tennisEntitiesForProbabilities);
        tennisEntitiesForProbabilities = filter.filter();

        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventTennisProbability> tennisProbabilityMap = oddReducer.tennisReduce(tennisEntitiesForProbabilities);
        logger.debug("tennisProbabilityMap:" + tennisProbabilityMap);
        return tennisProbabilityMap;
    }

    @Override
    public SportTypes sport() {
        return SportTypes.TENNIS;
    }
}
