package com.kellify.fractionsmaker.kellyfractionproviders.impl;

import com.kellify.common.model.tennis.EventTennisFraction;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.common.util.MathUtil;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.FractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.PilotFractionProvider;
import com.kellify.fractionsmaker.model.EventProbability;
import com.kellify.fractionsmaker.model.tennis.EventTennisProbability;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.*;

public class TennisFractionProvider implements FractionProvider {
    private static final Logger logger = LoggerFactory.getLogger(TennisFractionProvider.class);

    private final double QUOTAPERC;
    private final double PROBMAX;
    private final DbBettingUserConnector bettingUserConnector;
    private final PilotFractionProvider pilotFractionProvider;
    private final Properties config;

    public TennisFractionProvider(DbBettingUserConnector bettingUserConnector, PilotFractionProvider pilotFractionProvider, Properties config) {
        this.bettingUserConnector = bettingUserConnector;
        this.pilotFractionProvider = pilotFractionProvider;
        this.config = config;
        double qPerc = 0.0;
        try {
            qPerc = Double.parseDouble(config.getProperty("tennis.quotaperc"));
        } catch(NumberFormatException ex) {
            qPerc = 0.05;
        }
        QUOTAPERC = qPerc;
        double pMax = 0.0;
        try {
            pMax = Double.parseDouble(config.getProperty("tennis.probmax"));
        } catch(NumberFormatException ex) {
            qPerc = 0.7;
        }
        PROBMAX = pMax;
    }

    @Override
    public void execute() throws SQLException {
        Map<String, List<TennisBookmakerOdd>> tennisEntitiesForKelly = bettingUserConnector.loadTennisEntitiesForKelly();
        logger.debug("tennisEntitiesForKelly size:" + tennisEntitiesForKelly.size());
        List<EventTennisFraction> eventList = new ArrayList<>();
        Map<String, ? extends EventProbability> probabilityMap = pilotFractionProvider.probabilityMap();
        EventTennisProbability probability;
        List<TennisBookmakerOdd> oddList;
        String referrerId;
        String bettingOfferIdH,bettingOfferIdA;
        String homeTeam,awayTeam;
        double oh,oa;
        double aa,hh,dm;
        double pa,ph,pb;
        double fh,fa;
        EventTennisFraction fraction;
        Iterator<String> keysIterator = probabilityMap.keySet().iterator();
        while(keysIterator.hasNext()) {
            referrerId = keysIterator.next();
            probability = (EventTennisProbability)probabilityMap.get(referrerId);
            homeTeam=awayTeam="";
            oh=oa=0.0;
            bettingOfferIdH=bettingOfferIdA="";

            oddList = tennisEntitiesForKelly.get(referrerId);
            if(oddList == null) {
                continue;
            }
            for(TennisBookmakerOdd odd : oddList) {
                switch (odd.getRole()) {
                    case HOME:
                        homeTeam = odd.getTeam();
                        oh = odd.getOdd();
                        bettingOfferIdH = odd.getOddId();
                        break;
                    default:
                        awayTeam = odd.getTeam();
                        oa = odd.getOdd();
                        bettingOfferIdA = odd.getOddId();
                        break;
                }
                if(logger.isDebugEnabled()) {
                    logger.debug("team:" + odd.getTeam() + ", role:" + odd.getRole()+", platform:"+odd.getPlatformId()+", bookmaker:"+odd.getBookmaker()+", odd:"+odd.getOdd());
                }
                if ((oa*oh) > 0) {
                    if(logger.isDebugEnabled()) {
                        logger.debug("oa:" + oa+", oh:"+oh);
                    }
                    pa = 1.0/oa;
                    ph = 1.0/oh;
                    pb = pa+ph;
                    pa /= pb;
                    ph /= pb;
                    hh = probability.getHome();
                    aa = probability.getAway();

                    dm = Math.max(aa,hh);
                    if (MathUtil.smoothStep(dm , PROBMAX)>0.1) {
                        if(((((Math.abs(aa - pa)) / pa) >=QUOTAPERC) && (aa==dm)) || ((((Math.abs(hh - ph)) / ph) >=QUOTAPERC) && (hh==dm))){
                            fh = MathUtil.smoothStep(dm , PROBMAX)*((hh * oh) - 1.0) / (oh - 1.0);
                            fa = MathUtil.smoothStep(dm , PROBMAX)*((aa * oa) - 1.0) / (oa - 1.0);
                            if ((fh > 0) || (fa > 0)) {
                                if(logger.isDebugEnabled()) {
                                    logger.debug("fa:"+fa+", fh:"+fh+", probability.getHome():"+probability.getHome()+", probability.getAway():"+probability.getAway());
                                }
                                fraction = new EventTennisFraction();
                                fraction.setReferrerId(referrerId);
                                fraction.setEventId(odd.getEventId());
                                fraction.setOddId(odd.getOddId());
                                fraction.setPlatformId(odd.getPlatformId());
                                fraction.setHomeTeam(homeTeam);
                                fraction.setAwayTeam(awayTeam);
                                fraction.setChampionship(odd.getChampionShip());
                                fraction.setCountry(odd.getCountry());
                                fraction.setBookmakerId(odd.getBookmaker());
                                fraction.setStartTime(odd.getMatchDateM());
                                fraction.setFa(fa);
                                fraction.setFh(fh);
                                fraction.setPh(Math.round(Math.round(100 * probability.getHome())));
                                fraction.setPa(Math.round(Math.round(100 * probability.getAway())));
                                fraction.setPbh(Math.round(Math.round(100 * ph)));
                                fraction.setPba(Math.round(Math.round(100 * pa)));
                                fraction.setDelta(dm);
                                fraction.setBettingOfferIdH(bettingOfferIdH);
                                fraction.setBettingOfferIdA(bettingOfferIdA);
                                fraction.setBettingType(odd.getBettingType());
                                eventList.add(fraction);

                            }
                        }
                    }
                    oa = oh = 0;
                }
            }
        }
        logger.debug(eventList.toString());
        bettingUserConnector.truncateTennisFractionTables();
        bettingUserConnector.insertEventTennisFraction(eventList);
    }
}
