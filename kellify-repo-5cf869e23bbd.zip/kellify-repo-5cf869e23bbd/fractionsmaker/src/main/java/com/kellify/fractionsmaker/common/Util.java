package com.kellify.fractionsmaker.common;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public final class Util {
    private Util() {}

    public static String makeMapKey(String campionato, String nazione, LocalDateTime date) {
        return campionato + "_" + nazione + "_" + date.truncatedTo(ChronoUnit.DAYS).toString();
    }

    public static String makeMapKey(LocalDateTime date) {
        return "" + date.truncatedTo(ChronoUnit.DAYS).toString();
    }
}
