package com.kellify.fractionsmaker.model.americanfootball;

import com.kellify.common.BettingType;
import com.kellify.fractionsmaker.model.MatchWithContinent;

import java.time.LocalDateTime;

public class AmericanFootballMatch extends MatchWithContinent {
    public AmericanFootballMatch(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
    }

    public AmericanFootballMatch(String id, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, String referrerId, String country, BettingType bettingType) {
        super(id, homeTeam, awayTeam, leagueName, matchDate, referrerId, country, bettingType);
    }

    @Override
    public String toString() {
        return "AmericanFootballMatch{" +
                "continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
