package com.kellify.fractionsmaker.kellyfractionproviders;

import com.kellify.common.SportTypes;
import com.kellify.fractionsmaker.model.EventProbability;

import java.sql.SQLException;
import java.util.Map;

public interface PilotFractionProvider {
    Map<String, ? extends EventProbability> probabilityMap() throws SQLException;
    SportTypes sport();
}
