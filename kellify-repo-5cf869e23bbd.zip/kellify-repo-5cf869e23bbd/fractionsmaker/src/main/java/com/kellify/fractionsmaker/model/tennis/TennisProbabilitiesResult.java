package com.kellify.fractionsmaker.model.tennis;

import com.kellify.fractionsmaker.model.ProbabilitiesResult;

public class TennisProbabilitiesResult extends ProbabilitiesResult {

    public TennisProbabilitiesResult(int count, double confidence, double home, double away) {
        super(count,confidence, home, away);
    }
}
