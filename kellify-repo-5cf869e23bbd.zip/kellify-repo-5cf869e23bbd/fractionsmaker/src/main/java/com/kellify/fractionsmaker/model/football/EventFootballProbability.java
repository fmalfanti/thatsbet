package com.kellify.fractionsmaker.model.football;


import com.kellify.fractionsmaker.model.EventProbability;

public class EventFootballProbability extends EventProbability {
    private final double draw;

    public EventFootballProbability(String eventId, double confidence, double home, double away, double draw) {
        super(eventId, confidence, home, away);
        this.draw = draw;
    }

    public double getDraw() { return draw; }

    @Override
    public String toString() {
        return "EventFootballProbability{" +
                "draw=" + draw +
                ", eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
