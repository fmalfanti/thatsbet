package com.kellify.fractionsmaker.aggregation;

import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface FootballAggregation {
    FootballProbabilitiesResult evaluateDb(FootballDTO params) throws SQLException;
    FootballProbabilitiesResult evaluateOddDb(FootballDTO params) throws SQLException;
    FootballProbabilitiesResult evaluateKnn(FootballDTO params, Map<String, Map<Integer, Matrici.HdaMatrix>> MappaHDA);
    FootballProbabilitiesResult evaluateMatrix(FootballDTO params, Map<String, Map<Integer, Matrici.HdaMatrix>> MappaHDA);
    FootballProbabilitiesResult evaluateMatrixPerBookmaker(FootballDTO params, List<double[]> homeAwayProbabilityList, Map<String, Map<Integer, Matrici.HdaMatrix>> MappaHDA);
}
