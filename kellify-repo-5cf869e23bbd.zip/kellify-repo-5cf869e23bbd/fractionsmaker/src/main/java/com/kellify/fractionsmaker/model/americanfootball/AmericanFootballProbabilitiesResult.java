package com.kellify.fractionsmaker.model.americanfootball;

import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.fractionsmaker.model.ProbabilitiesResult;

public class AmericanFootballProbabilitiesResult extends ProbabilitiesResult {
    private final ProbabilitiesQueryType type;

    public AmericanFootballProbabilitiesResult(int count, double confidence, double home, double away, ProbabilitiesQueryType type) {
        super(count, confidence, home, away);
        this.type = type;
    }

    public ProbabilitiesQueryType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "AmericanFootballProbabilitiesResult{" +
                "type=" + type +
                ", count=" + count +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
