package com.kellify.fractionsmaker.aggregation;


import com.kellify.common.model.AsianOddsBasketDTO;
import com.kellify.common.model.HA.HADTO;
import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.basket.BasketDTO;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.basket.BasketProbabilitiesResult;
import com.kellify.fractionsmaker.oddreduce.ProbabiltyMapImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class BasketAggregationImpl implements BasketAggregation {
    private static final Logger logger = LoggerFactory.getLogger(ProbabiltyMapImpl.class);

    private final Map<String, List<BasketBookmakerOdd>> entities;
    private final DbUbibetterConnector ubibetterConnector;

    BasketAggregationImpl(Map<String, List<BasketBookmakerOdd>> entities, DbUbibetterConnector ubibetterConnector) {
        this.entities = entities;
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public BasketProbabilitiesResult evaluateDb(HADTO params) throws SQLException {
        BasketProbabilitiesResult result = null;
        result= ubibetterConnector.getBasketFTR(params);
        return result;
    }
    @Override
    public BasketProbabilitiesResult evaluateKnn(HADTO params, Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA) {
        int confidence=5;
        int aa=0,hh=0;
        int knn = 10000;
        int count=0;
        String[] parametri={params.getCountry(), params.getContinent(), "World"};
        Matrici.HAMatrix punto;
        Map<Integer, Matrici.HAMatrix> useNationMap;
        int mh = (int)(100*(params.getHomeMax()+params.getHomeMin())/2.0);

        for (String parametro : parametri) {
            if (count < knn) {
                useNationMap = mappaHA.get(parametro);
                if (useNationMap != null) {
                    for (int ind=0; ind < 4; ind++) {
                        confidence -= ind;
                        hh = 0;
                        aa = 0;
                        for (int i=mh - ind; i <= mh + ind; i++) {
                            punto = useNationMap.get(i);
                            if (punto != null) {
                                hh += punto.getH();
                                aa += punto.getA();
                            }
                        }
                        count = hh + aa;
                        if (count >= knn) {
                            ind = 5;
                        }
                    }
                }
            }
        }

        //System.out.println("count="+count);
        return new BasketProbabilitiesResult(count, confidence, hh, aa, params.getType());
    }

    @Override
    public BasketProbabilitiesResult evaluateMatrix(HADTO params, Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA) {
        int hh=0,aa=0;
        int count=0;
        int confidence = 7;
        String[] parametri = {params.getCountry(), params.getContinent(),"World"};
        Matrici.HAMatrix punto;
        Map<Integer,Matrici.HAMatrix> useNationMap;

        for (String parametro : parametri) {
            confidence -= 2;
            if (count <= 10) {
                hh=0;
                aa=0;
                useNationMap = mappaHA.get(parametro);
                if (useNationMap != null) {
                    for (int i=(int) (100 * params.getHomeMin()); i <= 100 * params.getHomeMax(); i++) {
                        punto = useNationMap.get(i);
                        if (punto != null) {
                            hh+=punto.getH();
                            aa+=punto.getA();
                        }
                    }
                }
                count=hh+aa;
            }
        }
        //System.out.println("count="+count);
        return new BasketProbabilitiesResult(count,confidence, hh, aa, params.getType());
    }

    @Override
    public BasketProbabilitiesResult evaluateMatrixPerBookmaker(BasketDTO params, List<Double> homeProbabilityList, Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA) {
        int hh=0,aa=0;
        int count=0;
        int confidence = 7;
        String[] parametri = {params.getCountry(), params.getContinent(),"World"};
        Matrici.HAMatrix punto;
        Map<Integer,Matrici.HAMatrix> useNationMap;
        int homeProbabilityInt = 0;
        for (String parametro : parametri) {
            confidence -= 2;
            if (count <= 10) {
                hh=0;
                aa=0;
                useNationMap = mappaHA.get(parametro);
                if (useNationMap != null) {
                    for(double homeProbability : homeProbabilityList) {
                        homeProbabilityInt = (int)(homeProbability * 100);
                        punto = useNationMap.get(homeProbabilityInt);
                        if (punto != null) {
                            hh += punto.getH();
                            aa += punto.getA();
                        }
                    }
                }
                count = hh + aa;
            }
        }
        //System.out.println("count="+count);
        return new BasketProbabilitiesResult(count, confidence, hh, aa, params.getType());
    }

    @Override
    public BasketProbabilitiesResult evaluateDbSingleBookmaker(AsianOddsBasketDTO params, Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA) {
        int confidence=5;
        int aa=0,hh=0;
        int knn = 5000;
        int count=0;
        String[] parametri = {params.getCountry(), params.getContinent(), "World"};
        Matrici.HAMatrix punto;
        Map<Integer, Matrici.HAMatrix> useNationMap;
        int mh = (int)(100*params.getHome());

        for (String parametro : parametri) {
            if (count < knn) {
                useNationMap = mappaHA.get(parametro);
                if (useNationMap != null) {
                    for (int ind=0; ind < 4; ind++) {
                        confidence -= ind;
                        hh = 0;
                        aa = 0;
                        for (int i=mh - ind; i <= mh + ind; i++) {
                            punto = useNationMap.get(i);
                            if (punto != null) {
                                hh += punto.getH();
                                aa += punto.getA();
                            }
                        }
                        count = hh + aa;
                        if (count >= knn) {
                            ind = 5;
                        }
                    }
                }
            }
        }

        //System.out.println("count="+count);
        return new BasketProbabilitiesResult(count, confidence, hh, aa, ProbabilitiesQueryType.ALL);
    }
}

