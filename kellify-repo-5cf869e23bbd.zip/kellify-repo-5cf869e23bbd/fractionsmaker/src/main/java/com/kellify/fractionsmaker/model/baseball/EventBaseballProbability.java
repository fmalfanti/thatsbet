package com.kellify.fractionsmaker.model.baseball;


import com.kellify.fractionsmaker.model.EventProbability;

public class EventBaseballProbability extends EventProbability {
    public EventBaseballProbability(String eventId, double confidence, double home, double away) {
        super(eventId, confidence, home, away);
    }

    @Override
    public String toString() {
        return "EventBaseballProbability{" +
                "eventId='" + eventId + '\'' +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
