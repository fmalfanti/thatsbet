package com.kellify.fractionsmaker.oddreduce;


import com.kellify.common.SportTypes;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.common.util.Matrici;
import com.kellify.fractionsmaker.aggregation.*;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.americanfootball.EventAmericanFootballProbability;
import com.kellify.fractionsmaker.model.baseball.EventBaseballProbability;
import com.kellify.fractionsmaker.model.basket.EventBasketProbability;
import com.kellify.fractionsmaker.model.football.EventFootballProbability;

import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHAProbability;
import com.kellify.fractionsmaker.model.icehockey.EventIceHockeyHDAProbability;
import com.kellify.fractionsmaker.model.tennis.EventTennisProbability;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.*;

public class ProbabiltyMapImpl implements ProbabilityMap {
    private static final Logger logger = LoggerFactory.getLogger(ProbabiltyMapImpl.class);

    private final DbUbibetterConnector ubibetterConnector;

    ProbabiltyMapImpl(DbUbibetterConnector ubibetterConnector) {
        this.ubibetterConnector = ubibetterConnector;
    }

    @Override
    public Map<String, EventFootballProbability> footballReduce(Map<String, List<FootballBookmakerOdd>> entities) throws SQLException {
        if(logger.isDebugEnabled()) {
            logger.debug(entities.toString());
        }
        Map<String,Map<Integer,Matrici.HdaMatrix>> mappeFootball;
        Map<String,Map<Integer,Matrici.HdaMatrix>> mappeFootballWeight;
        Map<String, EventFootballProbability> probabilityMap = new HashMap<>();

        EventFootballProbability eventFootballProbability = null;
        EventProbabilityMaker eventProbabilityMaker = null;

        FootballAggregation footballAggregation = Aggregation.getFootballInstance(entities,ubibetterConnector);
        try {
            mappeFootball = ubibetterConnector.createHDAMapsFromStrings(SportTypes.FOOTBALL);
            mappeFootballWeight = ubibetterConnector.createHDAMapsFromStringsWeight(SportTypes.FOOTBALL);
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }

        for (Map.Entry<String, List<FootballBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new FootballEventProbabilityMakerImpl(mapEntry, mappeFootball, mappeFootballWeight,footballAggregation);
            eventFootballProbability = (EventFootballProbability)eventProbabilityMaker.buildEventProbability();
            if (eventFootballProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventFootballProbability);
            }
        }
        ubibetterConnector.FTRStatementInitTearDown();

        return probabilityMap;
    }

    @Override
    public Map<String, EventTennisProbability> tennisReduce(Map<String, List<TennisBookmakerOdd>> entities) throws SQLException {
        if(logger.isDebugEnabled()) {
            logger.debug(entities.toString());
        }
        Map<Integer,Matrici.WLMatrix> mappaWL;
        Map<String, EventTennisProbability> probabilityMap = new HashMap<>();
        EventProbabilityMaker eventProbabilityMaker = null;
        EventTennisProbability eventTennisProbability = null;

        TennisAggregation tennisAggregation = Aggregation.getTennisInstance(entities, ubibetterConnector);
        try {
            mappaWL = ubibetterConnector.createWLMapsFromStrings();
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }
        for (Map.Entry<String, List<TennisBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new TennisEventProbabilityMakerImpl(mapEntry, mappaWL, tennisAggregation);
            eventTennisProbability = (EventTennisProbability)eventProbabilityMaker.buildEventProbability();
            if (eventTennisProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventTennisProbability);
            }
        }
                ubibetterConnector.WLStatementInitTearDown();

        return probabilityMap;
    }

    @Override
    public Map<String, EventBasketProbability> basketReduce(Map<String, List<BasketBookmakerOdd>> entities) throws SQLException {
        logger.debug(entities.toString());

        Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA;
        Map<String, EventBasketProbability> probabilityMap = new HashMap<>();
        EventProbabilityMaker eventProbabilityMaker = null;
        EventBasketProbability eventBasketProbability = null;
        BasketAggregation basketAggregation = Aggregation.getBasketInstance(entities, ubibetterConnector);
        try {
            mappaHA = ubibetterConnector.createHAMapsFromStrings(SportTypes.BASKET);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }
        for (Map.Entry<String, List<BasketBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new BasketEventProbabilityMakerImpl(mapEntry, mappaHA, basketAggregation);
            eventBasketProbability = (EventBasketProbability)eventProbabilityMaker.buildEventProbability();
            if (eventBasketProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventBasketProbability);
            }
        }
        ubibetterConnector.HAStatementInitTearDown();

        return probabilityMap;
    }
    @Override
    public Map<String, EventBaseballProbability> baseballReduce(Map<String, List<BaseballBookmakerOdd>> entities) throws SQLException {
        if(logger.isDebugEnabled()) {
            logger.debug(entities.toString());
        }

        Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA;
        Map<String, EventBaseballProbability> probabilityMap = new HashMap<>();
        EventProbabilityMaker eventProbabilityMaker = null;
        EventBaseballProbability eventBaseballProbability = null;
        BaseballAggregation baseballAggregation = Aggregation.getBaseballInstance(entities, ubibetterConnector);
        try {
            mappaHA = ubibetterConnector.createHAMapsFromStrings(SportTypes.BASEBALL);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }
        for (Map.Entry<String, List<BaseballBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new BaseballEventProbabilityMapImpl(mapEntry, mappaHA, baseballAggregation);
            eventBaseballProbability = (EventBaseballProbability)eventProbabilityMaker.buildEventProbability();
            if (eventBaseballProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventBaseballProbability);
            }
        }

        ubibetterConnector.HAStatementInitTearDown();

        return probabilityMap;
    }



    @Override
    public Map<String, EventIceHockeyHAProbability> iceHockeyHaReduce(Map<String, List<IceHockeyBookmakerOdd>> entities) throws SQLException {
        if(logger.isDebugEnabled()) {
            logger.debug(entities.toString());
        }

        Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA;
        Map<String, EventIceHockeyHAProbability> probabilityMap = new HashMap<>();
        EventProbabilityMaker eventProbabilityMaker = null;
        EventIceHockeyHAProbability eventIceHockeyHAProbability = null;
        IceHockeyHAAggregation iceHockeyHAAggregation = Aggregation.getIceHockeyHAInstance(entities, ubibetterConnector);
        try {
            mappaHA = ubibetterConnector.createHAMapsFromStrings(SportTypes.ICE_HOCKEY);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }
        for (Map.Entry<String, List<IceHockeyBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new IceHockeyHaEventProbabilityMakerImlp(mapEntry, mappaHA, iceHockeyHAAggregation);
            eventIceHockeyHAProbability = (EventIceHockeyHAProbability)eventProbabilityMaker.buildEventProbability();
            if (eventIceHockeyHAProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventIceHockeyHAProbability);
            }
        }

        ubibetterConnector.HAStatementInitTearDown();

        return probabilityMap;
    }

    @Override
    public Map<String, EventAmericanFootballProbability> americanfootballReduce(Map<String, List<AmericanFootballBookmakerOdd>> entities) throws SQLException {
        if(logger.isDebugEnabled()) {
            logger.debug(entities.toString());
        }

        Map<String,Map<Integer,Matrici.HAMatrix>> mappaHA;
        Map<String, EventAmericanFootballProbability> probabilityMap = new HashMap<>();
        EventProbabilityMaker eventProbabilityMaker = null;
        EventAmericanFootballProbability eventAmericanFootballProbability = null;
        AmericanFootballAggregation americanFootballAggregation = Aggregation.getAmericanFootballInstance(entities, ubibetterConnector);
        try {
            mappaHA = ubibetterConnector.createHAMapsFromStrings(SportTypes.AMERICAN_FOOTBALL);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }
        for (Map.Entry<String, List<AmericanFootballBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new AmericanFootballEventProbabilityMapImpl(mapEntry, mappaHA, americanFootballAggregation);
            eventAmericanFootballProbability = (EventAmericanFootballProbability)eventProbabilityMaker.buildEventProbability();
            if (eventAmericanFootballProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventAmericanFootballProbability);
            }
        }

        ubibetterConnector.HAStatementInitTearDown();

        return probabilityMap;
    }

    @Override
    public Map<String, EventIceHockeyHDAProbability> iceHockeyHdaReduce(Map<String, List<IceHockeyBookmakerOdd>> entities) throws SQLException {
        if(logger.isDebugEnabled()) {
            logger.debug(entities.toString());
        }

        Map<String,Map<Integer,Matrici.HdaMatrix>> mappaHDA;
        Map<String, EventIceHockeyHDAProbability> probabilityMap = new HashMap<>();
        EventProbabilityMaker eventProbabilityMaker = null;
        EventIceHockeyHDAProbability eventIceHockeyHDAProbability = null;
        IceHockeyHDAAggregation iceHockeyHDAAggregation = Aggregation.getIceHockeyHDAInstance(entities, ubibetterConnector);
        try {
            mappaHDA = ubibetterConnector.createHDAMapsFromStrings(SportTypes.ICE_HOCKEY_HDA);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return probabilityMap;
        }
        for (Map.Entry<String, List<IceHockeyBookmakerOdd>> mapEntry : entities.entrySet()) {
            eventProbabilityMaker = new IceHockeyHdaEventProbabilityMakerImlp(mapEntry, mappaHDA, iceHockeyHDAAggregation);
            eventIceHockeyHDAProbability = (EventIceHockeyHDAProbability)eventProbabilityMaker.buildEventProbability();
            if (eventIceHockeyHDAProbability != null) {
                probabilityMap.put(mapEntry.getKey(), eventIceHockeyHDAProbability);
            }
        }

        ubibetterConnector.HAStatementInitTearDown();

        return probabilityMap;
    }

}
