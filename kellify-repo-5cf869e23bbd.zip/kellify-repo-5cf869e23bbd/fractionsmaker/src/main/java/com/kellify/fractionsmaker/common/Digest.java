package com.kellify.fractionsmaker.common;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Digest {


    public Digest(String s) {
    }

    public static String MD5Digest(String  arg) throws NoSuchAlgorithmException {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(arg.getBytes());
            byte[] digest = md.digest();
            StringBuffer sb = new StringBuffer();
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }
            return sb.toString();
    }
}