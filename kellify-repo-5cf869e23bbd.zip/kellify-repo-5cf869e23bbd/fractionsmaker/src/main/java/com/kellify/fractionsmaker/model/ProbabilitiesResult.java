package com.kellify.fractionsmaker.model;

public class ProbabilitiesResult {
    protected final int count;
    protected final double home;
    protected final double away;
    protected final double confidence;

    public ProbabilitiesResult(int count, double confidence, double home, double away) {
        this.count = count;
        this.home = home;
        this.away = away;
        this.confidence = confidence;
    }

    public int getCount() {
        return count;
    }

    public double getHome() {
        return home;
    }

    public double getAway() {
        return away;
    }
    public double getConfidence() {
        return confidence;
    }

    @Override
    public String toString() {
        return "ProbabilitiesResult{" +
                "count=" + count +
                ", confidence=" + confidence +
                ", home=" + home +
                ", away=" + away +
                '}';
    }
}
