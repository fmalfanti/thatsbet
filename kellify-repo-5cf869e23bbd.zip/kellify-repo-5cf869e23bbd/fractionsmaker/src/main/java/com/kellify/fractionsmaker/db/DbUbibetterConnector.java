package com.kellify.fractionsmaker.db;

import com.kellify.common.SportTypes;
import com.kellify.common.model.DTO;
import com.kellify.common.model.HA.HADTO;
import com.kellify.common.model.HDA.HDADTO;
import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.common.model.americanFootball.AmericanFootballDTO;
import com.kellify.common.model.baseball.BaseballDTO;
import com.kellify.common.model.basket.BasketDTO;
import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.model.iceHockey.IceHockeyHADTO;
import com.kellify.common.model.iceHockey.IceHockeyHDADTO;
import com.kellify.common.model.tennis.TennisDTO;
import com.kellify.common.util.Matrici;
//import com.kellify.placebet.model.ProbabilitiesQueryType;
//import com.kellify.placebet.model.baseball.BaseballDTO;
//import com.kellify.placebet.model.baseball.BaseballProbabilitiesResult;
//import com.kellify.placebet.model.basket.BasketDTO;
//import com.kellify.placebet.model.basket.BasketProbabilitiesResult;
//import com.kellify.placebet.model.football.HDADTO;
//import com.kellify.placebet.model.football.FootballProbabilitiesResult;
//import com.kellify.placebet.model.ha.HADTO;
//import com.kellify.placebet.model.ha.HAProbabilitiesResult;
//import com.kellify.placebet.model.tennis.TennisDTO;
//import com.kellify.placebet.model.tennis.TennisProbabilitiesResult;
import com.kellify.fractionsmaker.model.americanfootball.AmericanFootballProbabilitiesResult;
import com.kellify.fractionsmaker.model.baseball.BaseballProbabilitiesResult;
import com.kellify.fractionsmaker.model.basket.BasketProbabilitiesResult;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;
import com.kellify.fractionsmaker.model.ha.HAProbabilitiesResult;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHaProbabilitiesResult;
import com.kellify.fractionsmaker.model.icehockey.IceHockeyHdaProbabilitiesResult;
import com.kellify.fractionsmaker.model.tennis.TennisProbabilitiesResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class DbUbibetterConnector extends DbConnector {
    private static final Logger logger = LoggerFactory.getLogger(DbUbibetterConnector.class);

    private static final String selectAllSport = "{call select_ha_history(?,?,?,?,?)}";

    public static final String selectProbabilitiesCountry = "select ftr from football_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectCountProbabilitiesCountry = "select count(*) from football_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectProbabilitiesContinent = "select ftr from football_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectCountProbabilitiesContinent = "select count(*) from football_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectAllProbabilities = "select ftr from football_cluster where ma between ? and ? and md between ? and ? and mh between ? and ?";
    public static final String selectFootballMatrici = "select * from football_matrici";
    public static final String selectFootballMatriciWeight = "select * from football_matrici_weight";
    public static final String selectTennisMatrici = "SELECT * FROM tennis_matrici_1";
    public static final String selectWinnerTennisProbabilities = "SELECT COUNT(*) FROM tennis_cluster WHERE MW BETWEEN ? AND ? AND ML BETWEEN ? AND ?";
    public static final String selectLoserTennisProbabilities = "SELECT COUNT(*) FROM tennis_cluster WHERE ML BETWEEN ? AND ? AND MW BETWEEN ? AND ?";
    public static final String selectBasketProbabilitiesCountry = "select ftr from basket_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectBasketCountProbabilitiesCountry = "select count(*) from basket_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectBasketProbabilitiesContinent = "select ftr from basket_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectBasketCountProbabilitiesContinent = "select count(*) from basket_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectBasketAllProbabilities = "select ftr from basket_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectBasketAllProbabilitiesCount = "select count(*) from basket_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectBasketMatrici = "select * from basket_matrici";

    public static final String selectBaseballProbabilitiesCountry = "select ftr from baseball_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectBaseballCountProbabilitiesCountry = "select count(*) from baseball_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectBaseballProbabilitiesContinent = "select ftr from baseball_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectBaseballCountProbabilitiesContinent = "select count(*) from baseball_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectBaseballAllProbabilities = "select ftr from baseball_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectBaseballAllProbabilitiesCount = "select count(*)  from baseball_cluster where ma between ? and ? and mh between ? and ?";

    public static final String selectBaseballMatrici = "select * from baseball_matrici";

    public static final String selectAmericanFootballProbabilitiesCountry = "select ftr from americanfootball_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectAmericanFootballCountProbabilitiesCountry = "select count(*) from americanfootball_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectAmericanFootballProbabilitiesContinent = "select ftr from americanfootball_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectAmericanFootballCountProbabilitiesContinent = "select count(*) from americanfootball_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectAmericanFootballAllProbabilities = "select ftr from americanfootball_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectAmericanFootballAllProbabilitiesCount = "select count(*) from americanfootball_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectAmericanFootballMatrici = "select * from americanfootball_matrici";

    public static final String selectIceHockeyHaProbabilitiesCountry = "select ftr from icehockey_ha_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectIceHockeyHaCountProbabilitiesCountry = "select count(*) from icehockey_ha_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectIceHockeyHaProbabilitiesContinent = "select ftr from icehockey_ha_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectIceHockeyHaCountProbabilitiesContinent = "select count(*) from icehockey_ha_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectIceHockeyHaAllProbabilities = "select ftr from icehockey_ha_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectIceHockeyHaAllProbabilitiesCount = "select count(*) from icehockey_ha_cluster where ma between ? and ? and mh between ? and ?";
    public static final String selectIceHockeyHaMatrici = "select * from icehockey_ha_matrici";


    public static final String selectIceHockeyHdaProbabilitiesCountry = "select ftr from icehockey_hda_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectIceHockeyHdaCountProbabilitiesCountry = "select count(*) from icehockey_hda_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectIceHockeyHdaProbabilitiesContinent = "select ftr from icehockey_hda_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectIceHockeyHdaCountProbabilitiesContinent = " select count(*) from icehockey_hda_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectIceHockeyHdaAllProbabilities = " select ftr from icehockey_hda_cluster where ma between ? and ? and md between ? and ? and mh between ? and ? ";
    public static final String selectIceHockeyHdaMatrici = "select * from icehockey_hda_matrici";

    public static final String selectHAProbabilities = "select ftr from ";
    public static final String selectHACountProbabilities = "select count(*) from ";
    public static final String selectHAFromNation = "_cluster where ma between ? and ? and mh between ? and ? and nazione = ?";
    public static final String selectHAFromContinent = "_cluster where ma between ? and ? and mh between ? and ? and continente = ?";
    public static final String selectHAFromAll = "_cluster where ma between ? and ? and mh between ? and ?";

    private StatementProbabilities statementProbabilities = null;
    private StatementProbabilitiesHA statementProbabilitiesHA = null;
    private StatementProbabilitiesTennis statementProbabilitiesTennis = null;
    private StatementProbabilitiesIceHockeyHDA statementProbabilitiesIceHockeyHDA = null;

    public static final String SELECT_DISTINCT_CONTINENT_BASKET ="select distinct continente from basket_history_odds";
    public static final String SELECT_DISTINCT_NAZIONE_BASKET = "select distinct nazione from basket_history_odds";
    public static final String BASKET_ODDS_PINNACLE = "select Nazione,Continente,FTR,pinnacle_op_ha_a,pinnacle_op_ha_h from basket_history_odds";

    private DbUbibetterConnector(Properties config) {
        this.config = config;
    }

    public static DbUbibetterConnector getInstance(Properties config) {
        return new DbUbibetterConnector(config);
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

    public boolean isFTRStatementInit() {
        if(statementProbabilities != null) {
            return statementProbabilities.isInit;
        }
        return false;
    }

    public boolean FTRStatementInitTearDown() {
        boolean ret = true;
        if(statementProbabilities != null) {
            statementProbabilities.tearDown();
            ret = statementProbabilities.isInit;
            statementProbabilities = null;
        }
        return ret;
    }
    public boolean isWLStatementInit() {
        if(statementProbabilitiesTennis != null) {
            return statementProbabilitiesTennis.isInit;
        }
        return false;
    }

    public boolean WLStatementInitTearDown() {
        boolean ret = true;
        if(statementProbabilitiesTennis != null) {
            statementProbabilitiesTennis.tearDown();
            ret = statementProbabilitiesTennis.isInit;
            statementProbabilitiesTennis = null;
        }
        return ret;
    }

    public boolean HAStatementInitTearDown() {
        boolean ret = true;
        if(statementProbabilitiesHA != null) {
            statementProbabilitiesHA.tearDown();
            ret = statementProbabilitiesHA.isInit;
            statementProbabilitiesHA = null;
        }
        return ret;
    }

    public boolean StatementInitTearDownIceHockeyHda() {
        boolean ret = true;
        if(statementProbabilitiesIceHockeyHDA != null) {
            statementProbabilitiesIceHockeyHDA.tearDown();
            ret = statementProbabilitiesIceHockeyHDA.isInit;
            statementProbabilitiesIceHockeyHDA = null;
        }
        return ret;
    }


    public FootballProbabilitiesResult getFTR(FootballDTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement psCount;
        PreparedStatement ps;
        ResultSet rs = null;
        int count = 0;
        String ftr;
        int confidence=5;
        double hh = 0.0;
        double aa = 0.0;
        double dd = 0.0;
        try {
            if(statementProbabilities == null) {
                statementProbabilities = new StatementProbabilities();
                statementProbabilities.init();
            }
            ps = statementProbabilities.getProbCountry();
            psCount = statementProbabilities.getProbCountryCount();
            populatePS(psCount, params);
            rs = psCount.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            rs = null;
            if (count <= 10) {
                confidence=3;
                params.setType(ProbabilitiesQueryType.CONTINENT);
                ps = statementProbabilities.getProbContinent();
                psCount = statementProbabilities.getProbContinentCount();
                populatePS(psCount, params);
                rs = psCount.executeQuery();
                while (rs.next()) {
                    count = rs.getInt(1);
                }
                rs.close();
                rs = null;
                if (count <= 10) {
                    confidence=1;
                    params.setType(ProbabilitiesQueryType.ALL);
                    ps = statementProbabilities.getProbAll();
                }
            }

            count = 0;
            populatePS(ps, params);
            rs = ps.executeQuery();
            while (rs.next()) {
                ftr = rs.getString(1);
                switch (ftr) {
                    case "H":
                        hh += 1.0;
                        break;
                    case "D":
                        dd += 1.0;
                        break;
                    default:
                        aa += 1.0;
                        break;
                }
                count++;
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new FootballProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());
    }
    public IceHockeyHdaProbabilitiesResult getFTRHDA(IceHockeyHDADTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement psCount;
        PreparedStatement ps;
        ResultSet rs = null;
        int count = 0;
        String ftr;
        int confidence=5;
        double hh = 0.0;
        double aa = 0.0;
        double dd = 0.0;
        try {
            if(statementProbabilitiesIceHockeyHDA == null) {
                statementProbabilitiesIceHockeyHDA = new StatementProbabilitiesIceHockeyHDA();
                statementProbabilitiesIceHockeyHDA.init();
            }
            ps = statementProbabilitiesIceHockeyHDA.getProbCountry();
            psCount = statementProbabilitiesIceHockeyHDA.getProbCountryCount();
            populatePSHDAIceHockeyHDA(psCount, params);
            rs = psCount.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            rs = null;
            if (count <= 10) {
                confidence=3;
                params.setType(ProbabilitiesQueryType.CONTINENT);
                ps = statementProbabilitiesIceHockeyHDA.getProbContinent();
                psCount = statementProbabilitiesIceHockeyHDA.getProbContinentCount();
                populatePSHDAIceHockeyHDA(psCount, params);
                rs = psCount.executeQuery();
                while (rs.next()) {
                    count = rs.getInt(1);
                }
                rs.close();
                rs = null;
                if (count <= 10) {
                    confidence=1;
                    params.setType(ProbabilitiesQueryType.ALL);
                    ps = statementProbabilitiesIceHockeyHDA.getProbAll();
                }
            }

            count = 0;
            populatePSHDAIceHockeyHDA(ps, params);
            rs = ps.executeQuery();
            while (rs.next()) {
                ftr = rs.getString(1);
                switch (ftr) {
                    case "H":
                        hh += 1.0;
                        break;
                    case "D":
                        dd += 1.0;
                        break;
                    default:
                        aa += 1.0;
                        break;
                }
                count++;
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new IceHockeyHdaProbabilitiesResult(count,confidence, hh, aa, dd, params.getType());
    }


    public BasketProbabilitiesResult getBasketFTR(HADTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement psCount;
        PreparedStatement ps;
        ResultSet rs = null;
        int count = 0;
        String ftr;
        int confidence=5;
        double hh = 0.0;
        double aa = 0.0;
        try {
            if(statementProbabilitiesHA == null) {
                statementProbabilitiesHA = new StatementProbabilitiesHA();
                statementProbabilitiesHA.init(SportTypes.BASKET);
            }
            ps = statementProbabilitiesHA.getProbCountry();
            psCount = statementProbabilitiesHA.getProbCountryCount();
            populateHAPS(psCount, params);
            rs = psCount.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            rs = null;
            if (count <= 1000) {
                confidence=3;
                params.setType(ProbabilitiesQueryType.CONTINENT);
                ps = statementProbabilitiesHA.getProbContinent();
                psCount = statementProbabilitiesHA.getProbContinentCount();
                populateHAPS(psCount, params);
                rs = psCount.executeQuery();
                while (rs.next()) {
                    count = rs.getInt(1);
                }
                rs.close();
                rs = null;
                if (count <= 1000) {
                    confidence=1;
                    params.setType(ProbabilitiesQueryType.ALL);
                    ps = statementProbabilitiesHA.getProbAll();
                    psCount = statementProbabilitiesHA.getProbAllCount();
                    populateHAPS(psCount, params);
                    rs = psCount.executeQuery();
                    while (rs.next()) {
                        count = rs.getInt(1);
                    }
                    rs.close();
                    rs = null;
                }
            }

            populateHAPS(ps, params);
            rs = ps.executeQuery();
            if (count<=1000){
                CallableStatement ps1 = connection.prepareCall(selectAllSport);
                populateHA(ps1, params);
                rs = ps1.executeQuery();
            }
            count = 0;
            while (rs.next()) {
                ftr = rs.getString(1);
                switch (ftr) {
                    case "H":
                        hh += 1.0;
                        break;
                    default:
                        aa += 1.0;
                        break;
                }
                count++;
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new BasketProbabilitiesResult(count,confidence, hh, aa, params.getType());
    }
    public BaseballProbabilitiesResult getBaseballFTR(HADTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement psCount;
        PreparedStatement ps;
        ResultSet rs = null;
        int count = 0;
        String ftr;
        int confidence=5;
        double hh = 0.0;
        double aa = 0.0;
        try {
            if(statementProbabilitiesHA == null) {
                statementProbabilitiesHA = new StatementProbabilitiesHA();
                statementProbabilitiesHA.init(SportTypes.BASEBALL);
            }
            params.setType(ProbabilitiesQueryType.COUNTRY);

            ps = statementProbabilitiesHA.getProbCountry();
            psCount = statementProbabilitiesHA.getProbCountryCount();
            populateHAPS(psCount, params);
            rs = psCount.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            rs = null;
            if (count <= 1000) {
                confidence = 3;
                params.setType(ProbabilitiesQueryType.CONTINENT);
                ps = statementProbabilitiesHA.getProbContinent();
                psCount = statementProbabilitiesHA.getProbContinentCount();
                populateHAPS(psCount, params);
                rs = psCount.executeQuery();
                while (rs.next()) {
                    count = rs.getInt(1);
                }
                rs.close();
                rs = null;
                if (count <= 1000) {
                    confidence = 1;
                    params.setType(ProbabilitiesQueryType.ALL);
                    ps = statementProbabilitiesHA.getProbAll();
                    psCount = statementProbabilitiesHA.getProbAllCount();
                    populateHAPS(psCount, params);
                    rs = psCount.executeQuery();
                    while (rs.next()) {
                        count = rs.getInt(1);
                    }
                    rs.close();
                    rs = null;
                }
            }
            populateHAPS(ps, params);
            rs = ps.executeQuery();
            if (count<=1000){
                CallableStatement ps1 = connection.prepareCall(selectAllSport);
                populateHA(ps1, params);
                rs = ps1.executeQuery();
            }
            count = 0;
            while (rs.next()) {
                ftr = rs.getString(1);
                switch (ftr) {
                    case "H":
                        hh += 1.0;
                        break;
                    default:
                        aa += 1.0;
                        break;
                }
                count++;
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new BaseballProbabilitiesResult(count,confidence, hh, aa, params.getType());
    }
    public AmericanFootballProbabilitiesResult getAmericanFootballFTR(HADTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement psCount;
        PreparedStatement ps;
        ResultSet rs = null;
        int count = 0;
        String ftr;
        int confidence=5;
        double hh = 0.0;
        double aa = 0.0;
        try {
            if(statementProbabilitiesHA == null) {
                statementProbabilitiesHA = new StatementProbabilitiesHA();
                statementProbabilitiesHA.init(SportTypes.AMERICAN_FOOTBALL);
            }
            ps = statementProbabilitiesHA.getProbCountry();
            psCount = statementProbabilitiesHA.getProbCountryCount();
            populateHAPS(psCount, params);
            rs = psCount.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            rs = null;
            if (count <= 1000) {
                confidence=3;
                params.setType(ProbabilitiesQueryType.CONTINENT);
                ps = statementProbabilitiesHA.getProbContinent();
                psCount = statementProbabilitiesHA.getProbContinentCount();
                populateHAPS(psCount, params);
                rs = psCount.executeQuery();
                while (rs.next()) {
                    count = rs.getInt(1);
                }
                rs.close();
                rs = null;
                if (count <= 1000) {
                    confidence=1;
                    params.setType(ProbabilitiesQueryType.ALL);
                    ps = statementProbabilitiesHA.getProbAll();
                    psCount = statementProbabilitiesHA.getProbAllCount();
                    populateHAPS(psCount, params);
                    rs = psCount.executeQuery();
                    while (rs.next()) {
                        count = rs.getInt(1);
                    }
                    rs.close();
                    rs = null;
                }
            }

            populateHAPS(ps, params);
            rs = ps.executeQuery();
            if (count<=1000){
                CallableStatement ps1 = connection.prepareCall(selectAllSport);
                populateHA(ps1, params);
                rs = ps1.executeQuery();
            }
            count = 0;
            while (rs.next()) {
                ftr = rs.getString(1);
                switch (ftr) {
                    case "H":
                        hh += 1.0;
                        break;
                    default:
                        aa += 1.0;
                        break;
                }
                count++;
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new AmericanFootballProbabilitiesResult(count,confidence, hh, aa, params.getType());
    }
    public IceHockeyHaProbabilitiesResult getIceHockeyHaFTR(HADTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement psCount;
        PreparedStatement ps;
        ResultSet rs = null;
        int count = 0;
        String ftr;
        int confidence=5;
        double hh = 0.0;
        double aa = 0.0;
        try {
            if(statementProbabilitiesHA == null) {
                statementProbabilitiesHA = new StatementProbabilitiesHA();
                statementProbabilitiesHA.init(SportTypes.ICE_HOCKEY);
            }
            ps = statementProbabilitiesHA.getProbCountry();
            psCount = statementProbabilitiesHA.getProbCountryCount();
            populateHAPS(psCount, params);
            rs = psCount.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            rs = null;
            if (count <= 1000) {
                confidence=3;
                params.setType(ProbabilitiesQueryType.CONTINENT);
                ps = statementProbabilitiesHA.getProbContinent();
                psCount = statementProbabilitiesHA.getProbContinentCount();
                populateHAPS(psCount, params);
                rs = psCount.executeQuery();
                while (rs.next()) {
                    count = rs.getInt(1);
                }
                rs.close();
                rs = null;
                if (count <= 1000) {
                    confidence=1;
                    params.setType(ProbabilitiesQueryType.ALL);
                    ps = statementProbabilitiesHA.getProbAll();
                    psCount = statementProbabilitiesHA.getProbAllCount();
                    populateHAPS(psCount, params);
                    rs = psCount.executeQuery();
                    while (rs.next()) {
                        count = rs.getInt(1);
                    }
                    rs.close();
                    rs = null;
                }
            }

            populateHAPS(ps, params);
            rs = ps.executeQuery();
            if (count<=1000){
                CallableStatement ps1 = connection.prepareCall(selectAllSport);
                populateHA(ps1, params);
                rs = ps1.executeQuery();
            }
            count = 0;
            while (rs.next()) {
                ftr = rs.getString(1);
                switch (ftr) {
                    case "H":
                        hh += 1.0;
                        break;
                    default:
                        aa += 1.0;
                        break;
                }
                count++;
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new IceHockeyHaProbabilitiesResult(count,confidence, hh, aa, params.getType());
    }



    public TennisProbabilitiesResult getResults(TennisDTO params) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        int confidence=5;
        PreparedStatement ps;
        ResultSet rs = null;
        int count;
        int ww = 0;
        int ll = 0;
        try {
            if(statementProbabilitiesTennis == null) {
                statementProbabilitiesTennis = new StatementProbabilitiesTennis();
                statementProbabilitiesTennis.init();
            }
            ps = statementProbabilitiesTennis.getProbWin();
            populatePSTennis(ps, params);
            rs = ps.executeQuery();
            while (rs.next()) {
                ww = rs.getInt(1);
            }
            rs.close();
            rs = null;
            ps = statementProbabilitiesTennis.getProbLoser();
            populatePSTennis(ps, params);
            rs = ps.executeQuery();

            while (rs.next()) {
                ll = rs.getInt(1);
            }
            rs.close();
            count=ww+ll;
            if (count <= 10) {
                ww=0;
                ll=0;
            }

        } finally {
            if(rs != null) {
                rs.close();
            }
        }
        return new TennisProbabilitiesResult(count, confidence, ww, ll);
    }
    public Map<String,Map<Integer,Matrici.HdaMatrix>> createHDAMapsFromStrings(SportTypes sportType) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeHDA = new HashMap<>();
        Map<Integer,Matrici.HdaMatrix> useNationMap = null;
        Matrici.HdaMatrix punto = null;
        int indice;
        String nazione, mappa;
        ResultSet rs;
        String query = null;
        PreparedStatement psMatrici;
        switch(sportType) {
            case FOOTBALL:
                query = selectFootballMatrici;
                break;
            case ICE_HOCKEY_HDA:
                query = selectIceHockeyHdaMatrici;
                break;
            default:
                throw new IllegalArgumentException("sportType " + sportType + " unknown");
        }
        psMatrici=connection.prepareStatement(query);
        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione=rs.getString(1);
            mappa=rs.getString(2);
            if (MappeHDA.get(nazione) == null) {
                MappeHDA.put(nazione, new HashMap<>());
            }
            useNationMap=MappeHDA.get(nazione);
            if (mappa != null && mappa.length() > 0) {
                String[] tokens=mappa.split(":");
                int idxEq=0;
                for (String token : tokens) {
                    idxEq=token.indexOf("=");
                    if (idxEq > 0) {
                        //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                        indice=new Integer(token.substring(0, idxEq));
                        punto=useNationMap.get(indice);
                        if (punto == null) {
                            punto=new Matrici.HdaMatrix();
                        }
                        punto.addFromString(token.substring(idxEq + 1));
                        useNationMap.put(indice, punto);
                    }
                }
            }
        }
        return MappeHDA;
    }
    public Map<String,Map<Integer,Matrici.HdaMatrix>> createHDAMapsFromStringsWeight(SportTypes sportType) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeHDA = new HashMap<>();
        Map<Integer,Matrici.HdaMatrix> useNationMap = null;
        Matrici.HdaMatrix punto = null;
        int indice;
        String nazione, mappa;
        ResultSet rs;
        String query = null;
        PreparedStatement psMatrici;
        switch(sportType) {
            case FOOTBALL:
                query = selectFootballMatriciWeight;
                break;
            default:
                throw new IllegalArgumentException("sportType " + sportType + " unknown");
        }
        psMatrici=connection.prepareStatement(query);
        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione=rs.getString(1);
            mappa=rs.getString(2);
            if (MappeHDA.get(nazione) == null) {
                MappeHDA.put(nazione, new HashMap<>());
            }
            useNationMap=MappeHDA.get(nazione);
            if (mappa != null && mappa.length() > 0) {
                String[] tokens=mappa.split(":");
                int idxEq=0;
                for (String token : tokens) {
                    idxEq=token.indexOf("=");
                    if (idxEq > 0) {
                        //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                        indice=new Integer(token.substring(0, idxEq));
                        punto=useNationMap.get(indice);
                        if (punto == null) {
                            punto=new Matrici.HdaMatrix();
                        }
                        punto.addFromString(token.substring(idxEq + 1));
                        useNationMap.put(indice, punto);
                    }
                }
            }
        }
        return MappeHDA;
    }
    public Map<String,Map<Integer,Matrici.HAMatrix>> createHAMapsFromStrings(SportTypes sportType) throws Exception {
        if(connection == null) {
            getConnection();
        }
        Map<String,Map<Integer,Matrici.HAMatrix>> mappeHA = new HashMap<>();
        Map<Integer,Matrici.HAMatrix> useNationMap = null;
        Matrici.HAMatrix punto = null;
        int indice;
        String nazione, mappa;
        ResultSet rs;
        PreparedStatement psMatrici;
        String query = null;
        switch(sportType) {
            case BASKET:
                query = selectBasketMatrici;
                break;
            case BASEBALL:
                query = selectBaseballMatrici;
                break;
            case AMERICAN_FOOTBALL:
                query = selectAmericanFootballMatrici;
                break;
            case ICE_HOCKEY:
                query = selectIceHockeyHaMatrici;
                break;
                default:
                    throw new IllegalArgumentException("sportType " + sportType + " unknown");
        }
        psMatrici=connection.prepareStatement(query);
        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione=rs.getString(1);
            mappa=rs.getString(2);
            if (mappeHA.get(nazione) == null) {
                mappeHA.put(nazione, new HashMap<>());
            }
            useNationMap = mappeHA.get(nazione);
            if (mappa != null && mappa.length() > 0) {
                String[] tokens = mappa.split(":");
                int idxEq = 0;
                for (String token : tokens) {
                    idxEq = token.indexOf("=");
                    if (idxEq > 0) {
                        //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                        indice=new Integer(token.substring(0, idxEq));
                        punto = useNationMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HAMatrix();
                        }
                        punto.addFromString(token.substring(idxEq + 1));
                        useNationMap.put(indice, punto);
                    }
                }
            }
        }
        return mappeHA;
    }

    public Map<Integer,Matrici.WLMatrix> createWLMapsFromStrings() throws SQLException  {
        if(connection == null) {
            getConnection();
        }
        Map<Integer,Matrici.WLMatrix> MappaWL = new HashMap();
        String mappa;
        String nazione;
        Matrici.WLMatrix punto;
        int indice;
        ResultSet rs;
        PreparedStatement psMatrici;

        psMatrici=connection.prepareStatement(selectTennisMatrici);
        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione=rs.getString(1);
            mappa=rs.getString(2);
            if (mappa != null && mappa.length() > 0) {
                String[] tokens=mappa.split(":");
                int idxEq=0;
                for (String token : tokens) {
                    idxEq=token.indexOf("=");
                    if (idxEq > 0) {
                        //System.out.println(token.substring(0,idxEq)+"-->" +token.substring(idxEq+1));
                        indice=new Integer(token.substring(0, idxEq));
                        punto=MappaWL.get(indice);
                        if (punto == null) {
                            punto=new Matrici.WLMatrix();
                        }
                        punto.addFromString(token.substring(idxEq + 1));
                        MappaWL.put(indice, punto);
                    }
                }
            }
        }
        return MappaWL;
    }


    public Map<String,Map<Integer,Matrici.HAMatrix>> createHAMapsPinnacleOnDemand(SportTypes sportType) throws Exception {
        if(connection == null) {
            getConnection();
        }
        Map<String,Map<Integer,Matrici.HAMatrix>> mappeHA = new HashMap<>();
        Map<Integer,Matrici.HAMatrix> useNationMap;
        Map<Integer,Matrici.HAMatrix> useContinentMap;
        Map<Integer,Matrici.HAMatrix> useWorldMap;

        double home;
        double away;
        double pH;
        double pA;
        double pNorm;
        int ipH;

        Matrici.HAMatrix punto = null;
        String nazione, continent;
        String ftr;
        ResultSet rs;
        PreparedStatement psCountry;
        PreparedStatement psContinent;
        PreparedStatement psMatrici;
        switch(sportType) {
            case BASKET:
                psCountry = connection.prepareStatement(SELECT_DISTINCT_NAZIONE_BASKET);
                psContinent = connection.prepareStatement(SELECT_DISTINCT_CONTINENT_BASKET);
                psMatrici = connection.prepareStatement(BASKET_ODDS_PINNACLE);
                break;
            default:
                throw new IllegalArgumentException("sportType " + sportType + " unknown");
        }
        useWorldMap = mappeHA.computeIfAbsent("World", k -> new HashMap<>());

        rs = psContinent.executeQuery();
        while (rs.next()) {
            continent = rs.getString(1);
            mappeHA.computeIfAbsent(continent, k -> new HashMap<>());
        }
        rs.close();

        rs = psCountry.executeQuery();
        while (rs.next()) {
            nazione = rs.getString(1);
            mappeHA.computeIfAbsent(nazione, k -> new HashMap<>());
        }
        rs.close();

        rs = psMatrici.executeQuery();
        while (rs.next()) {
            nazione = rs.getString("Nazione");
            continent = rs.getString("Continente");
            useContinentMap = mappeHA.get(continent);
            useNationMap = mappeHA.get(nazione);
            ftr = rs.getString("FTR");
            home = rs.getDouble("pinnacle_op_ha_h");
            away = rs.getDouble("pinnacle_op_ha_a");

            pH = 1 / home;
            pA = 1 / away;
            pNorm = pH + pA;
            pH /= pNorm;

            ipH = (int) Math.round(pH * 100);

            punto = useNationMap.get(ipH);
            if (punto == null) {
                punto = new Matrici.HAMatrix();
            }
            punto.add(ftr);
            useNationMap.put(ipH, punto);
            punto = useContinentMap.get(ipH);
            if (punto == null) {
                punto = new Matrici.HAMatrix();
            }
            punto.add(ftr);
            useContinentMap.put(ipH, punto);
            punto = useWorldMap.get(ipH);
            if (punto == null) {
                punto = new Matrici.HAMatrix();
            }
            punto.add(ftr);
            //System.out.println(punto.toString());
            useWorldMap.put(ipH, punto);
        }
        rs.close();

        return mappeHA;
    }

    private void populatePS(PreparedStatement ps, FootballDTO params) throws SQLException {
        ps.setDouble(1, params.getAwayMin());
        ps.setDouble(2, params.getAwayMax());
        ps.setDouble(3, params.getDrawMin());
        ps.setDouble(4, params.getDrawMax());
        ps.setDouble(5, params.getHomeMin());
        ps.setDouble(6, params.getHomeMax());
        if(params.getType() == ProbabilitiesQueryType.COUNTRY) {
            ps.setString(7, params.getCountry());
        } else if(params.getType() == ProbabilitiesQueryType.CONTINENT) {
            ps.setString(7, params.getContinent());
        }
    }
    private void populateHAPS(PreparedStatement ps, HADTO params) throws SQLException {
        ps.setDouble(1, params.getAwayMin());
        ps.setDouble(2, params.getAwayMax());
        ps.setDouble(3, params.getHomeMin());
        ps.setDouble(4, params.getHomeMax());
        if(params.getType() == ProbabilitiesQueryType.COUNTRY) {
            switch (params.getCountry()){
                case "United States":
                    params.setCountry("USA");
                    break;
                default:
                    params.getCountry();
                    break;
            }
            ps.setString(5, params.getCountry());
        } else if(params.getType() == ProbabilitiesQueryType.CONTINENT) {
            ps.setString(5, params.getContinent());
        }
    }


    private void populateHA(CallableStatement ps, HADTO params) throws SQLException {
        ps.setDouble(1, params.getAwayMin());
        ps.setDouble(2, params.getAwayMax());
        ps.setDouble(3, params.getHomeMin());
        ps.setDouble(4, params.getHomeMax());
        ps.setString(5,params.getCountry());

    }


    private void populatePSHA(PreparedStatement ps, HADTO params) throws SQLException {
        ps.setDouble(1, params.getAwayMin());
        ps.setDouble(2, params.getAwayMax());
        ps.setDouble(3, params.getHomeMin());
        ps.setDouble(4, params.getHomeMax());
        if(params.getType() == ProbabilitiesQueryType.COUNTRY) {
            ps.setString(5, params.getCountry());
        } else if(params.getType() == ProbabilitiesQueryType.CONTINENT) {
            ps.setString(5, params.getContinent());
        }
    }
    private void populatePSHDAIceHockeyHDA(PreparedStatement ps, IceHockeyHDADTO params) throws SQLException {
        ps.setDouble(1, params.getAwayMin());
        ps.setDouble(2, params.getAwayMax());
        ps.setDouble(3, params.getDrawMin());
        ps.setDouble(4, params.getDrawMax());
        ps.setDouble(5, params.getHomeMin());
        ps.setDouble(6, params.getHomeMax());
        if(params.getType() == ProbabilitiesQueryType.COUNTRY) {
            ps.setString(7, params.getCountry());
        } else if(params.getType() == ProbabilitiesQueryType.CONTINENT) {
            ps.setString(7, params.getContinent());
        }
    }
    private class StatementProbabilities {
        private PreparedStatement probCountry;
        private PreparedStatement probCountryCount;
        private PreparedStatement probContinent;
        private PreparedStatement probContinentCount;
        private PreparedStatement probAll;


        private boolean isInit = false;

        void init() {
            if(isInit) {
                return;
            }
            try {
                probCountry = connection.prepareStatement(selectProbabilitiesCountry);
                probCountryCount = connection.prepareStatement(selectCountProbabilitiesCountry);
                probContinent = connection.prepareStatement(selectProbabilitiesContinent);
                probContinentCount = connection.prepareStatement(selectCountProbabilitiesContinent);
                probAll = connection.prepareStatement(selectAllProbabilities);

                isInit = true;
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot initialize StatementProbabilities", e);
            }
        }

        void tearDown() {
            if(isInit) {
                try {
                    probCountry.close();
                    probCountry = null;
                    probCountryCount.close();
                    probCountryCount = null;
                    probContinent.close();
                    probContinent = null;
                    probContinentCount.close();
                    probContinentCount = null;
                    probAll.close();
                    probAll = null;

                    isInit = false;
                } catch (SQLException e) {
                    throw new IllegalStateException("Cannot tear down StatementProbabilities", e);
                }
            }
        }

        public PreparedStatement getProbCountry() {
            return probCountry;
        }

        public PreparedStatement getProbCountryCount() {
            return probCountryCount;
        }

        public PreparedStatement getProbContinent() {
            return probContinent;
        }

        public PreparedStatement getProbContinentCount() {
            return probContinentCount;
        }

        public PreparedStatement getProbAll() {
            return probAll;
        }

    }


    private class StatementProbabilitiesHA  {
        private PreparedStatement probCountry;
        private PreparedStatement probCountryCount;
        private PreparedStatement probContinent;
        private PreparedStatement probContinentCount;
        private PreparedStatement probAll;
        private PreparedStatement probAllCount;


        private boolean isInit = false;

        void init(SportTypes sportTypes) {
            if(isInit) {
                return;
            }
            try {
                switch (sportTypes){
                    case BASEBALL:
                        probCountry = connection.prepareStatement(selectBaseballProbabilitiesCountry);
                        probCountryCount = connection.prepareStatement(selectBaseballCountProbabilitiesCountry);
                        probContinent = connection.prepareStatement(selectBaseballProbabilitiesContinent);
                        probContinentCount = connection.prepareStatement(selectBaseballCountProbabilitiesContinent);
                        probAll = connection.prepareStatement(selectBaseballAllProbabilities);
                        probAllCount = connection.prepareStatement(selectBaseballAllProbabilitiesCount);
                        break;
                    case BASKET:
                        probCountry = connection.prepareStatement(selectBasketProbabilitiesCountry);
                        probCountryCount = connection.prepareStatement(selectBasketCountProbabilitiesCountry);
                        probContinent = connection.prepareStatement(selectBasketProbabilitiesContinent);
                        probContinentCount = connection.prepareStatement(selectBasketCountProbabilitiesContinent);
                        probAll = connection.prepareStatement(selectBasketAllProbabilities);
                        probAllCount = connection.prepareStatement(selectBasketAllProbabilitiesCount);
                        break;
                    case ICE_HOCKEY:
                        probCountry = connection.prepareStatement(selectIceHockeyHaProbabilitiesCountry);
                        probCountryCount = connection.prepareStatement(selectIceHockeyHaCountProbabilitiesCountry);
                        probContinent = connection.prepareStatement(selectIceHockeyHaProbabilitiesContinent);
                        probContinentCount = connection.prepareStatement(selectIceHockeyHaCountProbabilitiesContinent);
                        probAll = connection.prepareStatement(selectIceHockeyHaAllProbabilities);
                        probAllCount = connection.prepareStatement(selectIceHockeyHaAllProbabilitiesCount);
                        break;
                    case AMERICAN_FOOTBALL:
                        probCountry = connection.prepareStatement(selectAmericanFootballProbabilitiesCountry);
                        probCountryCount = connection.prepareStatement(selectAmericanFootballCountProbabilitiesCountry);
                        probContinent = connection.prepareStatement(selectAmericanFootballProbabilitiesContinent);
                        probContinentCount = connection.prepareStatement(selectAmericanFootballCountProbabilitiesContinent);
                        probAll = connection.prepareStatement(selectAmericanFootballAllProbabilities);
                        probAllCount = connection.prepareStatement(selectAmericanFootballAllProbabilitiesCount);
                        break;
                }


                isInit = true;
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot initialize StatementProbabilitiesBaseball", e);
            }
        }

        void tearDown() {
            if(isInit) {
                try {
                    probCountry.close();
                    probCountry = null;
                    probCountryCount.close();
                    probCountryCount = null;
                    probContinent.close();
                    probContinent = null;
                    probContinentCount.close();
                    probContinentCount = null;
                    probAll.close();
                    probAll = null;
                    probAllCount.close();
                    probAllCount = null;

                    isInit = false;
                } catch (SQLException e) {
                    throw new IllegalStateException("Cannot tear down StatementProbabilitiesBaseball", e);
                }
            }
        }

        public PreparedStatement getProbCountry() {
            return probCountry;
        }

        public PreparedStatement getProbCountryCount() {
            return probCountryCount;
        }

        public PreparedStatement getProbContinent() {
            return probContinent;
        }

        public PreparedStatement getProbContinentCount() {
            return probContinentCount;
        }

        public PreparedStatement getProbAll() {
            return probAll;
        }

        public PreparedStatement getProbAllCount() {
            return probAllCount;
        }

    }


    private class StatementProbabilitiesIceHockeyHDA {
        private PreparedStatement probCountry;
        private PreparedStatement probCountryCount;
        private PreparedStatement probContinent;
        private PreparedStatement probContinentCount;
        private PreparedStatement probAll;


        private boolean isInit = false;

        void init() {
            if(isInit) {
                return;
            }
            try {
                probCountry = connection.prepareStatement(selectIceHockeyHdaProbabilitiesCountry);
                probCountryCount = connection.prepareStatement(selectIceHockeyHdaCountProbabilitiesCountry);
                probContinent = connection.prepareStatement(selectIceHockeyHdaProbabilitiesContinent);
                probContinentCount = connection.prepareStatement(selectIceHockeyHdaCountProbabilitiesContinent);
                probAll = connection.prepareStatement(selectIceHockeyHdaAllProbabilities);

                isInit = true;
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot initialize StatementProbabilitiesIceHockeyHDA", e);
            }
        }

        void tearDown() {
            if(isInit) {
                try {
                    probCountry.close();
                    probCountry = null;
                    probCountryCount.close();
                    probCountryCount = null;
                    probContinent.close();
                    probContinent = null;
                    probContinentCount.close();
                    probContinentCount = null;
                    probAll.close();
                    probAll = null;

                    isInit = false;
                } catch (SQLException e) {
                    throw new IllegalStateException("Cannot tear down StatementProbabilitiesIceHocheyHA", e);
                }
            }
        }

        public PreparedStatement getProbCountry() {
            return probCountry;
        }

        public PreparedStatement getProbCountryCount() {
            return probCountryCount;
        }

        public PreparedStatement getProbContinent() {
            return probContinent;
        }

        public PreparedStatement getProbContinentCount() {
            return probContinentCount;
        }

        public PreparedStatement getProbAll() {
            return probAll;
        }

    }


    private void populatePSTennis(PreparedStatement ps, TennisDTO params) throws SQLException {

        ps.setDouble(1, params.getHomeMin());
        ps.setDouble(2, params.getHomeMax());
        ps.setDouble(3, params.getAwayMin());
        ps.setDouble(4, params.getAwayMax());
    }



    private class StatementProbabilitiesTennis {
        private PreparedStatement probWin;
        private PreparedStatement probLoser;


        private boolean isInit = false;

        void init() {
            if(isInit) {
                return;
            }
            try {
                probWin = connection.prepareStatement(selectWinnerTennisProbabilities);
                probLoser= connection.prepareStatement(selectLoserTennisProbabilities);


                isInit = true;
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot initialize StatementProbabilities", e);
            }
        }

        void tearDown() {
            if(isInit) {
                try {
                    probWin.close();
                    probWin = null;
                    probLoser.close();
                    probLoser = null;

                    isInit = false;
                } catch (SQLException e) {
                    throw new IllegalStateException("Cannot tear down StatementProbabilities", e);
                }
            }
        }

        public PreparedStatement getProbWin() {
            return probWin;
        }

        public PreparedStatement getProbLoser() {
            return probLoser;
        }
    }

}
