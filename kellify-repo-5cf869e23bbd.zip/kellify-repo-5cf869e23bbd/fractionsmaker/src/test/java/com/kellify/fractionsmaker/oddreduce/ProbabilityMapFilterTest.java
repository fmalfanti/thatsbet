package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.model.BookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProbabilityMapFilterTest {
    /*
    BaseballBookmakerOdd{eventId='4837540596940800', referrerId='4837540596940800', oddId='5841789650497920', platformId=1, role=HOME, odd=1.7510000467300415, bookmaker=1, team='Oakland Athletics', championShip='1', country='United States', continent='NorthAmerica', matchDateM=2018-08-14T02:05, bookmakerDescr='null', bettingType=HOME_AWAY},
  BaseballBookmakerOdd{eventId='4837540596940800', referrerId='4837540596940800', oddId='5841789650497792', platformId=1, role=AWAY, odd=2.2300000190734863, bookmaker=1, team='Seattle Mariners', championShip='1', country='United States', continent='NorthAmerica', matchDateM=2018-08-14T02:05, bookmakerDescr='null', bettingType=HOME_AWAY},
  BaseballBookmakerOdd{eventId='4837540596940800', referrerId='4837540596940800', oddId='5843552769024000', platformId=1, role=HOME, odd=1.7400000095367432, bookmaker=4, team='Oakland Athletics', championShip='1', country='United States', continent='NorthAmerica', matchDateM=2018-08-14T02:05, bookmakerDescr='null', bettingType=HOME_AWAY},
  BaseballBookmakerOdd{eventId='4837540596940800', referrerId='4837540596940800', oddId='5843552768893440', platformId=1, role=AWAY, odd=2.1500000953674316, bookmaker=4, team='Seattle Mariners', championShip='1', country='United States', continent='NorthAmerica', matchDateM=2018-08-14T02:05, bookmakerDescr='null', bettingType=HOME_AWAY},

BaseballBookmakerOdd{eventId='4836165567643648', referrerId='4836165567643648', oddId='5841771605946368', platformId=1, role=HOME, odd=2.0, bookmaker=1, team='Detroit Tigers', championShip='1', country='United States', continent='NorthAmerica', matchDateM=2018-08-13T23:10, bookmakerDescr='null', bettingType=HOME_AWAY},
  BaseballBookmakerOdd{eventId='4836165567643648', referrerId='4836165567643648', oddId='5841771605815296', platformId=1, role=AWAY, odd=1.9249999523162842, bookmaker=1, team='Chicago White Sox', championShip='1', country='United States', continent='NorthAmerica', matchDateM=2018-08-13T23:10, bookmakerDescr='null', bettingType=HOME_AWAY},

     */

    private Map<String, List<BaseballBookmakerOdd>> buildRightEntitiesForKelly() {
        Map<String, List<BaseballBookmakerOdd>> entitiesMap = new HashMap<>();

        List<BaseballBookmakerOdd> entities = new ArrayList<>();

        entities.add(new BaseballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497920", 1, OddRole.HOME, 1.7510000467300415, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497792", 1, OddRole.AWAY, 2.2300000190734863, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("1234456", "4837540596940800", "12348778", 3, OddRole.HOME, 1.654, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("1234456", "4837540596940800", "345788", 3, OddRole.AWAY, 2.25, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entitiesMap.put("4837540596940800", entities);

        List<BaseballBookmakerOdd> entities1 = new ArrayList<>();
        entities1.add(new BaseballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605946368", 1, OddRole.HOME, 2.0, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605815296", 1, OddRole.AWAY, 1.9249999523162842, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("98765", "4836165567643648", "88888", 3, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("98765", "4836165567643648", "77777", 3, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entitiesMap.put("4836165567643648", entities1);

        return entitiesMap;
    }

    private Map<String, List<BaseballBookmakerOdd>> buildOneWrongEntitiesForKelly() {
        Map<String, List<BaseballBookmakerOdd>> entitiesMap = new HashMap<>();

        List<BaseballBookmakerOdd> entities = new ArrayList<>();

        entities.add(new BaseballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497920", 1, OddRole.HOME, 1.7510000467300415, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497792", 1, OddRole.AWAY, 2.2300000190734863, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("1234456", "4837540596940800", "12348778", 3, OddRole.HOME, 1.654, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("1234456", "4837540596940800", "345788", 3, OddRole.AWAY, 2.25, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("44444", "4837540596940800", "44444", 2, OddRole.HOME, 1.654, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("44444", "4837540596940800", "55555", 2, OddRole.AWAY, 2.25, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entitiesMap.put("4837540596940800", entities);

        List<BaseballBookmakerOdd> entities1 = new ArrayList<>();
        entities1.add(new BaseballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605946368", 1, OddRole.HOME, 2.0, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605815296", 1, OddRole.AWAY, 1.9249999523162842, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("98765", "4836165567643648", "88888", 3, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("98765", "4836165567643648", "77777", 3, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("33333", "4836165567643648", "1243", 2, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("33333", "4836165567643648", "5678", 2, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entitiesMap.put("4836165567643648", entities1);

        return entitiesMap;
    }

    private Map<String, List<BaseballBookmakerOdd>> buildTwoWrongEntitiesForKelly() {
        Map<String, List<BaseballBookmakerOdd>> entitiesMap = new HashMap<>();

        List<BaseballBookmakerOdd> entities = new ArrayList<>();

        entities.add(new BaseballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497920", 1, OddRole.HOME, 1.7510000467300415, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497792", 1, OddRole.AWAY, 2.2300000190734863, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("1234456", "4837540596940800", "12348778", 3, OddRole.HOME, 1.654, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("1234456", "4837540596940800", "345788", 3, OddRole.AWAY, 2.25, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("44444", "4837540596940800", "44444", 2, OddRole.HOME, 1.654, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entities.add(new BaseballBookmakerOdd("44444", "4837540596940800", "55555", 2, OddRole.AWAY, 2.25, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_AWAY));
        entitiesMap.put("4837540596940800", entities);

        List<BaseballBookmakerOdd> entities1 = new ArrayList<>();
        entities1.add(new BaseballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605946368", 1, OddRole.HOME, 2.0, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605815296", 1, OddRole.AWAY, 1.9249999523162842, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("98765", "4836165567643648", "88888", 3, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("98765", "4836165567643648", "77777", 3, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("33333", "4836165567643648", "1243", 2, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entities1.add(new BaseballBookmakerOdd("33333", "4836165567643648", "5678", 2, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_AWAY));
        entitiesMap.put("4836165567643648", entities1);

        return entitiesMap;
    }

    private Map<String, List<FootballBookmakerOdd>> buildOneWrongEntitiesForKellyHomeDrawAway() {
        Map<String, List<FootballBookmakerOdd>> entitiesMap = new HashMap<>();

        List<FootballBookmakerOdd> entities = new ArrayList<>();

        entities.add(new FootballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497920", 1, OddRole.HOME, 1.7510000467300415, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("4837540596940800", "4837540596940800", "5841789650497792", 1, OddRole.AWAY, 2.2300000190734863, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("4837540596940800", "4837540596940800", "454454545454", 1, OddRole.DRAW, 3.2300000190734863, 1, "Oakland Athletics - Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("1234456", "4837540596940800", "12348778", 3, OddRole.HOME, 1.654, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("1234456", "4837540596940800", "345788", 3, OddRole.AWAY, 2.25, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("1234456", "4837540596940800", "8729", 3, OddRole.DRAW, 3.25, 1, "Oakland Athletics - Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("44444", "4837540596940800", "44444", 2, OddRole.HOME, 1.654, 1, "Seattle Mariners", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("44444", "4837540596940800", "55555", 2, OddRole.AWAY, 2.25, 1, "Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entities.add(new FootballBookmakerOdd("44444", "4837540596940800", "98824", 2, OddRole.DRAW, 3.25, 1, "Seattle Mariners - Oakland Athletics", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 14, 2, 5), BettingType.HOME_DRAW_AWAY));
        entitiesMap.put("4837540596940800", entities);

        List<FootballBookmakerOdd> entities1 = new ArrayList<>();
        entities1.add(new FootballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605946368", 1, OddRole.HOME, 2.0, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("4836165567643648", "4836165567643648", "5841771605815296", 1, OddRole.AWAY, 1.9249999523162842, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("4836165567643648", "4836165567643648", "12907", 1, OddRole.DRAW, 3.9249999523162842, 1, "Detroit Tigers - Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("98765", "4836165567643648", "88888", 3, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("98765", "4836165567643648", "77777", 3, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("98765", "4836165567643648", "2775634", 3, OddRole.DRAW, 3.85, 1, "Detroit Tigers - Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("33333", "4836165567643648", "1243", 2, OddRole.HOME, 1.958, 1, "Detroit Tigers", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("33333", "4836165567643648", "5678", 2, OddRole.AWAY, 1.85, 1, "Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entities1.add(new FootballBookmakerOdd("33333", "4836165567643648", "78954", 2, OddRole.DRAW, 3.85, 1, "Detroit Tigers - Chicago White Sox", "1","United States","NorthAmerica", LocalDateTime.of(2018, 8, 13, 23, 5), BettingType.HOME_DRAW_AWAY));
        entitiesMap.put("4836165567643648", entities1);

        return entitiesMap;
    }

    @Test
    public void rightRoleMatches_MustReturnAllMatches() {
        Map<String, List<BaseballBookmakerOdd>> origin = buildRightEntitiesForKelly();

        ProbabilityMapFilter filter = new ProbabilityMapFilter<BaseballBookmakerOdd>(origin);

        Map<String, List<BaseballBookmakerOdd>> filtered = filter.filter();

        System.out.println("filtered:" + filtered);

        Assert.assertNotNull(filtered);
        Assert.assertEquals(origin.size(), filtered.size());

        long originFlatted = origin.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();
        long filteredFlatted = filtered.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();

        Assert.assertEquals(originFlatted, filteredFlatted);
    }

    @Test
    public void wrongOneRoleMatche_MustReturnMatchesWithoutOneWrongMatch() {
        Map<String, List<BaseballBookmakerOdd>> origin = buildOneWrongEntitiesForKelly();

        ProbabilityMapFilter filter = new ProbabilityMapFilter<BaseballBookmakerOdd>(origin);

        Map<String, List<? extends BookmakerOdd>> filtered = filter.filter();

        System.out.println("filtered:" + filtered);

        Assert.assertNotNull(filtered);
        Assert.assertEquals(origin.size(), filtered.size());

        long originFlatted = origin.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();
        long filteredFlatted = filtered.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();

        Assert.assertNotEquals(originFlatted, filteredFlatted);
        Assert.assertEquals(12, originFlatted);
        Assert.assertEquals(10, filteredFlatted);
    }

    @Test
    public void wrongTwoRoleMatche_MustReturnMatchesWithoutTwoWrongMatch() {
        Map<String, List<BaseballBookmakerOdd>> origin = buildTwoWrongEntitiesForKelly();

        ProbabilityMapFilter filter = new ProbabilityMapFilter<BaseballBookmakerOdd>(origin);

        Map<String, List<? extends BookmakerOdd>> filtered = filter.filter();

        System.out.println("filtered:" + filtered);

        Assert.assertNotNull(filtered);
        Assert.assertEquals(origin.size(), filtered.size());

        long originFlatted = origin.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();
        long filteredFlatted = filtered.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();

        Assert.assertNotEquals(originFlatted, filteredFlatted);
        Assert.assertEquals(12, originFlatted);
        Assert.assertEquals(8, filteredFlatted);
    }

    @Test
    public void wrongTwoRoleMatche_MustReturnMatchesWithoutTwoWrongMatch_HomeAwayDraw() {
        Map<String, List<FootballBookmakerOdd>> origin = buildOneWrongEntitiesForKellyHomeDrawAway();

        ProbabilityMapFilter filter = new ProbabilityMapFilter<FootballBookmakerOdd>(origin);

        Map<String, List<? extends BookmakerOdd>> filtered = filter.filter();

        System.out.println("filtered:" + filtered);

        Assert.assertNotNull(filtered);
        Assert.assertEquals(origin.size(), filtered.size());

        long originFlatted = origin.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();
        long filteredFlatted = filtered.entrySet().stream().map(e -> e.getValue()).flatMap(e -> e.stream()).count();

        Assert.assertNotEquals(originFlatted, filteredFlatted);
        Assert.assertEquals(18, originFlatted);
        Assert.assertEquals(15, filteredFlatted);
    }
}
