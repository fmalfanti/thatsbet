package com.kellify.fractionsmaker.kellyfractionproviders;

import com.kellify.fractionsmaker.ConfigAbstract;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.TennisFractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot.BetBrainTennisPilotFraction;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.sql.*;

public class TennisFractionProviderTest extends ConfigAbstract {
    private static Connection getBettingUserConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bettinguser"), config.getProperty("user.bettinguser"), config.getProperty("password.bettinguser"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }
    private static Connection getUbibetterConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

//    private static void createTables() throws IOException, SQLException {
//        File createTennisFractionFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("create_tennis_fraction.sql").getFile());
//        String createTennisFractionStatement = readFileAsString(createTennisFractionFile);
//
//        File createTruncateProcedureFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("create_truncate_tennis_fraction_tables.sql").getFile());
//        String createTruncateProcedureStatement = readFileAsString(createTruncateProcedureFile);
//
//        File createTennisOddsSnapshotFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("create_tennis_odds_snapshot.sql").getFile());
//        String createTennisOddsSnapshotStatement = readFileAsString(createTennisOddsSnapshotFile);
//
//        File insertTennisOddsSnapshotFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("insert_tennis_odds_snapshot.sql").getFile());
//        String insertTennisOddsSnapshotStatement = readFileAsString(insertTennisOddsSnapshotFile);
//
//        File createTennisClusterFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("create_tennis_cluster.sql").getFile());
//        String createTennisClusterStatement = readFileAsString(createTennisClusterFile);
//
//        File insertTennisClusterFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("insert_tennis_cluster_1000.sql").getFile());
//        String insertTennisClusterStatement = readFileAsString(insertTennisClusterFile);
//
//        File createTennisMatriciFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("create_tennis_matrici.sql").getFile());
//        String createTennisMatriciStatement = readFileAsString(createTennisMatriciFile);
//
//        File insertTennisMatriciFile = new File(TennisFractionProviderTest.class.getClassLoader().getResource("insert_tennis_matrici.sql").getFile());
//        String insertTennisMatriciStatement = readFileAsString(insertTennisMatriciFile);
//
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute(createTennisFractionStatement);
//            st.execute(createTennisOddsSnapshotStatement);
//            st.execute(insertTennisOddsSnapshotStatement);
//            st.execute(createTruncateProcedureStatement);
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute(createTennisClusterStatement);
//            st.execute(insertTennisClusterStatement);
//            st.execute(createTennisMatriciStatement);
//            st.execute(insertTennisMatriciStatement);
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }
//
//    private static void dropTables() throws SQLException {
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute("drop table if exists tennis_fraction");
//            st.execute("drop table if exists tennis_odds_snapshot");
//            st.execute("drop alias if exists truncate_tennis_fraction_tables");
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute("drop table if exists tennis_cluster");
//            st.execute("drop table if exists tennis_matrici");
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }

    @BeforeClass
    public static void init() throws IOException, SQLException {
        readConfig();
//        dropTables();
//        createTables();
    }

//    @AfterClass
//    public static void tearDown() throws SQLException {
//        dropTables();
//    }

    private int printResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        int rowNumber = 0;
        while (rs.next()) {
//            for (int i = 1; i <= columnsNumber; i++) {
//                if (i > 1) System.out.print(",  ");
//                String columnValue = rs.getString(i);
//                System.out.print(columnValue + " " + rsmd.getColumnName(i));
//            }
//            System.out.println("");
            rowNumber++;
        }
        return rowNumber;
    }

    @Test
    public void insertFractionsTest() throws SQLException {
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        PilotFractionProvider tennisPilotFraction = new BetBrainTennisPilotFraction(bettingUserConnector, ubibetterConnector);
        FractionProvider fractionProvider = new TennisFractionProvider(bettingUserConnector, tennisPilotFraction, config);
        fractionProvider.execute();
        Connection conn = null;
        int rowNumber = 0;
        try {
            conn = getBettingUserConnection();
            PreparedStatement ps = conn.prepareStatement("select * from tennis_fraction");
            ResultSet rs = ps.executeQuery();
            rowNumber = printResultSet(rs);
            rs.close();
            ps.close();
        } finally {
            if(conn != null) {
                conn.close();
            }
        }

        Assert.assertEquals(0, rowNumber);
    }
}
