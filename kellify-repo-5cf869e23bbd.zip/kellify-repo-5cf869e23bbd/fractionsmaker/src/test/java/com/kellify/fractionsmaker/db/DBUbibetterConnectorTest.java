package com.kellify.fractionsmaker.db;

import com.kellify.common.model.ProbabilitiesQueryType;
import com.kellify.common.model.football.FootballDTO;
import com.kellify.common.util.DTOType;
import com.kellify.fractionsmaker.ConfigAbstract;
import com.kellify.fractionsmaker.model.football.FootballProbabilitiesResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUbibetterConnectorTest extends ConfigAbstract {

    private static Connection getConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

//    private static void createBetFootClusterTable() throws IOException, SQLException {
//        File createFile = new File(DBUbibetterConnectorTest.class.getClassLoader().getResource("create_football_cluster.sql").getFile());
//        String createStatement = readFileAsString(createFile);
//        File insertFile = new File(DBUbibetterConnectorTest.class.getClassLoader().getResource("insert_football_cluster_1000.sql").getFile());
//        String insertStatement = readFileAsString(insertFile);
//        Connection conn = getConnection();
//        Statement st = null;
//        try {
//            conn.setAutoCommit(true);
//            st = conn.createStatement();
//            st.execute(createStatement);
//            st.execute(insertStatement);
//        } finally {
//            if(conn != null)  {
//                conn.close();
//            }
//        }
//    }

    private FootballDTO fakeParam() {
        return new FootballDTO(0,0,0,0,0,0,"fake", DTOType.PROBABILITY,"fake");
    }

    @BeforeClass
    public static void init() throws IOException, SQLException {
        readConfig();
//        createBetFootClusterTable();
    }

    @Test
    public void stateProbabilities_notInitializated_shouldReturnFalse() {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        boolean isInit = true;
        try {
            isInit = ubiConnector.isFTRStatementInit();
        } finally {
            ubiConnector.closeConnection();
        }

        Assert.assertFalse("StateProbabilites should not be initializated", isInit);
    }

    @Test
    public void stateProbabilities_initializated_shouldReturnTrue() throws SQLException {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        boolean isInit = false;
        try {
            ubiConnector.getFTR(fakeParam());
            isInit = ubiConnector.isFTRStatementInit();
        } finally {
            ubiConnector.closeConnection();
        }

        Assert.assertTrue("StateProbabilites should be initializated", isInit);
    }

    @Test
    public void stateProbabilities_initializatedAndRecalled_shouldReturnTrue() throws SQLException {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        boolean isInit = false;
        try {
            ubiConnector.getFTR(fakeParam());
            isInit = ubiConnector.isFTRStatementInit();
            ubiConnector.getFTR(fakeParam());
            isInit = ubiConnector.isFTRStatementInit();
        } finally {
            ubiConnector.closeConnection();
        }

        Assert.assertTrue("StateProbabilites should be initializated", isInit);
    }

    @Test
    public void stateProbabilities_afterTearDown_shouldReturnFalse() throws SQLException {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        boolean isInit = false;
        try {
            ubiConnector.getFTR(fakeParam());
            isInit = ubiConnector.isFTRStatementInit();
            ubiConnector.FTRStatementInitTearDown();
            isInit = ubiConnector.isFTRStatementInit();
        } finally {
            ubiConnector.closeConnection();
        }

        Assert.assertFalse("StateProbabilites should not be initializated", isInit);
    }

    @Test
    public void shouldQueryCountry() throws SQLException {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        FootballDTO params = new FootballDTO(0.35,0.43,0.2,0.3,0.31,0.4,"Italy", DTOType.PROBABILITY,"Europe");
        FootballProbabilitiesResult result;
        try {
            result = ubiConnector.getFTR(params);
        } finally {
            ubiConnector.FTRStatementInitTearDown();
            ubiConnector.closeConnection();
        }

        Assert.assertEquals(ProbabilitiesQueryType.COUNTRY, result.getType());
    }

    @Test
    public void shouldQueryContinent() throws SQLException {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        FootballDTO params = new FootballDTO(0.41,0.43,0.27,0.31,0.31,0.4,"Italy", DTOType.PROBABILITY,"Europe");
        FootballProbabilitiesResult result;
        try {
            result = ubiConnector.getFTR(params);
        } finally {
            ubiConnector.FTRStatementInitTearDown();
            ubiConnector.closeConnection();
        }

        Assert.assertEquals(ProbabilitiesQueryType.CONTINENT, result.getType());
    }

    @Test
    public void shouldQueryWorld() throws SQLException {
        DbUbibetterConnector ubiConnector = DbUbibetterConnector.getInstance(config);
        FootballDTO params = new FootballDTO(0.41,0.43,0.28,0.31,0.31,0.4,"Italy", DTOType.PROBABILITY, "Europe");
        FootballProbabilitiesResult result;
        try {
            result = ubiConnector.getFTR(params);
        } finally {
            ubiConnector.FTRStatementInitTearDown();
            ubiConnector.closeConnection();
        }

        Assert.assertEquals(ProbabilitiesQueryType.ALL, result.getType());
    }

//    private static String buildEventFractionQuery(List<SportTypes> bettingSports) {
//        if(bettingSports == null || bettingSports.isEmpty()) {
//            return null;
//        }
//        StringBuilder query = new StringBuilder();
//        String unionAll = " union all ";
//        for(SportTypes sport : bettingSports) {
//            switch(sport) {
//                case FOOTBALL:
//                    query.append(SELECT_FOOTBALL_PLATFORM_FRACTION);
//                    break;
//                case BASKET:
//                    query.append(SELECT_BASKET_PLATFORM_FRACTION);
//                    break;
//                case TENNIS:
//                    query.append(SELECT_TENNIS_PLATFORM_FRACTION);
//                    break;
//            }
//            query.append(unionAll);
//        }
//        return query.delete(query.lastIndexOf(unionAll), query.length()).toString();
//    }
}
