package com.kellify.fractionsmaker.oddreduce;

import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.fractionsmaker.ConfigAbstract;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.model.basket.EventBasketProbability;
import com.kellify.fractionsmaker.model.football.EventFootballProbability;
import com.kellify.fractionsmaker.model.tennis.EventTennisProbability;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

public class ProbabilityMapTest extends ConfigAbstract {
    private static Connection getBettingUserConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bettinguser"), config.getProperty("user.bettinguser"), config.getProperty("password.bettinguser"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }
    private static Connection getUbibetterConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

//    private static void createTables() throws IOException, SQLException {
//        File createBasketOddsSnapshotFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_basket_odds_snapshot.sql").getFile());
//        String createBasketOddsSnapshotStatement = readFileAsString(createBasketOddsSnapshotFile);
//
//        File insertBasketOddsSnapshotFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_basket_odds_snapshot.sql").getFile());
//        String insertBasketOddsSnapshotStatement = readFileAsString(insertBasketOddsSnapshotFile);
//
//        File createBasketMatriciFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_basket_matrici.sql").getFile());
//        String createBasketMatriciStatement = readFileAsString(createBasketMatriciFile);
//
//        File insertBasketMatriciFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_basket_matrici.sql").getFile());
//        String insertBasketMatriciStatement = readFileAsString(insertBasketMatriciFile);
//
//        File createFootballOddsSnapshotFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_football_odds_snapshot.sql").getFile());
//        String createFootballOddsSnapshotStatement = readFileAsString(createFootballOddsSnapshotFile);
//
//        File insertFootballOddsSnapshotFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_football_odds_snapshot_new.sql").getFile());
//        String insertFootballOddsSnapshotStatement = readFileAsString(insertFootballOddsSnapshotFile);
//
//        File createFootballMatriciFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_football_matrici.sql").getFile());
//        String createFootballMatriciStatement = readFileAsString(createFootballMatriciFile);
//
//        File insertFootballMatriciFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_football_matrici.sql").getFile());
//        String insertFootballMatriciStatement = readFileAsString(insertFootballMatriciFile);
//
//        File createTennisOddsSnapshotFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_tennis_odds_snapshot.sql").getFile());
//        String createTennisOddsSnapshotStatement = readFileAsString(createTennisOddsSnapshotFile);
//
//        File insertTennisOddsSnapshotFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_tennis_odds_snapshot.sql").getFile());
//        String insertTennisOddsSnapshotStatement = readFileAsString(insertTennisOddsSnapshotFile);
//
//        File createTennisMatriciFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_tennis_matrici.sql").getFile());
//        String createTennisMatriciStatement = readFileAsString(createTennisMatriciFile);
//
//        File insertTennisMatriciFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_tennis_matrici.sql").getFile());
//        String insertTennisMatriciStatement = readFileAsString(insertTennisMatriciFile);
//
//        File createTennisClusterFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("create_tennis_cluster.sql").getFile());
//        String createTennisClusterStatement = readFileAsString(createTennisClusterFile);
//
//        File insertTennisClusterFile = new File(ProbabilityMapTest.class.getClassLoader().getResource("insert_tennis_cluster_1000.sql").getFile());
//        String insertTennisClusterStatement = readFileAsString(insertTennisClusterFile);
//
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute(createBasketOddsSnapshotStatement);
//            st.execute(insertBasketOddsSnapshotStatement);
//            st.execute(createFootballOddsSnapshotStatement);
//            st.execute(insertFootballOddsSnapshotStatement);
//            st.execute(createTennisOddsSnapshotStatement);
//            st.execute(insertTennisOddsSnapshotStatement);
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute(createBasketMatriciStatement);
//            st.execute(insertBasketMatriciStatement);
//            st.execute(createFootballMatriciStatement);
//            st.execute(insertFootballMatriciStatement);
//            st.execute(createTennisMatriciStatement);
//            st.execute(insertTennisMatriciStatement);
//            st.execute(createTennisClusterStatement);
//            st.execute(insertTennisClusterStatement);
//
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }
//    private static void dropTables() throws SQLException {
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute("drop table if exists basket_odds_snapshot");
//            st.execute("drop table if exists football_odds_snapshot");
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute("drop table if exists basket_matrici");
//            st.execute("drop table if exists football_matrici");
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }

    @BeforeClass
    public static void init() throws IOException, SQLException {
        readConfig();
//        dropTables();
//        createTables();
    }

//    @AfterClass
//    public static void tearDown() throws SQLException {
//        dropTables();
//    }

    @Test
    public void testBasketReduce() throws SQLException {
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        Map<String, List<BasketBookmakerOdd>> basketEntitiesForProbabilities = bettingUserConnector.loadBasketEntitiesForProbabilities();
        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventBasketProbability> basketProbabilityMap = oddReducer.basketReduce(basketEntitiesForProbabilities);
        System.out.println(basketProbabilityMap.toString());
    }

    @Test
    public void testBasket() throws SQLException {
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        Map<String, List<BasketBookmakerOdd>> basketEntitiesForProbabilities = bettingUserConnector.loadBasketEntitiesForProbabilities();
        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventBasketProbability> basketProbabilityMap = oddReducer.basketReduce(basketEntitiesForProbabilities);
        System.out.println(basketProbabilityMap.toString());
    }

    @Test
    public void testFootball() throws SQLException {
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        Map<String, List<FootballBookmakerOdd>> footballEntitiesForProbabilities = bettingUserConnector.loadFootballEntitiesForProbabilities();
        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventFootballProbability> footballProbabilityMap = oddReducer.footballReduce(footballEntitiesForProbabilities);
        System.out.println(footballProbabilityMap.toString());
    }
    @Test
    public void testTennis() throws SQLException {
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        Map<String, List<TennisBookmakerOdd>> tennisEntitiesForProbabilities = bettingUserConnector.loadTennisEntitiesForProbabilities();
        ProbabilityMap oddReducer = ProbabilityMap.getReducer(ubibetterConnector);
        Map<String, EventTennisProbability> tennisProbabilityMap = oddReducer.tennisReduce(tennisEntitiesForProbabilities);
        System.out.println(tennisProbabilityMap.toString());
    }
}
