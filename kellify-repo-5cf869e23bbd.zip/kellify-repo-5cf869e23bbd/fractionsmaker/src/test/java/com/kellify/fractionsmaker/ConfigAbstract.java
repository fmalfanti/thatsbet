package com.kellify.fractionsmaker;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Properties;

public abstract class ConfigAbstract {
    protected static Properties config;

    protected static void readConfig() throws IOException {
        File confFile = new File(ConfigAbstract.class.getClassLoader().getResource("application.properties").getFile());
        config = new Properties();
        config.load(new FileInputStream(confFile));
    }

    protected static String readFileAsString(File file) throws IOException {
        return new String(Files.readAllBytes(file.toPath()));
    }
}
