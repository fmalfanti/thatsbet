package com.kellify.fractionsmaker.kellyfractionproviders;

import com.kellify.fractionsmaker.ConfigAbstract;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.IceHockeyHAFractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot.BetBrainIceHockeyPilotFraction;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.sql.*;

public class IceHockeyHaFractionProviderTest extends ConfigAbstract {
    private static Connection getBettingUserConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bettinguser"), config.getProperty("user.bettinguser"), config.getProperty("password.bettinguser"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }
    private static Connection getUbibetterConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

//    private static void createTables() throws IOException, SQLException {
//        File createIceHockeyHAFractionFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("create_icehockeyHA_fraction.sql").getFile());
//        String createIceHockeyHAFractionStatement = readFileAsString(createIceHockeyHAFractionFile);
//
//        File createTruncateProcedureFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("create_truncate_icehockeyHA_fraction_tables.sql").getFile());
//        String createTruncateProcedureStatement = readFileAsString(createTruncateProcedureFile);
//
//        File createIceHockeyHAOddsSnapshotFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("create_icehockey_odds_snapshot.sql").getFile());
//        String createIceHockeyHAOddsSnapshotStatement = readFileAsString(createIceHockeyHAOddsSnapshotFile);
//
//        File insertIceHockeyHAOddsSnapshotFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("insert_icehockey_odds_snapshot.sql").getFile());
//        String insertIceHockeyHAOddsSnapshotStatement = readFileAsString(insertIceHockeyHAOddsSnapshotFile);
//
//        File createIceHockeyHAClusterFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("create_icehockey_ha_cluster.sql").getFile());
//        String createIceHockeyHAClusterStatement = readFileAsString(createIceHockeyHAClusterFile);
//
//        File insertIceHockeyHAClusterFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("insert_icehockey_ha_cluster.sql").getFile());
//        String insertIceHockeyHAClusterStatement = readFileAsString(insertIceHockeyHAClusterFile);
//
//        File createIceHockeyHAMatriciFile = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("create_icehockey_ha_matrici.sql").getFile());
//        String createIceHockeyHAMatriciStatement = readFileAsString(createIceHockeyHAMatriciFile);
//
//        File IceHockeyHaFractionProviderTest = new File(IceHockeyHaFractionProviderTest.class.getClassLoader().getResource("insert_icehockey_ha_matrici.sql").getFile());
//        String insertIceHockeyHAMatriciStatement = readFileAsString(IceHockeyHaFractionProviderTest);
//
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute(createIceHockeyHAFractionStatement);
//            st.execute(createIceHockeyHAOddsSnapshotStatement);
//            st.execute(insertIceHockeyHAOddsSnapshotStatement);
//            st.execute(createTruncateProcedureStatement);
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute(createIceHockeyHAClusterStatement);
//            st.execute(insertIceHockeyHAClusterStatement);
//            st.execute(createIceHockeyHAMatriciStatement);
//            st.execute(insertIceHockeyHAMatriciStatement);
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }
//
//    private static void dropTables() throws SQLException {
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute("drop table if exists icehockeyHA_fraction");
//            st.execute("drop table if exists icehochey_odds_snapshot");
//            st.execute("drop alias if exists truncate_icehocheyHA_fraction_tables");
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute("drop table if exists icehockey_ha_cluster");
//            st.execute("drop table if exists icehockey_ha_matrici");
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }

    @BeforeClass
    public static void init() throws IOException, SQLException {
        readConfig();
//        dropTables();
//        createTables();
    }

//    @AfterClass
//    public static void tearDown() throws SQLException {
//        dropTables();
//    }

    private int printResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        int rowNumber = 0;
        while (rs.next()) {
//            for (int i = 1; i <= columnsNumber; i++) {
//                if (i > 1) System.out.print(",  ");
//                String columnValue = rs.getString(i);
//                System.out.print(columnValue + " " + rsmd.getColumnName(i));
//            }
//            System.out.println("");
            rowNumber++;
        }
        return rowNumber;
    }

    @Test
    public void insertFractionsTest() throws SQLException {
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        PilotFractionProvider iceHockeyPilotFraction = new BetBrainIceHockeyPilotFraction(bettingUserConnector, ubibetterConnector);
        FractionProvider fractionProvider = new IceHockeyHAFractionProvider(bettingUserConnector, iceHockeyPilotFraction, config);
        fractionProvider.execute();
        Connection conn = null;
        int rowNumber = 0;
        try {
            conn = getBettingUserConnection();
            PreparedStatement ps = conn.prepareStatement("select * from icehockeyHA_fraction");
            ResultSet rs = ps.executeQuery();
            rowNumber = printResultSet(rs);
            rs.close();
            ps.close();
        } finally {
            if(conn != null) {
                conn.close();
            }
        }

        Assert.assertEquals(0, rowNumber);
    }
}
