package com.kellify.fractionsmaker.kellyfractionproviders;

import com.kellify.fractionsmaker.ConfigAbstract;
import com.kellify.fractionsmaker.db.DbBettingUserConnector;
import com.kellify.fractionsmaker.db.DbUbibetterConnector;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.BasketFractionProvider;
import com.kellify.fractionsmaker.kellyfractionproviders.impl.pilot.BetBrainBasketPilotFraction;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.sql.*;

public class BasketFractionProviderTest extends ConfigAbstract {
    private static Connection getBookmakerBettingConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bookmakerbetting"), config.getProperty("user.bookmakerbetting"), config.getProperty("password.bookmakerbetting"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }
    private static Connection getUbibetterConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.ubibetter"), config.getProperty("user.ubibetter"), config.getProperty("password.ubibetter"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }
    private static Connection getBettingUserConnection() {
        Connection connection;
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bettinguser"), config.getProperty("user.bettinguser"), config.getProperty("password.bettinguser"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

//    private static void createTables() throws IOException, SQLException {
//        File createBasketFractionFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("create_basket_fraction.sql").getFile());
//        String createBasketFractionStatement = readFileAsString(createBasketFractionFile);
//
//        File createTruncateProcedureFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("create_truncate_basket_fraction_tables.sql").getFile());
//        String createTruncateProcedureStatement = readFileAsString(createTruncateProcedureFile);
//
//        File createBasketOddsSnapshotFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("create_basket_odds_snapshot.sql").getFile());
//        String createBasketOddsSnapshotStatement = readFileAsString(createBasketOddsSnapshotFile);
//
//        File insertBasketOddsSnapshotFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("insert_basket_odds_snapshot.sql").getFile());
//        String insertBasketOddsSnapshotStatement = readFileAsString(insertBasketOddsSnapshotFile);
//
//        File createBasketHistoryOddsFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("create_basket_history_odds.sql").getFile());
//        String createBasketHistoryOddsStatement = readFileAsString(createBasketHistoryOddsFile);
//
//        File insertBasketHistoryOddsFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("insert_basket_history_odds.sql").getFile());
//        String insertBasketHistoryOddsStatement = readFileAsString(insertBasketHistoryOddsFile);
//
//
//        File createBasketClusterFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("create_basket_cluster.sql").getFile());
//        String createBasketClusterStatement = readFileAsString(createBasketClusterFile);
//
//        File insertBasketClusterFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("insert_basket_cluster_1000.sql").getFile());
//        String insertBasketClusterStatement = readFileAsString(insertBasketClusterFile);
//
//        File createBasketMatriciFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("create_basket_matrici.sql").getFile());
//        String createBasketMatriciStatement = readFileAsString(createBasketMatriciFile);
//
//        File insertBasketMatriciFile = new File(BasketFractionProviderTest.class.getClassLoader().getResource("insert_basket_matrici.sql").getFile());
//        String insertBasketMatriciStatement = readFileAsString(insertBasketMatriciFile);
//
//        //Connection connBetting = getBookmakerBettingConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Connection connBettingUser = getBettingUserConnection();
//        Statement st = null;
//        try {
////            connBetting.setAutoCommit(true);
////            st = connBetting.createStatement();
////            st.execute(createBasketFractionStatement);
////            st.execute(createBasketOddsSnapshotStatement);
////            st.execute(insertBasketOddsSnapshotStatement);
////            st.execute(createTruncateProcedureStatement);
////            st.close();
//
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute(createBasketFractionStatement);
//            st.execute(createBasketOddsSnapshotStatement);
//            st.execute(insertBasketOddsSnapshotStatement);
//            st.execute(createTruncateProcedureStatement);
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute(createBasketClusterStatement);
//            st.execute(insertBasketClusterStatement);
//            st.execute(createBasketMatriciStatement);
//            st.execute(insertBasketMatriciStatement);
//            st.execute(createBasketHistoryOddsStatement);
//            st.execute(insertBasketHistoryOddsStatement);
//        } finally {
////            if(connBetting != null)  {
////                connBetting.close();
////            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//        }
//    }
//
//    private static void dropTables() throws SQLException {
//        Connection connBettingUser = getBettingUserConnection();
//        Connection connUbibetter = getUbibetterConnection();
//        Statement st = null;
//        try {
//            connBettingUser.setAutoCommit(true);
//            st = connBettingUser.createStatement();
//            st.execute("drop table if exists basket_fraction");
//            st.execute("drop table if exists basket_odds_snapshot");
//            st.execute("drop alias if exists truncate_basket_fraction_tables");
//            st.close();
//
//            connUbibetter.setAutoCommit(true);
//            st = connUbibetter.createStatement();
//            st.execute("drop table if exists basket_cluster");
//            st.execute("drop table if exists basket_matrici");
//        } finally {
//            if(connBettingUser != null)  {
//                connBettingUser.close();
//            }
//            if(connUbibetter != null)  {
//                connUbibetter.close();
//            }
//        }
//    }

    @BeforeClass
    public static void init() throws IOException, SQLException {
        readConfig();
//        dropTables();
//        createTables();
    }

//    @AfterClass
//    public static void tearDown() throws SQLException {
//        dropTables();
//    }

    private int printResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        int rowNumber = 0;
        while (rs.next()) {
//            for (int i = 1; i <= columnsNumber; i++) {
//                if (i > 1) System.out.print(",  ");
//                String columnValue = rs.getString(i);
//                System.out.print(columnValue + " " + rsmd.getColumnName(i));
//            }
//            System.out.println("");
            rowNumber++;
        }
        return rowNumber;
    }

    @Test
    public void insertFractionsTest() throws SQLException {
        DbUbibetterConnector ubibetterConnector = DbUbibetterConnector.getInstance(config);
        DbBettingUserConnector bettingUserConnector = DbBettingUserConnector.getInstance(config);
        PilotFractionProvider basketPilotFraction = new BetBrainBasketPilotFraction(ubibetterConnector, bettingUserConnector);
        FractionProvider fractionProvider = new BasketFractionProvider( bettingUserConnector, basketPilotFraction, config);
        fractionProvider.execute();
        Connection conn = null;
        int rowNumber = 0;
        try {
            conn = getBettingUserConnection();
            PreparedStatement ps = conn.prepareStatement("select * from basket_fraction");
            ResultSet rs = ps.executeQuery();
            rowNumber = printResultSet(rs);
            rs.close();
            ps.close();
        } finally {
            if(conn != null) {
                conn.close();
            }
        }

        Assert.assertEquals(0, rowNumber);
    }
}
