create table basket_odds_snapshot
(
	id int auto_increment	primary key,
	referrer_id varchar(50) not null,
	match_date datetime not null,
	event_id varchar(50) not null,
	odd_id varchar(50) default '' not null,
	platform_id int not null,
	role tinyint not null,
	odd double not null,
	bookmaker_id int not null,
	team varchar(100) not null,
	championship varchar(10) not null,
	country varchar(100) not null,
	continent varchar(100) null,
	betting_type int null,
	bookmaker_enabled INT(4) DEFAULT '0'     NULL
)

