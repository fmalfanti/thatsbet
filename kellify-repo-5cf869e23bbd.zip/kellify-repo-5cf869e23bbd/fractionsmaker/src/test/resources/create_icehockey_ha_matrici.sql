-- auto-generated definition
CREATE TABLE icehockey_ha_matrici
(
  Nazione VARCHAR(32) NOT NULL
    PRIMARY KEY,
  Valori  TEXT        NOT NULL
)