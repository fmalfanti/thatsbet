-- auto-generated definition
CREATE TABLE icehockey_ha_cluster
(
  MatchDate  DATE DEFAULT '1970-01-01'    NOT NULL,
  Campionato VARCHAR(9) DEFAULT ''        NOT NULL,
  Nazione    VARCHAR(20) DEFAULT ''       NOT NULL,
  Continente VARCHAR(64) DEFAULT ''       NULL,
  HomeTeam   VARCHAR(25) DEFAULT ''       NOT NULL,
  AwayTeam   VARCHAR(25) DEFAULT ''       NOT NULL,
  FTHG       SMALLINT(6) DEFAULT '-1'     NOT NULL,
  FTAG       SMALLINT(6) DEFAULT '-1'     NOT NULL,
  FTR        VARCHAR(2)                   NOT NULL,
  MA         DOUBLE DEFAULT '-1.00' NULL,
  MH         DOUBLE DEFAULT '-1.00' NULL,
  NM         SMALLINT DEFAULT '-1'        NULL,
  PRIMARY KEY (MatchDate, HomeTeam, AwayTeam, Campionato),
  CONSTRAINT indice
  UNIQUE (Campionato, MatchDate, HomeTeam, AwayTeam)
)