create table tennis_cluster
(
	MatchDate date default '1970-01-01' not null,
	Winner varchar(25) default '' not null,
	Loser varchar(25) default '' not null,
	WRank smallint(6) default '-1' not null,
	LRank smallint(6) default '-1' not null,
	MW double default '-1.00' null,
	ML double default '-1.00' null,
	NM int(5) default '-1' null,
	Location varchar(5) default '' null,
	Tournament varchar(255) default '' not null,
	Series varchar(5) default '' null,
	Surface varchar(30) default '' null,
	Round varchar(50) default '' null,
	primary key (MatchDate, Winner, Loser, Tournament)
)