create table football_fraction
(
  referrer_id varchar(50) not null,
  event_id varchar(50) not null,
  odd_id varchar(50) not null,
  platform_id int not null,
  home_team varchar(100) not null,
  away_team varchar(100) not null,
  country varchar(100) not null,
  continent varchar(100) not null,
  championship varchar(10) not null,
  bookmaker_id int not null,
  match_date datetime not null,
  fh double not null,
  fd double not null,
  fa double not null,
  ph int not null,
  pd int not null,
  pa int not null,
  pbh int not null,
  pbd int not null,
  pba int not null,
  delta double not null,
  id_betting_home varchar(50) not null,
  id_betting_draw varchar(50) not null,
  id_betting_away varchar(50) not null,
  betting_type int
);
create index football_fraction_platforms_id_fk on football_fraction (platform_id);
create index football_fraction_bookmakers_id_fk on football_fraction (bookmaker_id);

