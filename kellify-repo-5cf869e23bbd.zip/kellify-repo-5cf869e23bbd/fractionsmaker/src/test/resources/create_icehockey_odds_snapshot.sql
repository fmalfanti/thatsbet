CREATE TABLE icehockey_odds_snapshot
(
  id                INT AUTO_INCREMENT
    PRIMARY KEY,
  referrer_id       VARCHAR(50)            NOT NULL,
  match_date        DATETIME               NOT NULL,
  event_id          VARCHAR(50)            NOT NULL,
  odd_id            VARCHAR(50) DEFAULT '' NOT NULL,
  platform_id       INT                    NOT NULL,
  role              TINYINT                NOT NULL
  COMMENT '1=Home, 0=Draw, 2=Away',
  odd               DOUBLE                 NOT NULL,
  bookmaker_id      INT                    NOT NULL,
  team              VARCHAR(100)           NOT NULL,
  championship      VARCHAR(10)            NOT NULL,
  country           VARCHAR(100)           NOT NULL,
  continent         VARCHAR(100)           NULL,
  betting_type      INT                    NULL,
  bookmaker_enabled TINYINT DEFAULT '0'    NOT NULL
)

