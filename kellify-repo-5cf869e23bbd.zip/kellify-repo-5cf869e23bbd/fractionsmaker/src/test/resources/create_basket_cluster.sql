create table basket_cluster
(
	MatchDate date default '1970-01-01' not null,
	Campionato varchar(9) default '' not null,
	Nazione varchar(20) default '' not null,
	Continente varchar(64) default '' null,
	HomeTeam varchar(25) default '' not null,
	AwayTeam varchar(25) default '' not null,
	FTHG smallint(6) default '-1' not null,
	FTAG smallint(6) default '-1' not null,
	FTR varchar(2) not null,
	MA double default '-1.00' null,
	MH double default '-1.00' null,
	NM smallint default '-1' null,
	primary key (MatchDate, HomeTeam, AwayTeam, Campionato)
)

