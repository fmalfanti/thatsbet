CREATE ALIAS IF NOT EXISTS truncate_baseball_fraction_tables as $$
void dropFraction(Connection conn) throws Exception {
  Statement st = conn.createStatement();
  st.execute("truncate table baseball_fraction");
} $$;

