create table tennis_matrici
(
	Surface varchar(32) not null
		primary key,
	Valori text not null
);

