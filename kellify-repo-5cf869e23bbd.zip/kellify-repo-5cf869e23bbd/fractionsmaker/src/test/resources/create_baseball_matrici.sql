-- auto-generated definition
CREATE TABLE baseball_matrici
(
  Nazione VARCHAR(32) NOT NULL
    PRIMARY KEY,
  Valori  TEXT        NOT NULL
)


