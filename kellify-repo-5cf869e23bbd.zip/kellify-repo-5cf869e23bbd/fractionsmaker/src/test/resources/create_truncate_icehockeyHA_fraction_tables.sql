CREATE ALIAS IF NOT EXISTS truncate_icehockeyHA_fraction_tables as $$
void dropFraction(Connection conn) throws Exception {
  Statement st = conn.createStatement();
  st.execute("truncate table icehockeyHA_fraction");
} $$;

