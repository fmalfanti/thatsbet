create table basket_matrici
(
	Nazione varchar(32) not null
		primary key,
	Valori text not null
)

