CREATE ALIAS IF NOT EXISTS truncate_basket_fraction_tables as $$
void dropFraction(Connection conn) throws Exception {
  Statement st = conn.createStatement();
  st.execute("truncate table basket_fraction");
} $$;

