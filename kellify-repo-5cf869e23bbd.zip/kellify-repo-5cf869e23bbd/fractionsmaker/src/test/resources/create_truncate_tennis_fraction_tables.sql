CREATE ALIAS IF NOT EXISTS truncate_tennis_fraction_tables as $$
void dropFraction(Connection conn) throws Exception {
  Statement st = conn.createStatement();
  st.execute("truncate table tennis_fraction");
} $$;

