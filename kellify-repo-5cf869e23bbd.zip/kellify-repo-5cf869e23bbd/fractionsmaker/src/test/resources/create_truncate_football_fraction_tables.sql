CREATE ALIAS IF NOT EXISTS truncate_football_fraction_tables as $$
void dropFraction(Connection conn) throws Exception {
  Statement st = conn.createStatement();
  st.execute("truncate table football_fraction");
} $$;

