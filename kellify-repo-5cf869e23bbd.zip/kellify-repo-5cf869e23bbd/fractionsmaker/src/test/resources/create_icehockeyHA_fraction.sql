CREATE TABLE icehockeyHA_fraction
(
  referrer_id     VARCHAR(50)  NOT NULL,
  event_id        VARCHAR(50)  NOT NULL,
  odd_id          VARCHAR(50)  NULL,
  platform_id     INT          NOT NULL,
  home_team       VARCHAR(100) NOT NULL,
  away_team       VARCHAR(100) NOT NULL,
  country         VARCHAR(100) NOT NULL,
  continent       VARCHAR(100) NOT NULL,
  championship    VARCHAR(100) NOT NULL,
  bookmaker_id    INT          NOT NULL,
  match_date      DATETIME     NOT NULL,
  fh              DOUBLE       NOT NULL,
  fa              DOUBLE       NOT NULL,
  ph              INT          NOT NULL,
  pa              INT          NOT NULL,
  pbh             INT          NOT NULL,
  pba             INT          NOT NULL,
  delta           DOUBLE       NOT NULL,
  id_betting_home VARCHAR(50)  NOT NULL,
  id_betting_away VARCHAR(50)  NOT NULL,
  betting_type    INT          NULL
)