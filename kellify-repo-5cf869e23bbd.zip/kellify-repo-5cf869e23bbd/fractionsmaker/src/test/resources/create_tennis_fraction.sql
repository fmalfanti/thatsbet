create table tennis_fraction
(
	referrer_id varchar(50) not null,
	event_id varchar(50) not null,
	odd_id varchar(50) null,
	platform_id int not null,
	home_team varchar(100) not null,
	away_team varchar(100) not null,
	country varchar(100) not null,
	championship varchar(100) not null,
	bookmaker_id int not null,
	match_date datetime not null,
	fh double not null,
	fa double not null,
	ph int not null,
	pa int not null,
	pbh int not null,
	pba int not null,
	delta double not null,
	id_betting_home varchar(50) not null,
	id_betting_away varchar(50) not null,
	betting_type int null
);

