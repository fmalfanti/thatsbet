package com.kellify.kellifyweb.model;

import java.util.Arrays;
import java.util.Date;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public class BetMoneyDistribution {
    private long providerId;
    private String homeTeam;
    private String awayTeam;
    private String platform;
    private String location;
    private String campionato;
    private String bookmaker;
    private Date startTime;
    private int moneyAway;
    private int moneyHome;
    private int moneyDraw;
    private int ph;
    private int pd;
    private int pa;
    private int pbh;
    private int pbd;
    private int pba;
    private int[] ok = new int[3]; // 0=green, 1=red, -1=blank

    private BetMoneyDistribution(BetMoneyDistributionBuilder builder) {
        this.providerId = builder.getProviderId();
        this.homeTeam = builder.getHomeTeam();
        this.awayTeam = builder.getAwayTeam();
        this.platform = builder.getPlatform();
        this.location = builder.getLocation();
        this.campionato = builder.getCampionato();
        this.bookmaker = builder.getBookmaker();
        this.startTime = builder.getStartTime();
        this.moneyAway = builder.getMoneyAway();
        this.moneyHome = builder.getMoneyHome();
        this.moneyDraw = builder.getMoneyDraw();
        this.ph = builder.getPh();
        this.pd = builder.getPd();
        this.pa = builder.getPa();
        this.pbh = builder.getPbh();
        this.pbd = builder.getPbd();
        this.pba = builder.getPba();
        this.ok = builder.getOk();
    }

    public long getProviderId() {
        return providerId;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public String getLocation() {
        return location;
    }

    public String getCampionato() {
        return campionato;
    }

    public String getBookmaker() {
        return bookmaker;
    }

    public Date getStartTime() {
        return startTime;
    }

    public int getMoneyAway() {
        return moneyAway;
    }

    public int getMoneyHome() {
        return moneyHome;
    }

    public int getMoneyDraw() {
        return moneyDraw;
    }

    public int getPh() {
        return ph;
    }

    public int getPd() {
        return pd;
    }

    public int getPa() {
        return pa;
    }

    public int getPbh() {
        return pbh;
    }

    public int getPbd() {
        return pbd;
    }

    public int getPba() {
        return pba;
    }

    public int[] getOk() {
        return ok;
    }

    public String getPlatform() {
        return platform;
    }

    @Override
    public String toString() {
        return "BetMoneyDistribution{" +
                "providerId=" + providerId +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", platform='" + platform + '\'' +
                ", location='" + location + '\'' +
                ", campionato='" + campionato + '\'' +
                ", bookmaker='" + bookmaker + '\'' +
                ", startTime=" + startTime +
                ", moneyAway=" + moneyAway +
                ", moneyHome=" + moneyHome +
                ", moneyDraw=" + moneyDraw +
                ", ph=" + ph +
                ", pd=" + pd +
                ", pa=" + pa +
                ", pbh=" + pbh +
                ", pbd=" + pbd +
                ", pba=" + pba +
                ", ok=" + Arrays.toString(ok) +
                '}';
    }

    public static class BetMoneyDistributionBuilder {
        private long providerId;
        private String homeTeam;
        private String awayTeam;
        private String platform;
        private String location;
        private String campionato;
        private String bookmaker;
        private Date startTime;
        private int moneyAway;
        private int moneyHome;
        private int moneyDraw;
        private int ph;
        private int pd;
        private int pa;
        private int pbh;
        private int pbd;
        private int pba;
        private int[] ok = new int[3];

        public BetMoneyDistributionBuilder ProviderId(long providerId) {
            this.providerId = providerId;
            return this;
        }
        public BetMoneyDistributionBuilder HomeTeam(String homeTeam) {
            this.homeTeam = homeTeam;
            return this;
        }
        public BetMoneyDistributionBuilder AwayTeam(String awayTeam) {
            this.awayTeam = awayTeam;
            return this;
        }
        public BetMoneyDistributionBuilder Platform(String platform) {
            this.platform = platform;
            return this;
        }
        public BetMoneyDistributionBuilder Location(String location) {
            this.location = location;
            return this;
        }
        public BetMoneyDistributionBuilder Campionato(String campionato) {
            this.campionato = campionato;
            return this;
        }
        public BetMoneyDistributionBuilder Bookmaker(String bookmaker) {
            this.bookmaker = bookmaker;
            return this;
        }
        public BetMoneyDistributionBuilder StartTime(Date startTime) {
            this.startTime = startTime;
            return this;
        }
        public BetMoneyDistributionBuilder MoneyAway(int moneyAway) {
            this.moneyAway = moneyAway;
            return this;
        }
        public BetMoneyDistributionBuilder MoneyHome(int moneyHome) {
            this.moneyHome = moneyHome;
            return this;
        }
        public BetMoneyDistributionBuilder Ph(int ph) {
            this.ph = ph;
            return this;
        }
        public BetMoneyDistributionBuilder Pd(int pd) {
            this.pd = pd;
            return this;
        }
        public BetMoneyDistributionBuilder Pa(int pa) {
            this.pa = pa;
            return this;
        }
        public BetMoneyDistributionBuilder Pbh(int pbh) {
            this.pbh = pbh;
            return this;
        }
        public BetMoneyDistributionBuilder Pbd(int pbd) {
            this.pbd = pbd;
            return this;
        }
        public BetMoneyDistributionBuilder Pba(int pba) {
            this.pba = pba;
            return this;
        }
        public BetMoneyDistributionBuilder MoneyDraw(int moneyDraw) {
            this.moneyDraw = moneyDraw;
            return this;
        }
        public BetMoneyDistributionBuilder Ok(int[] ok) {
            this.ok = ok;
            return this;
        }
        public BetMoneyDistribution Build() {
            return new BetMoneyDistribution(this);
        }

        public long getProviderId() {
            return providerId;
        }

        public String getHomeTeam() {
            return homeTeam;
        }

        public String getAwayTeam() {
            return awayTeam;
        }

        public String getLocation() {
            return location;
        }

        public String getCampionato() {
            return campionato;
        }

        public String getBookmaker() {
            return bookmaker;
        }

        public Date getStartTime() {
            return startTime;
        }

        public int getMoneyAway() {
            return moneyAway;
        }

        public int getMoneyHome() {
            return moneyHome;
        }

        public int getMoneyDraw() {
            return moneyDraw;
        }

        public int getPh() {
            return ph;
        }

        public int getPd() {
            return pd;
        }

        public int getPa() {
            return pa;
        }

        public int getPbh() {
            return pbh;
        }

        public int getPbd() {
            return pbd;
        }

        public int getPba() {
            return pba;
        }

        public int[] getOk() {
            return ok;
        }

        public String getPlatform() {
            return platform;
        }
    }
}
