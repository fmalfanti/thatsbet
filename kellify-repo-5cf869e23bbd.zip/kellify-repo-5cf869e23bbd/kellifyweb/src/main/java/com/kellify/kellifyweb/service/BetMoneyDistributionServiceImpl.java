package com.kellify.kellifyweb.service;

import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import com.kellify.kellifyweb.model.BetMoneyDistribution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
@Service("betMoneyDistributionService")
public class BetMoneyDistributionServiceImpl implements BetMoneyDistributionService {
    private static final Logger logger = Logger.getLogger(BetMoneyDistributionServiceImpl.class);

    @Value("${moneydistribution.risky}")
    private double moneydistributionRisky;

    @Value("${moneydistribution.moneytobet.perc}")
    private double moneyToBetPerc;


    @Override
    public List<BetMoneyDistribution> buildDistribution(final List<EventBookmakerFractions> eventBookmakerFractionsList, final double amount) {
        List<BetMoneyDistribution> betMoneyDistributionList = new ArrayList<>();
        if(eventBookmakerFractionsList == null || eventBookmakerFractionsList.size() == 0 || amount == 0.0) {
            return betMoneyDistributionList;
        }
        double moneyToBet = moneyToBet(eventBookmakerFractionsList, amount);
        if(logger.isDebugEnabled()) {
            logger.debug("buildDistribution - eventBookmakerFractionsList.size:" + eventBookmakerFractionsList.size() + ", amount:" + amount + ", moneyToBet:" + moneyToBet + ", moneydistributionRisky:" + moneydistributionRisky);
        }

        BetMoneyDistribution.BetMoneyDistributionBuilder betMoneyDistributionBuilder;
        MoneyAll moneyAll;
        int[] okMask;
        for(EventBookmakerFractions eventBookmakerFractions : eventBookmakerFractionsList) {
            moneyAll = initMoneyAll(eventBookmakerFractions, moneyToBet, moneydistributionRisky);
            if(!moneyAll.isValid()) {
                continue;
            }
            okMask = new int[3];
            okMask[0] = okMask[1] = okMask[2] = 1;
            betMoneyDistributionBuilder = new BetMoneyDistribution.BetMoneyDistributionBuilder();
            betMoneyDistributionBuilder
                    .ProviderId(eventBookmakerFractions.getProviderId())
                    .HomeTeam(eventBookmakerFractions.getHomeTeam())
                    .AwayTeam(eventBookmakerFractions.getAwayTeam())
                    .Platform(eventBookmakerFractions.getPlatform())
                    .Location(eventBookmakerFractions.getLocation())
                    .Campionato(eventBookmakerFractions.getCampionato())
                    .Bookmaker(eventBookmakerFractions.getBookmaker())
                    .StartTime(eventBookmakerFractions.getStartTime())
                    .Ph(eventBookmakerFractions.getPh())
                    .Pd(eventBookmakerFractions.getPd())
                    .Pa(eventBookmakerFractions.getPa())
                    .Pbh(eventBookmakerFractions.getPbh())
                    .Pbd(eventBookmakerFractions.getPbd())
                    .Pba(eventBookmakerFractions.getPba())
                    .MoneyAway(moneyAll.moneyAway)
                    .MoneyDraw(moneyAll.moneyDraw)
                    .MoneyHome(moneyAll.moneyHome);
            if((eventBookmakerFractions.getPh()>50)||(eventBookmakerFractions.getPd()>50)||(eventBookmakerFractions.getPa()>50)) {
                okMask[0] = okMask[1] = okMask[2] = 0;
            }
            if(eventBookmakerFractions.getPd() == -1000) {
                okMask[1] = -1;
            }
            betMoneyDistributionBuilder.Ok(okMask);

            betMoneyDistributionList.add(betMoneyDistributionBuilder.Build());
        }
        return betMoneyDistributionList;
    }

    private double moneyToBet(final List<EventBookmakerFractions> eventFractions, final double credit) {
        double moneyToBet = credit * moneyToBetPerc;
        double kellyFractionSum = 0.0;
        for(EventBookmakerFractions eventFraction : eventFractions) {
            if(eventFraction.getFa() > 0) {
                kellyFractionSum += eventFraction.getFa();
            }
            if(eventFraction.getFd() > 0) {
                kellyFractionSum += eventFraction.getFd();
            }
            if(eventFraction.getFh() > 0) {
                kellyFractionSum += eventFraction.getFh();
            }
        }


        return moneyToBet;

//        if(kellyFractionSum > 1.0) {
//            return moneyToBet - (moneyToBet * (kellyFractionSum - 1.0));
//        } else {
//            return moneyToBet;
//        }
    }

    private MoneyAll initMoneyAll(EventBookmakerFractions eventFootballFraction, double moneyToBet, double riskyPerc) {
        int moneyAway = 0;
        int moneyHome = 0;
        int moneyDraw = 0;
        if(eventFootballFraction.getFa() > 0) {
            moneyAway = ((int) ((moneyToBet * eventFootballFraction.getFa()) / 2) + 1) * 2;
            if(eventFootballFraction.getPa()<50) {
                moneyAway *= riskyPerc;
            }
        }
        if(eventFootballFraction.getFh() > 0) {
            moneyHome = ((int)((moneyToBet * eventFootballFraction.getFh())/2)+1)*2;
            if(eventFootballFraction.getPh()<50) {
                moneyHome *= riskyPerc;
            }
        }
        if(eventFootballFraction.getFd() > 0) {
            moneyDraw = ((int)((moneyToBet * eventFootballFraction.getFd())/2)+1)*2;
            if(eventFootballFraction.getPd()<50) {
                moneyDraw *= riskyPerc;
            }
        }
        if(eventFootballFraction.getFd() == -1000) {
            moneyDraw = -1000;
        }
        return new MoneyAll(moneyAway, moneyDraw, moneyHome);
    }

    private class MoneyAll {
        private final int moneyAway;
        private final int moneyDraw;
        private final int moneyHome;

        MoneyAll(int moneyAway, int moneyDraw, int moneyHome) {
            this.moneyAway = moneyAway;
            this.moneyDraw = moneyDraw;
            this.moneyHome = moneyHome;
        }

        boolean isValid() {
            return moneyAway > 0 || moneyDraw > 0 || moneyHome > 0;
        }
    }
}
