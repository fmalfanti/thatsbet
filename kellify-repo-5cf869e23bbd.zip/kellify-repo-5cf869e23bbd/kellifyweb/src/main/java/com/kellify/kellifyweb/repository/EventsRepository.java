package com.kellify.kellifyweb.repository;

import com.kellify.kellifyweb.repository.dto.BookmakerMatches;
import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
@Repository
public class EventsRepository {
    private static final Logger logger = Logger.getLogger(EventsRepository.class);

    @Autowired
    @Qualifier("jdbcTemplate")
    private JdbcTemplate jdbcTemplate;
    @Autowired
    @Qualifier("jdbcTemplateUser")
    private JdbcTemplate jdbcTemplateUser;

//    private static final String MATCH_BOOKMAKERS = "select bookmaker_id,sum(num_match) as num_match,descr from (" +
//            "select a.bookmaker_id, a.num_match, b.descr from (select bookmaker_id, count(*) as num_match from football_fraction where fa>? or fd>? or fh>? group by bookmaker_id) " +
//            "as a left join bookmakers as b on a.bookmaker_id = b.id " +
//            "union all " +
//            "select a.bookmaker_id, a.num_match, b.descr from (select bookmaker_id, count(*) as num_match from tennis_fraction where fa>? or fh>? group by bookmaker_id) " +
//            "as a left join bookmakers as b on a.bookmaker_id = b.id) as tb " +
//            "group by bookmaker_id,descr";
    private static final String SELECT_BOOKMAKER = "select bookmaker_id,label from bookmaker_platform";
    private static final String SELECT_PLATFORM = "select id,descr from platforms";
    private static final String MATCH_BOOKMAKERS = "select bookmaker_id,sum(num_match) as num_match from ("+
            "select bookmaker_id, num_match from (select bookmaker_id, count(*) as num_match from football_fraction where match_date>=? and (fa>? or fd>? or fh>?) group by bookmaker_id) as a " +
            "union all "+
            "select bookmaker_id, num_match from (select bookmaker_id, count(*) as num_match from tennis_fraction where match_date>=? and ( fa>? or fh>?) group by bookmaker_id) as a " +
            "union all " +
            "select bookmaker_id, num_match from (select bookmaker_id, count(*) as num_match from basket_fraction where match_date>=? and ( fa>? or fh>?) group by bookmaker_id) as a" +
            ") as tb "+
            "group by bookmaker_id";

//    private static final String BOOKMAKER_FRACTIONS = "select a.referrer_id,a.home_team,a.away_team,d.descr as platform, a.country,c.eventNameBetbrain as championship,a.match_date,b.descr as bookmaker,a.fa,a.fh,a.fd,a.ph,a.pd,a.pa,a.pbh,a.pbd,a.pba,a.delta from football_fraction a left join bookmakers b ON a.bookmaker_id = b.id left join football_championship_decode c on a.championship = c.Campionato left join platforms d on a.platform_id=d.id where a.bookmaker_id=?  and (a.fa>? or a.fd>? or a.fh>?) " +
//            "union all " +
//            "select a.referrer_id,a.home_team,a.away_team,d.descr as platform,a.country,a.championship,a.match_date,b.descr as bookmaker,a.fa,a.fh,-1000,a.ph,-1000,a.pa,a.pbh,-1000,a.pba,a.delta from tennis_fraction a left join bookmakers b ON a.bookmaker_id = b.id left join platforms d on a.platform_id=d.id where a.bookmaker_id=? and (a.fa>? or a.fh>?) order by delta desc";
    private static final String BOOKMAKER_FRACTIONS = "select referrer_id,home_team,away_team,platform_id,bookmaker_id,country,championship,match_date,fa,fh,fd,ph,pd,pa,pbh,pbd,pba,delta from football_fraction where bookmaker_id=? and match_date>=? and (fa>? or fd>? or fh>?) " +
        "union all " +
        "select referrer_id,home_team,away_team,platform_id,bookmaker_id,country,championship,match_date,fa,fh,-1000,ph,-1000,pa,pbh,-1000,pba,delta from tennis_fraction where bookmaker_id=? and match_date>=? and (fa>? or fh>?) " +
        "union all " +
        "select referrer_id,home_team,away_team,platform_id,bookmaker_id,country,championship,match_date,fa,fh,-1000,ph,-1000,pa,pbh,-1000,pba,delta from basket_fraction where bookmaker_id=? and match_date>=? and (fa>? or fh>?) " +
        "order by delta desc";
    private static final String BOOKMAKER_FRACTIONS_WITH_LIMIT = BOOKMAKER_FRACTIONS + " limit ?";
    //private static final String FOOTBALL_FRACTIONS_TABLE = "select a.referrer_id,a.home_team,a.away_team,a.country,a.championship,a.match_date,b.descr,a.fa,a.fh,a.fd,a.ph,a.pd,a.pa,a.pbh,a.pbd,a.pba,a.delta from football_fraction a left join bookmakers b ON a.bookmaker_id = b.id order by a.referrer_id,a.delta,a.bookmaker_id";
    private static final String FOOTBALL_FRACTIONS_TABLE = "select referrer_id,home_team,away_team,platform_id,bookmaker_id,country,championship,match_date,fa,fh,fd,ph,pd,pa,pbh,pbd,pba,delta from football_fraction order by referrer_id,delta,bookmaker_id";
    //private static final String TENNIS_FRACTIONS_TABLE = "select a.referrer_id,a.home_team,a.away_team,a.country,a.championship,a.match_date,b.descr,a.fa,a.fh,a.ph,a.pa,a.pbh,a.pba,a.delta from tennis_fraction a left join bookmakers b ON a.bookmaker_id = b.id order by a.referrer_id,a.delta,a.bookmaker_id";
    private static final String TENNIS_FRACTIONS_TABLE = "select referrer_id,home_team,away_team,platform_id,bookmaker_id,country,championship,match_date,fa,fh,ph,pa,pbh,pba,delta from tennis_fraction order by referrer_id,delta,bookmaker_id";
    private static final String BASKET_FRACTIONS_TABLE = "select referrer_id,home_team,away_team,platform_id,bookmaker_id,country,championship,match_date,fa,fh,ph,pa,pbh,pba,delta from basket_fraction order by referrer_id,delta,bookmaker_id";
    // tag
    private static final String FOOTBALL_TAG_CHAMPIONSHIP = "select championship from web_football_tag_championship where tag = ?";
    private static final String FOOTBALL_BOOKMAKER_CHAMPIONSHIP_PREFIX = "select a.bookmaker_id,a.num_match,b.descr from (select bookmaker_id, count(*) as num_match from football_fraction where championship in (";
    private static final String FOOTBALL_BOOKMAKER_CHAMPIONSHIP_SUFFIX = ") group by bookmaker_id) as a left join bookmakers as b on a.bookmaker_id=b.id";
    private static final String FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_WITH_LIMIT_PREFIX = "select a.referrer_id,a.home_team,a.away_team,a.country,a.championship,a.match_date,b.descr,a.fa,a.fh,a.fd,a.ph,a.pd,a.pa,a.pbh,a.pbd,a.pba,a.delta from football_fraction a left join bookmakers b ON a.bookmaker_id = b.id where a.bookmaker_id=? and a.championship in (";
    private static final String FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_WITH_LIMIT_SUFFIX = ") order by a.delta desc limit ?";
    private static final String FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_PREFIX = "select a.referrer_id,a.home_team,a.away_team,a.country,a.championship,a.match_date,b.descr,a.fa,a.fh,a.fd,a.ph,a.pd,a.pa,a.pbh,a.pbd,a.pba,a.delta from football_fraction a left join bookmakers b ON a.bookmaker_id = b.id where a.bookmaker_id=? and a.championship in (";
    private static final String FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_SUFFIX = ") order by a.delta desc";

    public Map<Integer, String> getBookmakerMap() {
        Map<Integer, String> bMap = jdbcTemplate.query(SELECT_BOOKMAKER, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> bookmakerMap = new HashMap<>();
                while(rs.next()) {
                    bookmakerMap.putIfAbsent(rs.getInt("bookmaker_id"), rs.getString("label"));
                }
                return bookmakerMap;
            }
        });
        return bMap;
    }

    public Map<Integer, String> getPlatformMap() {
        Map<Integer, String> platformMap = jdbcTemplate.query(SELECT_PLATFORM, new ResultSetExtractor<Map<Integer, String>>() {
            @Override
            public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, String> platformMap = new HashMap<>();
                while(rs.next()) {
                    platformMap.putIfAbsent(rs.getInt("id"), rs.getString("descr"));
                }
                return platformMap;
            }
        });
        return platformMap;
    }

    public List<BookmakerMatches> getMatchesForBookmakerList(double kellyThreshold) {
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        if(logger.isDebugEnabled()) {
            logger.debug("bookmakerMap:" + bookmakerMap);
        }
        LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
        return jdbcTemplateUser.query(MATCH_BOOKMAKERS, new Object[] { now, kellyThreshold, kellyThreshold, kellyThreshold, now, kellyThreshold, kellyThreshold, now, kellyThreshold, kellyThreshold }, new BookmakerMatchesMapper(bookmakerMap));
    }

    public List<EventBookmakerFractions> getEventBookmakerFractions(int bookmaker, int limit, double kellyThreshold) {
        if(limit < 0) {
            return null;
        }
        if(logger.isDebugEnabled()) {
            logger.debug("bookmaker:" + bookmaker);
        }
        Map<Integer, String> platformMap = getPlatformMap();
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
        if(limit == 0) {
            return jdbcTemplateUser.query(BOOKMAKER_FRACTIONS, new Object[] { bookmaker, now, kellyThreshold, kellyThreshold, kellyThreshold, bookmaker, now, kellyThreshold, kellyThreshold, bookmaker, now, kellyThreshold, kellyThreshold }, new EventBookmakerFractionsMapper(platformMap, bookmakerMap));
        }
        return jdbcTemplateUser.query(BOOKMAKER_FRACTIONS_WITH_LIMIT, new Object[] { bookmaker, now, kellyThreshold, kellyThreshold, kellyThreshold, bookmaker, now, kellyThreshold, kellyThreshold, bookmaker, now, kellyThreshold, kellyThreshold, limit }, new EventBookmakerFractionsMapper(platformMap, bookmakerMap));
    }

    public List<String> getCampionatiFromTag(String tag) {
        return jdbcTemplate.queryForList(FOOTBALL_TAG_CHAMPIONSHIP, new Object[] {tag}, String.class);
    }

    public List<BookmakerMatches> getMatchesForBookmakerList(List<String> campionati) {
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        StringBuilder query = new StringBuilder();
        query.append(FOOTBALL_BOOKMAKER_CHAMPIONSHIP_PREFIX);
        for (String c: campionati) {
            query.append("?,");
        }
        query.delete(query.length()-1, query.length());
        query.append(FOOTBALL_BOOKMAKER_CHAMPIONSHIP_SUFFIX);
        return jdbcTemplate.query(query.toString(), campionati.toArray(), new BookmakerMatchesMapper(bookmakerMap));
    }

    public List<EventBookmakerFractions> getEventBookmakerFractions(int bookmaker, List<String> campionati, int limit, double kellyThreshold) {
        if(campionati == null || campionati.isEmpty()) {
            return getEventBookmakerFractions(bookmaker, limit, kellyThreshold);
        }
        if(limit < 0) {
            return null;
        }
        Map<Integer, String> platformMap = getPlatformMap();
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        StringBuilder query = new StringBuilder();
        List<Object> params = new ArrayList<>();
        params.add(bookmaker);
        params.addAll(campionati);
        if(limit == 0) {
            query.append(FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_PREFIX);
            for (String c: campionati) {
                query.append("?,");
            }
            query.delete(query.length()-1, query.length());
            query.append(FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_SUFFIX);
            return jdbcTemplate.query(query.toString(), params.toArray(), new EventBookmakerFractionsMapper(platformMap, bookmakerMap));
        }
        query.append(FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_WITH_LIMIT_PREFIX);
        for (String c: campionati) {
            query.append("?,");
        }
        query.delete(query.length()-1, query.length());
        query.append(FOOTBALL_BOOKMAKER_CHAMPIONSHIP_FRACTIONS_WITH_LIMIT_SUFFIX);
        params.add(limit);
        return jdbcTemplate.query(query.toString(), params.toArray(), new EventBookmakerFractionsMapper(platformMap, bookmakerMap));
    }

    public List<EventBookmakerFractions> getFootballMatchesForTableList() {
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        return jdbcTemplateUser.query(FOOTBALL_FRACTIONS_TABLE, new FootballEventBookmakerFractionsTableMapper(bookmakerMap));
    }

    public List<EventBookmakerFractions> getTennisMatchesForTableList() {
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        return jdbcTemplateUser.query(TENNIS_FRACTIONS_TABLE, new TennisEventBookmakerFractionsTableMapper(bookmakerMap));
    }

    public List<EventBookmakerFractions> getBasketMatchesForTableList() {
        Map<Integer, String> bookmakerMap = getBookmakerMap();
        return jdbcTemplateUser.query(BASKET_FRACTIONS_TABLE, new TennisEventBookmakerFractionsTableMapper(bookmakerMap));
    }

    private class BookmakerMatchesMapper implements RowMapper<BookmakerMatches> {
        private final Map<Integer, String> bookmakerMap;

        private BookmakerMatchesMapper(Map<Integer, String> bookmakerMap) {
            this.bookmakerMap = bookmakerMap;
        }

        @Override
        public BookmakerMatches mapRow(ResultSet rs, int rowNum) throws SQLException {
            if(logger.isDebugEnabled()) {
                logger.debug("bookmakerMap:" + bookmakerMap);
            }
            int bookmakerId = rs.getInt("bookmaker_id");
            logger.debug("bookmakerId:" + bookmakerId);
            return new BookmakerMatches(bookmakerId, bookmakerMap.get(bookmakerId), rs.getInt("num_match"));
        }
    }

    private class EventBookmakerFractionsMapper implements  RowMapper<EventBookmakerFractions> {
        private final Map<Integer, String> platformMap;
        private final Map<Integer, String> bookmakerMap;

        private EventBookmakerFractionsMapper(Map<Integer, String> platformMap, Map<Integer, String> bookmakerMap) {
            this.platformMap = platformMap;
            this.bookmakerMap = bookmakerMap;
        }

        @Override
        public EventBookmakerFractions mapRow(ResultSet rs, int rowNum) throws SQLException {
            int platformId = rs.getInt("platform_id");
            int bookmakerId = rs.getInt("bookmaker_id");
            EventBookmakerFractions eventBookmakerFractions = new EventBookmakerFractions();
            eventBookmakerFractions.setEventId(rs.getString("referrer_id"));
            eventBookmakerFractions.setHomeTeam(rs.getString("home_team"));
            eventBookmakerFractions.setAwayTeam(rs.getString("away_team"));
            eventBookmakerFractions.setPlatform(platformMap.get(platformId));
            eventBookmakerFractions.setLocation(rs.getString("country"));
            eventBookmakerFractions.setCampionato(rs.getString("championship"));
            eventBookmakerFractions.setStartTime(rs.getTimestamp("match_date"));
            eventBookmakerFractions.setBookmaker(bookmakerMap.get(bookmakerId));
            eventBookmakerFractions.setFh(rs.getDouble("fh"));
            eventBookmakerFractions.setFd(rs.getDouble("fd"));
            eventBookmakerFractions.setFa(rs.getDouble("fa"));
            eventBookmakerFractions.setPh(rs.getInt("ph"));
            eventBookmakerFractions.setPd(rs.getInt("pd"));
            eventBookmakerFractions.setPa(rs.getInt("pa"));
            eventBookmakerFractions.setPbh(rs.getInt("pbh"));
            eventBookmakerFractions.setPbd(rs.getInt("pbd"));
            eventBookmakerFractions.setPba(rs.getInt("pba"));
            eventBookmakerFractions.setDelta(rs.getDouble("delta"));
            return eventBookmakerFractions;
        }
    }

    private class FootballEventBookmakerFractionsTableMapper implements  RowMapper<EventBookmakerFractions> {
        private final Map<Integer, String> bookmakerMap;

        private FootballEventBookmakerFractionsTableMapper(Map<Integer, String> bookmakerMap) {
            this.bookmakerMap = bookmakerMap;
        }

        @Override
        public EventBookmakerFractions mapRow(ResultSet rs, int rowNum) throws SQLException {
            int bookmakerId = rs.getInt("bookmaker_id");
            EventBookmakerFractions eventBookmakerFractions = new EventBookmakerFractions();
            eventBookmakerFractions.setEventId(rs.getString("referrer_id"));
            eventBookmakerFractions.setHomeTeam(rs.getString("home_team"));
            eventBookmakerFractions.setAwayTeam(rs.getString("away_team"));
            eventBookmakerFractions.setLocation(rs.getString("country"));
            eventBookmakerFractions.setCampionato(rs.getString("championship"));
            eventBookmakerFractions.setStartTime(rs.getTimestamp("match_date"));
            eventBookmakerFractions.setBookmaker(bookmakerMap.get(bookmakerId));
            eventBookmakerFractions.setFh(rs.getDouble("fh"));
            eventBookmakerFractions.setFd(rs.getDouble("fd"));
            eventBookmakerFractions.setFa(rs.getDouble("fa"));
            eventBookmakerFractions.setPh(rs.getInt("ph"));
            eventBookmakerFractions.setPd(rs.getInt("pd"));
            eventBookmakerFractions.setPa(rs.getInt("pa"));
            eventBookmakerFractions.setPbh(rs.getInt("pbh"));
            eventBookmakerFractions.setPbd(rs.getInt("pbd"));
            eventBookmakerFractions.setPba(rs.getInt("pba"));
            eventBookmakerFractions.setDelta(rs.getDouble("delta"));
            return eventBookmakerFractions;
        }
    }

    private class TennisEventBookmakerFractionsTableMapper implements  RowMapper<EventBookmakerFractions> {
        private final Map<Integer, String> bookmakerMap;

        private TennisEventBookmakerFractionsTableMapper(Map<Integer, String> bookmakerMap) {
            this.bookmakerMap = bookmakerMap;
        }

        @Override
        public EventBookmakerFractions mapRow(ResultSet rs, int rowNum) throws SQLException {
            int bookmakerId = rs.getInt("bookmaker_id");
            EventBookmakerFractions eventBookmakerFractions = new EventBookmakerFractions();
            eventBookmakerFractions.setEventId(rs.getString("referrer_id"));
            eventBookmakerFractions.setHomeTeam(rs.getString("home_team"));
            eventBookmakerFractions.setAwayTeam(rs.getString("away_team"));
            eventBookmakerFractions.setLocation(rs.getString("country"));
            eventBookmakerFractions.setCampionato(rs.getString("championship"));
            eventBookmakerFractions.setStartTime(rs.getTimestamp("match_date"));
            eventBookmakerFractions.setBookmaker(bookmakerMap.get(bookmakerId));
            eventBookmakerFractions.setFh(rs.getDouble("fh"));
            eventBookmakerFractions.setFa(rs.getDouble("fa"));
            eventBookmakerFractions.setPh(rs.getInt("ph"));
            eventBookmakerFractions.setPa(rs.getInt("pa"));
            eventBookmakerFractions.setPbh(rs.getInt("pbh"));
            eventBookmakerFractions.setPba(rs.getInt("pba"));
            eventBookmakerFractions.setDelta(rs.getDouble("delta"));
            return eventBookmakerFractions;
        }
    }
}
