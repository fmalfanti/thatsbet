package com.kellify.kellifyweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KellyApplication {

	public static void main(String[] args) {
				SpringApplication.run(KellyApplication.class, args);
	}
}
