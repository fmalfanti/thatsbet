package com.kellify.kellifyweb.getOdds;



import com.kellify.kellifyweb.util.DoHttpUrlConnection;


/**
 * Created by fabrizio on 15/05/2017.
 */

public class GetOddsFromBetbrainImpl implements GetOddsFromBetbrain{
@Override
    public String getHttpOddsFromBetbrain() {
        try {
            String myUrl = "http://www.intelligrate.it/";
            // myUrl = URLEncoder.encode(myUrl, "UTF-8");
            String results = DoHttpUrlConnection.doHttpUrlConnection(myUrl);
            //System.out.println(results);
            return results;
        } catch (Exception e) {
            return "Errore";
        }
    }



}
