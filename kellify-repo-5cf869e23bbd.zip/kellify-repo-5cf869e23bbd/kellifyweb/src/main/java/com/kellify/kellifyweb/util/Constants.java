package com.kellify.kellifyweb.util;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public class Constants {
    private Constants() {}

    public static final String USER_REQUEST = "userName";
    public static final String BOOKMAKER_MATCHES_LIST = "bookmakerMatchesList";
    public static final String BOOKMAKER = "bookmaker";
    public static final String BOOKMAKER_ID = "bookmakerId";
    public static final String NUM_MATCHES = "numMatches";
    public static final String AMOUNT = "amount";
    public static final String TAG = "tagVal";
    public static final String BET_MONEY_DISTRIBUTION_LIST = "betMoneyDistributionList";
    public static final String MATCHES_FOR_TABLE_LIST = "matchesForTableList";
}
