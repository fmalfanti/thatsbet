package com.kellify.kellifyweb.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.catalina.connector.Connector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@ComponentScan
@EnableTransactionManagement
@PropertySource(value = {"application.properties"})
public class AppConfig
{
    @Autowired
    private Environment env;

    @Value("${init-dbload:false}")
    private String initDatabase;

    @Value("${ds.data-source-class-name}")
    private String dsClassName;
    @Value("${ds.hostname}")
    private String dbHostName;
    @Value("${ds.portnumber}")
    private String dbPortNumber;
    @Value("${ds.database}")
    private String dbDatabase;
    @Value("${ds.username}")
    private String dbUsername;
    @Value("${ds.password}")
    private String dbPasswd;

    @Value("${ds.user.hostname}")
    private String dbUserHostName;
    @Value("${ds.user.portnumber}")
    private String dbUserPortNumber;
    @Value("${ds.user.database}")
    private String dbUserDatabase;
    @Value("${ds.user.username}")
    private String dbUserUsername;
    @Value("${ds.user.password}")
    private String dbUserPasswd;

    @Value("${ds.maximum-pool-size}")
    private int dsMaxPoolSize;
    @Value("${ds.connection-timeout}")
    private long dsConnectionTimeout;
    @Value("${ds.connection-test-query}")
    private String dsTestQuery;
    @Value("${ds.minimum-idle}")
    private int dsMinIdle;
    @Value("${tomcat.ajp.port}")
    private int ajpPort;
    @Value("${tomcat.ajp.remoteauthentication}")
    private String remoteAuthentication;
    @Value("${tomcat.ajp.enabled}")
    private boolean tomcatAjpEnabled;

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer()
    {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean(name="jdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("myDataSource") DataSource myDataSource)
    {
        return new JdbcTemplate(myDataSource);
    }
    @Bean(name="jdbcTemplateUser")
    public JdbcTemplate jdbcTemplateUser(@Qualifier("userDataSource") DataSource userDataSource)
    {
        return new JdbcTemplate(userDataSource);
    }

//    @Bean
//    public PlatformTransactionManager transactionManager(@Qualifier("myDataSource") DataSource myDataSource)
//    {
//        return new DataSourceTransactionManager(myDataSource);
//    }
    @Bean(name="myDataSource")
    @Primary
    public DataSource myDataSource() {
        HikariConfig config = new HikariConfig();
        config.setDataSourceClassName(dsClassName);
        config.addDataSourceProperty("serverName", dbHostName);
        config.addDataSourceProperty("portNumber", dbPortNumber);
        config.addDataSourceProperty("databaseName", dbDatabase);
        config.setUsername(dbUsername);
        config.setPassword(dbPasswd);

        config.setConnectionTimeout(dsConnectionTimeout);
        config.setMaximumPoolSize(dsMaxPoolSize);
        config.setMinimumIdle(dsMinIdle);
        config.setIdleTimeout(2 * 60 * 1000);
        config.setConnectionTestQuery(dsTestQuery);
        HikariDataSource ds = new HikariDataSource(config);
        return ds;
    }
    @Bean(name="userDataSource")
    public DataSource userDataSource() {
        HikariConfig config = new HikariConfig();
        config.setDataSourceClassName(dsClassName);
        config.addDataSourceProperty("serverName", dbUserHostName);
        config.addDataSourceProperty("portNumber", dbUserPortNumber);
        config.addDataSourceProperty("databaseName", dbUserDatabase);
        config.setUsername(dbUserUsername);
        config.setPassword(dbUserPasswd);

        config.setConnectionTimeout(dsConnectionTimeout);
        config.setMaximumPoolSize(dsMaxPoolSize);
        config.setMinimumIdle(dsMinIdle);
        config.setIdleTimeout(2 * 60 * 1000);
        config.setConnectionTestQuery(dsTestQuery);
        HikariDataSource ds = new HikariDataSource(config);
        return ds;
    }
    @Bean
    public EmbeddedServletContainerFactory servletContainer() {

        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();
        if (tomcatAjpEnabled)
        {
            Connector ajpConnector = new Connector("AJP/1.3");
            ajpConnector.setPort(ajpPort);
            ajpConnector.setSecure(false);
            ajpConnector.setAllowTrace(false);
            ajpConnector.setScheme("http");
            tomcat.addAdditionalTomcatConnectors(ajpConnector);
        }

        return tomcat;
    }
}