package com.kellify.kellifyweb.service;

import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import com.kellify.kellifyweb.model.BetMoneyDistribution;

import java.util.List;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public interface BetMoneyDistributionService {
    List<BetMoneyDistribution> buildDistribution(List<EventBookmakerFractions> eventBookmakerFractionsList, double amount);
}
