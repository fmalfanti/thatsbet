package com.kellify.kellifyweb.service;

import com.kellify.kellifyweb.repository.dto.BookmakerMatches;
import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import com.kellify.kellifyweb.repository.dto.EventWithBookmakerFractionsArray;

import java.util.List;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public interface EventsService {
    List<BookmakerMatches> getMatchesForBookmakerList(double kellyThreshold);
    List<EventBookmakerFractions> getEventBookmakerFractions(int bookmaker, int limit, double kellyThreshold);
    List<String> getCampionatiFromTag(String tag);
    List<BookmakerMatches> getMatchesForBookmakerList(List<String> campionati);
    List<EventBookmakerFractions> getEventBookmakerFractions(int bookmaker, List<String> campionati, int limit, double kellyThreshold);
    List<EventWithBookmakerFractionsArray> getFootballMatchesForTableList();
    List<EventWithBookmakerFractionsArray> getTennisMatchesForTableList();
    List<EventWithBookmakerFractionsArray> getBasketMatchesForTableList();
}
