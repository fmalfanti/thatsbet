package com.kellify.kellifyweb.util;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Date;

/**
 * Created by fabrizio on 17/05/2017.
 */
public class SportEvents {

    public static class FootballEvent {
        String homeTeam;
        String awayTeam;
        Date data;
        String campionato;
        double hMin;
        double hMax;
        double dMin;
        double dMax;
        double aMin;
        double aMax;

        public String toString() {
            return ToStringBuilder.reflectionToString(this);
        }

        public String getAwayTeam() {
            return awayTeam;
        }

        public void setAwayTeam(String awayTeam) {
            this.awayTeam = awayTeam;
        }

        public Date getData() {
            return data;
        }

        public void setData(Date data) {
            this.data = data;
        }

        public String getCampionato() {
            return campionato;
        }

        public void setCampionato(String campionato) {
            this.campionato = campionato;
        }

        public double gethMin() {
            return hMin;
        }

        public void sethMin(double hMin) {
            this.hMin = hMin;
        }

        public double gethMax() {
            return hMax;
        }

        public void sethMax(double hMax) {
            this.hMax = hMax;
        }

        public double getdMin() {
            return dMin;
        }

        public void setdMin(double dMin) {
            this.dMin = dMin;
        }

        public double getdMax() {
            return dMax;
        }

        public void setdMax(double dMax) {
            this.dMax = dMax;
        }

        public double getaMin() {
            return aMin;
        }

        public void setaMin(double aMin) {
            this.aMin = aMin;
        }

        public double getaMax() {
            return aMax;
        }

        public void setaMax(double aMax) {
            this.aMax = aMax;
        }

        public String getHomeTeam() {
            return homeTeam;
        }

        public void setHomeTeam(String homeTeam) {
            this.homeTeam = homeTeam;
        }
    }

    public class TennisEvent {
        String playerA;
        String playerB;
        Date data;
        double aMin;
        double aMax;
        double bMin;

        public String getPlayerA() {
            return playerA;
        }

        public void setPlayerA(String playerA) {
            this.playerA = playerA;
        }

        public String getPlayerB() {
            return playerB;
        }

        public void setPlayerB(String playerB) {
            this.playerB = playerB;
        }

        public Date getData() {
            return data;
        }

        public void setData(Date data) {
            this.data = data;
        }

        public double getaMin() {
            return aMin;
        }

        public void setaMin(double aMin) {
            this.aMin = aMin;
        }

        public double getaMax() {
            return aMax;
        }

        public void setaMax(double aMax) {
            this.aMax = aMax;
        }

        public double getbMin() {
            return bMin;
        }

        public void setbMin(double bMin) {
            this.bMin = bMin;
        }

        public double getbMax() {
            return bMax;
        }

        public void setbMax(double bMax) {
            this.bMax = bMax;
        }

        double bMax;
    }

}
