package com.kellify.kellifyweb.repository.dto;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public class BookmakerMatches {
    private final int bookmakerId;
    private final String bookmaker;
    private final int numMatch;

    public BookmakerMatches(int bookmakerId, String bookmaker, int numMatch) {
        this.bookmakerId = bookmakerId;
        this.bookmaker = bookmaker;
        this.numMatch = numMatch;
    }

    public String getBookmaker() {
        return bookmaker;
    }

    public int getNumMatch() {
        return numMatch;
    }

    public int getBookmakerId() {
        return bookmakerId;
    }

    @Override
    public String toString() {
        return "BookmakerMatches{" +
                "bookmakerId=" + bookmakerId +
                ", bookmaker='" + bookmaker + '\'' +
                ", numMatch=" + numMatch +
                '}';
    }
}
