package com.kellify.kellifyweb.repository.dto;

import java.util.Date;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public class EventBookmakerFractions {
    private String eventId;
    private long providerId;
    private String homeTeam;
    private String awayTeam;
    private String platform;
    private String location;
    private String campionato;
    private String bookmaker;
    private Date startTime;
    private int ph;
    private int pd;
    private int pa;
    private int pbh;
    private int pbd;
    private int pba;
    private double fa;
    private double fh;
    private double fd;
    private double delta;

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public long getProviderId() {
        return providerId;
    }

    public void setProviderId(long providerId) {
        this.providerId = providerId;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCampionato() {
        return campionato;
    }

    public void setCampionato(String campionato) {
        this.campionato = campionato;
    }

    public String getBookmaker() {
        return bookmaker;
    }

    public void setBookmaker(String bookmaker) {
        this.bookmaker = bookmaker;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public double getFa() {
        return fa;
    }

    public void setFa(double fa) {
        this.fa = fa;
    }

    public double getFh() {
        return fh;
    }

    public void setFh(double fh) {
        this.fh = fh;
    }

    public double getFd() {
        return fd;
    }

    public void setFd(double fd) {
        this.fd = fd;
    }

    public double getDelta() {
        return delta;
    }

    public void setDelta(double delta) {
        this.delta = delta;
    }

    public int getPh() {
        return ph;
    }

    public void setPh(int ph) {
        this.ph = ph;
    }

    public int getPd() {
        return pd;
    }

    public void setPd(int pd) {
        this.pd = pd;
    }

    public int getPa() {
        return pa;
    }

    public void setPa(int pa) {
        this.pa = pa;
    }

    public int getPbh() {
        return pbh;
    }

    public void setPbh(int pbh) {
        this.pbh = pbh;
    }

    public int getPbd() {
        return pbd;
    }

    public void setPbd(int pbd) {
        this.pbd = pbd;
    }

    public int getPba() {
        return pba;
    }

    public void setPba(int pba) {
        this.pba = pba;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    @Override
    public String toString() {
        return "EventBookmakerFractions{" +
                "eventId='" + eventId + '\'' +
                ", providerId=" + providerId +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", platform='" + platform + '\'' +
                ", location='" + location + '\'' +
                ", campionato='" + campionato + '\'' +
                ", bookmaker='" + bookmaker + '\'' +
                ", startTime=" + startTime +
                ", ph=" + ph +
                ", pd=" + pd +
                ", pa=" + pa +
                ", pbh=" + pbh +
                ", pbd=" + pbd +
                ", pba=" + pba +
                ", fa=" + fa +
                ", fh=" + fh +
                ", fd=" + fd +
                ", delta=" + delta +
                '}';
    }
}
