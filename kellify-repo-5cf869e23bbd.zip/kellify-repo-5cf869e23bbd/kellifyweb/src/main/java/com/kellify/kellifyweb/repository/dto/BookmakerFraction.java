package com.kellify.kellifyweb.repository.dto;

public class BookmakerFraction {
    private String bookmaker;
    private int pbh;
    private int pbd;
    private int pba;
    private double fa;
    private double fh;
    private double fd;
    private double delta;

    public String getBookmaker() {
        return bookmaker;
    }

    public void setBookmaker(String bookmaker) {
        this.bookmaker = bookmaker;
    }

    public int getPbh() {
        return pbh;
    }

    public void setPbh(int pbh) {
        this.pbh = pbh;
    }

    public int getPbd() {
        return pbd;
    }

    public void setPbd(int pbd) {
        this.pbd = pbd;
    }

    public int getPba() {
        return pba;
    }

    public void setPba(int pba) {
        this.pba = pba;
    }

    public double getFa() {
        return fa;
    }

    public void setFa(double fa) {
        this.fa = fa;
    }

    public double getFh() {
        return fh;
    }

    public void setFh(double fh) {
        this.fh = fh;
    }

    public double getFd() {
        return fd;
    }

    public void setFd(double fd) {
        this.fd = fd;
    }

    public double getDelta() {
        return delta;
    }

    public void setDelta(double delta) {
        this.delta = delta;
    }

    @Override
    public String toString() {
        return "BookmakerFraction{" +
                "bookmaker='" + bookmaker + '\'' +
                ", pbh=" + pbh +
                ", pbd=" + pbd +
                ", pba=" + pba +
                ", fa=" + fa +
                ", fh=" + fh +
                ", fd=" + fd +
                ", delta=" + delta +
                '}';
    }
}
