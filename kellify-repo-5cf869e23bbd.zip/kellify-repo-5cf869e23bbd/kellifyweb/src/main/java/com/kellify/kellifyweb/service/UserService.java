package com.kellify.kellifyweb.service;

import com.kellify.kellifyweb.model.User;

public interface UserService {
    public User findUserByUsername(String username);

}