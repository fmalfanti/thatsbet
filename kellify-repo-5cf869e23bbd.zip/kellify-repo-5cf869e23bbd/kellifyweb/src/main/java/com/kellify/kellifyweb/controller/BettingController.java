package com.kellify.kellifyweb.controller;

import com.kellify.kellifyweb.repository.dto.BookmakerMatches;
import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import com.kellify.kellifyweb.model.BetMoneyDistribution;
import com.kellify.kellifyweb.repository.dto.EventWithBookmakerFractionsArray;
import com.kellify.kellifyweb.service.BetMoneyDistributionService;
import com.kellify.kellifyweb.service.EventsService;
import com.kellify.kellifyweb.util.Constants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
@Controller
public class BettingController {
    private static final Logger logger = Logger.getLogger(BettingController.class);

    @Autowired
    private EventsService eventsService;
    @Autowired
    private BetMoneyDistributionService betMoneyDistributionService;

    @Value("${kelly.threshold}")
    private double kellyThreshold;

    @RequestMapping(value="/home", method = {RequestMethod.POST, RequestMethod.GET})
    public ModelAndView home(@RequestParam(value="bookmaker", required=false) Integer bookmakerId,
                             @RequestParam(value="numMatches", required=false) Integer numMatches,
                             @RequestParam(value="amount", required=false) Double amount) {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("home - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        double localKellyThreshold = 0.0;

        if(logger.isDebugEnabled()) {
            logger.debug("home - bookmaker:" + bookmakerId + ", numMatches:" + numMatches + ", amount:" + amount + ", kellyThreshold:" + localKellyThreshold);
        }

        List<BookmakerMatches> bookmakerMatchesList = eventsService.getMatchesForBookmakerList(localKellyThreshold);
        if(logger.isDebugEnabled()) {
            logger.debug("home - bookmakerMatchesList:" + bookmakerMatchesList);
        }

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.BOOKMAKER_MATCHES_LIST, bookmakerMatchesList);
        if(bookmakerId != null) {
            modelAndView.addObject(Constants.BOOKMAKER, bookmakerId);
        }
        if(numMatches != null) {
            modelAndView.addObject(Constants.NUM_MATCHES, numMatches);
        }
        if(amount != null) {
            modelAndView.addObject(Constants.AMOUNT, amount);
        }

        modelAndView.setViewName("home");
        return modelAndView;
    }

    @RequestMapping(value="/kellylimit", method = {RequestMethod.POST, RequestMethod.GET})
    public ModelAndView kellyLimit(@RequestParam(value="bookmaker", required=false) Integer bookmakerId,
                             @RequestParam(value="numMatches", required=false) Integer numMatches,
                             @RequestParam(value="amount", required=false) Double amount) {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("kellyLimit - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        if(logger.isDebugEnabled()) {
            logger.debug("kellyLimit - bookmaker:" + bookmakerId + ", numMatches:" + numMatches + ", amount:" + amount + ", kellyThreshold:" + kellyThreshold);
        }

        List<BookmakerMatches> bookmakerMatchesList = eventsService.getMatchesForBookmakerList(kellyThreshold);
        if(logger.isDebugEnabled()) {
            logger.debug("kellyLimit - bookmakerMatchesList:" + bookmakerMatchesList);
        }

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.BOOKMAKER_MATCHES_LIST, bookmakerMatchesList);
        if(bookmakerId != null) {
            modelAndView.addObject(Constants.BOOKMAKER, bookmakerId);
        }
        if(numMatches != null) {
            modelAndView.addObject(Constants.NUM_MATCHES, numMatches);
        }
        if(amount != null) {
            modelAndView.addObject(Constants.AMOUNT, amount);
        }

        modelAndView.setViewName("kellylimit");
        return modelAndView;
    }

    @RequestMapping(value="/footballbookmakerstable", method = {RequestMethod.GET})
    public ModelAndView footballBookmakersTable() {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("footballbookmakerstable - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        List<EventWithBookmakerFractionsArray> matchesForTable =  eventsService.getFootballMatchesForTableList();
        if(logger.isDebugEnabled()) {
            logger.debug("footballbookmakerstable - matchesForTable:" + matchesForTable);
        }

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.MATCHES_FOR_TABLE_LIST, matchesForTable);

        modelAndView.setViewName("footballbookmakerstable");
        return modelAndView;
    }

    @RequestMapping(value="/tennisbookmakerstable", method = {RequestMethod.GET})
    public ModelAndView tennisBookmakersTable() {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("tennisbookmakerstable - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        List<EventWithBookmakerFractionsArray> matchesForTable =  eventsService.getTennisMatchesForTableList();
        if(logger.isDebugEnabled()) {
            logger.debug("tennisbookmakerstable - matchesForTable:" + matchesForTable);
        }

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.MATCHES_FOR_TABLE_LIST, matchesForTable);

        modelAndView.setViewName("tennisbookmakerstable");
        return modelAndView;
    }

    @RequestMapping(value="/basketbookmakerstable", method = {RequestMethod.GET})
    public ModelAndView basketBookmakersTable() {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("basketbookmakerstable - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        List<EventWithBookmakerFractionsArray> matchesForTable =  eventsService.getBasketMatchesForTableList();
        if(logger.isDebugEnabled()) {
            logger.debug("basketbookmakerstable - matchesForTable:" + matchesForTable);
        }

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.MATCHES_FOR_TABLE_LIST, matchesForTable);

        modelAndView.setViewName("basketbookmakerstable");
        return modelAndView;
    }

    @RequestMapping(value="/tag/{tagval}", method = {RequestMethod.POST, RequestMethod.GET})
    public ModelAndView tag(@PathVariable(value="tagval") String tagval,
                            @RequestParam(value="bookmaker", required=false) Integer bookmakerId,
                            @RequestParam(value="numMatches", required=false) Integer numMatches,
                            @RequestParam(value="amount", required=false) Double amount) {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("tag - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }
        if(logger.isDebugEnabled()) {
            logger.debug("tag - tagval:" + tagval + ", bookmaker:" + bookmakerId + ", numMatches:" + numMatches + ", amount:" + amount);
        }

        List<String> campionati = eventsService.getCampionatiFromTag(tagval);
        if(logger.isDebugEnabled()) {
            logger.debug("tag - campionati:" + campionati);
        }
        if(campionati.size() == 0) {
            return home(bookmakerId, numMatches, amount);
        }

        List<BookmakerMatches> bookmakerMatchesList = eventsService.getMatchesForBookmakerList(campionati);
        if(logger.isDebugEnabled()) {
            logger.debug("tag - bookmakerMatchesList:" + bookmakerMatchesList);
        }

        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.TAG, tagval);
        modelAndView.addObject(Constants.BOOKMAKER_MATCHES_LIST, bookmakerMatchesList);
        if(bookmakerId != null) {
            modelAndView.addObject(Constants.BOOKMAKER, bookmakerId);
        }
        if(numMatches != null) {
            modelAndView.addObject(Constants.NUM_MATCHES, numMatches);
        }
        if(amount != null) {
            modelAndView.addObject(Constants.AMOUNT, amount);
        }

        modelAndView.setViewName("tag");
        return modelAndView;
    }

    @RequestMapping(value="/betdistribution", method = RequestMethod.POST)
    public ModelAndView betDistribution(@RequestParam(value="bookmaker", required=true) Integer bookmakerId,
                                        @RequestParam(value="numMatches", required=false) Integer numMatches,
                                        @RequestParam(value="amount", required=true) double amount) {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("betdistribution - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }

        double localKellyThreshold = 0.0;

        if(logger.isDebugEnabled()) {
            logger.debug("betdistribution - bookmaker:" + bookmakerId + ", numMatches:" + numMatches + ", amount:" + amount + ", kellyThreshold:" + localKellyThreshold);
        }
        int limitNumMatches = 0;
        if(numMatches != null) {
            limitNumMatches = numMatches.intValue();
        }
        if(logger.isDebugEnabled()) {
            logger.debug("betdistribution - limitNumMatches:" + limitNumMatches);
        }
        List<EventBookmakerFractions> eventBookmakerFractionsList = eventsService.getEventBookmakerFractions(bookmakerId, limitNumMatches, localKellyThreshold);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistribution - ------------ eventBookmakerFractionsList -------------");
            for(EventBookmakerFractions eventBookmakerFractions : eventBookmakerFractionsList) {
                logger.debug(eventBookmakerFractions);
            }
        }
        List<BetMoneyDistribution> betMoneyDistributionList = betMoneyDistributionService.buildDistribution(eventBookmakerFractionsList, amount);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistribution - ------------ betMoneyDistributionList -------------");
            for(BetMoneyDistribution betMoneyDistribution : betMoneyDistributionList) {
                logger.debug(betMoneyDistribution);
            }
        }
        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.BOOKMAKER, getBookamkerDescr(eventBookmakerFractionsList));
        modelAndView.addObject(Constants.BOOKMAKER_ID, bookmakerId);
        modelAndView.addObject(Constants.BET_MONEY_DISTRIBUTION_LIST, betMoneyDistributionList);
        modelAndView.addObject(Constants.NUM_MATCHES, numMatches);
        modelAndView.addObject(Constants.AMOUNT, amount);

        modelAndView.setViewName("betdistribution");
        return modelAndView;
    }

    @RequestMapping(value="/betdistributionkellylimit", method = RequestMethod.POST)
    public ModelAndView betDistributionKellyLimit(@RequestParam(value="bookmaker", required=true) Integer bookmakerId,
                                        @RequestParam(value="numMatches", required=false) Integer numMatches,
                                        @RequestParam(value="amount", required=true) double amount) {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributionkellylimit - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributionkellylimit - bookmaker:" + bookmakerId + ", numMatches:" + numMatches + ", amount:" + amount + ", kellyThreshold:" + kellyThreshold);
        }
        int limitNumMatches = 0;
        if(numMatches != null) {
            limitNumMatches = numMatches.intValue();
        }
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributionkellylimit - limitNumMatches:" + limitNumMatches);
        }
        List<EventBookmakerFractions> eventBookmakerFractionsList = eventsService.getEventBookmakerFractions(bookmakerId, limitNumMatches, kellyThreshold);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributionkellylimit - ------------ eventBookmakerFractionsList -------------");
            for(EventBookmakerFractions eventBookmakerFractions : eventBookmakerFractionsList) {
                logger.debug(eventBookmakerFractions);
            }
        }
        List<BetMoneyDistribution> betMoneyDistributionList = betMoneyDistributionService.buildDistribution(eventBookmakerFractionsList, amount);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributionkellylimit - ------------ betMoneyDistributionList -------------");
            for(BetMoneyDistribution betMoneyDistribution : betMoneyDistributionList) {
                logger.debug(betMoneyDistribution);
            }
        }
        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.BOOKMAKER, getBookamkerDescr(eventBookmakerFractionsList));
        modelAndView.addObject(Constants.BOOKMAKER_ID, bookmakerId);
        modelAndView.addObject(Constants.BET_MONEY_DISTRIBUTION_LIST, betMoneyDistributionList);
        modelAndView.addObject(Constants.NUM_MATCHES, numMatches);
        modelAndView.addObject(Constants.AMOUNT, amount);

        modelAndView.setViewName("betdistributionkellylimit");
        return modelAndView;
    }

    @RequestMapping(value="/betdistributiontag", method = RequestMethod.POST)
    public ModelAndView betDistributionTag(
            @RequestParam(value="tagVal", required=true) String tagval,
            @RequestParam(value="bookmaker", required=true) Integer bookmakerId,
            @RequestParam(value="numMatches", required=false) Integer numMatches,
            @RequestParam(value="amount", required=true) double amount) {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributiontag - user:" + auth.getName());
        }
        if(!auth.isAuthenticated()) {
            modelAndView.setViewName("unauth");
            return modelAndView;
        }
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributiontag - bookmaker:" + bookmakerId + ", numMatches:" + numMatches + ", amount:" + amount);
        }
        List<String> campionati = eventsService.getCampionatiFromTag(tagval);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributiontag - campionati:" + campionati);
        }
        if(campionati.size() == 0) {
            return home(bookmakerId, numMatches, amount);
        }
        int limitNumMatches = 0;
        if(numMatches != null) {
            limitNumMatches = numMatches.intValue();
        }
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributiontag - limitNumMatches:" + limitNumMatches);
        }
        List<EventBookmakerFractions> eventBookmakerFractionsList = eventsService.getEventBookmakerFractions(bookmakerId, campionati, limitNumMatches, kellyThreshold);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributiontag - ------------ eventBookmakerFractionsList -------------");
            for(EventBookmakerFractions eventBookmakerFractions : eventBookmakerFractionsList) {
                logger.debug(eventBookmakerFractions);
            }
        }
        List<BetMoneyDistribution> betMoneyDistributionList = betMoneyDistributionService.buildDistribution(eventBookmakerFractionsList, amount);
        if(logger.isDebugEnabled()) {
            logger.debug("betdistributiontag - ------------ betMoneyDistributionList -------------");
            for(BetMoneyDistribution betMoneyDistribution : betMoneyDistributionList) {
                logger.debug(betMoneyDistribution);
            }
        }
        modelAndView.addObject(Constants.USER_REQUEST, auth.getName());
        modelAndView.addObject(Constants.TAG, tagval);
        modelAndView.addObject(Constants.BOOKMAKER, getBookamkerDescr(eventBookmakerFractionsList));
        modelAndView.addObject(Constants.BOOKMAKER_ID, bookmakerId);
        modelAndView.addObject(Constants.BET_MONEY_DISTRIBUTION_LIST, betMoneyDistributionList);
        modelAndView.addObject(Constants.NUM_MATCHES, numMatches);
        modelAndView.addObject(Constants.AMOUNT, amount);

        modelAndView.setViewName("betdistributiontag");
        return modelAndView;
    }

    private String getBookamkerDescr(List<EventBookmakerFractions> eventBookmakerFractionsList) {
        if(eventBookmakerFractionsList.size() > 0) {
            return eventBookmakerFractionsList.get(0).getBookmaker();
        }
        return "";
    }
}
