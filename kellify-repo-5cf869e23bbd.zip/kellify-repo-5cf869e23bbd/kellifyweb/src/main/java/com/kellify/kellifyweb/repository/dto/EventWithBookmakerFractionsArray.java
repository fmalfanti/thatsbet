package com.kellify.kellifyweb.repository.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EventWithBookmakerFractionsArray {
    private String eventId;
    private String homeTeam;
    private String awayTeam;
    private String location;
    private String campionato;
    private Date startTime;
    private int ph;
    private int pd;
    private int pa;
    private List<BookmakerFraction> bookmakerFractions;

    public EventWithBookmakerFractionsArray() {
        this.bookmakerFractions = new ArrayList<>();
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public void setHomeTeam(String homeTeam) {
        this.homeTeam = homeTeam;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public void setAwayTeam(String awayTeam) {
        this.awayTeam = awayTeam;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCampionato() {
        return campionato;
    }

    public void setCampionato(String campionato) {
        this.campionato = campionato;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public int getPh() {
        return ph;
    }

    public void setPh(int ph) {
        this.ph = ph;
    }

    public int getPd() {
        return pd;
    }

    public void setPd(int pd) {
        this.pd = pd;
    }

    public int getPa() {
        return pa;
    }

    public void setPa(int pa) {
        this.pa = pa;
    }

    public List<BookmakerFraction> getBookmakerFractions() {
        return bookmakerFractions;
    }

    public void addBookmakerFraction(BookmakerFraction bookmakerFraction) {
        this.bookmakerFractions.add(bookmakerFraction);
    }

    @Override
    public String toString() {
        return "EventWithBookmakerFractionsArray{" +
                "eventId='" + eventId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", location='" + location + '\'' +
                ", campionato='" + campionato + '\'' +
                ", startTime=" + startTime +
                ", ph=" + ph +
                ", pd=" + pd +
                ", pa=" + pa +
                ", bookmakerFractions=" + bookmakerFractions +
                '}';
    }
}
