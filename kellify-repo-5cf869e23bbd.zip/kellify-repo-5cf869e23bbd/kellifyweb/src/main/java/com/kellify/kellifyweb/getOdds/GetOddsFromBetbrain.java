package com.kellify.kellifyweb.getOdds;

/**
 * Created by fabrizio on 16/05/2017.
 */
public interface GetOddsFromBetbrain {
    public String getHttpOddsFromBetbrain();
}
