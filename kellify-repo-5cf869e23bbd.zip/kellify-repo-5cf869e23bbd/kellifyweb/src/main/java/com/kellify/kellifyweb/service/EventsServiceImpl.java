package com.kellify.kellifyweb.service;

import com.kellify.kellifyweb.repository.EventsRepository;
import com.kellify.kellifyweb.repository.dto.BookmakerFraction;
import com.kellify.kellifyweb.repository.dto.BookmakerMatches;
import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import com.kellify.kellifyweb.repository.dto.EventWithBookmakerFractionsArray;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
@Service("eventsService")
public class EventsServiceImpl implements EventsService {
    private static final Logger logger = Logger.getLogger(EventsServiceImpl.class);

    @Autowired
    private EventsRepository eventsRepository;

    @Override
    public List<BookmakerMatches> getMatchesForBookmakerList(double kellyThreshold) {
        return eventsRepository.getMatchesForBookmakerList(kellyThreshold);
    }

    @Override
    public List<EventBookmakerFractions> getEventBookmakerFractions(int bookmaker, int limit, double kellyThreshold) {
        return eventsRepository.getEventBookmakerFractions(bookmaker, limit, kellyThreshold);
    }

    @Override
    public List<String> getCampionatiFromTag(String tag) {
        return eventsRepository.getCampionatiFromTag(tag);
    }

    @Override
    public List<BookmakerMatches> getMatchesForBookmakerList(List<String> campionati) {
        return eventsRepository.getMatchesForBookmakerList(campionati);
    }

    @Override
    public List<EventBookmakerFractions> getEventBookmakerFractions(int bookmaker, List<String> campionati, int limit, double kellyThreshold) {
        return eventsRepository.getEventBookmakerFractions(bookmaker, campionati, limit, kellyThreshold);
    }

    @Override
    public List<EventWithBookmakerFractionsArray> getFootballMatchesForTableList() {
        List<EventWithBookmakerFractionsArray> events = new ArrayList<>();

        List<EventBookmakerFractions> eventBookmakerFractions = eventsRepository.getFootballMatchesForTableList();
        EventWithBookmakerFractionsArray event = null;
        BookmakerFraction bookmakerFraction;
        String eventId = "-1";
        String currentEventId = "";
        for(EventBookmakerFractions eventBookmakerFraction : eventBookmakerFractions) {
            currentEventId = eventBookmakerFraction.getEventId();
            if(!currentEventId.equals(eventId)) {
                event = new EventWithBookmakerFractionsArray();
                event.setEventId(currentEventId);
                event.setHomeTeam(eventBookmakerFraction.getHomeTeam());
                event.setAwayTeam(eventBookmakerFraction.getAwayTeam());
                event.setLocation(eventBookmakerFraction.getLocation());
                event.setCampionato(eventBookmakerFraction.getCampionato());
                event.setStartTime(eventBookmakerFraction.getStartTime());
                event.setPh(eventBookmakerFraction.getPh());
                event.setPd(eventBookmakerFraction.getPd());
                event.setPa(eventBookmakerFraction.getPa());
                events.add(event);
                eventId = currentEventId;
            }
            bookmakerFraction = new BookmakerFraction();
            bookmakerFraction.setBookmaker(eventBookmakerFraction.getBookmaker());
            bookmakerFraction.setPbh(eventBookmakerFraction.getPbh());
            bookmakerFraction.setPbd(eventBookmakerFraction.getPbd());
            bookmakerFraction.setPba(eventBookmakerFraction.getPba());
            bookmakerFraction.setFh(round(eventBookmakerFraction.getFh(), 2));
            bookmakerFraction.setFd(round(eventBookmakerFraction.getFd(), 2));
            bookmakerFraction.setFa(round(eventBookmakerFraction.getFa(), 2));
            bookmakerFraction.setDelta(eventBookmakerFraction.getDelta());
            event.addBookmakerFraction(bookmakerFraction);
        }

        return events;
    }

    @Override
    public List<EventWithBookmakerFractionsArray> getTennisMatchesForTableList() {
        List<EventWithBookmakerFractionsArray> events = new ArrayList<>();

        List<EventBookmakerFractions> eventBookmakerFractions = eventsRepository.getTennisMatchesForTableList();
        EventWithBookmakerFractionsArray event = null;
        BookmakerFraction bookmakerFraction;
        String eventId = "-1";
        String currentEventId = "";
        for(EventBookmakerFractions eventBookmakerFraction : eventBookmakerFractions) {
            currentEventId = eventBookmakerFraction.getEventId();
            if(!currentEventId.equals(eventId)) {
                event = new EventWithBookmakerFractionsArray();
                event.setEventId(currentEventId);
                event.setHomeTeam(eventBookmakerFraction.getHomeTeam());
                event.setAwayTeam(eventBookmakerFraction.getAwayTeam());
                event.setLocation(eventBookmakerFraction.getLocation());
                event.setCampionato(eventBookmakerFraction.getCampionato());
                event.setStartTime(eventBookmakerFraction.getStartTime());
                event.setPh(eventBookmakerFraction.getPh());
                event.setPa(eventBookmakerFraction.getPa());
                events.add(event);
                eventId = currentEventId;
            }
            bookmakerFraction = new BookmakerFraction();
            bookmakerFraction.setBookmaker(eventBookmakerFraction.getBookmaker());
            bookmakerFraction.setPbh(eventBookmakerFraction.getPbh());
            bookmakerFraction.setPba(eventBookmakerFraction.getPba());
            bookmakerFraction.setFh(round(eventBookmakerFraction.getFh(), 2));
            bookmakerFraction.setFa(round(eventBookmakerFraction.getFa(), 2));
            bookmakerFraction.setDelta(eventBookmakerFraction.getDelta());
            event.addBookmakerFraction(bookmakerFraction);
        }

        return events;
    }

    @Override
    public List<EventWithBookmakerFractionsArray> getBasketMatchesForTableList() {
        List<EventWithBookmakerFractionsArray> events = new ArrayList<>();

        List<EventBookmakerFractions> eventBookmakerFractions = eventsRepository.getBasketMatchesForTableList();
        EventWithBookmakerFractionsArray event = null;
        BookmakerFraction bookmakerFraction;
        String eventId = "-1";
        String currentEventId = "";
        for(EventBookmakerFractions eventBookmakerFraction : eventBookmakerFractions) {
            currentEventId = eventBookmakerFraction.getEventId();
            if(!currentEventId.equals(eventId)) {
                event = new EventWithBookmakerFractionsArray();
                event.setEventId(currentEventId);
                event.setHomeTeam(eventBookmakerFraction.getHomeTeam());
                event.setAwayTeam(eventBookmakerFraction.getAwayTeam());
                event.setLocation(eventBookmakerFraction.getLocation());
                event.setCampionato(eventBookmakerFraction.getCampionato());
                event.setStartTime(eventBookmakerFraction.getStartTime());
                event.setPh(eventBookmakerFraction.getPh());
                event.setPa(eventBookmakerFraction.getPa());
                events.add(event);
                eventId = currentEventId;
            }
            bookmakerFraction = new BookmakerFraction();
            bookmakerFraction.setBookmaker(eventBookmakerFraction.getBookmaker());
            bookmakerFraction.setPbh(eventBookmakerFraction.getPbh());
            bookmakerFraction.setPba(eventBookmakerFraction.getPba());
            bookmakerFraction.setFh(round(eventBookmakerFraction.getFh(), 2));
            bookmakerFraction.setFa(round(eventBookmakerFraction.getFa(), 2));
            bookmakerFraction.setDelta(eventBookmakerFraction.getDelta());
            event.addBookmakerFraction(bookmakerFraction);
        }

        return events;
    }

    private static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(Double.toString(value));
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
