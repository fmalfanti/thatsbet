package com.kellify.kellifyweb;

import com.kellify.kellifyweb.model.BetMoneyDistribution;
import com.kellify.kellifyweb.repository.dto.EventBookmakerFractions;
import com.kellify.kellifyweb.service.BetMoneyDistributionService;
import com.kellify.kellifyweb.service.BetMoneyDistributionServiceImpl;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by INTELLIGRATE\andrea on 5/25/17.
 */
public class BetDistributionTest {
    private static DataSource ds;
    private static DataSource dsUser;

    private static DataSource createDataSource() {
        System.out.println("createDataSource");
        return DataSourceBuilder
                .create()
                .username("ubibetter")
                .password("R0t0l0n!")
                .url("jdbc:mysql://ubibetter.intelligrate.local:3306/bookmaker_betting")
                .driverClassName("com.mysql.jdbc.Driver")
                .build();
    }
    private static DataSource createDataSourceUser() {
        System.out.println("createDataSourceUser");
        return DataSourceBuilder
                .create()
                .username("ubibetter")
                .password("R0t0l0n!")
                .url("jdbc:mysql://ubibetter.intelligrate.local:3306/betting_testuser")
                .driverClassName("com.mysql.jdbc.Driver")
                .build();
    }


    @BeforeClass
    public static void initDbConnection() {
        ds = createDataSource();
        dsUser = createDataSourceUser();
    }

    private List<EventBookmakerFractions> getEventBookmakers(int bId) {
        List<EventBookmakerFractions> eventBookmakerFractionsList = new ArrayList<>();
        Connection conn = null;
        Connection connUser = null;
        PreparedStatement ps;
        ResultSet rs;
        EventBookmakerFractions eventBookmakerFractions;
        Map<Integer, String> bookmakerMap = new HashMap<>();
        try {
            conn = ds.getConnection();
            ps = conn.prepareStatement("select bookmaker_id,label from bookmaker_platform");
            rs = ps.executeQuery();
            while(rs.next()) {
                bookmakerMap.put(rs.getInt("bookmaker_id"), rs.getString("label"));
            }
            rs.close();
            ps.close();
            conn.close();;
            conn = null;

            conn = dsUser.getConnection();
            int bookmakerId = 0;
            ps = conn.prepareStatement("select referrer_id,home_team,away_team,country,championship,match_date,bookmaker_id,fa,fh,fd,ph,pd,pa,pbh,pbd,pba,delta from football_fraction where bookmaker_id=? order by delta desc");
            ps.setInt(1, bId);
            rs = ps.executeQuery();
            while(rs.next()) {
                bookmakerId = rs.getInt("bookmaker_id");
                eventBookmakerFractions = new EventBookmakerFractions();
                eventBookmakerFractions.setEventId(rs.getString("referrer_id"));
                eventBookmakerFractions.setHomeTeam(rs.getString("home_team"));
                eventBookmakerFractions.setAwayTeam(rs.getString("away_team"));
                eventBookmakerFractions.setLocation(rs.getString("country"));
                eventBookmakerFractions.setCampionato(rs.getString("championship"));
                eventBookmakerFractions.setStartTime(rs.getTimestamp("match_date"));
                eventBookmakerFractions.setBookmaker(bookmakerMap.get(bookmakerId));
                eventBookmakerFractions.setFh(rs.getDouble("fh"));
                eventBookmakerFractions.setFd(rs.getDouble("fd"));
                eventBookmakerFractions.setFa(rs.getDouble("fa"));
                eventBookmakerFractions.setPh(rs.getInt("ph"));
                eventBookmakerFractions.setPd(rs.getInt("pd"));
                eventBookmakerFractions.setPa(rs.getInt("pa"));
                eventBookmakerFractions.setPbh(rs.getInt("pbh"));
                eventBookmakerFractions.setPbd(rs.getInt("pbd"));
                eventBookmakerFractions.setPba(rs.getInt("pba"));
                eventBookmakerFractions.setDelta(rs.getDouble("delta"));
                eventBookmakerFractionsList.add(eventBookmakerFractions);
            }
        } catch(Exception ex) {
            ex.printStackTrace();
        } finally {
            if(conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return eventBookmakerFractionsList;
    }

    private List<EventBookmakerFractions> getEventBookmakers(String bookmaker, int limit) {
        List<EventBookmakerFractions> eventBookmakerFractionsList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps;
        ResultSet rs;
        EventBookmakerFractions eventBookmakerFractions;
        try {
            conn = ds.getConnection();
            ps = conn.prepareStatement("select a.referrer_id,a.home_team,a.away_team,a.country,a.championship,a.match_date,b.descr,a.fa,a.fh,a.fd,a.ph,a.pd,a.pa,a.pbh,a.pbd,a.pba,a.delta from football_fraction a left join bookmakers b ON a.bookmaker_id = b.id where a.bookmaker_id=? order by a.delta limit ?");
            ps.setString(1, bookmaker);
            ps.setInt(2, limit);
            rs = ps.executeQuery();
            while(rs.next()) {
                eventBookmakerFractions = new EventBookmakerFractions();
                eventBookmakerFractions.setEventId(rs.getString("referrer_id"));
                eventBookmakerFractions.setHomeTeam(rs.getString("home_team"));
                eventBookmakerFractions.setAwayTeam(rs.getString("away_team"));
                eventBookmakerFractions.setLocation(rs.getString("country"));
                eventBookmakerFractions.setCampionato(rs.getString("championship"));
                eventBookmakerFractions.setStartTime(rs.getTimestamp("match_date"));
                eventBookmakerFractions.setBookmaker(rs.getString("descr"));
                eventBookmakerFractions.setFh(rs.getDouble("fh"));
                eventBookmakerFractions.setFd(rs.getDouble("fd"));
                eventBookmakerFractions.setFa(rs.getDouble("fa"));
                eventBookmakerFractions.setPh(rs.getInt("ph"));
                eventBookmakerFractions.setPd(rs.getInt("pd"));
                eventBookmakerFractions.setPa(rs.getInt("pa"));
                eventBookmakerFractions.setPbh(rs.getInt("pbh"));
                eventBookmakerFractions.setPbd(rs.getInt("pbd"));
                eventBookmakerFractions.setPba(rs.getInt("pba"));
                eventBookmakerFractions.setDelta(rs.getDouble("delta"));
                eventBookmakerFractionsList.add(eventBookmakerFractions);
            }
        } catch(Exception ex) {
            ex.printStackTrace();
        } finally {
            if(conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return eventBookmakerFractionsList;
    }

    @Test
    public void getCorrectBookmakersUnibet() {
        List<EventBookmakerFractions> eventBookmakerFractionsList = getEventBookmakers(10);
        for (EventBookmakerFractions eventBookmakerFractions : eventBookmakerFractionsList) {
            System.out.println(eventBookmakerFractions);
        }
        //Assert.assertEquals(5, eventBookmakerFractionsList.size());
    }

    @Test
    public void getCorrectBookmakersWilliamHill() {
        List<EventBookmakerFractions> eventBookmakerFractionsList = getEventBookmakers(2);
        for (EventBookmakerFractions eventBookmakerFractions : eventBookmakerFractionsList) {
            System.out.println(eventBookmakerFractions);
        }
        //Assert.assertEquals(4, eventBookmakerFractionsList.size());
    }

    @Test
    public void betMoneyDistributionWilliamHill_1000_All() {
        List<EventBookmakerFractions> eventBookmakerFractionsList = getEventBookmakers(2);
        BetMoneyDistributionService service = new BetMoneyDistributionServiceImpl();
        List<BetMoneyDistribution> betMoneyDistributionList = service.buildDistribution(eventBookmakerFractionsList, 1000);
        for(BetMoneyDistribution betMoneyDistribution : betMoneyDistributionList) {
            System.out.println(betMoneyDistribution);
        }
        //Assert.assertEquals(0, betMoneyDistributionList.size());
    }
}
