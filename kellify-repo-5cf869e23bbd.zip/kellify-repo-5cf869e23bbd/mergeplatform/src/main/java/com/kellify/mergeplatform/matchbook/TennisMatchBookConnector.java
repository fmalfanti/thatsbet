package com.kellify.mergeplatform.matchbook;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.tennis.TennisBookmakerOdd;

import java.util.List;

public interface TennisMatchBookConnector {
    List<EventFraction> tennisOdds() throws Exception;
}
