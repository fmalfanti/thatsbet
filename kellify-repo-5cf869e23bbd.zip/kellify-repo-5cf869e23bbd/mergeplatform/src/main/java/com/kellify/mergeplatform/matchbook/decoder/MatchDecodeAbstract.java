package com.kellify.mergeplatform.matchbook.decoder;

import com.kellify.common.Platforms;
import com.kellify.common.matchbook.SportIds;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.model.Match;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.tree.ExpandVetoException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public abstract class MatchDecodeAbstract {
    private static final Logger logger = LoggerFactory.getLogger(MatchDecodeAbstract.class);

    protected final DbBookmakerBettingConnector bbConnector;

    protected MatchDecodeAbstract(DbBookmakerBettingConnector bbConnector) {
        this.bbConnector = bbConnector;
    }

    protected boolean matchesSameDate(EventFraction bbMatch, Match providerMatch) {
        LocalDateTime providerMatchDate = providerMatch.getMatchDate();
        LocalDateTime bbMatchDate = bbMatch.getStartTime();

        return bbMatchDate.truncatedTo(ChronoUnit.DAYS).isEqual(providerMatchDate.truncatedTo(ChronoUnit.DAYS));
    }
    protected boolean matchesSameDateOneDayMore(EventFraction bbMatch, Match providerMatch) {
        LocalDateTime providerMatchDate = providerMatch.getMatchDate().truncatedTo(ChronoUnit.DAYS).plusDays(1);
        LocalDateTime bbMatchDate = bbMatch.getStartTime().truncatedTo(ChronoUnit.DAYS);
        return bbMatchDate.isEqual(providerMatchDate);
    }

    protected boolean matchesSameLeagueSameDate(EventFraction bbMatch, MatchWithContinent providerMatch) {
        LocalDateTime providerMatchDate = providerMatch.getMatchDate();
        LocalDateTime bbMatchDate = bbMatch.getStartTime();
        //logger.debug("bbMatch.getLeagueName()----" + bbMatch.getLeagueName() + "providerMatch.getLeagueName()------"+ providerMatch.getLeagueName() +" bbMatchDate.getMatchDate()"+ bbMatchDate.truncatedTo(ChronoUnit.DAYS)+"providerMatchDate.getMatchDate()" +providerMatchDate.truncatedTo(ChronoUnit.DAYS) );
        return bbMatch.getChampionship().equalsIgnoreCase(providerMatch.getLeagueName()) &&
                bbMatchDate.truncatedTo(ChronoUnit.DAYS).isEqual(providerMatchDate.truncatedTo(ChronoUnit.DAYS));
    }

    protected String stripSlashesAndDot(String player) {
        String slashesStripped = player.replaceAll("/", " ").replaceAll("\\.", " ");
        return slashesStripped;
    }
    protected void insertTokensDecodedTeam(EventFraction bbMatch, Match providerMatch, SportIds sportId) throws SQLException {
       // logger.debug("bbMatch.getHomeTeam():" + bbMatch.getHomeTeam() + ", bbMatch.getAwayTeam():" + bbMatch.getAwayTeam() + ", providerMatch.getHomeTeam():" + providerMatch.getHomeTeam() + ", providerMatch.getAwayTeam():" + providerMatch.getAwayTeam());
        if(!bbMatch.getAwayTeam().equalsIgnoreCase(providerMatch.getAwayTeam())) {
            switch(sportId) {
                case FOOTBALL:
                    bbConnector.insertFootballTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.MATCHBOOK.getNumVal(), providerMatch.getLeagueName());
                    break;
                case TENNIS:
                    bbConnector.insertTennisPlayerDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.MATCHBOOK.getNumVal());
                    break;
                case BASKET:
                    bbConnector.insertBasketTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
                    break;
                case BASEBALL:
                    bbConnector.insertBaseballTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
                    break;
                case ICE_HOCKEY:
                    bbConnector.insertIceHockeyTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
                    break;
            }
        }
        if(!bbMatch.getHomeTeam().equalsIgnoreCase(providerMatch.getHomeTeam())) {
            switch(sportId) {
                case FOOTBALL:
                    bbConnector.insertFootballTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.MATCHBOOK.getNumVal(), providerMatch.getLeagueName());
                    break;
                case TENNIS:
                    bbConnector.insertTennisPlayerDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.MATCHBOOK.getNumVal());
                    break;
                case BASKET:
                    bbConnector.insertBasketTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
                    break;
                case BASEBALL:
                    bbConnector.insertBaseballTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
                    break;
                case ICE_HOCKEY:
                    bbConnector.insertIceHockeyTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
                    break;
            }

        }
    }
}
