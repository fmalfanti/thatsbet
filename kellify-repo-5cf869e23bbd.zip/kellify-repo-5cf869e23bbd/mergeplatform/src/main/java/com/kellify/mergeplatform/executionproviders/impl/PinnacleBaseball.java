package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.model.MatchWithContinent;
import com.kellify.mergeplatform.pinnacle.BaseballPinnacleConnector;
import com.kellify.mergeplatform.pinnacle.BaseballPinnacleConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.tree.ExpandVetoException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class PinnacleBaseball extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(PinnacleBaseball.class);
    public PinnacleBaseball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }
    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> baseballChampionshipDecodePinnacleMap = bbConnector.baseballChampionshipDecodePinnacleMap();
        logger.debug("baseballChampionshipDecodePinnacleMap -------");
        logger.debug(baseballChampionshipDecodePinnacleMap.toString());

        List<EventFraction> baseballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.BASEBALL);
        //List<EventFraction> baseballBetbrainMatchesCleaned = Util.cleanFractionList(baseballBetbrainMatches);

        BaseballPinnacleConnector pinnacleConnector = BaseballPinnacleConnectorImpl.getInstance(config, baseballChampionshipDecodePinnacleMap, baseballBetbrainMatches, bbConnector);
        List<EventFraction> baseballBookmakerOdds = pinnacleConnector.baseballOdds();
        logger.debug("baseballBookmakerOdds -------");
        logger.debug(baseballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.PINNACLE);
        bettingUserConnector.insertEventFraction(baseballBookmakerOdds, bookmakerMap, Platforms.PINNACLE, SportTypes.BASEBALL);
    }

}
