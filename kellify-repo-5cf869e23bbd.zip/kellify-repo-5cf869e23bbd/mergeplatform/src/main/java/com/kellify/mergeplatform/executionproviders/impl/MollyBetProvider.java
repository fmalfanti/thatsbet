package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.mergeplatform.db.DBBetbrainConnector;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.Provider;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Properties;

public class MollyBetProvider extends GenericProvider implements Provider {

    private static final Logger logger = LoggerFactory.getLogger(MollyBetProvider.class);
    private final Properties config;
    private final DbBookmakerBettingConnector bbConnector;
    private final DbBettingUserConnector bettingUserConnector;
    private final DBBetbrainConnector dbBetbrainConnector;

    public MollyBetProvider(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, ProviderPilot providerPilot, DBBetbrainConnector dbBetbrainConnector) {
        super(providerPilot);
        this.config = config;
        this.bbConnector = bbConnector;
        this.bettingUserConnector = bettingUserConnector;
        this.dbBetbrainConnector = dbBetbrainConnector;

    }

    @Override
    public void execute() throws Exception {
        initProviderSportMap();
        for(ProviderSport providerSport : providerSportMap) {
            if(providerSport.needPilot()) {
                providerSport.setPilot(providerPilot);
            }
            providerSport.execute();
        }
    }

    protected void initProviderSportMap() {
        providerSportMap = new ArrayList<>();
        providerSportMap.add(new MollyBetTennis(config, bbConnector, bettingUserConnector, dbBetbrainConnector));
        providerSportMap.add(new MollyBetBasket(config, bbConnector, bettingUserConnector, dbBetbrainConnector));
        providerSportMap.add(new MollyBetFootball(config, bbConnector, bettingUserConnector, dbBetbrainConnector));
        providerSportMap.add(new MollyBetIceHockey(config, bbConnector, bettingUserConnector, dbBetbrainConnector));
        providerSportMap.add(new MollyBetAmericanFootball(config, bbConnector, bettingUserConnector, dbBetbrainConnector));
    }

    @Override
    public String name() {
        return Platforms.MOLLYBET.name();
    }
}
