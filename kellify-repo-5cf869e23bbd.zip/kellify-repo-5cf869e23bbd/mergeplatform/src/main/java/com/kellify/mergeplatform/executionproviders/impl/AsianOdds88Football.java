package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.BettingType;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.mergeplatform.asianodds88.AsianOdds88Connector;
import com.kellify.mergeplatform.asianodds88.AsianOdds88ConnectorImpl;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.model.EventFractionWithRole;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AsianOdds88Football extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(AsianOdds88Football.class);

    public AsianOdds88Football(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws Exception {
        Map<String, ChampionshipDecode> footballChampionshipDecodeAsianodds88Map = bbConnector.footballChampionshipDecodeAsianodds88Map();
        logger.debug("footballChampionshipDecodeAsianodds88Map -------");
        logger.debug(footballChampionshipDecodeAsianodds88Map.toString());

        List<EventFraction> footballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.FOOTBALL);

        List<EventFraction> footballBetbrainMatchesCleaned =Util.cleanFractionList(footballBetbrainMatches);

        AsianOdds88Connector asianOdds88Connector = AsianOdds88ConnectorImpl.getInstance(config, footballChampionshipDecodeAsianodds88Map, footballBetbrainMatchesCleaned, bbConnector);
        Map<String, Integer> bookmakerMapID = bbConnector.bookmakerMapID(Platforms.ASIANODDS88);

        List<EventFraction> asianOdds88FootballOdds = asianOdds88Connector.footballOdds(bookmakerMapID);
        logger.debug("asianOdds88FootballOddsEvent -------");
        logger.debug(asianOdds88FootballOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.ASIANODDS88);
        bettingUserConnector.insertEventFootballFraction(asianOdds88FootballOdds, bookmakerMap, Platforms.ASIANODDS88);
    }
}
