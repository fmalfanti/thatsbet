package com.kellify.mergeplatform.model;

import com.kellify.common.OddRole;
import com.kellify.common.model.EventFraction;

public class EventFractionWithRole {
    private final EventFraction fraction;
    private final OddRole role;
    private final int probability;
    private final double kellyFraction;
    private final double odd;

    public EventFractionWithRole(EventFraction fraction, OddRole role, int probability, double kellyFraction, double odd) {
        this.fraction = fraction;
        this.role = role;

        this.probability = probability;
        this.kellyFraction = kellyFraction;
        this.odd = odd;
    }

    public double getOdd() {
        return odd;
    }

    public EventFraction getFraction() {
        return fraction;
    }

    public int getProbability() {
        return probability;
    }

    public double getKellyFraction() {
        return kellyFraction;
    }

    public OddRole getRole() {
        return role;
    }

    @Override
    public String toString() {
        return "EventFractionWithRole{" +
                "fraction='" + fraction + '\'' +
                ", role=" + role +
                ", probability=" + probability +
                ", kellyFraction=" + kellyFraction +
                ", odd=" + odd +
                '}';
    }
}
