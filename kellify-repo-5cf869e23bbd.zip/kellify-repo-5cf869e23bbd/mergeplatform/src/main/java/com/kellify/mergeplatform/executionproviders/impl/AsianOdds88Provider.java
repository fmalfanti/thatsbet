package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.Provider;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Properties;

public class AsianOdds88Provider extends GenericProvider implements Provider {
    private static final Logger logger = LoggerFactory.getLogger(AsianOdds88Provider.class);
    private final Properties config;
    private final DbBookmakerBettingConnector bbConnector;
    private final DbBettingUserConnector bettingUserConnector;

    public AsianOdds88Provider(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, ProviderPilot providerPilot) {
        super(providerPilot);
        this.config = config;
        this.bbConnector = bbConnector;
        this.bettingUserConnector = bettingUserConnector;
    }

    @Override
    public void execute() throws Exception {
        initProviderSportMap();
        for(ProviderSport providerSport : providerSportMap) {
            if(providerSport.needPilot()) {
                providerSport.setPilot(providerPilot);
            }
            providerSport.execute();
        }
    }

    @Override
    protected void initProviderSportMap() {
        providerSportMap = new ArrayList<>();
        providerSportMap.add(new AsianOdds88Football(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new AsianOdds88Basket(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new AsianOdds88Tennis(config, bbConnector, bettingUserConnector));
    }

    @Override
    public String name() {
        return Platforms.ASIANODDS88.name();
    }
}
