package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.matchbook.AmericanFootballMatchBookConnector;
import com.kellify.mergeplatform.matchbook.AmericanFootballMatchBookConnectorImpl;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MatchBookAmericanFootball extends GenericProviderSport implements ProviderSport {

    private static final Logger logger = LoggerFactory.getLogger(MatchBookAmericanFootball.class);

    public MatchBookAmericanFootball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> americanfootballChampionshipDecodeMatchBookMap = bbConnector.americanfootballChampionshipDecodeMatchBookMap();
        logger.debug("americanfootballChampionshipDecodeMatchBookMap -------");
        logger.debug(americanfootballChampionshipDecodeMatchBookMap.toString());

        List<EventFraction> americanfootballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.AMERICAN_FOOTBALL);
        List<EventFraction> americanfootballBetbrainMatchesCleaned = Util.cleanFractionList(americanfootballBetbrainMatches);

        AmericanFootballMatchBookConnector connector = AmericanFootballMatchBookConnectorImpl.getInstance(config, americanfootballChampionshipDecodeMatchBookMap, americanfootballBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> americanfootballBookmakerOdds = connector.americanfootballOdds();
        logger.debug("americanfootballBookmakerOdds -------");
        logger.debug(americanfootballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MATCHBOOK);
        logger.debug("MatchBook bookmakerMap -------" + bookmakerMap.toString());
        bettingUserConnector.insertEventAmericanFootballFraction(americanfootballBookmakerOdds, bookmakerMap, Platforms.MATCHBOOK);
    }
}
