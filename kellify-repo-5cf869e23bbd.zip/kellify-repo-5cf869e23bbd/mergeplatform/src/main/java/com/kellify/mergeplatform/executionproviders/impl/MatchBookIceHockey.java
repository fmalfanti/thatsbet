package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.matchbook.BaseballMatchBookConnector;
import com.kellify.mergeplatform.matchbook.BaseballMatchBookConnectorImpl;
import com.kellify.mergeplatform.matchbook.IceHockeyMatchBookConnector;
import com.kellify.mergeplatform.matchbook.IceHockeyMatchBookConnectorImpl;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MatchBookIceHockey extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookIceHockey.class);

    public MatchBookIceHockey(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> icehockeyChampionshipDecodeMatchBookMap = bbConnector.icehockeyChampionshipDecodeMatchBookMap();
        logger.debug("icehockeyChampionshipDecodeMatchBookMap -------");
        logger.debug(icehockeyChampionshipDecodeMatchBookMap.toString());

        List<EventFraction> icehockeyBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.ICE_HOCKEY);
        List<EventFraction> icehHockeyBetbrainMatchesCleaned = Util.cleanFractionList(icehockeyBetbrainMatches);

        IceHockeyMatchBookConnector connector = IceHockeyMatchBookConnectorImpl.getInstance(config, icehockeyChampionshipDecodeMatchBookMap, icehHockeyBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> iceHockeyBookmakerOdds = connector.icehockeyOdds();
        logger.debug("iceHockeyBookmakerOdds -------");
        logger.debug(iceHockeyBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MATCHBOOK);
        logger.debug("MatchBook bookmakerMap -------" + bookmakerMap.toString());
        bettingUserConnector.insertEventIcehockeyHAFraction(iceHockeyBookmakerOdds, bookmakerMap, Platforms.MATCHBOOK);
    }
}
