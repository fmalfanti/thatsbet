package com.kellify.mergeplatform.matchbook;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.football.FootballBookmakerOdd;

import java.util.List;

public interface FootballMatchBookConnector {
    List<EventFraction> footballOdds() throws Exception;
}
