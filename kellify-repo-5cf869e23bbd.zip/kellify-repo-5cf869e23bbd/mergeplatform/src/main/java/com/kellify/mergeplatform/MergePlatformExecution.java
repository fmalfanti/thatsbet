package com.kellify.mergeplatform;

import com.kellify.common.Platforms;
import com.kellify.mergeplatform.db.DBBetbrainConnector;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.Provider;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.impl.AsianOdds88Provider;
import com.kellify.mergeplatform.executionproviders.impl.MatchBookProvider;
import com.kellify.mergeplatform.executionproviders.impl.PinnacleProvider;
import com.kellify.mergeplatform.executionproviders.impl.pilot.BetBrainProviderPilot;
import com.kellify.mergeplatform.executionproviders.impl.MollyBetProvider;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class MergePlatformExecution {
    private static final Logger logger = LoggerFactory.getLogger(MergePlatformExecution.class);
    private final Properties config;
    private List<Provider> providers;

    public MergePlatformExecution(Properties config) {
        this.config = config;
    }

    private List<Platforms> activePlatforms() {
        List<Platforms> platforms = new ArrayList<>();
        String platformsActive = config.getProperty("platforms.active");
        if(!StringUtils.isBlank(platformsActive)) {
            List<String> result = Arrays.asList(platformsActive.split("\\s*,\\s*"));
            for(String s : result) {
                try {
                    platforms.add(Platforms.valueOf(s.toUpperCase()));
                } catch(IllegalArgumentException ex) {
                    logger.error("platform " + s + " does not exists");
                }
        }
        }
        return platforms;
    }

    private List<Provider> initProvider(DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, ProviderPilot providerPilot, DBBetbrainConnector dbBetbrainConnector) {
        List<Provider> providers = new ArrayList<>();
        List<Platforms> platforms = activePlatforms();
        for(Platforms p : platforms) {
            switch(p) {
                case ASIANODDS88:
                    providers.add(new AsianOdds88Provider(config, bbConnector, bettingUserConnector, providerPilot));
                    break;
                case PINNACLE:
                    providers.add(new PinnacleProvider(config, bbConnector, bettingUserConnector, providerPilot));
                    break;
                case MATCHBOOK:
                    providers.add(new MatchBookProvider(config, bbConnector, bettingUserConnector, providerPilot));
                    break;
                case MOLLYBET:
                    providers.add(new MollyBetProvider(config, bbConnector, bettingUserConnector, providerPilot, dbBetbrainConnector));
                    break;
            }
        }

        return providers;
    }

    private void logProviders(List<Provider> providers) {
        StringBuilder sb = new StringBuilder();
        for(Provider provider : providers) {
            sb.append(provider.name()).append(" ");
        }
        logger.info("providers:" + sb.toString());
    }

    private ProviderPilot initProviderPilot(DBBetbrainConnector betbrainConnector, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector ) throws SQLException {
        BetBrainProviderPilot providerPilot = new BetBrainProviderPilot(betbrainConnector, bbConnector, bettingUserConnector);
        providerPilot.init();
        return providerPilot;
    }

    public void run() {
        DbBookmakerBettingConnector bbConnector = null;
        DBBetbrainConnector betbrainConnector = null;
        DbBettingUserConnector bettingUserConnector = null;
        DBBetbrainConnector dbBetbrainConnector = null;
        try {
            bbConnector = new DbBookmakerBettingConnector(config);
            betbrainConnector = new DBBetbrainConnector(config);
            bettingUserConnector = new DbBettingUserConnector(config);
            dbBetbrainConnector = new DBBetbrainConnector(config);

//            bettingUserConnector.truncateFootballSnapshot();
//            bettingUserConnector.truncateTennisSnapshot();
//            bettingUserConnector.truncateBasketSnapshot();
//            bettingUserConnector.truncateBaseballSnapshot();
//            bettingUserConnector.truncateAmericanFootballSnapshot();
//            bettingUserConnector.truncateIcehockeySnapshot();

            ProviderPilot providerPilot = initProviderPilot(betbrainConnector, bbConnector, bettingUserConnector);
//            providerPilot.createOddsSnapshot();

            providers = initProvider(bbConnector, bettingUserConnector, providerPilot, betbrainConnector);
            logProviders(providers);

            for(Provider provider : providers) {
                try {
                    provider.execute();
                } catch(Exception ex) {
                    logger.error("Provider:" + provider.name() + ", error:" + ex.getMessage(), ex);
                }
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        } finally {
            if(bbConnector != null) {
                bbConnector.closeConnection();;
            }
            if(betbrainConnector != null) {
                betbrainConnector.closeConnection();;
            }
            if(bettingUserConnector != null) {
                bettingUserConnector.closeConnection();;
            }
        }
    }
}
