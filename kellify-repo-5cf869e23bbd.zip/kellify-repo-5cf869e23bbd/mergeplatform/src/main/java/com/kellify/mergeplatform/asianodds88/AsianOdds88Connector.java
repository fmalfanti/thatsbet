package com.kellify.mergeplatform.asianodds88;

import com.kellify.common.BettingType;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;

import java.util.List;
import java.util.Map;

public interface AsianOdds88Connector {
    List<EventFraction> footballOdds(Map<String, Integer> bookmakerMapID) throws Exception;
    List<EventFraction> basketOdds(Map<String, Integer> bookmakerMapID) throws Exception;
    List<EventFraction> tennisOdds(Map<String, Integer> bookmakerMapID) throws Exception;
}
