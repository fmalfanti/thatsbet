package com.kellify.mergeplatform.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;

import java.time.LocalDateTime;

public class TennisMatch extends Match {
    public TennisMatch(String id, String referrerId, String homeTeam, String awayTeam, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType);
    }

    @Override
    public String toString() {
        return "TennisMatch{" +
                "id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
