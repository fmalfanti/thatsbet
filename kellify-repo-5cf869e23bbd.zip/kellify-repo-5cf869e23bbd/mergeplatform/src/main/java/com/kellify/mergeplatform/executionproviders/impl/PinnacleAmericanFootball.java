package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.model.MatchWithContinent;
import com.kellify.mergeplatform.pinnacle.AmericanFootballPinnacleConnector;
import com.kellify.mergeplatform.pinnacle.AmericanFootballPinnacleConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class PinnacleAmericanFootball extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(PinnacleAmericanFootball.class);
    public PinnacleAmericanFootball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }
    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> americanfootballChampionshipDecodePinnacleMap = bbConnector.americanfootballChampionshipDecodePinnacleMap();
        logger.debug("americanfootballChampionshipDecodePinnacleMap -------");
        logger.debug(americanfootballChampionshipDecodePinnacleMap.toString());

        List<EventFraction> americanfootballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.AMERICAN_FOOTBALL);
        List<EventFraction> americanfootballBetbrainMatchesCleaned = Util.cleanFractionList(americanfootballBetbrainMatches);

        AmericanFootballPinnacleConnector pinnacleConnector =AmericanFootballPinnacleConnectorImpl.getInstance(config,americanfootballChampionshipDecodePinnacleMap, americanfootballBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> americanfootballBookmakerOdds = pinnacleConnector.americanfootballOdd();
        logger.debug("americanfootballBookmakerOdds -------");
        logger.debug(americanfootballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.PINNACLE);
        bettingUserConnector.insertEventAmericanFootballFraction(americanfootballBookmakerOdds, bookmakerMap, Platforms.PINNACLE);
    }

}
