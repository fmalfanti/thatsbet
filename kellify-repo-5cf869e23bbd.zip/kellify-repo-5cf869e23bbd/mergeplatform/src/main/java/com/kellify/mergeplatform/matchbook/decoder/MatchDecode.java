package com.kellify.mergeplatform.matchbook.decoder;

import com.kellify.common.Platforms;
import com.kellify.common.matchbook.SportIds;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.common.MatchDecodeState;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.matchbook.model.TennisMatchBookMatch;
import com.kellify.mergeplatform.model.TennisMatch;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class MatchDecode extends MatchDecodeAbstract {
    private static final Logger logger = LoggerFactory.getLogger(MatchDecode.class);

    private final List<EventFraction> betbrainMatchesMap;


    public MatchDecode(List<EventFraction> betbrainMatchesMap, DbBookmakerBettingConnector bbConnector) {
        super(bbConnector);
        this.betbrainMatchesMap = betbrainMatchesMap;
    }

    public ImmutablePair<MatchDecodeState, EventFraction> decodeTennis(TennisMatchBookMatch providerMatch) throws SQLException {
        if(betbrainMatchesMap == null) {
            return null;
        }
        String providerHomePlayer = providerMatch.getHomeTeam();
        String providerAwayPlayer = providerMatch.getAwayTeam();
        providerHomePlayer = bbConnector.tennisPlayerDecode(providerHomePlayer, Platforms.MATCHBOOK.getNumVal());
        providerAwayPlayer = bbConnector.tennisPlayerDecode(providerAwayPlayer, Platforms.MATCHBOOK.getNumVal());
        if(!tennisPlayerSanitize(providerHomePlayer) || !tennisPlayerSanitize(providerAwayPlayer)) {
            logger.warn("match has not allowed characters:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        providerHomePlayer = stripSlashesAndDot(providerHomePlayer);
        providerAwayPlayer = stripSlashesAndDot(providerAwayPlayer);

        String[] tokensHomeProvider = providerHomePlayer.split("\\s+");
        String[] tokensAwayProvider = providerAwayPlayer.split("\\s+");


        String bbHomeTeam;
        String bbAwayTeam;
        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                bbHomeTeam = stripSlashesAndDot(bbMatch.getHomeTeam());
                bbAwayTeam = stripSlashesAndDot(bbMatch.getAwayTeam());

                if (matchesSameDateOneDayMore(bbMatch, providerMatch)) {
                    if (bbAwayTeam.equalsIgnoreCase(providerAwayPlayer) && bbHomeTeam.equalsIgnoreCase(providerHomePlayer)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildTennisMatch(bbMatch, providerMatch));
                    }
                }
                if (matchesSameDate(bbMatch, providerMatch)) {
                    if (bbAwayTeam.equalsIgnoreCase(providerAwayPlayer) && bbHomeTeam.equalsIgnoreCase(providerHomePlayer)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildTennisMatch(bbMatch, providerMatch));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayPlayer) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomePlayer)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decode
                    String[] tokensHomeBetBrain = bbHomeTeam.split("\\s+");
                    String[] tokensAwayBetBrain = bbAwayTeam.split("\\s+");
                    if (matchMatch(tokensHomeBetBrain, tokensHomeProvider) && matchMatch(tokensAwayBetBrain, tokensAwayProvider)) {
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch, SportIds.TENNIS);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildTennisMatch(bbMatch, providerMatch));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }

    private EventFraction buildTennisMatch(EventFraction bbMatch, TennisMatchBookMatch providerMatch) {
        EventFraction fraction = new EventFraction();
        fraction.setReferrerId(bbMatch.getReferrerId());
        fraction.setEventId(providerMatch.getId());
        fraction.setOddId(providerMatch.getReferrerId());
        fraction.setPlatformId(Platforms.MATCHBOOK.getNumVal());
        fraction.setHomeTeam(bbMatch.getHomeTeam());
        fraction.setAwayTeam(bbMatch.getAwayTeam());
        fraction.setChampionship(bbMatch.getChampionship());
        fraction.setCountry(bbMatch.getCountry());
        fraction.setBookmakerId(  bbMatch.getBookmakerId());
        fraction.setBookmakerLabel(providerMatch.getOdds().getName());
        fraction.setStartTime(  bbMatch.getStartTime());
        fraction.setFa(bbMatch.getFa());
        fraction.setFh(bbMatch.getFh());
        fraction.setPh(bbMatch.getPh());
        fraction.setPa(bbMatch.getPa());
        fraction.setPbh(bbMatch.getPbh());
        fraction.setPba(bbMatch.getPba());
        fraction.setDelta(bbMatch.getDelta());
        fraction.setBettingOfferIdH(providerMatch.getOdds().getIdHome());
        fraction.setBettingOfferIdA(providerMatch.getOdds().getIdAway());
        fraction.setBettingType( bbMatch.getBettingType());
        fraction.setSportType( bbMatch.getSportType());

        return fraction;
    }

    private boolean tennisPlayerSanitize(String tennisPlayer) {
        return true;
    }

    private boolean matchMatch(String[] tokensBetBrain, String[] tokensProvider) {
        int tokensProviderLength = tokensProvider.length;
        int tokensBetBrainLength = tokensBetBrain.length;

        String surname = "";
        String name = "";

        if(tokensProviderLength == 1) {
            surname = tokensProvider[0];
        } else {
            String[] nameSurname = findNameSurname(tokensProvider);
            name = nameSurname[0];
            surname = nameSurname[1];
        }

        List<String> remaining = new ArrayList<>();
        String tk1;
        for(int i=0; i<tokensBetBrainLength; i++) {
            tk1 = tokensBetBrain[i];
            if(!tk1.equals(surname)) {
                remaining.add(tk1);
            } else {
                if(tokensProviderLength == 1) {
                    return true;
                }
            }
        }

        if(remaining.size() < tokensBetBrainLength) {
            for(String rName : remaining) {
                if(name.contains(rName.substring(0, 1))) {
                    return true;
                }
            }
        }

        return false;
    }

    private String[] findNameSurname(String[] tokens) {
        String surname = "";
        String name = "";
        surname = name = tokens[0];
        int maxLength = surname.length();
        for(String token : tokens) {
            if(token.length() > maxLength) {
                maxLength = token.length();
                surname = token;
            } else {
                name = token;
            }
        }

        return new String[] {name, surname};
    }
}
