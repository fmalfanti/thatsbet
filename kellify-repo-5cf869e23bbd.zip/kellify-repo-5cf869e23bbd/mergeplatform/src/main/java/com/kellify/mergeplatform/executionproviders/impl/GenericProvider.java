package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.SportTypes;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.ProviderSport;

import java.util.List;
import java.util.Map;

public abstract class GenericProvider {
    protected final ProviderPilot providerPilot;
    protected List<ProviderSport> providerSportMap;

    protected GenericProvider(ProviderPilot providerPilot) {
        this.providerPilot = providerPilot;
    }

    protected Map<String, ChampionshipDecode> championshipDecode(SportTypes sportType, DbBookmakerBettingConnector bbConnector) {
        return null;
    }

    protected abstract void initProviderSportMap();
}
