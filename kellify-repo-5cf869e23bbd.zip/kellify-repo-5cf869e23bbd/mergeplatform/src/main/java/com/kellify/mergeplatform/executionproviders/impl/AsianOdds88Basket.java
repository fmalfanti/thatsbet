package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.mergeplatform.asianodds88.AsianOdds88Connector;
import com.kellify.mergeplatform.asianodds88.AsianOdds88ConnectorImpl;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AsianOdds88Basket extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(AsianOdds88Basket.class);

    protected AsianOdds88Basket(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> basketChampionshipDecodeAsianodds88Map = bbConnector.basketChampionshipDecodeAsianodds88Map();
        logger.debug("basketChampionshipDecodeAsianodds88Map -------");
        logger.debug(basketChampionshipDecodeAsianodds88Map.toString());

        List<EventFraction> basketBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.BASKET);

        List<EventFraction> basketBetbrainMatchesCleaned =Util.cleanFractionList(basketBetbrainMatches);
        AsianOdds88Connector asianOdds88Connector = AsianOdds88ConnectorImpl.getInstance(config, basketChampionshipDecodeAsianodds88Map, basketBetbrainMatchesCleaned, bbConnector);
        Map<String, Integer> bookmakerMapID = bbConnector.bookmakerMapID(Platforms.ASIANODDS88);
        List<EventFraction> asianOdds88BasketOdds = asianOdds88Connector.basketOdds(bookmakerMapID);
        logger.debug("asianOdds88BasketEvent -------");
        logger.debug(asianOdds88BasketOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.ASIANODDS88);
        bettingUserConnector.insertEventBasketFraction(asianOdds88BasketOdds, bookmakerMap, Platforms.ASIANODDS88);
    }
}
