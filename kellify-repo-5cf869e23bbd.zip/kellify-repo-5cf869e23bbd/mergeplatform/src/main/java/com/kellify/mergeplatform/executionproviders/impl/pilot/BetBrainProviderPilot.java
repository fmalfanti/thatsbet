package com.kellify.mergeplatform.executionproviders.impl.pilot;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.db.DBBetbrainConnector;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.*;

public class BetBrainProviderPilot implements ProviderPilot {
    private static final Logger logger = LoggerFactory.getLogger(BetBrainProviderPilot.class);

    private final DBBetbrainConnector betbrainConnector;
    private final DbBookmakerBettingConnector bbConnector;
    private final DbBettingUserConnector bettingUserConnector;

    private Map<String, Integer> betTypeDecodeMap;


    private Map<SportTypes, Map<String, ChampionshipDecode>> championshipDecodeCache = null;
    private List<SportTypes> sportTypesList = null;

    public BetBrainProviderPilot(DBBetbrainConnector betbrainConnector, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        this.betbrainConnector = betbrainConnector;
        this.bbConnector = bbConnector;
        this.bettingUserConnector = bettingUserConnector;
        championshipDecodeCache = new HashMap<>();
    }

    @Override
    public void init() throws SQLException {
        initBettingTypeDecodeMap();
        initSportTypesList();
    }

    @Override
    public List< ?> pilotMatches(SportTypes sportType) throws SQLException {
        return builPilotMatches(sportType);
    }

    @Override
    public Map<String, Integer> bettingTypeDecodeMap() {
        return betTypeDecodeMap;
    }

    @Override
    public Map<String, ChampionshipDecode> championshipDecodeMap(SportTypes sportType) throws SQLException {
        Map<String, ChampionshipDecode> championshipMap = championshipDecodeCache.get(sportType);
        if(championshipMap == null) {
            championshipMap = championshipDecodeSportMap(sportType);
            championshipDecodeCache.put(sportType, championshipMap);
        }
        return championshipMap;
    }

    @Override
    public void createOddsSnapshot() throws SQLException {
        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.BETBRAIN);
        List<String> bkLabels = bookmakerLabels(bookmakerMap);
        for(SportTypes sportType : sportTypesList) {
            switch (sportType) {
                case FOOTBALL:
                    List<FootballBookmakerOdd> betbrainFootballOdds = betbrainConnector.footballBetbrainOdds(championshipDecodeMap(SportTypes.FOOTBALL), bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainFootballOdds:" + betbrainFootballOdds);
                    bettingUserConnector.truncateFootballSnapshot();
                    bettingUserConnector.insertFootballOddsSnapshot(betbrainFootballOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
                case TENNIS:
                    List<TennisBookmakerOdd> betbrainTennisOdds = betbrainConnector.tennisBetbrainOdds(bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainTennisOdds:" + betbrainTennisOdds);
                    bettingUserConnector.truncateTennisSnapshot();
                    bettingUserConnector.insertTennisOddsSnapshot(betbrainTennisOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
                case BASEBALL:
                    List<BaseballBookmakerOdd> betbrainBaseballOdds = betbrainConnector.baseballBetbrainOdds(championshipDecodeMap(SportTypes.BASEBALL), bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainBaseballOdds:" + betbrainBaseballOdds);
                    bettingUserConnector.truncateBaseballSnapshot();
                    bettingUserConnector.insertBaseballOddsSnapshot(betbrainBaseballOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
                case BASKET:
                    List<BasketBookmakerOdd> betbrainBasketOdds = betbrainConnector.basketBetbrainOdds(championshipDecodeMap(SportTypes.BASKET), bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainBasketOdds:" + betbrainBasketOdds);
                    bettingUserConnector.truncateBasketSnapshot();
                    bettingUserConnector.insertBasketOddsSnapshot(betbrainBasketOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
                case ICE_HOCKEY:
                    List<IceHockeyBookmakerOdd> betbrainIcehockeyOdds = betbrainConnector.icehockeyBetbrainOdds(championshipDecodeMap(SportTypes.ICE_HOCKEY), bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainIcehockeyOdds:" + betbrainIcehockeyOdds);
                    bettingUserConnector.truncateIcehockeySnapshot();
                    bettingUserConnector.insertIcehockeyOddsSnapshot(betbrainIcehockeyOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
                case ICE_HOCKEY_HDA:
                    List<IceHockeyBookmakerOdd> betbrainIcehockeyHDAOdds = betbrainConnector.icehockeyHDABetbrainOdds(championshipDecodeMap(SportTypes.ICE_HOCKEY), bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainIcehockeyHDAOdds:" + betbrainIcehockeyHDAOdds);
                    bettingUserConnector.truncateIcehockeySnapshot();
                    bettingUserConnector.insertIcehockeyOddsSnapshot(betbrainIcehockeyHDAOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
                case AMERICAN_FOOTBALL:
                    List<AmericanFootballBookmakerOdd> betbrainAmericanFootballOdds = betbrainConnector.americanfootballBetbrainOdds(championshipDecodeMap(SportTypes.AMERICAN_FOOTBALL), bettingTypeDecodeMap(), bkLabels);
                    logger.debug("betbrainAmericanFootballOdds:" + betbrainAmericanFootballOdds);
                    bettingUserConnector.truncateAmericanFootballSnapshot();
                    bettingUserConnector.insertAmericanFootballOddsSnapshot(betbrainAmericanFootballOdds, bookmakerMap, Platforms.BETBRAIN);
                    break;
            }
        }
    }

    private List<String> bookmakerLabels(Map<String, BookmakerAttributes> bookmakerMap) {
        List<String> labels = new ArrayList<>();
        for(Map.Entry<String, BookmakerAttributes> entry : bookmakerMap.entrySet()) {
            labels.add(entry.getValue().getLabel());
        }
        return labels;
    }

    private void initBettingTypeDecodeMap() throws SQLException {
        betTypeDecodeMap = bbConnector.bettingTypeDecodeBetBrainMap();
        logger.debug("betTypeDecodeMap -------");
        logger.debug(betTypeDecodeMap.toString());
    }
    private void initSportTypesList() {
        sportTypesList = Arrays.asList(SportTypes.FOOTBALL, SportTypes.TENNIS, SportTypes.BASEBALL, SportTypes.ICE_HOCKEY, SportTypes.BASKET, SportTypes.AMERICAN_FOOTBALL);
    }

    private Map<String, ChampionshipDecode> championshipDecodeSportMap(SportTypes sportType) throws SQLException {
        switch (sportType) {
            case FOOTBALL:
                return bbConnector.footballChampionshipDecodeBetBrainMap();
            case TENNIS:
                return bbConnector.tennisChampionshipDecodeBetBrainMap();
            case BASEBALL:
                return bbConnector.baseballChampionshipDecodeBetBrainMap();
            case BASKET:
                return bbConnector.basketChampionshipDecodeBetBrainMap();
            case ICE_HOCKEY:
                return bbConnector.icehockeyChampionshipDecodeBetBrainMap();
            case ICE_HOCKEY_HDA:
                return bbConnector.icehockeyChampionshipDecodeBetBrainMap();
            case AMERICAN_FOOTBALL:
                return bbConnector.americanfootballChampionshipDecodeBetBrainMap();


        }
        return null;
    }

    private List< ?> builPilotMatches(SportTypes sportType ) throws SQLException {
        Map<Integer, String> bookmakerMap = bbConnector.bookmakerMapString(Platforms.BETBRAIN);
        switch (sportType) {
            case FOOTBALL:
                List<EventFraction> footballBetbrainMatches = bettingUserConnector.loadFootballPlatformEventFractions(bookmakerMap);
                logger.debug("footballBetbrainMatches -------");
                logger.debug(footballBetbrainMatches.toString());
                return footballBetbrainMatches;
            case TENNIS:
                List<EventFraction> tennisBetbrainMatches = bettingUserConnector.loadTennisPlatformEventFractions(bookmakerMap);
                logger.debug("tennisBetbrainMatches -------");
                logger.debug(tennisBetbrainMatches.toString());
                return tennisBetbrainMatches;
            case BASEBALL:
                List<EventFraction> baseballBetbrainMatches = bettingUserConnector.loadBaseballPlatformEventFractions(bookmakerMap);
                logger.debug("baseballBetbrainMatches -------");
                logger.debug(baseballBetbrainMatches.toString());
                return baseballBetbrainMatches;
           case BASKET:
                 List<EventFraction> basketBetbrainMatches = bettingUserConnector.loadBasketPlatformEventFractions(bookmakerMap);
                logger.debug("basketBetbrainMatches -------");
                logger.debug(basketBetbrainMatches.toString());
                return basketBetbrainMatches;
            case ICE_HOCKEY:
                List<EventFraction> icehockeyBetbrainMatches = bettingUserConnector.loadIceHockeyPlatformEventFractions(bookmakerMap);
                logger.debug("icehockeyBetbrainMatches -------");
                logger.debug(icehockeyBetbrainMatches.toString());
                return icehockeyBetbrainMatches;
//            case ICE_HOCKEY_HDA:
//                Map<String, List<IceHockeyMatch>> icehockeyHDABetbrainMatches = betbrainConnector.icehockeyHDABetbrainMatches(championshipDecodeSportMap(sportType), bettingTypeDecodeMap());
//                logger.debug("icehockeyHDABetbrainMatches -------");
//                logger.debug(icehockeyHDABetbrainMatches.toString());
//                return icehockeyHDABetbrainMatches;
            case AMERICAN_FOOTBALL:
                List<EventFraction> americanfootballBetbrainMatches = bettingUserConnector.loadAmericanFootballPlatformEventFractions(bookmakerMap);
                logger.debug("americanfootballBetbrainMatches -------");
                logger.debug(americanfootballBetbrainMatches.toString());
                return americanfootballBetbrainMatches;
        }
        return null;
    }
}
