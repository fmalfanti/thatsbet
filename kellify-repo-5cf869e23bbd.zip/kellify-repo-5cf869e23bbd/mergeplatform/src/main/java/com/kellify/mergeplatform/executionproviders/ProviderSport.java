package com.kellify.mergeplatform.executionproviders;

import java.sql.SQLException;

public interface ProviderSport {
    boolean needPilot();
    void setPilot(ProviderPilot providerPilot);
    void execute() throws SQLException, Exception;
}
