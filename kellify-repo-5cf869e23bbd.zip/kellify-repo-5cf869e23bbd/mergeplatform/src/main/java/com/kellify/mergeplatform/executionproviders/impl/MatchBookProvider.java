package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.Provider;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Properties;

public class MatchBookProvider extends GenericProvider implements Provider {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookProvider.class);

    private final Properties config;
    private final DbBookmakerBettingConnector bbConnector;
    private final DbBettingUserConnector bettingUserConnector;

    public MatchBookProvider(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, ProviderPilot providerPilot) {
        super(providerPilot);
        this.config = config;
        this.bbConnector = bbConnector;
        this.bettingUserConnector = bettingUserConnector;
    }

    @Override
    public void execute() throws Exception {
        initProviderSportMap();
        for(ProviderSport providerSport : providerSportMap) {
            if(providerSport.needPilot()) {
                providerSport.setPilot(providerPilot);
            }
            providerSport.execute();
        }
    }

    @Override
    public String name() {
        return Platforms.MATCHBOOK.name();
    }

    @Override
    protected void initProviderSportMap() {
        providerSportMap = new ArrayList<>();
        providerSportMap.add(new MatchBookFootball(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new MatchBookTennis(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new MatchBookBaseball(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new MatchBookBasket(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new MatchBookIceHockey(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new MatchBookAmericanFootball(config, bbConnector, bettingUserConnector));
    }
}
