package com.kellify.mergeplatform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) throws IOException, SQLException {
        File confFile;

        if(args.length == 0) {
            logger.warn("Not <conf_file_path> provided, using default");
            App app = new App();
            confFile = new File(app.getClass().getClassLoader().getResource("application.properties").getFile());
        } else {
            confFile = new File(args[0]);
            if(!confFile.exists()) {
                logger.warn("Config file" + args[0] + " does not exists or is not readable, using default");
                App app = new App();
                confFile = new File(app.getClass().getClassLoader().getResource("application.properties").getFile());
            } else {
                logger.info("Config file " + args[0] + " found");
            }

        }

        Properties config = new Properties();
        config.load(new FileInputStream(confFile));

        if(logger.isDebugEnabled()) {
            logger.debug("Configuration:" + config);
        }

        MergePlatformExecution mergePlatformExecution = new MergePlatformExecution(config);
        mergePlatformExecution.run();

        logger.info("mergeplatform process end");
    }
}
