package com.kellify.mergeplatform.common;

public class ChampionshipDecode {
    private final String championship;
    private final String location;
    private final String continent;

    public ChampionshipDecode(String championship, String location, String continent) {
        this.championship = championship;
        this.location = location;
        this.continent = continent;
    }

    public String getChampionship() {
        return championship;
    }

    public String getLocation() {
        return location;
    }

    public String getContinent() {
        return continent;
    }

    @Override
    public String toString() {
        return "ChampionshipDecode{" +
                "championship='" + championship + '\'' +
                ", location='" + location + '\'' +
                ", continent='" + continent + '\'' +
                '}';
    }
}
