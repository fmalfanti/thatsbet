package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.Provider;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Properties;

public class PinnacleProvider extends GenericProvider implements Provider {
    private static final Logger logger = LoggerFactory.getLogger(PinnacleProvider.class);
    private final Properties config;
    private final DbBookmakerBettingConnector bbConnector;
    private final DbBettingUserConnector bettingUserConnector;

    public PinnacleProvider(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, ProviderPilot providerPilot) {
        super(providerPilot);
        this.config = config;
        this.bbConnector = bbConnector;
        this.bettingUserConnector = bettingUserConnector;
    }

    @Override
    public void execute() throws Exception {
        initProviderSportMap();
        for(ProviderSport providerSport : providerSportMap) {
            if(providerSport.needPilot()) {
                providerSport.setPilot(providerPilot);
            }
            providerSport.execute();
        }
    }

    @Override
    protected void initProviderSportMap() {
        providerSportMap = new ArrayList<>();
        providerSportMap.add(new PinnacleTennis(config, bbConnector, bettingUserConnector));
        providerSportMap.add(new PinnacleBaseball(config, bbConnector, bettingUserConnector));
//        providerSportMap.add(new PinnacleFootball(config, bbConnector, bettingUserConnector));
       // providerSportMap.add(new PinnacleBasket(config, bbConnector, bettingUserConnector));
//        providerSportMap.add(new PinnacleIceHockey(config, bbConnector, bettingUserConnector));
//        providerSportMap.add(new PinnacleAmericanFootball(config, bbConnector, bettingUserConnector));
    }

    @Override
    public String name() {
        return Platforms.PINNACLE.name();
    }
}
