package com.kellify.mergeplatform.matchbook.model;

import java.util.Objects;

public class MatchBookHomeAwayDrawOdd {
    private final String idHome;
    private final String idAway;
    private final String idDraw;
    private final double away;
    private final String name = "MATCHBOOK";
    private final double home;
    private final double draw;

    public MatchBookHomeAwayDrawOdd(String idHome, String idAway, String idDraw, double home, double away, double draw) {
        this.idHome = idHome;
        this.idAway = idAway;
        this.idDraw = idDraw;
        this.away = away;
        this.home = home;
        this.draw = draw;
    }

    public String getIdHome() {
        return idHome;
    }

    public String getIdAway() {
        return idAway;
    }

    public String getIdDraw() {
        return idDraw;
    }

    public double getAway() {
        return away;
    }

    public String getName() {
        return name;
    }

    public double getHome() {
        return home;
    }

    public double getDraw() {
        return draw;
    }

    public boolean isValid() {
        return home > 0 || away > 0 || draw > 0;
    }

    @Override
    public String toString() {
        return "MatchBookHomeAwayDrawOdd{" +
                "name='" + name + '\'' +
                ", idHome='" + idHome + '\'' +
                ", idAway='" + idAway + '\'' +
                ", idDraw='" + idDraw + '\'' +
                ", home=" + home +
                ", away=" + away +
                ", draw=" + draw +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MatchBookHomeAwayDrawOdd that = (MatchBookHomeAwayDrawOdd) o;
        return Double.compare(that.away, away) == 0 &&
                Double.compare(that.home, home) == 0 &&
                Double.compare(that.draw, draw) == 0 &&
                Objects.equals(idHome, that.idHome) &&
                Objects.equals(idAway, that.idAway) &&
                Objects.equals(idDraw, that.idDraw) &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHome, idAway, idDraw, away, name, home, draw);
    }
}
