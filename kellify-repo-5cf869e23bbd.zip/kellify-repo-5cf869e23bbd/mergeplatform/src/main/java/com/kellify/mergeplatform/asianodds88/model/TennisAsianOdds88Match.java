package com.kellify.mergeplatform.asianodds88.model;

import com.kellify.common.BettingType;
import com.kellify.mergeplatform.model.Match;

import java.time.LocalDateTime;
import java.util.List;

public class TennisAsianOdds88Match extends Match {
    private List<HomeAwayDrawAsianOdds88Odd> odds;

    public TennisAsianOdds88Match(String id, String referrerId, String homeTeam, String awayTeam, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType);
    }
    public List<HomeAwayDrawAsianOdds88Odd> getOdds() {
        return odds;
    }

    public void setOdds(List<HomeAwayDrawAsianOdds88Odd> odds) {
        this.odds = odds;
    }

    @Override
    public String toString() {
        return "TennisAsianOdds88Match{" +
                "odds=" + odds +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType=" + bettingType +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
