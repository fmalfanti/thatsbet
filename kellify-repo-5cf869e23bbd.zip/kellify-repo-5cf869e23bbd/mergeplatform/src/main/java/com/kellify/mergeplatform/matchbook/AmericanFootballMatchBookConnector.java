package com.kellify.mergeplatform.matchbook;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;

import java.util.List;

public interface AmericanFootballMatchBookConnector {
    List<EventFraction> americanfootballOdds() throws Exception;
}
