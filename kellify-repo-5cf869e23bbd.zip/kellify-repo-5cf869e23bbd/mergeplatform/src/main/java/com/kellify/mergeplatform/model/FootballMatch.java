package com.kellify.mergeplatform.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;

import java.time.LocalDateTime;

public class FootballMatch extends MatchWithContinent{
    public FootballMatch(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
    }

    @Override
    public String toString() {
        return "FootballMatch{" +
                "continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
