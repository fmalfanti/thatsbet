package com.kellify.mergeplatform.asianodds88.model;

import java.util.Objects;

public class HomeAwayDrawAsianOdds88Odd {
    private final String id;
    private final String name;
    private final double away;
    private final double home;
    private final double draw;

    public HomeAwayDrawAsianOdds88Odd(String id, String name, double away, double home, double draw) {
        this.id = id;
        this.name = name;
        this.away = away;
        this.home = home;
        this.draw = draw;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getAway() {
        return away;
    }

    public double getHome() {
        return home;
    }

    public double getDraw() {
        return draw;
    }

    @Override
    public String toString() {
        return "HomeAwayDrawAsianOdds88Odd{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", away=" + away +
                ", home=" + home +
                ", draw=" + draw +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HomeAwayDrawAsianOdds88Odd that = (HomeAwayDrawAsianOdds88Odd) o;
        return Objects.equals(id, that.id) &&
                Double.compare(that.away, away) == 0 &&
                Double.compare(that.home, home) == 0 &&
                Double.compare(that.draw, draw) == 0 &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, away, home, draw);
    }
}
