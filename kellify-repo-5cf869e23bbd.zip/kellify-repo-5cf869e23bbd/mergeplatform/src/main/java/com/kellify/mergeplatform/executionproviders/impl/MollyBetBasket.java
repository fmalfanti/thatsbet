package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DBBetbrainConnector;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.mollybet.BasketMollyBetConnector;
import com.kellify.mergeplatform.mollybet.BasketMollyBetConnectorImpl;
import com.kellify.mergeplatform.mollybet.TennisMollyBetConnector;
import com.kellify.mergeplatform.mollybet.TennisMollyBetConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MollyBetBasket extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookBasket.class);
    protected DBBetbrainConnector dbBetbrainConnector;

    public MollyBetBasket(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, DBBetbrainConnector dbBetbrainConnector) {
        super(config, bbConnector, bettingUserConnector);
        this.dbBetbrainConnector = dbBetbrainConnector;
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> basketChampionshipDecodeMollybetMap = bbConnector.basketChampionshipMollyBetMap();
        logger.debug("basketChampionshipDecodeMollybetMap -------");
        logger.debug(basketChampionshipDecodeMollybetMap.toString());
        List<EventFraction> basketBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.BASKET);
        List<EventFraction> basketBetbrainMatchesCleaned = Util.cleanFractionList(basketBetbrainMatches);

        BasketMollyBetConnector connector = BasketMollyBetConnectorImpl.getInstance(config, basketChampionshipDecodeMollybetMap, basketBetbrainMatchesCleaned, bbConnector, dbBetbrainConnector);
        List<EventFraction> basketBookmakerOdds = connector.basketOdds();

        logger.debug("basketBookmakerOdds -------");
        logger.debug(basketBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MOLLYBET);
        logger.debug("bookmakerMap -------" +  bookmakerMap);
        bettingUserConnector.insertEventBasketFraction(basketBookmakerOdds, bookmakerMap, Platforms.MOLLYBET);

    }
}
