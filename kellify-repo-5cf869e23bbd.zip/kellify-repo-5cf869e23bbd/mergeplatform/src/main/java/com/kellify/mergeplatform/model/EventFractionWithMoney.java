package com.kellify.mergeplatform.model;


import com.kellify.common.model.EventFraction;

public class EventFractionWithMoney {
    private final EventFraction eventFraction;
    private final int moneyHome;
    private final int moneyDraw;
    private final int moneyAway;

    public EventFractionWithMoney(EventFraction eventFraction, int moneyHome, int moneyDraw, int moneyAway) {
        this.eventFraction = eventFraction;
        this.moneyHome = moneyHome;
        this.moneyDraw = moneyDraw;
        this.moneyAway = moneyAway;
    }

    public int getMoneyHome() {
        return moneyHome;
    }

    public int getMoneyDraw() {
        return moneyDraw;
    }

    public int getMoneyAway() {
        return moneyAway;
    }

    public EventFraction getEventFraction() {
        return eventFraction;
    }

    @Override
    public String toString() {
        return "EventFractionWithMoney{" +
                "eventFraction=" + eventFraction +
                ", moneyHome=" + moneyHome +
                ", moneyDraw=" + moneyDraw +
                ", moneyAway=" + moneyAway +
                '}';
    }
}
