package com.kellify.mergeplatform.db;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.BookmakerOdd;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.basket.EventBasketFraction;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.mergeplatform.model.EventFractionWithRole;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class DbBettingUserConnector extends DbConnector {
    private static final Logger logger = LoggerFactory.getLogger(DbBettingUserConnector.class);

    private static final String TRUNCATE_FOOTBALL_SNAPSHOT = "truncate table football_odds_snapshot";
    private static final String INSERT_FOOTBALL_SNAPSHOT = "insert into football_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_TENNIS_SNAPSHOT = "truncate table tennis_odds_snapshot";
    private static final String INSERT_TENNIS_SNAPSHOT = "insert into tennis_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_BASKET_SNAPSHOT = "truncate table basket_odds_snapshot";
    private static final String INSERT_BASKET_SNAPSHOT = "insert into basket_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_BASEBALL_SNAPSHOT = "truncate table baseball_odds_snapshot";
    private static final String INSERT_BASEBALL_SNAPSHOT = "insert into baseball_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_ICEHOCKEY_SNAPSHOT = "truncate table icehockey_odds_snapshot";
    private static final String INSERT_ICEHOCKEY_SNAPSHOT = "insert into icehockey_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_AMERICANFOOTBALL_SNAPSHOT = "truncate table americanfootball_odds_snapshot";
    private static final String INSERT_AMERICANFOOTBALL_SNAPSHOT = "insert into americanfootball_odds_snapshot (match_date,referrer_id,event_id,odd_id,platform_id,role,odd,bookmaker_id,team,championship,country,continent,betting_type,bookmaker_enabled) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public DbBettingUserConnector(Properties config) {
        this.config = config;
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bettinguser"), config.getProperty("user.bettinguser"), config.getProperty("password.bettinguser"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

    public void truncateFootballSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_FOOTBALL_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    public void insertFootballOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_FOOTBALL_SNAPSHOT);
            FootballBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (FootballBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                //ps.setInt(8, bookmakerMap.get(odd.getBookmakerDescr()));
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.FOOTBALL));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    // basket
    public void truncateBasketSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_BASKET_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }
    public void insertBasketOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASKET_SNAPSHOT);
            BasketBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (BasketBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.BASKET));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    // tennis
    public void truncateTennisSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_TENNIS_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    public void insertTennisOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_TENNIS_SNAPSHOT);
            TennisBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (TennisBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                ps.setInt(12, odd.getBettingType().getNumVal());
                ps.setInt(13, bookmakerAttributes.getHistoryMap().get(SportTypes.TENNIS));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {
                    logger.error("odd not inserted:" + odd);
                    logger.error(ex.getMessage(), ex);
                }
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    // baseball
    public void insertBaseballOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASEBALL_SNAPSHOT);
            BaseballBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (BaseballBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.BASEBALL));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void truncateBaseballSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_BASEBALL_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }
    // americanfootball
    public void insertAmericanFootballOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_AMERICANFOOTBALL_SNAPSHOT);
            AmericanFootballBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (AmericanFootballBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.AMERICAN_FOOTBALL));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void truncateAmericanFootballSnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_AMERICANFOOTBALL_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    // icehockey
    public void insertIcehockeyOddsSnapshot(List<? extends BookmakerOdd> odds, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_ICEHOCKEY_SNAPSHOT);
            IceHockeyBookmakerOdd odd;
            BookmakerAttributes bookmakerAttributes;
            for(int i=0; i<odds.size(); i++) {
                odd = (IceHockeyBookmakerOdd)odds.get(i);
                bookmakerAttributes = bookmakerMap.get(odd.getBookmakerDescr());
                ps.setTimestamp(1, Timestamp.valueOf(odd.getMatchDateM()));
                ps.setString(2, odd.getEventId());
                ps.setString(3, odd.getReferrerId());
                ps.setString(4, "" + odd.getOddId());
                ps.setInt(5, platform.getNumVal());
                ps.setInt(6, odd.getRole().getNumVal());
                ps.setDouble(7, odd.getOdd());
                ps.setInt(8, bookmakerAttributes.getId());
                ps.setString(9, odd.getTeam());
                ps.setString(10, odd.getChampionShip());
                ps.setString(11, odd.getCountry());
                if(odd.getContinent() == null) {
                    ps.setNull(12, Types.VARCHAR);
                } else {
                    ps.setString(12, odd.getContinent());
                }
                ps.setInt(13, odd.getBettingType().getNumVal());
                ps.setInt(14, bookmakerAttributes.getHistoryMap().get(SportTypes.ICE_HOCKEY));
                try {
                    ps.executeUpdate();
                } catch(Exception ex) {}
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void truncateIcehockeySnapshot() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_ICEHOCKEY_SNAPSHOT);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }

    //nuova mergeplatform

    private static final String INSERT_FOOTBALL_FRACTION = "insert into football_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fd,fa,ph,pd,pa,pbh,pbd,pba,delta,id_betting_home,id_betting_draw,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String INSERT_BASKET_FRACTION = "insert into basket_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String INSERT_BASEBALL_FRACTION = "insert into baseball_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String INSERT_AMERICAN_FOOTBALL_FRACTION = "insert into americanfootball_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String INSERT_ICEHOCKEY_HA_FRACTION = "insert into icehockeyHA_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,continent,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String INSERT_TENNIS_FRACTION = "insert into tennis_fraction (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String TRUNCATE_TO_PINNACLE = "truncate table bet_to_pinnacle";
    private static final String INSERT_TO_PINNACLE = "insert into bet_to_pinnacle (referrer_id,event_id,odd_id,platform_id,home_team,away_team,country,championship,bookmaker_id,match_date,fh,fa,ph,pa,pbh,pba,delta,id_betting_home,id_betting_away,betting_type, sport_id) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE referrer_id=?";


    public void insertEventFootballFraction(List<EventFraction> footballFractionList,   Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(footballFractionList == null || footballFractionList.size() == 0) {
            return;
        }
        BookmakerAttributes bookmakerAttributes;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {

            ps = connection.prepareStatement(INSERT_FOOTBALL_FRACTION);
            for(EventFraction fraction : footballFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, platform.getNumVal());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(10,  bookmakerAttributes.getId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFd());
                ps.setDouble(14, fraction.getFa());
                ps.setInt(15, fraction.getPh());
                ps.setInt(16, fraction.getPd());
                ps.setInt(17, fraction.getPa());
                ps.setInt(18, fraction.getPbh());
                ps.setInt(19, fraction.getPbd());
                ps.setInt(20, fraction.getPba());
                ps.setDouble(21, fraction.getDelta());
                ps.setString(22, fraction.getBettingOfferIdH());
                ps.setString(23, fraction.getBettingOfferIdD());
                ps.setString(24, fraction.getBettingOfferIdA());
                ps.setInt(25, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public void insertEventTennisFraction(List<EventFraction> eventFractionList, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(eventFractionList == null || eventFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        BookmakerAttributes bookmakerAttributes;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_TENNIS_FRACTION);
            for(EventFraction fraction : eventFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(9,  bookmakerAttributes.getId());
                ps.setTimestamp(10, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(11, fraction.getFh());
                ps.setDouble(12, fraction.getFa());
                ps.setInt(13, fraction.getPh());
                ps.setInt(14, fraction.getPa());
                ps.setInt(15, fraction.getPbh());
                ps.setInt(16, fraction.getPba());
                ps.setDouble(17, fraction.getDelta());
                ps.setString(18, fraction.getBettingOfferIdH());
                ps.setString(19, fraction.getBettingOfferIdA());
                ps.setInt(20, 1000);
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public void truncateEventFraction() throws SQLException {
        if(connection == null) {
            getConnection();
        }
        Statement st = null;
        try {
            st = connection.createStatement();
            st.execute(TRUNCATE_TO_PINNACLE);
        } finally {
            if(st != null) {
                st.close();
            }
        }
    }


    public void insertEventFraction(List<EventFraction> eventFractionList, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform, SportTypes sport) throws SQLException {
        if(eventFractionList == null || eventFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        BookmakerAttributes bookmakerAttributes;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_TO_PINNACLE);
            for(EventFraction fraction : eventFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(9,  bookmakerAttributes.getId());
                ps.setTimestamp(10, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(11, fraction.getFh());
                ps.setDouble(12, fraction.getFa());
                ps.setInt(13, fraction.getPh());
                ps.setInt(14, fraction.getPa());
                ps.setInt(15, fraction.getPbh());
                ps.setInt(16, fraction.getPba());
                ps.setDouble(17, fraction.getDelta());
                ps.setString(18, fraction.getBettingOfferIdH());
                ps.setString(19, fraction.getBettingOfferIdA());
                ps.setInt(20, 1000);
                ps.setInt(21, sport.getNumVal());
                ps.setString(22, fraction.getReferrerId());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public void insertEventBasketFraction(List<EventFraction> basketFractionList, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(basketFractionList == null || basketFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        BookmakerAttributes bookmakerAttributes;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASKET_FRACTION);
            for(EventFraction fraction : basketFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(10,  bookmakerAttributes.getId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void insertEventBaseballFraction(List<EventFraction> baseballFractionList, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(baseballFractionList == null || baseballFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        BookmakerAttributes bookmakerAttributes;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASEBALL_FRACTION);
            for(EventFraction fraction : baseballFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(10,  bookmakerAttributes.getId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }


    public void insertEventAmericanFootballFraction(List<EventFraction> americanfootballFractionList, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(americanfootballFractionList == null || americanfootballFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        BookmakerAttributes bookmakerAttributes;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_AMERICAN_FOOTBALL_FRACTION);
            for(EventFraction fraction : americanfootballFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(10,  bookmakerAttributes.getId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public void insertEventIcehockeyHAFraction(List<EventFraction> icehockeyFractionList, Map<String, BookmakerAttributes> bookmakerMap, Platforms platform) throws SQLException {
        if(icehockeyFractionList == null || icehockeyFractionList.size() == 0) {
            return;
        }
        if(connection == null) {
            getConnection();
        }
        BookmakerAttributes bookmakerAttributes;
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_ICEHOCKEY_HA_FRACTION);
            for(EventFraction fraction : icehockeyFractionList) {
                ps.setString(1, fraction.getReferrerId());
                ps.setString(2, fraction.getEventId());
                ps.setString(3, fraction.getOddId());
                ps.setInt(4, fraction.getPlatformId());
                ps.setString(5, fraction.getHomeTeam());
                ps.setString(6, fraction.getAwayTeam());
                ps.setString(7, fraction.getCountry());
                ps.setString(8, fraction.getContinent());
                ps.setString(9, fraction.getChampionship());
                bookmakerAttributes = bookmakerMap.get(fraction.getBookmakerLabel());
                ps.setInt(10,  bookmakerAttributes.getId());
                ps.setTimestamp(11, Timestamp.valueOf(fraction.getStartTime()));
                ps.setDouble(12, fraction.getFh());
                ps.setDouble(13, fraction.getFa());
                ps.setInt(14, fraction.getPh());
                ps.setInt(15, fraction.getPa());
                ps.setInt(16, fraction.getPbh());
                ps.setInt(17, fraction.getPba());
                ps.setDouble(18, fraction.getDelta());
                ps.setString(19, fraction.getBettingOfferIdH());
                ps.setString(20, fraction.getBettingOfferIdA());
                ps.setInt(21, fraction.getBettingType().getNumVal());
                ps.executeUpdate();
            }
        } finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    private static final String SELECT_BETBRAIN_FRACTION_FOOTBALL = "{call select_football_fraction()}";
    private static final String SELECT_BETBRAIN_FRACTION_TENNIS = "{call select_tennis_fraction()}";
    private static final String SELECT_BETBRAIN_FRACTION_BASEBALL= "{call select_baseball_fraction()}";
    private static final String SELECT_BETBRAIN_FRACTION_BASKET = "{call select_basket_fraction()}";
    private static final String SELECT_BETBRAIN_FRACTION_ICE_HOCKEY = "{call select_icehockeyHA_fraction()}";
    private static final String SELECT_BETBRAIN_FRACTION_AMERICAN_FOOTBALL = "{call select_americanfootball_fraction()}";

//    public List<EventFraction> loadPlatformEventFractions( SportTypes sportTypes, Map<Integer, String> bookmakerMap) throws SQLException {
//        List<EventFraction> fractions = new ArrayList<>();
//        if(connection == null) {
//            getConnection();
//        }
//        EventFraction fraction;
//        Platforms platforms;
//        CallableStatement ps = null;
//        ResultSet rs = null;
//        try {
//            int bookmakerId;
//            switch (sportTypes){
//                case FOOTBALL:
//                    ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_FOOTBALL);
//                case TENNIS:
//                    ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_TENNIS);
//                case BASEBALL:
//                    ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_BASEBALL);
//                case BASKET:
//                    ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_BASKET);
//                case ICE_HOCKEY:
//                    ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_ICE_HOCKEY);
//                case AMERICAN_FOOTBALL:
//                    ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_AMERICAN_FOOTBALL);
//
//            }
//
//            rs = ps.executeQuery();
//            while(rs.next()) {
//                fraction = new EventFraction();
//                fraction.setPlatformId(rs.getInt("platform_id"));
//                fraction.setReferrerId(rs.getString("referrer_id"));
//                fraction.setEventId(rs.getString("event_id"));
//                fraction.setOddId(rs.getString("odd_id"));
//                fraction.setHomeTeam(rs.getString("home_team"));
//                fraction.setAwayTeam(rs.getString("away_team"));
//                fraction.setCountry(rs.getString("country"));
//                fraction.setContinent(rs.getString("continent"));
//                fraction.setChampionship(rs.getString("championship"));
//                bookmakerId = rs.getInt("bookmaker_id");
//                fraction.setBookmakerId(bookmakerId);
//                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
//                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
//                fraction.setFh(rs.getDouble("fh"));
//                fraction.setFd(rs.getDouble("fd"));
//                fraction.setFa(rs.getDouble("fa"));
//                fraction.setPh(rs.getInt("ph"));
//                fraction.setPd(rs.getInt("pd"));
//                fraction.setPa(rs.getInt("pa"));
//                fraction.setPbh(rs.getInt("pbh"));
//                fraction.setPbd(rs.getInt("pbd"));
//                fraction.setPba(rs.getInt("pba"));
//                fraction.setDelta(rs.getDouble("delta"));
//                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
//                fraction.setBettingOfferIdD(rs.getString("id_betting_draw"));
//                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
//                fraction.setBettingType(BettingType.getEnum(rs.getInt("betting_type")));
//                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
//                fractions.add(fraction);
//            }
//        } finally {
//            if(rs != null) {
//                rs.close();
//            }
//            if(ps != null) {
//                ps.close();
//            }
//        }
//        return fractions;
//    }

    public List<EventFraction> loadFootballPlatformEventFractions(  Map<Integer, String> bookmakerMap) throws SQLException {
        List<EventFraction> fractions = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        EventFraction fraction;
        Platforms platforms;
        CallableStatement ps = null;
        int bookmakerId;

        ResultSet rs = null;
        try {

            ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_FOOTBALL);

            rs = ps.executeQuery();
            while(rs.next()) {
                fraction = new EventFraction();
                fraction.setPlatformId(rs.getInt("platform_id"));
                fraction.setReferrerId(rs.getString("referrer_id"));
                fraction.setEventId(rs.getString("event_id"));
                fraction.setOddId(rs.getString("odd_id"));
                fraction.setHomeTeam(rs.getString("home_team"));
                fraction.setAwayTeam(rs.getString("away_team"));
                fraction.setCountry(rs.getString("country"));
                fraction.setContinent(rs.getString("continent"));
                fraction.setChampionship(rs.getString("championship"));
                bookmakerId = rs.getInt("bookmaker_id");
                fraction.setBookmakerId(bookmakerId);
                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
                fraction.setFh(rs.getDouble("fh"));
                fraction.setFd(rs.getDouble("fd"));
                fraction.setFa(rs.getDouble("fa"));
                fraction.setPh(rs.getInt("ph"));
                fraction.setPd(rs.getInt("pd"));
                fraction.setPa(rs.getInt("pa"));
                fraction.setPbh(rs.getInt("pbh"));
                fraction.setPbd(rs.getInt("pbd"));
                fraction.setPba(rs.getInt("pba"));
                fraction.setDelta(rs.getDouble("delta"));
                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
                fraction.setBettingOfferIdD(rs.getString("id_betting_draw"));
                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
                fraction.setBettingType(BettingType.getEnum(rs.getInt("betting_type")));
                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
                fractions.add(fraction);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return fractions;
    }
    public List<EventFraction> loadBasketPlatformEventFractions(  Map<Integer, String> bookmakerMap) throws SQLException {
        List<EventFraction> fractions = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        EventFraction fraction;
        Platforms platforms;
        CallableStatement ps = null;
        int bookmakerId;

        ResultSet rs = null;
        try {

            ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_BASKET);

            rs = ps.executeQuery();
            while(rs.next()) {
                fraction = new EventFraction();
                fraction.setPlatformId(rs.getInt("platform_id"));
                fraction.setReferrerId(rs.getString("referrer_id"));
                fraction.setEventId(rs.getString("event_id"));
                fraction.setOddId(rs.getString("odd_id"));
                fraction.setHomeTeam(rs.getString("home_team"));
                fraction.setAwayTeam(rs.getString("away_team"));
                fraction.setCountry(rs.getString("country"));
                fraction.setContinent(rs.getString("continent"));
                fraction.setChampionship(rs.getString("championship"));
                bookmakerId = rs.getInt("bookmaker_id");
                fraction.setBookmakerId(bookmakerId);
                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
                fraction.setFh(rs.getDouble("fh"));
                fraction.setFa(rs.getDouble("fa"));
                fraction.setPh(rs.getInt("ph"));
                fraction.setPa(rs.getInt("pa"));
                fraction.setPbh(rs.getInt("pbh"));
                fraction.setPba(rs.getInt("pba"));
                fraction.setDelta(rs.getDouble("delta"));
                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
                fraction.setBettingType(BettingType.getEnum(rs.getInt("betting_type")));
                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
                fractions.add(fraction);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return fractions;
    }
    public List<EventFraction> loadBaseballPlatformEventFractions(  Map<Integer, String> bookmakerMap) throws SQLException {
        List<EventFraction> fractions = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        EventFraction fraction;
        Platforms platforms;
        CallableStatement ps = null;
        int bookmakerId;

        ResultSet rs = null;
        try {

            ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_BASEBALL);

            rs = ps.executeQuery();
            while(rs.next()) {
                fraction = new EventFraction();
                fraction.setPlatformId(rs.getInt("platform_id"));
                fraction.setReferrerId(rs.getString("referrer_id"));
                fraction.setEventId(rs.getString("event_id"));
                fraction.setOddId(rs.getString("odd_id"));
                fraction.setHomeTeam(rs.getString("home_team"));
                fraction.setAwayTeam(rs.getString("away_team"));
                fraction.setCountry(rs.getString("country"));
                fraction.setContinent(rs.getString("continent"));
                fraction.setChampionship(rs.getString("championship"));
                bookmakerId = rs.getInt("bookmaker_id");
                fraction.setBookmakerId(bookmakerId);
                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
                fraction.setFh(rs.getDouble("fh"));
                fraction.setFa(rs.getDouble("fa"));
                fraction.setPh(rs.getInt("ph"));
                fraction.setPa(rs.getInt("pa"));
                fraction.setPbh(rs.getInt("pbh"));
                fraction.setPba(rs.getInt("pba"));
                fraction.setDelta(rs.getDouble("delta"));
                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
                fraction.setBettingType(null);
                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
                fractions.add(fraction);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return fractions;

    }

    public List<EventFraction> loadTennisPlatformEventFractions(  Map<Integer, String> bookmakerMap) throws SQLException {
        List<EventFraction> fractions = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        EventFraction fraction;
        Platforms platforms;
        CallableStatement ps = null;
        int bookmakerId;

        ResultSet rs = null;
        try {

            ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_TENNIS);

            rs = ps.executeQuery();
            while(rs.next()) {
                fraction = new EventFraction();
                fraction.setPlatformId(rs.getInt("platform_id"));
                fraction.setReferrerId(rs.getString("referrer_id"));
                fraction.setEventId(rs.getString("event_id"));
                fraction.setOddId(rs.getString("odd_id"));
                fraction.setHomeTeam(rs.getString("home_team"));
                fraction.setAwayTeam(rs.getString("away_team"));
                fraction.setCountry(rs.getString("country"));
                fraction.setChampionship(rs.getString("championship"));
                bookmakerId = rs.getInt("bookmaker_id");
                fraction.setBookmakerId(bookmakerId);
                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
                fraction.setFh(rs.getDouble("fh"));
                fraction.setFa(rs.getDouble("fa"));
                fraction.setPh(rs.getInt("ph"));
                fraction.setPa(rs.getInt("pa"));
                fraction.setPbh(rs.getInt("pbh"));
                fraction.setPba(rs.getInt("pba"));
                fraction.setDelta(rs.getDouble("delta"));
                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
                fraction.setBettingType(null);
                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
                fractions.add(fraction);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return fractions;
    }

    public List<EventFraction> loadIceHockeyPlatformEventFractions(  Map<Integer, String> bookmakerMap) throws SQLException {
        List<EventFraction> fractions = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        EventFraction fraction;
        Platforms platforms;
        CallableStatement ps = null;
        int bookmakerId;

        ResultSet rs = null;
        try {

            ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_ICE_HOCKEY);

            rs = ps.executeQuery();
            while(rs.next()) {
                fraction = new EventFraction();
                fraction.setPlatformId(rs.getInt("platform_id"));
                fraction.setReferrerId(rs.getString("referrer_id"));
                fraction.setEventId(rs.getString("event_id"));
                fraction.setOddId(rs.getString("odd_id"));
                fraction.setHomeTeam(rs.getString("home_team"));
                fraction.setAwayTeam(rs.getString("away_team"));
                fraction.setCountry(rs.getString("country"));
                fraction.setContinent(rs.getString("continent"));
                fraction.setChampionship(rs.getString("championship"));
                bookmakerId = rs.getInt("bookmaker_id");
                fraction.setBookmakerId(bookmakerId);
                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
                fraction.setFh(rs.getDouble("fh"));
                fraction.setFa(rs.getDouble("fa"));
                fraction.setPh(rs.getInt("ph"));
                fraction.setPa(rs.getInt("pa"));
                fraction.setPbh(rs.getInt("pbh"));
                fraction.setPba(rs.getInt("pba"));
                fraction.setDelta(rs.getDouble("delta"));
                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
                fraction.setBettingType(BettingType.getEnum(rs.getInt("betting_type")));
                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
                fractions.add(fraction);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return fractions;

    }

    public List<EventFraction> loadAmericanFootballPlatformEventFractions(  Map<Integer, String> bookmakerMap) throws SQLException {
        List<EventFraction> fractions = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        EventFraction fraction;
        Platforms platforms;
        CallableStatement ps = null;
        int bookmakerId;

        ResultSet rs = null;
        try {

            ps = connection.prepareCall(SELECT_BETBRAIN_FRACTION_AMERICAN_FOOTBALL);

            rs = ps.executeQuery();
            while(rs.next()) {
                fraction = new EventFraction();
                fraction.setPlatformId(rs.getInt("platform_id"));
                fraction.setReferrerId(rs.getString("referrer_id"));
                fraction.setEventId(rs.getString("event_id"));
                fraction.setOddId(rs.getString("odd_id"));
                fraction.setHomeTeam(rs.getString("home_team"));
                fraction.setAwayTeam(rs.getString("away_team"));
                fraction.setCountry(rs.getString("country"));
                fraction.setContinent(rs.getString("continent"));
                fraction.setChampionship(rs.getString("championship"));
                bookmakerId = rs.getInt("bookmaker_id");
                fraction.setBookmakerId(bookmakerId);
                fraction.setBookmakerLabel(bookmakerMap.get(bookmakerId));
                fraction.setStartTime(rs.getTimestamp("match_date").toLocalDateTime());
                fraction.setFh(rs.getDouble("fh"));
                fraction.setFa(rs.getDouble("fa"));
                fraction.setPh(rs.getInt("ph"));
                fraction.setPa(rs.getInt("pa"));
                fraction.setPbh(rs.getInt("pbh"));
                fraction.setPba(rs.getInt("pba"));
                fraction.setDelta(rs.getDouble("delta"));
                fraction.setBettingOfferIdH(rs.getString("id_betting_home"));
                fraction.setBettingOfferIdA(rs.getString("id_betting_away"));
                fraction.setBettingType(BettingType.getEnum(rs.getInt("betting_type")));
                fraction.setSportType(SportTypes.getEnum(rs.getInt("sport_id")));
                fractions.add(fraction);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return fractions;

    }

}
