package com.kellify.mergeplatform.matchbook;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import java.util.List;

public interface BasketballMatchBookConnector {
    List<EventFraction> basketOdds() throws Exception;
}
