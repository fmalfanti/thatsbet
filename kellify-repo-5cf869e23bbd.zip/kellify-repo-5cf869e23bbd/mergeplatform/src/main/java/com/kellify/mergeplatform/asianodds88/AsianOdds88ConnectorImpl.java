package com.kellify.mergeplatform.asianodds88;

import com.kellify.common.OddRole;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.mergeplatform.asianodds88.decoder.MatchDecode;
import com.kellify.mergeplatform.asianodds88.model.*;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.MatchDecodeState;
import com.kellify.common.asianodds88.SportIds;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.email.EmailMergePlatform;
import com.kellify.mergeplatform.model.Match;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class AsianOdds88ConnectorImpl implements AsianOdds88Connector {
    private static final Logger logger = LoggerFactory.getLogger(AsianOdds88ConnectorImpl.class);

    private Properties config;
    private Map<String, ChampionshipDecode> championshipDecodeMap;
    private List<EventFraction> referMatches;
    private DbBookmakerBettingConnector bbConnector;

    private List<? super MatchWithContinent> notDecodedMatches;
    private List<? super Match> notDecodedMatchesForTennis;

    private AsianOdds88ConnectorImpl(Properties config, Map<String, ChampionshipDecode> championshipDecodeMap, List<EventFraction> referMatches, DbBookmakerBettingConnector bbConnector) {
        this.config = config;
        this.championshipDecodeMap = championshipDecodeMap;
        this.referMatches = referMatches;
        this.bbConnector = bbConnector;
        notDecodedMatches = new ArrayList<>();
        notDecodedMatchesForTennis = new ArrayList<>();
    }

    public static AsianOdds88Connector getInstance(Properties config, Map<String, ChampionshipDecode> championshipDecodeMap, List<EventFraction>referMatches, DbBookmakerBettingConnector bbConnector) {
        return new AsianOdds88ConnectorImpl(config, championshipDecodeMap, referMatches, bbConnector);
    }

    @Override
    public List<EventFraction> footballOdds(Map<String, Integer> bookmakerMapID) throws Exception {
        AsianOdds88Protocol protocol = new AsianOdds88Protocol(config);
        String feeds = protocol.responseBody(SportTypes.FOOTBALL);
        ProviderResponse providerResponse = new ProviderResponse(feeds, SportIds.FOOTBALL);
        List<FootballAsianOdds88Match> matches = (List<FootballAsianOdds88Match>)providerResponse.sportMatches();
        logger.info("matches count:" + matches.size());
        logger.debug("matches:" + matches);
        MatchDecode matchDecode = new MatchDecode(referMatches, championshipDecodeMap, bbConnector);
        List<EventFraction> oddList = new ArrayList<>();
        List<EventFraction> decodedMatches;
        ImmutablePair<MatchDecodeState, List<EventFraction>> decodedMatchWrap;
        int decoded = 0;
        int notDecoded = 0;
        for(FootballAsianOdds88Match match : matches) {
            if(!championshipDecodeMap.containsKey(match.getLeagueName())){
                continue;
            }
            decodedMatchWrap = matchDecode.decodeFootball(match, bookmakerMapID);
            if(decodedMatchWrap != null) {
                if(decodedMatchWrap.getLeft() == MatchDecodeState.OK) {
                    decodedMatches = decodedMatchWrap.getRight();
                    logger.debug(decodedMatches.toString());
                    oddList.addAll(decodedMatches);
                    decoded++;
                } else if(decodedMatchWrap.getLeft() == MatchDecodeState.NOT_DECODED) {
                    notDecodedMatches.add(match);
                    notDecoded++;
                }
            }
        }
        logger.info("decoded matches count:" + decoded);
        logger.info("NOT decoded matches count:" + notDecoded);
//        if(notDecoded > 0  & !referMatches.isEmpty()) {
//            // email not decoded matches
//            EmailMergePlatform emailSender = EmailMergePlatform.getSender(config, Platforms.ASIANODDS88);
//            boolean sent = emailSender.sendEmailMatchesNotDecoded(referMatches, notDecodedMatches,SportTypes.getStringEnum(1));
//        }
        return oddList;
    }

    @Override
    public List<EventFraction> basketOdds(Map<String, Integer> bookmakerMapID) throws Exception {
        AsianOdds88Protocol protocol = new AsianOdds88Protocol(config);
        String feeds = protocol.responseBody(SportTypes.BASKET);
        ProviderResponse providerResponse = new ProviderResponse(feeds, SportIds.BASKET);
        List<BasketAsianOdds88Match> matches = (List<BasketAsianOdds88Match>)providerResponse.sportMatches();
        logger.info("matches count:" + matches.size());
        logger.info("matches:" + matches);
        MatchDecode matchDecode = new MatchDecode(referMatches, championshipDecodeMap, bbConnector);
        List<EventFraction> oddList = new ArrayList<>();
        ImmutablePair<MatchDecodeState, List<EventFraction>> decodedMatchWrap;
        List<EventFraction> decodedMatches;
        int decoded = 0;
        int notDecoded = 0;
        for(BasketAsianOdds88Match match : matches) {
            decodedMatchWrap = matchDecode.decodeBasket(match, bookmakerMapID);
            if(decodedMatchWrap != null) {
                if(decodedMatchWrap.getLeft() == MatchDecodeState.OK) {
                    decodedMatches = decodedMatchWrap.getRight();
                    logger.debug(decodedMatches.toString());
                    oddList.addAll(decodedMatches);
                    decoded++;
                } else if(decodedMatchWrap.getLeft() == MatchDecodeState.NOT_DECODED) {
                    notDecodedMatches.add(match);
                    notDecoded++;
                }
            }
        }
        logger.info("decoded matches count:" + decoded);
        logger.info("NOT decoded matches count:" + notDecoded);
//        if(notDecoded > 0  & !referMatches.isEmpty()) {
//            // email not decoded matches
//            EmailMergePlatform emailSender = EmailMergePlatform.getSender(config, Platforms.ASIANODDS88);
//            boolean sent = emailSender.sendEmailMatchesNotDecoded(referMatches, notDecodedMatches,SportTypes.getStringEnum(3));
//        }
      //  logger.debug("oddList:" + oddList);
        return oddList;
    }

    @Override
    public List<EventFraction> tennisOdds(Map<String, Integer> bookmakerMapID) throws Exception {
        AsianOdds88Protocol protocol = new AsianOdds88Protocol(config);
        String feeds = protocol.responseBody(SportTypes.TENNIS);
        ProviderResponse providerResponse = new ProviderResponse(feeds, SportIds.TENNIS);
        List<TennisAsianOdds88Match> matches = (List<TennisAsianOdds88Match>)providerResponse.sportMatches();
        logger.info("matches count:" + matches.size());
        logger.info("matches:" + matches);
        MatchDecode matchDecode = new MatchDecode(referMatches, null, bbConnector);
        List<EventFraction> oddList = new ArrayList<>();
        ImmutablePair<MatchDecodeState, List<EventFraction>> decodedMatchWrap;
        List<EventFraction> decodedMatches;
        int decoded = 0;
        int notDecoded = 0;
        for(TennisAsianOdds88Match match : matches) {
            decodedMatchWrap = matchDecode.decodeTennis(match, bookmakerMapID);
            if(decodedMatchWrap != null) {
                if(decodedMatchWrap.getLeft() == MatchDecodeState.OK) {
                    decodedMatches = decodedMatchWrap.getRight();
                    logger.debug(decodedMatches.toString());
                    oddList.addAll(decodedMatches);
                    decoded++;
                } else if(decodedMatchWrap.getLeft() == MatchDecodeState.NOT_DECODED) {
                    notDecodedMatchesForTennis.add(match);
                    notDecoded++;
                }
            }
        }
        logger.info("decoded matches count:" + decoded);
        logger.info("NOT decoded matches count:" + notDecoded);
//        if(notDecoded > 0  & !referMatches.isEmpty()) {
//            // email not decoded matches
//            EmailMergePlatform emailSender = EmailMergePlatform.getSender(config, Platforms.ASIANODDS88);
//            boolean sent = emailSender.sendEmailMatchesNotDecoded(referMatches, notDecodedMatches,SportTypes.getStringEnum(3));
//        }
        //  logger.debug("oddList:" + oddList);
        return oddList;
    }
}
