package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.asianodds88.AsianOdds88Connector;
import com.kellify.mergeplatform.asianodds88.AsianOdds88ConnectorImpl;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AsianOdds88Tennis extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(AsianOdds88Basket.class);

    protected AsianOdds88Tennis(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {

        List<EventFraction> betbrainMatches = (List<EventFraction>) providerPilot.pilotMatches(SportTypes.TENNIS);

        List<EventFraction> betbrainMatchesCleaned = Util.cleanFractionList(betbrainMatches);
        AsianOdds88Connector asianOdds88Connector = AsianOdds88ConnectorImpl.getInstance(config, null, betbrainMatchesCleaned, bbConnector);
        Map<String, Integer> bookmakerMapID = bbConnector.bookmakerMapID(Platforms.ASIANODDS88);
        List<EventFraction> asianOdds88TennisOdds = asianOdds88Connector.tennisOdds(bookmakerMapID);
        logger.debug("asianOdds88TennisOdds -------");
        logger.debug(asianOdds88TennisOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.ASIANODDS88);
        bettingUserConnector.insertEventTennisFraction(asianOdds88TennisOdds, bookmakerMap, Platforms.ASIANODDS88);
    }
}

