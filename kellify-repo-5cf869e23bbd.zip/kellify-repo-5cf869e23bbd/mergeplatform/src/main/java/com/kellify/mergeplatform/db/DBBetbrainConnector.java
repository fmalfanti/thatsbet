package com.kellify.mergeplatform.db;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.BookmakerOdd;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.americanFootball.AmericanFootballBookmakerOdd;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;
import com.kellify.common.mollybet.EventMollybet;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.mergeplatform.model.*;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.mergeplatform.mollybet.model.MollybetMatch;
import com.kellify.mergeplatform.mollybet.model.TennisMollyBetMatch;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class DBBetbrainConnector extends DbConnector {
    private static final Logger log = LoggerFactory.getLogger(DBBetbrainConnector.class);

    private static final String SELECT_FOOTBALL_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from FootballOdds where participantName is not null order by eventId";
    //private static final String SELECT_FOOTBALL_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM FootballOdds order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_FOOTBALL_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM FootballOdds ";
    private static final String SELECT_FOOTBALL_BETBRAIN_ODDS_SUFFIX = " order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_FOOTBALL_BETBRAIN_MATCHES_BY_ID = "select eventId,participantName,role from FootballOdds where participantName is not null group by eventId,participantName,role";

    //private static final String SELECT_TENNIS_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM TennisOdds order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_TENNIS_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM TennisOdds ";
    private static final String SELECT_TENNIS_BETBRAIN_ODDS_SUFFIX = " order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_TENNIS_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from TennisOdds where participantName is not null order by eventId";

    private static final String SELECT_BASEBALL_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from BaseballOdds where participantName is not null order by eventId";
    private static final String SELECT_BASEBALL_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM BaseballOdds order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_BASEBALL_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM BaseballOdds ";
    private static final String SELECT_BASEBALL_BETBRAIN_ODDS_SUFFIX =" order by eventId,participantName,bookmaker,role,lastChangedTime";

    private static final String SELECT_BASEBALL_BETBRAIN_MATCHES_BY_ID = "select eventId,participantName,role from BaseballOdds where participantName is not null group by eventId,participantName,role";

    private static final String SELECT_BASKET_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from BasketOdds where participantName is not null order by eventId";
    //private static final String SELECT_BASKET_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM BasketOdds order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_BASKET_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM BasketOdds ";
    private static final String SELECT_BASKET_BETBRAIN_ODDS_SUFFIX = "order by eventId,participantName,bookmaker,role,lastChangedTime";

    private static final String SELECT_BASKET_BETBRAIN_MATCHES_BY_ID = "select eventId,participantName,role from BasketOdds where participantName is not null group by eventId,participantName,role";

    private static final String SELECT_ICEHOCKEY_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from IceHockeyOddsHA where participantName is not null order by eventId";
    //private static final String SELECT_ICEHOCKEY_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM IceHockeyOddsHA order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_ICEHOCKEY_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM IceHockeyOddsHA ";
    private static final String SELECT_ICEHOCKEY_BETBRAIN_ODDS_SUFFIX = "and participantName is not null order by eventId,participantName,bookmaker,role,lastChangedTime";

    private static final String SELECT_ICEHOCKEY_BETBRAIN_MATCHES_BY_ID = "select eventId,participantName,role from IceHockeyOddsHA where participantName is not null group by eventId,participantName,role";

    private static final String SELECT_ICEHOCKEY_HDA_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from IceHockeyOddsHDA where participantName is not null order by eventId";
    //private static final String SELECT_ICEHOCKEY_HDA_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM IceHockeyOddsHA order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_ICEHOCKEY_HDA_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM IceHockeyOddsHDA ";
    private static final String SELECT_ICEHOCKEY_HDA_BETBRAIN_ODDS_SUFFIX = " order by eventId,participantName,bookmaker,role,lastChangedTime";

    private static final String SELECT_AMERICANFOOTBALL_BETBRAIN_MATCHES = "select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from AmericanFootballOdds where participantName is not null order by eventId";
    //private static final String SELECT_BASKET_BETBRAIN_ODDS = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM BasketOdds order by eventId,participantName,bookmaker,role,lastChangedTime";
    private static final String SELECT_AMERICANFOOTBALL_BETBRAIN_ODDS_PREFIX = "select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM AmericanFootballOdds ";
    private static final String SELECT_AMERICANFOOTBALL_BETBRAIN_ODDS_SUFFIX = " and participantName is not null order by eventId,participantName,bookmaker,role,lastChangedTime";

    private static final String SELECT_ICEHOCKEY_HDA_BETBRAIN_MATCHES_BY_ID = "select eventId,participantName,role from IceHockeyOddsHDA where participantName is not null group by eventId,participantName,role";

    //mollybet

    private static final String SELECT_MOLLYBET_AMERICAN_FOOTBALL_MATCH = " select event_id,home_team,away_team,match_date,championship_id,championship_name,sport from AmericanFootballMollybetEvent";
    private static final String SELECT_MOLLYBET_FOOTBALL_MATCH = " select event_id,home_team,away_team,match_date,championship_id,championship_name,sport from FootballMollybetEvent";
    private static final String SELECT_MOLLYBET_BASKET_MATCH = " select event_id,home_team,away_team,match_date,championship_id,championship_name,sport from BasketMollybetEvent";
    private static final String SELECT_MOLLYBET_TENNIS_MATCH = " select event_id,home_team,away_team,match_date,championship_id,championship_name,sport from TennisMollybetEvent";
    private static final String SELECT_MOLLYBET_ICEHOCKEY_MATCH = " select event_id,home_team,away_team,match_date,championship_id,championship_name,sport from IceHockeyMollybetEvent";

    public DBBetbrainConnector(Properties config) {
        this.config = config;
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.betbrain"), config.getProperty("user.betbrain"), config.getProperty("password.betbrain"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

    // football
    public Map<String, List<FootballMatch>> footballBetbrainMatches(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<FootballMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String campionato = null;
        String nazione = null;
        String role = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        FootballMatch footballMatch;
        List<FootballMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId from FootballOdds where participantName is not null order by eventId
        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");

                if(eventId != eventIdPrev && !first) {
                    footballMatch = new FootballMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                    champDecode = championshipMap.get(campionato + "_" + nazione);
                    if(champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                        footballMatch.setCountry(nazione);
                        footballMatch.setContinent(champDecode.getContinent());
                        footballMatch.setLeagueName(champDecode.getChampionship());
                        mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                        matches = map.get(mapKey);
                        if(matches == null) {
                            matches = new ArrayList<>();
                            map.put(mapKey, matches);
                        }
                        matches.add(footballMatch);
                    }
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }

            if(hasRows) {
                footballMatch = new FootballMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                champDecode = championshipMap.get(campionato + "_" + nazione);
                if (champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                    footballMatch.setCountry(nazione);
                    footballMatch.setContinent(champDecode.getContinent());
                    footballMatch.setLeagueName(champDecode.getChampionship());
                    mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                    matches = map.get(mapKey);
                    if (matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(footballMatch);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }
    private String buildInClause(List<String> bookmakerLabels) {
        if(bookmakerLabels.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("  where bookmaker in (");
        for(int i=0; i<bookmakerLabels.size(); i++) {
            if(i>0) {
                sb.append(",");
            }
            sb.append("?");
        }
        sb.append(")");
        return sb.toString();
    }

    public List<FootballBookmakerOdd> footballBetbrainOdds(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<FootballBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        //select eventId,bettingOfferId,role,odds,bookmaker,participantName,eventName,location,date,bettingTypeId,lastChangedTime FROM FootballOdds order by eventId,participantName,bookmaker,role,lastChangedTime
        String query = SELECT_FOOTBALL_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_FOOTBALL_BETBRAIN_ODDS_SUFFIX;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        FootballBookmakerOdd footballBookmakerOdd;
        FootballBookmakerOdd previousFootballBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        MatchWithContinent match;
        String championship;
        String country;
        String continent;
        String championshipKey;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        ChampionshipDecode championshipDecode;
        try {
            Map<Long, MatchWithContinent> footballBetbrainMatches = footballBetbrainMatchesById();
            ps = connection.prepareStatement(query);
            for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                championshipKey = championship + "_" + country;
                championshipDecode = championshipMap.get(championshipKey);
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                if(championshipDecode != null) {
                    continent = championshipDecode.getContinent();
                    championship = championshipDecode.getChampionship();
                    if(team == null) {
                        match = footballBetbrainMatches.get(eventId);
                        if(match != null) {
                            footballBookmakerOdd = new FootballBookmakerOdd(
                                    "" + eventId,
                                    "" + eventId,
                                    "" + oddId,
                                    Platforms.BETBRAIN.getNumVal(),
                                    OddRole.valueOf(rs.getString("role").toUpperCase()),
                                    rs.getDouble("odds"),
                                    0,
                                    match.getHomeTeam() + " - " + match.getAwayTeam(),
                                    championship,
                                    country,
                                    continent,
                                    rs.getTimestamp("date").toLocalDateTime(),
                                    BettingType.getEnum(bettingType));
                            footballBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));

                            if(previousFootballBookmakerOdd == null) {
                                previousFootballBookmakerOdd = footballBookmakerOdd.copy();
                                previousLastChanged = lastChanged;
                                continue;
                            } else {
                                if(isSameOdd(previousFootballBookmakerOdd, footballBookmakerOdd) && previousLastChanged < lastChanged) {
                                    previousFootballBookmakerOdd = footballBookmakerOdd.copy();
                                    previousLastChanged = lastChanged;
                                    continue;
                                }
                            }
                            oddList.add(previousFootballBookmakerOdd);
                            previousFootballBookmakerOdd = footballBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                        }
                    } else {
                        footballBookmakerOdd = new FootballBookmakerOdd(
                                "" + eventId,
                                "" + eventId,
                                "" + oddId,
                                Platforms.BETBRAIN.getNumVal(),
                                OddRole.valueOf(rs.getString("role").toUpperCase()),
                                rs.getDouble("odds"),
                                0,
                                team,
                                championship,
                                country,
                                continent,
                                rs.getTimestamp("date").toLocalDateTime(),
                                BettingType.getEnum(bettingType));
                        footballBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));
                        if(previousFootballBookmakerOdd == null) {
                            previousFootballBookmakerOdd = footballBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                            continue;
                        } else {
                            if(isSameOdd(previousFootballBookmakerOdd, footballBookmakerOdd) && previousLastChanged < lastChanged) {
                                previousFootballBookmakerOdd = footballBookmakerOdd.copy();
                                previousLastChanged = lastChanged;
                                continue;
                            }
                        }
                        oddList.add(previousFootballBookmakerOdd);
                        previousFootballBookmakerOdd = footballBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                    }
                }
            }
            if(previousFootballBookmakerOdd != null) {
                oddList.add(previousFootballBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }
    private Map<Long, MatchWithContinent> footballBetbrainMatchesById() throws SQLException {
        Map<Long, MatchWithContinent> matchesById = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        MatchWithContinent match;
        long eventId = 0;
        String team;
        OddRole role;
        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_BETBRAIN_MATCHES_BY_ID);
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                team = rs.getString("participantName");
                role = OddRole.valueOf(rs.getString("role").toUpperCase());
                match = matchesById.get(eventId);
                if(match == null) {
                    if(role == OddRole.HOME) {
                        match = new MatchWithContinent("" + eventId, "" + eventId, team, null, null, null, null,null);
                    } else {
                        match = new MatchWithContinent("" + eventId, "" + eventId, null, team, null, null, null,null);
                    }
                } else {
                    if(role == OddRole.HOME) {
                        match = new MatchWithContinent("" + eventId, "" + eventId, team, match.getAwayTeam(), null, null, null,null);
                    } else {
                        match = new MatchWithContinent("" + eventId, "" + eventId, match.getHomeTeam(), team, null, null, null,null);
                    }
                }
                matchesById.put(eventId, match);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return matchesById;
    }

    // tennis
    public Map<String, List<TennisMatch>> tennisBetbrainMatches(Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<TennisMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String campionato = null;
        String nazione = null;
        String role = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        TennisMatch tennisMatch;
        List<TennisMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId
        try {
            ps = connection.prepareStatement(SELECT_TENNIS_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");

                if(eventId != eventIdPrev && !first) {
                    tennisMatch = new TennisMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, date, BettingType.getEnum(bettingType));
                    tennisMatch.setLeagueName(campionato);
                    tennisMatch.setCountry(nazione);
                    mapKey = Util.makeMapKey(date);
                    matches = map.get(mapKey);
                    if(matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(tennisMatch);
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }

            if(hasRows) {
                tennisMatch = new TennisMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, date, BettingType.getEnum(bettingType));
                tennisMatch.setLeagueName(campionato);
                tennisMatch.setCountry(nazione);
                mapKey = Util.makeMapKey(date);
                matches = map.get(mapKey);
                if (matches == null) {
                    matches = new ArrayList<>();
                    map.put(mapKey, matches);
                }
                matches.add(tennisMatch);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }

    public List<TennisBookmakerOdd> tennisBetbrainOdds(Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<TennisBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        String query = SELECT_TENNIS_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_TENNIS_BETBRAIN_ODDS_SUFFIX;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        String championship;
        String country;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        TennisBookmakerOdd tennisBookmakerOdd;
        TennisBookmakerOdd previousTennisBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        try {
            ps = connection.prepareStatement(query);
            for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                tennisBookmakerOdd = new TennisBookmakerOdd(
                        "" + eventId,
                        "" + eventId,
                        "" + oddId,
                        Platforms.BETBRAIN.getNumVal(),
                        OddRole.valueOf(rs.getString("role").toUpperCase()),
                        rs.getDouble("odds"),
                        0,
                        team,
                        championship,
                        country,
                        rs.getTimestamp("date").toLocalDateTime(),
                        BettingType.getEnum(bettingType));
                tennisBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));

                if(previousTennisBookmakerOdd == null) {
                    previousTennisBookmakerOdd = tennisBookmakerOdd.copy();
                    previousLastChanged = lastChanged;
                    continue;
                } else {
                    if(isSameOdd(previousTennisBookmakerOdd, tennisBookmakerOdd) && previousLastChanged < lastChanged) {
                        previousTennisBookmakerOdd = tennisBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                        continue;
                    }
                }

                oddList.add(previousTennisBookmakerOdd);
                previousTennisBookmakerOdd = tennisBookmakerOdd.copy();
                previousLastChanged = lastChanged;
            }
            if(previousTennisBookmakerOdd != null) {
                oddList.add(previousTennisBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }
    private boolean isSameOdd(BookmakerOdd previousBookmakerOdd, BookmakerOdd bookmakerOdd) {
        if(previousBookmakerOdd.getEventId().equals(bookmakerOdd.getEventId())
                && previousBookmakerOdd.getRole() == bookmakerOdd.getRole()
                && previousBookmakerOdd.getTeam().equals(bookmakerOdd.getTeam())
                && previousBookmakerOdd.getBookmakerDescr().equals(bookmakerOdd.getBookmakerDescr())) {
            return true;
        }
        return false;
    }

    //baseball
    public Map<String, List<BaseballMatch>> baseballBetbrainMatches(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<BaseballMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String role = null;
        String campionato = null;
        String nazione = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        BaseballMatch baseballMatch;
        List<BaseballMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId
        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");
                if(eventId != eventIdPrev && !first) {
                    baseballMatch = new BaseballMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                    champDecode = championshipMap.get(campionato + "_" + nazione);
                    if(champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                        baseballMatch.setCountry(nazione);
                        baseballMatch.setContinent(champDecode.getContinent());
                        baseballMatch.setLeagueName(champDecode.getChampionship());
                        mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                        matches = map.get(mapKey);
                        if(matches == null) {
                            matches = new ArrayList<>();
                            map.put(mapKey, matches);
                        }
                        matches.add(baseballMatch);
                    }
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }

            if(hasRows) {
                baseballMatch = new BaseballMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                champDecode = championshipMap.get(campionato + "_" + nazione);
                if (champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                    baseballMatch.setCountry(nazione);
                    baseballMatch.setContinent(champDecode.getContinent());
                    baseballMatch.setLeagueName(champDecode.getChampionship());
                    mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                    matches = map.get(mapKey);
                    if (matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(baseballMatch);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }

    public List<BaseballBookmakerOdd> baseballBetbrainOdds(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<BaseballBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        String query = SELECT_BASEBALL_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_BASEBALL_BETBRAIN_ODDS_SUFFIX;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        BaseballBookmakerOdd baseballBookmakerOdd;
        BaseballBookmakerOdd previousBaseballBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        String championship;
        String country;
        String continent;
        String championshipKey;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        ChampionshipDecode championshipDecode;
        try {
            ps = connection.prepareStatement(query);
            for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                championshipKey = championship + "_" + country;
                championshipDecode = championshipMap.get(championshipKey);
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                if(championshipDecode != null) {
                    continent = championshipDecode.getContinent();
                    championship = championshipDecode.getChampionship();
                    baseballBookmakerOdd = new BaseballBookmakerOdd(
                            "" + eventId,
                            "" + eventId,
                            "" + oddId,
                            Platforms.BETBRAIN.getNumVal(),
                            OddRole.valueOf(rs.getString("role").toUpperCase()),
                            rs.getDouble("odds"),
                            0,
                            team,
                            championship,
                            country,
                            continent,
                            rs.getTimestamp("date").toLocalDateTime(),
                            BettingType.getEnum(bettingType));
                    baseballBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));
                    if(previousBaseballBookmakerOdd == null) {
                        previousBaseballBookmakerOdd = baseballBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                        continue;
                    } else {
                        if(isSameOdd(previousBaseballBookmakerOdd, baseballBookmakerOdd) && previousLastChanged < lastChanged) {
                            previousBaseballBookmakerOdd = baseballBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                            continue;
                        }
                    }
                    oddList.add(previousBaseballBookmakerOdd);
                    previousBaseballBookmakerOdd = baseballBookmakerOdd.copy();
                    previousLastChanged = lastChanged;
                }
            }
            if(previousBaseballBookmakerOdd != null) {
                oddList.add(previousBaseballBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }

    // basket
    public Map<String, List<BasketMatch>> basketBetbrainMatches(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<BasketMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String campionato = null;
        String nazione = null;
        String role = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        BasketMatch basketMatch;
        List<BasketMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId
        try {
            ps = connection.prepareStatement(SELECT_BASKET_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");

                if(eventId != eventIdPrev && !first) {
                    basketMatch = new BasketMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                    champDecode = championshipMap.get(campionato + "_" + nazione);
                    if(champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                        basketMatch.setCountry(nazione);
                        basketMatch.setContinent(champDecode.getContinent());
                        basketMatch.setLeagueName(champDecode.getChampionship());
                        mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                        matches = map.get(mapKey);
                        if(matches == null) {
                            matches = new ArrayList<>();
                            map.put(mapKey, matches);
                        }
                        matches.add(basketMatch);
                    }
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }

            if(hasRows) {
                basketMatch = new BasketMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                champDecode = championshipMap.get(campionato + "_" + nazione);
                if (champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                    basketMatch.setCountry(nazione);
                    basketMatch.setContinent(champDecode.getContinent());
                    basketMatch.setLeagueName(champDecode.getChampionship());
                    mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                    matches = map.get(mapKey);
                    if (matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(basketMatch);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }

    public List<BasketBookmakerOdd> basketBetbrainOdds(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<BasketBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        String query = SELECT_BASKET_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_BASKET_BETBRAIN_ODDS_SUFFIX;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        BasketBookmakerOdd baseballBookmakerOdd;
        BasketBookmakerOdd previousBaseballBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        MatchWithContinent match;
        String championship;
        String country;
        String continent;
        String championshipKey;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        ChampionshipDecode championshipDecode;
        try {
            ps = connection.prepareStatement(query);
            for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                championshipKey = championship + "_" + country;
                championshipDecode = championshipMap.get(championshipKey);
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                if(championshipDecode != null) {
                    continent = championshipDecode.getContinent();
                    championship = championshipDecode.getChampionship();
                    baseballBookmakerOdd = new BasketBookmakerOdd(
                            "" + eventId,
                            "" + eventId,
                            "" + oddId,
                            Platforms.BETBRAIN.getNumVal(),
                            OddRole.valueOf(rs.getString("role").toUpperCase()),
                            rs.getDouble("odds"),
                            0,
                            team,
                            championship,
                            country,
                            continent,
                            rs.getTimestamp("date").toLocalDateTime(),
                            BettingType.getEnum(bettingType));
                    baseballBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));
                    if(previousBaseballBookmakerOdd == null) {
                        previousBaseballBookmakerOdd = baseballBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                        continue;
                    } else {
                        if(isSameOdd(previousBaseballBookmakerOdd, baseballBookmakerOdd) && previousLastChanged < lastChanged) {
                            previousBaseballBookmakerOdd = baseballBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                            continue;
                        }
                    }
                    oddList.add(previousBaseballBookmakerOdd);
                    previousBaseballBookmakerOdd = baseballBookmakerOdd.copy();
                    previousLastChanged = lastChanged;
                }
            }
            if(previousBaseballBookmakerOdd != null) {
                oddList.add(previousBaseballBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }

    // icehockey
    public Map<String, List<IceHockeyMatch>> icehockeyBetbrainMatches(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<IceHockeyMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String campionato = null;
        String nazione = null;
        String role = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        IceHockeyMatch iceHockeyMatch;
        List<IceHockeyMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");
                if(eventId != eventIdPrev && !first) {
                    iceHockeyMatch = new IceHockeyMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                    champDecode = championshipMap.get(campionato + "_" + nazione);
                    if(champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                        iceHockeyMatch.setCountry(nazione);
                        iceHockeyMatch.setContinent(champDecode.getContinent());
                        iceHockeyMatch.setLeagueName(champDecode.getChampionship());
                        mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                        matches = map.get(mapKey);
                        if(matches == null) {
                            matches = new ArrayList<>();
                            map.put(mapKey, matches);
                        }
                        matches.add(iceHockeyMatch);
                    }
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }
            if(hasRows) {
                iceHockeyMatch = new IceHockeyMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                champDecode = championshipMap.get(campionato + "_" + nazione);
                if (champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                    iceHockeyMatch.setCountry(nazione);
                    iceHockeyMatch.setContinent(champDecode.getContinent());
                    iceHockeyMatch.setLeagueName(champDecode.getChampionship());
                    mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                    matches = map.get(mapKey);
                    if (matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(iceHockeyMatch);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }

    public List<IceHockeyBookmakerOdd> icehockeyBetbrainOdds(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<IceHockeyBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        String query = SELECT_ICEHOCKEY_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_ICEHOCKEY_BETBRAIN_ODDS_SUFFIX;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        IceHockeyBookmakerOdd iceHockeyBookmakerOdd;
        IceHockeyBookmakerOdd previousIceHockeyBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        MatchWithContinent match;
        String championship;
        String country;
        String continent;
        String championshipKey;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        ChampionshipDecode championshipDecode;
        try {
            Map<Long, MatchWithContinent> iceHockeyBetbrainMatches = icehockeyBetbrainMatchesById();
            ps = connection.prepareStatement(query);for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                championshipKey = championship + "_" + country;
                championshipDecode = championshipMap.get(championshipKey);
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                if(championshipDecode != null) {
                    continent = championshipDecode.getContinent();
                    championship = championshipDecode.getChampionship();
                    if(team == null) {
                        match = iceHockeyBetbrainMatches.get(eventId);
                        if(match != null) {
                            iceHockeyBookmakerOdd = new IceHockeyBookmakerOdd(
                                    "" + eventId,
                                    "" + eventId,
                                    "" + oddId,
                                    Platforms.BETBRAIN.getNumVal(),
                                    OddRole.valueOf(rs.getString("role").toUpperCase()),
                                    rs.getDouble("odds"),
                                    0,
                                    match.getHomeTeam() + " - " + match.getAwayTeam(),
                                    championship,
                                    country,
                                    continent,
                                    rs.getTimestamp("date").toLocalDateTime(),
                                    BettingType.getEnum(bettingType));
                            iceHockeyBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));

                            if(previousIceHockeyBookmakerOdd == null) {
                                previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                                previousLastChanged = lastChanged;
                                continue;
                            } else {
                                if(isSameOdd(previousIceHockeyBookmakerOdd, iceHockeyBookmakerOdd) && previousLastChanged < lastChanged) {
                                    previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                                    previousLastChanged = lastChanged;
                                    continue;
                                }
                            }
                            oddList.add(previousIceHockeyBookmakerOdd);
                            previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                        }
                    } else {
                        iceHockeyBookmakerOdd = new IceHockeyBookmakerOdd(
                                "" + eventId,
                                "" + eventId,
                                "" + oddId,
                                Platforms.BETBRAIN.getNumVal(),
                                OddRole.valueOf(rs.getString("role").toUpperCase()),
                                rs.getDouble("odds"),
                                0,
                                team,
                                championship,
                                country,
                                continent,
                                rs.getTimestamp("date").toLocalDateTime(),
                                BettingType.getEnum(bettingType));
                        iceHockeyBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));
                        if(previousIceHockeyBookmakerOdd == null) {
                            previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                            continue;
                        } else {
                            if(isSameOdd(previousIceHockeyBookmakerOdd, iceHockeyBookmakerOdd) && previousLastChanged < lastChanged) {
                                previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                                previousLastChanged = lastChanged;
                                continue;
                            }
                        }
                        oddList.add(previousIceHockeyBookmakerOdd);
                        previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                    }
                }
            }
            if(previousIceHockeyBookmakerOdd != null) {
                oddList.add(previousIceHockeyBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }
    private Map<Long, MatchWithContinent> icehockeyBetbrainMatchesById() throws SQLException {
        Map<Long, MatchWithContinent> matchesById = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        MatchWithContinent match;
        long eventId = 0;
        String team;
        OddRole role;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_BETBRAIN_MATCHES_BY_ID);
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                team = rs.getString("participantName");
                role = OddRole.valueOf(rs.getString("role").toUpperCase());
                match = matchesById.get(eventId);
                if(match == null) {
                    if(role == OddRole.HOME) {
                        match = new MatchWithContinent("" + eventId, "" + eventId, team, null, null, null, null,null);
                    } else {
                        match = new MatchWithContinent("" + eventId, "" + eventId, null, team, null, null, null,null);
                    }
                } else {
                    if(role == OddRole.HOME) {
                        match = new MatchWithContinent("" + eventId, "" + eventId, team, match.getAwayTeam(), null, null, null,null);
                    } else {
                        match = new MatchWithContinent("" + eventId, "" + eventId, match.getHomeTeam(), team, null, null, null,null);
                    }
                }
                matchesById.put(eventId, match);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return matchesById;
    }
    // icehockeyHDA
    public Map<String, List<IceHockeyMatch>> icehockeyHDABetbrainMatches(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<IceHockeyMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String campionato = null;
        String nazione = null;
        String role = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        IceHockeyMatch iceHockeyMatch;
        List<IceHockeyMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_HDA_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");
                if(eventId != eventIdPrev && !first) {
                    iceHockeyMatch = new IceHockeyMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                    champDecode = championshipMap.get(campionato + "_" + nazione);
                    if(champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                        iceHockeyMatch.setCountry(nazione);
                        iceHockeyMatch.setContinent(champDecode.getContinent());
                        iceHockeyMatch.setLeagueName(champDecode.getChampionship());
                        mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                        matches = map.get(mapKey);
                        if(matches == null) {
                            matches = new ArrayList<>();
                            map.put(mapKey, matches);
                        }
                        matches.add(iceHockeyMatch);
                    }
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }

            if(hasRows) {
                iceHockeyMatch = new IceHockeyMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                champDecode = championshipMap.get(campionato + "_" + nazione);
                if (champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                    iceHockeyMatch.setCountry(nazione);
                    iceHockeyMatch.setContinent(champDecode.getContinent());
                    iceHockeyMatch.setLeagueName(champDecode.getChampionship());
                    mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                    matches = map.get(mapKey);
                    if (matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(iceHockeyMatch);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }

    public List<IceHockeyBookmakerOdd> icehockeyHDABetbrainOdds(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<IceHockeyBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        String query = SELECT_ICEHOCKEY_HDA_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_ICEHOCKEY_HDA_BETBRAIN_ODDS_SUFFIX;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        IceHockeyBookmakerOdd iceHockeyBookmakerOdd;
        IceHockeyBookmakerOdd previousIceHockeyBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        MatchWithContinent match;
        String championship;
        String country;
        String continent;
        String championshipKey;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        ChampionshipDecode championshipDecode;
        try {
            Map<Long, MatchWithContinent> icehockeyHDABetbrainMatchesById = icehockeyHDABetbrainMatchesById();
            ps = connection.prepareStatement(query);for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                championshipKey = championship + "_" + country;
                championshipDecode = championshipMap.get(championshipKey);
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                if(championshipDecode != null) {
                    continent = championshipDecode.getContinent();
                    championship = championshipDecode.getChampionship();
                    if(team == null) {
                        match = icehockeyHDABetbrainMatchesById.get(eventId);
                        if(match != null) {
                            iceHockeyBookmakerOdd = new IceHockeyBookmakerOdd(
                                    "" + eventId,
                                    "" + eventId,
                                    "" + oddId,
                                    Platforms.BETBRAIN.getNumVal(),
                                    OddRole.valueOf(rs.getString("role").toUpperCase()),
                                    rs.getDouble("odds"),
                                    0,
                                    match.getHomeTeam() + " - " + match.getAwayTeam(),
                                    championship,
                                    country,
                                    continent,
                                    rs.getTimestamp("date").toLocalDateTime(),
                                    BettingType.getEnum(bettingType));
                            iceHockeyBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));

                            if(previousIceHockeyBookmakerOdd == null) {
                                previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                                previousLastChanged = lastChanged;
                                continue;
                            } else {
                                if(isSameOdd(previousIceHockeyBookmakerOdd, iceHockeyBookmakerOdd) && previousLastChanged < lastChanged) {
                                    previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                                    previousLastChanged = lastChanged;
                                    continue;
                                }
                            }
                            oddList.add(previousIceHockeyBookmakerOdd);
                            previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                        }
                    } else {
                        iceHockeyBookmakerOdd = new IceHockeyBookmakerOdd(
                                "" + eventId,
                                "" + eventId,
                                "" + oddId,
                                Platforms.BETBRAIN.getNumVal(),
                                OddRole.valueOf(rs.getString("role").toUpperCase()),
                                rs.getDouble("odds"),
                                0,
                                team,
                                championship,
                                country,
                                continent,
                                rs.getTimestamp("date").toLocalDateTime(),
                                BettingType.getEnum(bettingType));
                        iceHockeyBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));
                        if(previousIceHockeyBookmakerOdd == null) {
                            previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                            continue;
                        } else {
                            if(isSameOdd(previousIceHockeyBookmakerOdd, iceHockeyBookmakerOdd) && previousLastChanged < lastChanged) {
                                previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                                previousLastChanged = lastChanged;
                                continue;
                            }
                        }
                        oddList.add(previousIceHockeyBookmakerOdd);
                        previousIceHockeyBookmakerOdd = iceHockeyBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                    }
                }
            }
            if(previousIceHockeyBookmakerOdd != null) {
                oddList.add(previousIceHockeyBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }
    private Map<Long, MatchWithContinent> icehockeyHDABetbrainMatchesById() throws SQLException {
        Map<Long, MatchWithContinent> matchesById = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        MatchWithContinent match;
        long eventId = 0;
        String team;
        OddRole role;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_HDA_BETBRAIN_MATCHES_BY_ID);
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                team = rs.getString("participantName");
                role = OddRole.valueOf(rs.getString("role").toUpperCase());
                match = matchesById.get(eventId);
                if(match == null) {
                    if(role == OddRole.HOME) {
                        match = new MatchWithContinent("" + eventId, "" + eventId, team, null, null, null, null,null);
                    } else {
                        match = new MatchWithContinent("" + eventId, "" + eventId, null, team, null, null, null,null);
                    }
                } else {
                    if(role == OddRole.HOME) {
                        match = new MatchWithContinent("" + eventId, "" + eventId, team, match.getAwayTeam(), null, null, null,null);
                    } else {
                        match = new MatchWithContinent("" + eventId, "" + eventId, match.getHomeTeam(), team, null, null, null,null);
                    }
                }
                matchesById.put(eventId, match);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return matchesById;
    }

    //americanfootball
    public Map<String, List<AmericanFootballMatch>> americanFootballBetbrainMatches(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap) throws SQLException {
        Map<String, List<AmericanFootballMatch>> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long eventIdPrev = 0;
        String team = null;
        String homeTeam = null;
        String awayTeam = null;
        String campionato = null;
        String nazione = null;
        String role = null;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        LocalDateTime date = null;
        boolean first = true;
        boolean hasRows = false;
        AmericanFootballMatch americanFootballMatch;
        List<AmericanFootballMatch> matches;
        String mapKey;
        ChampionshipDecode champDecode;
        //select distinct eventId,eventName as championship,location,participantName,role,date,bettingTypeId
        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_BETBRAIN_MATCHES);
            rs = ps.executeQuery();
            while(rs.next()) {
                hasRows = true;
                eventId = rs.getLong("eventId");
                if(eventId != eventIdPrev && !first) {
                    americanFootballMatch = new AmericanFootballMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                    champDecode = championshipMap.get(campionato + "_" + nazione);
                    if(champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                        americanFootballMatch.setCountry(nazione);
                        americanFootballMatch.setContinent(champDecode.getContinent());
                        americanFootballMatch.setLeagueName(champDecode.getChampionship());
                        mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                        matches = map.get(mapKey);
                        if(matches == null) {
                            matches = new ArrayList<>();
                            map.put(mapKey, matches);
                        }
                        matches.add(americanFootballMatch);
                    }
                }

                campionato = rs.getString("championship");
                nazione = rs.getString("location");
                team = rs.getString("participantName");
                role = rs.getString("role");
                date = rs.getTimestamp("date").toLocalDateTime();
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);
                if(role.equals("Home")) {
                    homeTeam = team;
                } else {
                    awayTeam = team;
                }
                eventIdPrev = eventId;
                first = false;
            }

            if(hasRows) {
                americanFootballMatch = new AmericanFootballMatch("" + eventIdPrev, "" + eventIdPrev, homeTeam, awayTeam, campionato, date, BettingType.getEnum(bettingType));
                champDecode = championshipMap.get(campionato + "_" + nazione);
                if (champDecode != null && champDecode.getLocation().equalsIgnoreCase(nazione)) {
                    americanFootballMatch.setCountry(nazione);
                    americanFootballMatch.setContinent(champDecode.getContinent());
                    americanFootballMatch.setLeagueName(champDecode.getChampionship());
                    mapKey = Util.makeMapKey(champDecode.getChampionship(), nazione, date);
                    matches = map.get(mapKey);
                    if (matches == null) {
                        matches = new ArrayList<>();
                        map.put(mapKey, matches);
                    }
                    matches.add(americanFootballMatch);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }

        return map;
    }

    public List<AmericanFootballBookmakerOdd> americanfootballBetbrainOdds(Map<String, ChampionshipDecode> championshipMap, Map<String, Integer> bettingTypeDecodeBetBrainMap, List<String> bookmakerLabels) throws SQLException {
        List<AmericanFootballBookmakerOdd> oddList = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        String query = SELECT_AMERICANFOOTBALL_BETBRAIN_ODDS_PREFIX + buildInClause(bookmakerLabels) + SELECT_AMERICANFOOTBALL_BETBRAIN_ODDS_SUFFIX;

        PreparedStatement ps = null;
        ResultSet rs = null;
        long eventId = 0;
        long oddId = 0;
        String team = null;
        AmericanFootballBookmakerOdd americanFootballBookmakerOdd;
        AmericanFootballBookmakerOdd previousAmericanFootballBookmakerOdd = null;
        long lastChanged;
        long previousLastChanged = 0;
        MatchWithContinent match;
        String championship;
        String country;
        String continent;
        String championshipKey;
        int bettingType = 0;
        String bettingTypeBetBrain = null;
        ChampionshipDecode championshipDecode;
        try {
            ps = connection.prepareStatement(query);
            for(int i=0; i<bookmakerLabels.size(); i++) {
                ps.setString((i+1), bookmakerLabels.get(i));
            }
            rs = ps.executeQuery();
            while(rs.next()) {
                eventId = rs.getLong("eventId");
                oddId = rs.getLong("bettingOfferId");
                team = rs.getString("participantName");
                championship = rs.getString("eventName");
                country = rs.getString("location");
                championshipKey = championship + "_" + country;
                championshipDecode = championshipMap.get(championshipKey);
                bettingTypeBetBrain = rs.getString("bettingTypeId");
                bettingType = bettingTypeDecodeBetBrainMap.get(bettingTypeBetBrain);

                lastChanged = rs.getTimestamp("lastChangedTime").getTime();

                if(championshipDecode != null) {
                    continent = championshipDecode.getContinent();
                    championship = championshipDecode.getChampionship();
                    americanFootballBookmakerOdd = new AmericanFootballBookmakerOdd(
                            "" + eventId,
                            "" + eventId,
                            "" + oddId,
                            Platforms.BETBRAIN.getNumVal(),
                            OddRole.valueOf(rs.getString("role").toUpperCase()),
                            rs.getDouble("odds"),
                            0,
                            team,
                            championship,
                            country,
                            continent,
                            rs.getTimestamp("date").toLocalDateTime(),
                            BettingType.getEnum(bettingType));
                    americanFootballBookmakerOdd.setBookmakerDescr(rs.getString("bookmaker"));
                    if(previousAmericanFootballBookmakerOdd == null) {
                        previousAmericanFootballBookmakerOdd = americanFootballBookmakerOdd.copy();
                        previousLastChanged = lastChanged;
                        continue;
                    } else {
                        if(isSameOdd(previousAmericanFootballBookmakerOdd, americanFootballBookmakerOdd) && previousLastChanged < lastChanged) {
                            previousAmericanFootballBookmakerOdd = americanFootballBookmakerOdd.copy();
                            previousLastChanged = lastChanged;
                            continue;
                        }
                    }
                    oddList.add(previousAmericanFootballBookmakerOdd);
                    previousAmericanFootballBookmakerOdd = americanFootballBookmakerOdd.copy();
                    previousLastChanged = lastChanged;
                }
            }
            if(previousAmericanFootballBookmakerOdd != null) {
                oddList.add(previousAmericanFootballBookmakerOdd);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return oddList;
    }

    public List<MollybetMatch> mollyBetMatches (SportTypes sportTypes) throws Exception {
        List<MollybetMatch> eventMollybets = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query;
        String homeTeam, awayTeam, championshipId, championshipName, event_id, sport;
        MollybetMatch eventMollybet;
        LocalDateTime matchDate;
        try {
            switch (sportTypes){
                case AMERICAN_FOOTBALL:
                    query = SELECT_MOLLYBET_AMERICAN_FOOTBALL_MATCH;
                    break;
                case FOOTBALL:
                    query = SELECT_MOLLYBET_FOOTBALL_MATCH;
                    break;
                case BASKET:
                    query = SELECT_MOLLYBET_BASKET_MATCH;
                    break;
                case TENNIS:
                    query = SELECT_MOLLYBET_TENNIS_MATCH;
                    break;
                case ICE_HOCKEY:
                    query = SELECT_MOLLYBET_ICEHOCKEY_MATCH;
                    break;
                 default:
                    throw new Exception(" Unknown sport ");
            }
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()) {
                event_id = rs.getString("event_id");
                sport = rs.getString("sport");
                if( event_id.isEmpty() || sport.isEmpty()){
                    continue;
                }

                homeTeam = rs.getString("home_team");
                awayTeam = rs.getString("away_team");
                matchDate = rs.getTimestamp("match_date").toLocalDateTime();
                championshipId = Integer.toString(rs.getInt("championship_id"));
                championshipName = rs.getString("championship_name");
                eventMollybet = new MollybetMatch( event_id, null, homeTeam, awayTeam, championshipName, matchDate, null, championshipId, "MOLLYBET");
                eventMollybets.add(eventMollybet);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return eventMollybets;
    }

    public List<TennisMollyBetMatch> tennisMollyBetMatches () throws Exception {
        List<TennisMollyBetMatch> eventMollybets = new ArrayList<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query;
        String homeTeam, awayTeam, championshipId, championshipName, event_id, sport;
        TennisMollyBetMatch eventMollybet;
        LocalDateTime matchDate;
        try {
            query = SELECT_MOLLYBET_TENNIS_MATCH;
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()) {
                event_id = rs.getString("event_id");
                sport = rs.getString("sport");
                if( event_id.isEmpty() || sport.isEmpty()){
                    continue;
                }

                homeTeam = rs.getString("home_team");
                awayTeam = rs.getString("away_team");
                matchDate = rs.getTimestamp("match_date").toLocalDateTime();
                championshipId = Integer.toString(rs.getInt("championship_id"));
                championshipName = rs.getString("championship_name");
                eventMollybet = new TennisMollyBetMatch( event_id, null, homeTeam, awayTeam, matchDate, BettingType.HOME_AWAY, "MOLLYBET");
                eventMollybets.add(eventMollybet);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return eventMollybets;
    }
}
