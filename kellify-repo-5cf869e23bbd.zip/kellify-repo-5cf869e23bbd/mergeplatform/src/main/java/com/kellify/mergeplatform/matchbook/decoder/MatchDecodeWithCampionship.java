package com.kellify.mergeplatform.matchbook.decoder;

import com.kellify.common.Platforms;
import com.kellify.common.matchbook.SportIds;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.MatchDecodeState;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.matchbook.model.*;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class MatchDecodeWithCampionship extends MatchDecodeAbstract {
    private static final Logger logger = LoggerFactory.getLogger(MatchDecodeWithCampionship.class);

    private final List<EventFraction> betbrainMatchesMap;
    private final Map<String, ChampionshipDecode> championshipLocationMap;

    public MatchDecodeWithCampionship( List<EventFraction>betbrainMatchesMap, Map<String, ChampionshipDecode> championshipLocationMap, DbBookmakerBettingConnector bbConnector) {
        super(bbConnector);
        this.betbrainMatchesMap = betbrainMatchesMap;
        this.championshipLocationMap = championshipLocationMap;
    }

    // BASEBALL
    public ImmutablePair<MatchDecodeState, EventFraction> decodeBaseball(BaseballMatchBookMatch providerMatch) throws SQLException {
        if(championshipLocationMap == null || betbrainMatchesMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }
        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();

        providerHomeTeam = bbConnector.baseballTeamDecode(providerHomeTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.baseballTeamDecode(providerAwayTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");

        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildBaseballMatch(bbMatch, providerMatch));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decodeFootball
                    String homeAndAwayBetBrain = bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");

                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch, SportIds.BASEBALL);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildBaseballMatch(bbMatch, providerMatch));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }
    private EventFraction buildBaseballMatch(EventFraction bbMatch, BaseballMatchBookMatch providerMatch) {
        EventFraction fraction = new EventFraction();
        fraction.setReferrerId(bbMatch.getReferrerId());
        fraction.setEventId(providerMatch.getId());
        fraction.setOddId(providerMatch.getReferrerId());
        fraction.setPlatformId(Platforms.MATCHBOOK.getNumVal());
        fraction.setHomeTeam(bbMatch.getHomeTeam());
        fraction.setAwayTeam(bbMatch.getAwayTeam());
        fraction.setChampionship(providerMatch.getLeagueName());
        fraction.setCountry(bbMatch.getCountry());
        fraction.setContinent( bbMatch.getContinent());
        fraction.setBookmakerId(  bbMatch.getBookmakerId());
        fraction.setBookmakerLabel(providerMatch.getOdds().getName());
        fraction.setStartTime(  bbMatch.getStartTime());
        fraction.setFa(bbMatch.getFa());
        fraction.setFh(bbMatch.getFh());
        fraction.setPh(bbMatch.getPh());
        fraction.setPa(bbMatch.getPa());
        fraction.setPbh(bbMatch.getPbh());
        fraction.setPba(bbMatch.getPba());
        fraction.setDelta(bbMatch.getDelta());
        fraction.setBettingOfferIdH(providerMatch.getOdds().getIdHome());
        fraction.setBettingOfferIdA(providerMatch.getOdds().getIdAway());
        fraction.setBettingType( bbMatch.getBettingType());
        fraction.setSportType( bbMatch.getSportType());

        return fraction;
    }

    // AMERICAN FOOTBALL
    public ImmutablePair<MatchDecodeState, EventFraction> decodeAmericanfootball(AmericanFootballMatchBookMatch providerMatch) throws SQLException {
        if(championshipLocationMap == null || betbrainMatchesMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }
        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();

        providerHomeTeam = bbConnector.americanfootballTeamDecode(providerHomeTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.americanfootballTeamDecode(providerAwayTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");

        if(betbrainMatchesMap != null) {
            for ( EventFraction bbMatch : betbrainMatchesMap) {
                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildAmericanFootballMatch(bbMatch, providerMatch));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decodeFootball
                    String homeAndAwayBetBrain = bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");

                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch, SportIds.BASEBALL);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildAmericanFootballMatch(bbMatch, providerMatch));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }
    private EventFraction buildAmericanFootballMatch(EventFraction bbMatch, AmericanFootballMatchBookMatch providerMatch) {
        EventFraction fraction = new EventFraction();
        fraction.setReferrerId(bbMatch.getReferrerId());
        fraction.setEventId(providerMatch.getId());
        fraction.setOddId(providerMatch.getReferrerId());
        fraction.setPlatformId(Platforms.MATCHBOOK.getNumVal());
        fraction.setHomeTeam(bbMatch.getHomeTeam());
        fraction.setAwayTeam(bbMatch.getAwayTeam());
        fraction.setChampionship(providerMatch.getLeagueName());
        fraction.setCountry(bbMatch.getCountry());
        fraction.setContinent( bbMatch.getContinent());
        fraction.setBookmakerId(  bbMatch.getBookmakerId());
        fraction.setBookmakerLabel(providerMatch.getOdds().getName());
        fraction.setStartTime(  bbMatch.getStartTime());
        fraction.setFa(bbMatch.getFa());
        fraction.setFh(bbMatch.getFh());
        fraction.setPh(bbMatch.getPh());
        fraction.setPa(bbMatch.getPa());
        fraction.setPbh(bbMatch.getPbh());
        fraction.setPba(bbMatch.getPba());
        fraction.setDelta(bbMatch.getDelta());
        fraction.setBettingOfferIdH(providerMatch.getOdds().getIdHome());
        fraction.setBettingOfferIdA(providerMatch.getOdds().getIdAway());
        fraction.setBettingType( bbMatch.getBettingType());
        fraction.setSportType( bbMatch.getSportType());

        return fraction;
    }

    //BASKET
    public ImmutablePair<MatchDecodeState, EventFraction> decodeBasket(BasketMatchBookMatch providerMatch) throws SQLException {
        if(championshipLocationMap == null || betbrainMatchesMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }
        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();
        providerHomeTeam = bbConnector.basketTeamDecode(providerHomeTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.basketTeamDecode(providerAwayTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");

        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                String betbrainHomeTeam = Util.cleanUp(bbMatch.getHomeTeam());
                String betbrainAwayTeam = Util.cleanUp(bbMatch.getAwayTeam());

                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {

                    if (betbrainAwayTeam.equalsIgnoreCase(providerAwayTeam) && betbrainHomeTeam.equalsIgnoreCase(providerHomeTeam)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildBasketMatch(bbMatch, providerMatch));
                    }
                    if(betbrainHomeTeam.equalsIgnoreCase(providerAwayTeam) && betbrainAwayTeam.equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decodeBasket
                    String homeAndAwayBetBrain = betbrainHomeTeam + " " + betbrainAwayTeam;
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");
                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch, SportIds.BASKET);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildBasketMatch(bbMatch, providerMatch));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }
    private EventFraction buildBasketMatch(EventFraction bbMatch, BasketMatchBookMatch providerMatch) {
        EventFraction fraction = new EventFraction();
        fraction.setReferrerId(bbMatch.getReferrerId());
        fraction.setEventId(providerMatch.getId());
        fraction.setOddId(providerMatch.getReferrerId());
        fraction.setPlatformId(Platforms.MATCHBOOK.getNumVal());
        fraction.setHomeTeam(bbMatch.getHomeTeam());
        fraction.setAwayTeam(bbMatch.getAwayTeam());
        fraction.setChampionship(providerMatch.getLeagueName());
        fraction.setCountry(bbMatch.getCountry());
        fraction.setContinent( bbMatch.getContinent());
        fraction.setBookmakerId(  bbMatch.getBookmakerId());
        fraction.setBookmakerLabel(providerMatch.getOdds().getName());
        fraction.setStartTime(  bbMatch.getStartTime());
        fraction.setFa(bbMatch.getFa());
        fraction.setFh(bbMatch.getFh());
        fraction.setPh(bbMatch.getPh());
        fraction.setPa(bbMatch.getPa());
        fraction.setPbh(bbMatch.getPbh());
        fraction.setPba(bbMatch.getPba());
        fraction.setDelta(bbMatch.getDelta());
        fraction.setBettingOfferIdH(providerMatch.getOdds().getIdHome());
        fraction.setBettingOfferIdA(providerMatch.getOdds().getIdAway());
        fraction.setBettingType( bbMatch.getBettingType());
        fraction.setSportType( bbMatch.getSportType());

        return fraction;
    }

    //ICE_HOCKEY
    public ImmutablePair<MatchDecodeState, EventFraction> decodeIceHockey(IceHockeyMatchBookMatch providerMatch) throws SQLException {
        if(championshipLocationMap == null || betbrainMatchesMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }
        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();
        providerHomeTeam = bbConnector.iceHockeyTeamDecode(providerHomeTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.iceHockeyTeamDecode(providerAwayTeam, Platforms.MATCHBOOK.getNumVal(),providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");

        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
                        //betbrainMatch.remove(bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.OK, buildIceHockeyMatch(bbMatch, providerMatch));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens
                    String homeAndAwayBetBrain = bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");

                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        //betbrainMatch.remove(bbMatch);
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch, SportIds.ICE_HOCKEY);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildIceHockeyMatch(bbMatch, providerMatch));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }
    private EventFraction buildIceHockeyMatch(EventFraction bbMatch, IceHockeyMatchBookMatch providerMatch) {
        EventFraction fraction = new EventFraction();
        fraction.setReferrerId(bbMatch.getReferrerId());
        fraction.setEventId(providerMatch.getId());
        fraction.setOddId(providerMatch.getReferrerId());
        fraction.setPlatformId(Platforms.MATCHBOOK.getNumVal());
        fraction.setHomeTeam(bbMatch.getHomeTeam());
        fraction.setAwayTeam(bbMatch.getAwayTeam());
        fraction.setChampionship(providerMatch.getLeagueName());
        fraction.setCountry(bbMatch.getCountry());
        fraction.setContinent( bbMatch.getContinent());
        fraction.setBookmakerId(  bbMatch.getBookmakerId());
        fraction.setBookmakerLabel(providerMatch.getOdds().getName());
        fraction.setStartTime(  bbMatch.getStartTime());
        fraction.setFa(bbMatch.getFa());
        fraction.setFh(bbMatch.getFh());
        fraction.setPh(bbMatch.getPh());
        fraction.setPa(bbMatch.getPa());
        fraction.setPbh(bbMatch.getPbh());
        fraction.setPba(bbMatch.getPba());
        fraction.setDelta(bbMatch.getDelta());
        fraction.setBettingOfferIdH(providerMatch.getOdds().getIdHome());
        fraction.setBettingOfferIdA(providerMatch.getOdds().getIdAway());
        fraction.setBettingType( bbMatch.getBettingType());
        fraction.setSportType( bbMatch.getSportType());

        return fraction;
    }

    // FOOTBALL
    public ImmutablePair<MatchDecodeState, EventFraction> decodeFootball(FootballMatchBookMatch providerMatch) throws SQLException {
        if(championshipLocationMap == null || betbrainMatchesMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }

        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();
        providerHomeTeam = bbConnector.footballTeamDecode(providerHomeTeam, Platforms.MATCHBOOK.getNumVal(), providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.footballTeamDecode(providerAwayTeam, Platforms.MATCHBOOK.getNumVal(), providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");


        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildFootballMatch(bbMatch, providerMatch));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decodeFootball
                    String homeAndAwayBetBrain = bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");

                    //if (matchMatch(tokensBetBrain, tokensProvider)) {
                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        //betbrainMatch.remove(bbMatch);
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch, SportIds.FOOTBALL);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildFootballMatch(bbMatch, providerMatch));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }
    private EventFraction buildFootballMatch(EventFraction bbMatch, FootballMatchBookMatch providerMatch) {
        EventFraction fraction = new EventFraction();
        fraction.setReferrerId(bbMatch.getReferrerId());
        fraction.setEventId(providerMatch.getId());
        fraction.setOddId(providerMatch.getReferrerId());
        fraction.setPlatformId(Platforms.MATCHBOOK.getNumVal());
        fraction.setHomeTeam(bbMatch.getHomeTeam());
        fraction.setAwayTeam(bbMatch.getAwayTeam());
        fraction.setChampionship(providerMatch.getLeagueName());
        fraction.setCountry(bbMatch.getCountry());
        fraction.setContinent( bbMatch.getContinent());
        fraction.setBookmakerId(  bbMatch.getBookmakerId());
        fraction.setBookmakerLabel(providerMatch.getOdds().getName());
        fraction.setStartTime( bbMatch.getStartTime());
        fraction.setFa(bbMatch.getFa());
        fraction.setFd(bbMatch.getFd());
        fraction.setFh(bbMatch.getFh());
        fraction.setPh(bbMatch.getPh());
        fraction.setPa(bbMatch.getPa());
        fraction.setPd(bbMatch.getPd());
        fraction.setPbh(bbMatch.getPbh());
        fraction.setPbd(bbMatch.getPbd());
        fraction.setPba(bbMatch.getPba());
        fraction.setDelta(bbMatch.getDelta());
        fraction.setBettingOfferIdH(providerMatch.getOdds().getIdHome());
        fraction.setBettingOfferIdD(providerMatch.getOdds().getIdDraw());
        fraction.setBettingOfferIdA(providerMatch.getOdds().getIdAway());
        fraction.setBettingType( bbMatch.getBettingType());
        fraction.setSportType( bbMatch.getSportType());

        return fraction;
    }

    private boolean matchMatch(String[] tokensBetBrain, String[] tokensProvider) {
        // 0.30 = n/100*60/2
        int minLengthToken = 2;
        int realNumToken = 0;
        String tk1;
        String tk2;
        for(int i=0; i<tokensBetBrain.length; i++) {
            tk1 = tokensBetBrain[i];
            if(tk1.length() <= minLengthToken) {
                continue;
            }
            realNumToken++;
        }
        for(int i=0; i<tokensProvider.length; i++) {
            tk2 = tokensProvider[i];
            if(tk2.length() <= minLengthToken) {
                continue;
            }
            realNumToken++;
        }

        int quorum = (int)((double)(realNumToken)*0.4)+1;
        int counterMatch = 0;

        for(int i=0; i<tokensBetBrain.length; i++) {
            tk1 = tokensBetBrain[i];
            if(tk1.length() <= minLengthToken) {
                continue;
            }
            for(int j=0; j<tokensProvider.length; j++) {
                tk2 = tokensProvider[j];
                if(tk2.length() <= minLengthToken) {
                    continue;
                }
                if(tk1.equalsIgnoreCase(tk2)) {
                    counterMatch++;
                    if(counterMatch == quorum) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
