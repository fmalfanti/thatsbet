package com.kellify.mergeplatform.common;

import com.kellify.common.model.EventFraction;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentNavigableMap;

public final class Util {
    private Util() {}

    public static String makeMapKey(String campionato, String nazione, LocalDateTime date) {
        return campionato + "_" + nazione + "_" + date.truncatedTo(ChronoUnit.DAYS).toString();
    }

    public static String makeMapKey(LocalDateTime date) {
        return "" + date.truncatedTo(ChronoUnit.DAYS).toString();
    }

    public static List<EventFraction> cleanFractionList(List<EventFraction> eventFractionList ) throws Exception {
        EventFraction eventFractionTemp;
        String roleFraction = null;
        String removedId = null;
        Map< String, EventFraction> map = new HashMap<>();
        for (EventFraction eventFraction : eventFractionList) {
            eventFractionTemp = map.get(eventFraction.getReferrerId());
            if( eventFractionTemp== null  ) {
                if( eventFraction.getReferrerId().equalsIgnoreCase(removedId)){
                    continue;
                }
                map.put(eventFraction.getReferrerId(), eventFraction);
                if(eventFraction.getFh()> 0 ) {
                    roleFraction = "Home";
                }
                else if (eventFraction.getFa()> 0 ){
                    roleFraction = "Away";
                }
                else if ( eventFraction.getFd()> 0 ){
                    roleFraction = "Draw";
                }
                continue;
            }
            else{

                if(eventFractionTemp.getFh() * eventFraction.getFh() <0 ){
                    removedId = eventFraction.getReferrerId();
                    map.remove(removedId);
                    continue;
                }
                if(eventFractionTemp.getFa() * eventFraction.getFa() <0 ){
                    removedId = eventFraction.getReferrerId();
                    map.remove(removedId);
                    continue;
                }
                // non aggiungiamo controllo sul DRAW per quanto riguarda il calcio perchè non giochiamo
                switch (roleFraction){
                    case "Home":
                        if(eventFraction.getFh() > eventFractionTemp.getFh()){
                            eventFractionTemp.setFh(eventFraction.getFh() );
                            eventFractionTemp.setFa(eventFraction.getFa() );
                            eventFractionTemp.setFd(eventFraction.getFd() );
                        }
                        if(eventFraction.getPh() > eventFractionTemp.getPh() ){
                            eventFractionTemp.setPh(eventFraction.getPh() );
                            eventFractionTemp.setPa(eventFraction.getPa() );
                            eventFractionTemp.setPd(eventFraction.getPd() );
                            eventFractionTemp.setPbh(eventFraction.getPbh() );
                            eventFractionTemp.setPba(eventFraction.getPba() );
                            eventFractionTemp.setPbd(eventFraction.getPbd() );


                        }
                        break;
                    case "Away":
                        if(eventFraction.getFa() > eventFractionTemp.getFa()){
                            eventFractionTemp.setFh(eventFraction.getFh() );
                            eventFractionTemp.setFa(eventFraction.getFa() );
                            eventFractionTemp.setFd(eventFraction.getFd() );
                        }
                        if(eventFraction.getPa() > eventFractionTemp.getPa() ){
                            eventFractionTemp.setPh(eventFraction.getPh() );
                            eventFractionTemp.setPa(eventFraction.getPa() );
                            eventFractionTemp.setPd(eventFraction.getPd() );
                            eventFractionTemp.setPbh(eventFraction.getPbh() );
                            eventFractionTemp.setPba(eventFraction.getPba() );
                            eventFractionTemp.setPbd(eventFraction.getPbd() );

                        }
                        break;
                    case "Draw":
                        if(eventFraction.getFd() > eventFractionTemp.getFd()){
                            eventFractionTemp.setFd(eventFraction.getFd() );
                            eventFractionTemp.setFa(eventFraction.getFa() );
                            eventFractionTemp.setFh(eventFraction.getFh() );
                        }
                        if(eventFraction.getPd() > eventFractionTemp.getPd() ){
                            eventFractionTemp.setPh(eventFraction.getPh() );
                            eventFractionTemp.setPa(eventFraction.getPa() );
                            eventFractionTemp.setPd(eventFraction.getPd() );
                            eventFractionTemp.setPbh(eventFraction.getPbh() );
                            eventFractionTemp.setPba(eventFraction.getPba() );
                            eventFractionTemp.setPbd(eventFraction.getPbd() );

                        }
                        break;
                    default:
                        throw new Exception(" Not role accepted") ;


                }
            }

        }

        return new ArrayList<>(map.values());
    }

    public static String cleanUp(String team) {
        String cleanUpString = team.replaceAll(" \\(W\\)", "");
        return cleanUpString;
    }


}
