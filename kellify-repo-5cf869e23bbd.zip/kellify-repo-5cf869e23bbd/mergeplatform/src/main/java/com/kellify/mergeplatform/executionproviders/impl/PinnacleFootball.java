package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.BettingType;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.football.FootballBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.model.MatchWithContinent;
import com.kellify.mergeplatform.pinnacle.FootballPinnacleConnector;
import com.kellify.mergeplatform.pinnacle.FootballPinnacleConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class PinnacleFootball extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(PinnacleFootball.class);

    public PinnacleFootball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }
    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {

        Map<String, ChampionshipDecode> footballChampionshipDecodePinnacleMap = bbConnector.footballChampionshipDecodePinnacleMap();
        logger.debug("footballChampionshipDecodePinnacleMap -------");
        logger.debug(footballChampionshipDecodePinnacleMap.toString());

        List<EventFraction> footballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.FOOTBALL);
        List<EventFraction> footballBetbrainMatchesCleaned = Util.cleanFractionList(footballBetbrainMatches);

        FootballPinnacleConnector pinnacleConnector = FootballPinnacleConnectorImpl.getInstance(config,footballChampionshipDecodePinnacleMap, footballBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> footballBookmakerOdds = pinnacleConnector.footballOdds();
        logger.debug("footballBookmakerOdds -------");
        logger.debug(footballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.PINNACLE);
        bettingUserConnector.insertEventFootballFraction(footballBookmakerOdds, bookmakerMap, Platforms.PINNACLE);
    }
}
