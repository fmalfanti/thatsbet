package com.kellify.mergeplatform.db;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class DbBookmakerBettingConnector extends DbConnector {
    private static final Logger logger = LoggerFactory.getLogger(DbBookmakerBettingConnector.class);
    private static final String SELECT_BOOKMAKER = "select label,bookmaker_id from bookmaker_platform where platform_id=?";

    private static final String SELECT_BETTING_TYPE_DECODE_FOR_ASIANODDS88 = "select id,asianodds88_id from betting_type_decode where asianodds88_id is not null";
    private static final String SELECT_BETTING_TYPE_DECODE_FOR_BETBRAIN = "select id,betbrain_id from betting_type_decode where betbrain_id is not null";

    //private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88 = "select eventNameAsian88,Campionato,locationBetbrain,Continente from football_championship_decode where eventNameAsian88 is not null";
    //private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select eventNameBetbrain,Campionato,locationBetbrain,Continente from football_championship_decode where eventNameBetbrain is not null";

    private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88 = "select a.id_pilot,a.championship_platform,b.country,b.continent from football_championship_decode_platform a left join football_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.ASIANODDS88.getNumVal();
    private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select id,championship,country,continent from football_championship_decode_pilot";
    private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_PINNACLE = "select a.id_pilot,a.championship_platform,b.country,b.continent from football_championship_decode_platform a left join football_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.PINNACLE.getNumVal();
    private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK = "select a.id_pilot,a.championship_platform,b.country,b.continent from football_championship_decode_platform a left join football_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MATCHBOOK.getNumVal();
    private static final String SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_MOLLYBET = "select a.id_pilot,a.championship_platform,b.country,b.continent from football_championship_decode_platform a left join football_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MOLLYBET.getNumVal();

    private static final String SELECT_BOOKMAKERS_FOR_ASIANODDS88_NEW = "select a.id,b.label,b.football_history,b.tennis_history,b.basket_history,b.baseball_history,b.ice_hockey_history,b.american_football_history from bookmakers a join bookmaker_platform b on a.id=b.bookmaker_id where b.platform_id=" + Platforms.ASIANODDS88.getNumVal();
    private static final String SELECT_BOOKMAKERS_FOR_BETBRAIN_NEW = "select a.id,b.label,b.football_history,b.tennis_history,b.basket_history,b.baseball_history,b.ice_hockey_history,b.american_football_history from bookmakers a join bookmaker_platform b on a.id=b.bookmaker_id where b.platform_id=" + Platforms.BETBRAIN.getNumVal();
    private static final String SELECT_BOOKMAKERS_FOR_PINNACLE_NEW = "select a.id,b.label,b.football_history,b.tennis_history,b.basket_history,b.baseball_history,b.ice_hockey_history,b.american_football_history from bookmakers a join bookmaker_platform b on a.id=b.bookmaker_id where b.platform_id=" + Platforms.PINNACLE.getNumVal();
    private static final String SELECT_BOOKMAKERS_FOR_MATCHBOOK_NEW = "select a.id,b.label,b.football_history,b.tennis_history,b.basket_history,b.baseball_history,b.ice_hockey_history,b.american_football_history from bookmakers a join bookmaker_platform b on a.id=b.bookmaker_id where b.platform_id=" + Platforms.MATCHBOOK.getNumVal();
    private static final String SELECT_BOOKMAKERS_FOR_MOLLYBET_NEW = "select a.id,b.label,b.football_history,b.tennis_history,b.basket_history,b.baseball_history,b.ice_hockey_history,b.american_football_history from bookmakers a join bookmaker_platform b on a.id=b.bookmaker_id where b.platform_id=" + Platforms.MOLLYBET.getNumVal();

    private static final String SELECT_FOOTBALL_TEAM_DECODE_WITHOUT_PLATFORM = "select team_betbrain from football_team_decode where team_provider=?";
    private static final String SELECT_FOOTBALL_TEAM_DECODE_FOR_PLATFORM = "select team_betbrain from football_team_decode where team_provider=? and championship_country_id=? and platform_id=?";
    private static final String INSERT_FOOTBALL_TEAM_DECODE_FOR_PLATFORM = "insert into football_team_decode (team_betbrain,team_provider,championship_country_id,platform_id) values (?,?,?,?) ON DUPLICATE KEY UPDATE team_provider=?";

    private static final String SELECT_TENNIS_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88 = "select eventNameAsian88,Campionato,locationBetbrain,Continente from tennis_championship_decode where eventNameAsian88 is not null";
    private static final String SELECT_TENNIS_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select id,championship,country,continent from tennis_championship_decode_pilot";

    private static final String SELECT_TENNIS_PLAYER_DECODE_WITHOUT_PLATFORM = "select player_betbrain from tennis_player_decode where player_provider=?";
    private static final String SELECT_TENNIS_PLAYER_DECODE_FOR_PLATFORM = "select player_betbrain from tennis_player_decode where player_provider=? and platform_id=?";
    private static final String INSERT_TENNIS_PLAYER_DECODE_FOR_PLATFORM = "insert into tennis_player_decode (player_betbrain,platform_id,player_provider) values (?,?,?) ON DUPLICATE KEY UPDATE player_provider=? ";

    //private static final String SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88 = "select eventNameAsian88,Campionato,locationBetbrain,Continente from basket_championship_decode where eventNameAsian88 is not null";
    private static final String SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_PINNACLE = "select a.id_pilot,a.championship_platform,b.country,b.continent from basket_championship_decode_platform a left join basket_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.PINNACLE.getNumVal();
    private static final String SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88 = "select a.id_pilot,a.championship_platform,b.country,b.continent from basket_championship_decode_platform a left join basket_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.ASIANODDS88.getNumVal();
    private static final String SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select id,championship,country,continent from basket_championship_decode_pilot";
    private static final String SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK ="select a.id_pilot,a.championship_platform,b.country,b.continent from basket_championship_decode_platform a left join basket_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MATCHBOOK.getNumVal();
    private static final String SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_MOLLYBET ="select a.id_pilot,a.championship_platform,b.country,b.continent from basket_championship_decode_platform a left join basket_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MOLLYBET.getNumVal();

    private static final String SELECT_BASKET_TEAM_DECODE_WITHOUT_PLATFORM = "select team_betbrain from basket_team_decode where team_provider=?";
    private static final String SELECT_BASKET_TEAM_DECODE_FOR_PLATFORM = "select team_betbrain from basket_team_decode where team_provider=? and championship_country_id=? and platform_id=?";
    private static final String INSERT_BASKET_TEAM_DECODE_FOR_PLATFORM = "insert into basket_team_decode (team_betbrain,team_provider,championship_country_id,platform_id) values (?,?,?,?) ON DUPLICATE KEY UPDATE team_provider=?";

    private static final String SELECT_BASEBALL_CHAMPIONSHIP_DECODE_FOR_PINNACLE = "select a.id_pilot,b.championship,b.country,b.continent from baseball_championship_decode_platform a left join baseball_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.PINNACLE.getNumVal();
    private static final String SELECT_BASEBALL_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK = "select a.id_pilot,a.championship_platform,b.country,b.continent from baseball_championship_decode_platform a left join baseball_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MATCHBOOK.getNumVal();
    private static final String SELECT_BASEBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select id,championship,country,continent from baseball_championship_decode_pilot";
    private static final String SELECT_BASEBALL_TEAM_DECODE_WITHOUT_PLATFORM = "select team_betbrain from baseball_team_decode where team_provider=?";
    private static final String SELECT_BASEBALL_TEAM_DECODE_FOR_PLATFORM = "select team_betbrain from baseball_team_decode where team_provider=? and championship_country_id=? and platform_id=?";
    private static final String INSERT_BASEBALL_TEAM_DECODE_FOR_PLATFORM = "insert into baseball_team_decode (team_betbrain,team_provider,championship_country_id,platform_id) values (?,?,?,?) ON DUPLICATE KEY UPDATE team_provider=?";

    private static final String SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_PINNACLE = "select a.id_pilot,a.championship_platform,b.country,b.continent from icehockey_championship_decode_platform a left join icehockey_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.PINNACLE.getNumVal();
    private static final String SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK = "select a.id_pilot,a.championship_platform,b.country,b.continent from icehockey_championship_decode_platform a left join icehockey_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MATCHBOOK.getNumVal();
    private static final String SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select id,championship,country,continent from icehockey_championship_decode_pilot";
    private static final String SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_MOLLYBET = "select a.id_pilot,a.championship_platform,b.country,b.continent from icehockey_championship_decode_platform a left join icehockey_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MOLLYBET.getNumVal();
    private static final String SELECT_ICEHOCKEY_TEAM_DECODE_WITHOUT_PLATFORM = "select team_betbrain from icehockey_team_decode where team_provider=?";
    private static final String SELECT_ICEHOCKEY_TEAM_DECODE_FOR_PLATFORM = "select team_betbrain from icehockey_team_decode where team_provider=? and championship_country_id=? and platform_id=?";
    private static final String INSERT_ICEHOCKEY_TEAM_DECODE_FOR_PLATFORM = "insert into icehockey_team_decode (team_betbrain,team_provider,championship_country_id,platform_id) values (?,?,?,?) ON DUPLICATE KEY UPDATE team_provider=?";

    private static final String SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_PINNACLE = "select a.id_pilot,a.championship_platform,b.country,b.continent from americanfootball_championship_decode_platform a left join americanfootball_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.PINNACLE.getNumVal();
    private static final String SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK = "select a.id_pilot,a.championship_platform,b.country,b.continent from americanfootball_championship_decode_platform a left join americanfootball_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MATCHBOOK.getNumVal();
    private static final String SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN = "select id,championship,country,continent from americanfootball_championship_decode_pilot";
    private static final String SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_MOLLYBET = "select a.id_pilot,a.championship_platform,b.country,b.continent from americanfootball_championship_decode_platform a left join americanfootball_championship_decode_pilot b on a.id_pilot=b.id where a.platform_id=" + Platforms.MOLLYBET.getNumVal();
    private static final String SELECT_AMERICANFOOTBALL_TEAM_DECODE_WITHOUT_PLATFORM = "select team_betbrain from americanfootball_team_decode where team_provider=?";
    private static final String SELECT_AMERICANFOOTBALL_TEAM_DECODE_FOR_PLATFORM = "select team_betbrain from americanfootball_team_decode where team_provider=? and championship_country_id=? and platform_id=?";
    private static final String INSERT_AMERICANFOOTBALL_TEAM_DECODE_FOR_PLATFORM = "insert into americanfootball_team_decode (team_betbrain,team_provider,championship_country_id,platform_id) values (?,?,?,?) ON DUPLICATE KEY UPDATE team_provider=?";

    public DbBookmakerBettingConnector(Properties config) {
        this.config = config;
    }

    private Connection getConnection() {
        try {
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl.bookmakerbetting"), config.getProperty("user.bookmakerbetting"), config.getProperty("password.bookmakerbetting"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }

//    public Map<String, Integer> bettingTypeDecodeAsianodds88Map() throws SQLException {
//        Map<String, Integer> bettingTypeMap = new HashMap<>();
//        if(connection == null) {
//            getConnection();
//        }
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//        try {
//            ps = connection.prepareStatement(SELECT_BETTING_TYPE_DECODE_FOR_ASIANODDS88);
//            rs = ps.executeQuery();
//            while(rs.next()) {
//                bettingTypeMap.put(rs.getString("asianodds88_id"), rs.getInt("id"));
//            }
//        } finally {
//            if(rs != null) {
//                rs.close();
//            }
//            if(ps != null) {
//                ps.close();
//            }
//        }
//        return bettingTypeMap;
//    }

    public Map<String, Integer> bettingTypeDecodeBetBrainMap() throws SQLException {
        Map<String, Integer> bettingTypeMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_BETTING_TYPE_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                bettingTypeMap.put(rs.getString("betbrain_id"), rs.getInt("id"));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return bettingTypeMap;
    }
    //select a.id,b.label,b.football_history,b.tennis_history,b.basket_history,b.baseball_history,b.ice_hockey_history,b.american_football_history

    public Map<String, BookmakerAttributes> bookmakerMap(Platforms platform) throws SQLException {
        Map<String, BookmakerAttributes> bookmakerMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query;
        try {
            switch(platform) {
                case BETBRAIN:
                    query = SELECT_BOOKMAKERS_FOR_BETBRAIN_NEW;
                    break;
                case ASIANODDS88:
                    query = SELECT_BOOKMAKERS_FOR_ASIANODDS88_NEW;
                    break;
                case PINNACLE:
                    query = SELECT_BOOKMAKERS_FOR_PINNACLE_NEW;
                    break;
                case MATCHBOOK:
                    query = SELECT_BOOKMAKERS_FOR_MATCHBOOK_NEW;
                    break;
                case MOLLYBET:
                    query = SELECT_BOOKMAKERS_FOR_MOLLYBET_NEW;
                    break;
                default:
                    query = SELECT_BOOKMAKERS_FOR_BETBRAIN_NEW;
            }
            BookmakerAttributes bookmakerAttributes;
            Map<SportTypes,Integer> historyMap;
            String label;
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()) {
                label = rs.getString("label");
                bookmakerAttributes = new BookmakerAttributes(rs.getInt("id"), label);
                historyMap = new HashMap<>();
                historyMap.put(SportTypes.FOOTBALL, rs.getInt("football_history"));
                historyMap.put(SportTypes.TENNIS, rs.getInt("tennis_history"));
                historyMap.put(SportTypes.BASKET, rs.getInt("basket_history"));
                historyMap.put(SportTypes.ICE_HOCKEY, rs.getInt("ice_hockey_history"));
                historyMap.put(SportTypes.BASEBALL, rs.getInt("baseball_history"));
                historyMap.put(SportTypes.AMERICAN_FOOTBALL, rs.getInt("american_football_history"));
                bookmakerAttributes.setHistoryMap(historyMap);
                bookmakerMap.put(label, bookmakerAttributes);
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return bookmakerMap;
    }
    //FOOTBALL

    public Map<String, ChampionshipDecode> footballChampionshipDecodeAsianodds88Map() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

//    public Map<String, ChampionshipDecode> footballChampionshipDecodeAsianodds88MapNew() throws SQLException {
//        Map<String, ChampionshipDecode> map = new HashMap<>();
//        if(connection == null) {
//            getConnection();
//        }
//        //a.id_pilot,a.championship_platform,b.country,b.continent
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//        try {
//            ps = connection.prepareStatement(SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88_NEW);
//            rs = ps.executeQuery();
//            while(rs.next()) {
//                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
//            }
//        } finally {
//            if(rs != null) {
//                rs.close();
//            }
//            if(ps != null) {
//                ps.close();
//            }
//        }
//        return map;
//    }

    public Map<String, ChampionshipDecode> footballChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship") + "_" + rs.getString("country"), new ChampionshipDecode(rs.getString("id"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> footballChampionshipDecodePinnacleMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_PINNACLE);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> footballChampionshipDecodeMatchBookMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> footballChampionshipMollyBetMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if (connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_FOOTBALL_CHAMPIONSHIP_DECODE_FOR_MOLLYBET);
            rs = ps.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public String footballTeamDecode(String team, int platformId, String championshipCountryId) throws SQLException {
        String betbrainTeam = team;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            //elect team_betbrain from football_team_decode where team_provider=? and championship_country_id=? and platform_id=
            ps = connection.prepareStatement(SELECT_FOOTBALL_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, team);
            ps.setString(2, championshipCountryId);
            ps.setInt(3, platformId);
            rs = ps.executeQuery();
            if(rs.next()) {
                betbrainTeam = rs.getString(1);
            } else {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
                boolean found = false;
                ps = connection.prepareStatement(SELECT_FOOTBALL_TEAM_DECODE_WITHOUT_PLATFORM);
                ps.setString(1, team);
                rs = ps.executeQuery();
                if(rs.next()) {
                    betbrainTeam = rs.getString(1);
                    found = true;
                }
                if(found) {
                    rs.close();
                    rs = null;
                    ps.close();
                    ps = null;
                    insertFootballTeamDecode(betbrainTeam, team, platformId, championshipCountryId);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return betbrainTeam;
    }

    public void insertFootballTeamDecode(String betbrainTeam, String platformTeam, int platformId, String championshipCountryId) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            //insert into football_team_decode (team_betbrain,team_provider,championship_country_id,platform_id) values (?,?,?,?)"
            ps = connection.prepareStatement(INSERT_FOOTBALL_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, betbrainTeam);
            ps.setString(2, platformTeam);
            ps.setString(3, championshipCountryId);
            ps.setInt(4, platformId);
            ps.setString(5, platformTeam);
            ps.executeUpdate();
        } catch(SQLException ex) {
            logger.error(" tuple not inserted betbrainTeam:" + betbrainTeam + ", platformTeam:" + platformTeam + ", championshipCountryId:" + championshipCountryId + ", platformId:" + platformId, ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    //BASEBALL

    public Map<String, ChampionshipDecode> baseballChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship") + "_" + rs.getString("country"), new ChampionshipDecode(rs.getString("id"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> baseballChampionshipDecodePinnacleMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_CHAMPIONSHIP_DECODE_FOR_PINNACLE);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship"), new ChampionshipDecode(rs.getString("championship"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> baseballChampionshipDecodeMatchBookMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }
    public String baseballTeamDecode(String team, int platformId, String championshipCountryId) throws SQLException {
        String betbrainTeam = team;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_BASEBALL_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, team);
            ps.setString(2, championshipCountryId);
            ps.setInt(3, platformId);
            rs = ps.executeQuery();
            if(rs.next()) {
                betbrainTeam = rs.getString(1);
            } else {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
                boolean found = false;
                ps = connection.prepareStatement(SELECT_BASEBALL_TEAM_DECODE_WITHOUT_PLATFORM);
                ps.setString(1, team);
                rs = ps.executeQuery();
                if(rs.next()) {
                    betbrainTeam = rs.getString(1);
                    found = true;
                }
                if(found) {
                    rs.close();
                    rs = null;
                    ps.close();
                    ps = null;
                    insertBaseballTeamDecode(betbrainTeam, team, platformId,championshipCountryId);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return betbrainTeam;
    }

    public void insertBaseballTeamDecode(String betbrainTeam, String platformTeam, int platformId, String championshipCountryId) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASEBALL_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, betbrainTeam);
            ps.setString(2, platformTeam);
            ps.setString(3, championshipCountryId);
            ps.setInt(4, platformId);
            ps.setString(5, platformTeam);
            ps.executeUpdate();
        } catch(SQLException ex) {
            logger.error(" tuple not inserted betbrainTeam:" + betbrainTeam + ", platformTeam:" + platformTeam + ", championshipCountryId:" + championshipCountryId + ", platformId:" + platformId, ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public Map<String, ChampionshipDecode> iceHockeyChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship") + "_" + rs.getString("country"), new ChampionshipDecode(rs.getString("id"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }


    //ICEHOCKEY

    public Map<String, ChampionshipDecode> iceHockeyChampionshipDecodePinnacleMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_PINNACLE);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }
    public Map<String, ChampionshipDecode> icehockeyChampionshipDecodeMatchBookMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> iceHockeyChampionshipMollyBetMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if (connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_MOLLYBET);
            rs = ps.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public String iceHockeyTeamDecode(String team, int platformId, String championshipCountryId) throws SQLException {
        String betbrainTeam = team;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, team);
            ps.setString(2, championshipCountryId);
            ps.setInt(3, platformId);
            rs = ps.executeQuery();
            if(rs.next()) {
                betbrainTeam = rs.getString(1);
            } else {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
                boolean found = false;
                ps = connection.prepareStatement(SELECT_ICEHOCKEY_TEAM_DECODE_WITHOUT_PLATFORM);
                ps.setString(1, team);
                rs = ps.executeQuery();
                if(rs.next()) {
                    betbrainTeam = rs.getString(1);
                    found = true;
                }
                if(found) {
                    rs.close();
                    rs = null;
                    ps.close();
                    ps = null;
                    insertIceHockeyTeamDecode(betbrainTeam, team, platformId,championshipCountryId);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return betbrainTeam;
    }
    public void insertIceHockeyTeamDecode(String betbrainTeam, String platformTeam, int platformId,String championshipCountryId) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_ICEHOCKEY_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, betbrainTeam);
            ps.setString(2, platformTeam);
            ps.setString(3, championshipCountryId);
            ps.setInt(4, platformId);
            ps.setString(5, platformTeam);
            ps.executeUpdate();
        } catch(SQLException ex) {
            logger.error(" tuple not inserted betbrainTeam:" + betbrainTeam + ", platformTeam:" + platformTeam + ", championshipCountryId:" + championshipCountryId + ", platformId:" + platformId, ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    public Map<String, ChampionshipDecode> icehockeyChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_ICEHOCKEY_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship") + "_" + rs.getString("country"), new ChampionshipDecode(rs.getString("id"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }


    //BASKET

    public Map<String, ChampionshipDecode> basketChampionshipDecodeAsianodds88Map() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_ASIANODDS88);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }
    public Map<String, ChampionshipDecode> basketChampionshipDecodePinnacleMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_PINNACLE);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }
    public Map<String, ChampionshipDecode> basketChampionshipMatchBookMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if (connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK);
            rs = ps.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> basketChampionshipMollyBetMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if (connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_MOLLYBET);
            rs = ps.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> basketChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_BASKET_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship") + "_" + rs.getString("country"), new ChampionshipDecode(rs.getString("id"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public String basketTeamDecode(String team, int platformId, String championshipCountryId) throws SQLException {
        String betbrainTeam = team;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_BASKET_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, team);
            ps.setString(2, championshipCountryId);
            ps.setInt(3, platformId);
            rs = ps.executeQuery();
            if(rs.next()) {
                betbrainTeam = rs.getString(1);
            } else {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
                boolean found = false;
                ps = connection.prepareStatement(SELECT_BASKET_TEAM_DECODE_WITHOUT_PLATFORM);
                ps.setString(1, team);
                rs = ps.executeQuery();
                if(rs.next()) {
                    betbrainTeam = rs.getString(1);
                    found = true;
                }
                if(found) {
                    rs.close();
                    rs = null;
                    ps.close();
                    ps = null;
                    insertBasketTeamDecode(betbrainTeam, team, platformId, championshipCountryId);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return betbrainTeam;
    }

    public void insertBasketTeamDecode(String betbrainTeam, String platformTeam, int platformId,  String championshipCountryId) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_BASKET_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, betbrainTeam);
            ps.setString(2, platformTeam);
            ps.setString(3, championshipCountryId);
            ps.setInt(4, platformId);
            ps.setString(5, platformTeam);
            ps.executeUpdate();
        } catch(SQLException ex) {
            logger.error(" tuple not inserted betbrainTeam:" + betbrainTeam + ", platformTeam:" + platformTeam + ", championshipCountryId:" + championshipCountryId + ", platformId:" + platformId, ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }

    //TENNIS

    public Map<String, ChampionshipDecode> tennisChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_TENNIS_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString(1) + "_" + rs.getString(3), new ChampionshipDecode(rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public String tennisPlayerDecode(String player, int platformId) throws SQLException {
        String betbrainPlayer = player;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_TENNIS_PLAYER_DECODE_FOR_PLATFORM);
            ps.setString(1, player);
            ps.setInt(2, platformId);
            rs = ps.executeQuery();
            if(rs.next()) {
                betbrainPlayer = rs.getString(1);
            } else {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
                boolean found = false;
                ps = connection.prepareStatement(SELECT_TENNIS_PLAYER_DECODE_WITHOUT_PLATFORM);
                ps.setString(1, player);
                rs = ps.executeQuery();
                if(rs.next()) {
                    betbrainPlayer = rs.getString(1);
                    found = true;
                }
                if(found) {
                    rs.close();
                    rs = null;
                    ps.close();
                    ps = null;
                    insertTennisPlayerDecode(betbrainPlayer, player, platformId);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return betbrainPlayer;
    }

    public void insertTennisPlayerDecode(String betbrainPlayer, String platformPlayer, int platformId) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_TENNIS_PLAYER_DECODE_FOR_PLATFORM);
            ps.setString(1, betbrainPlayer);
            ps.setInt(2, platformId);
            ps.setString(3, platformPlayer);
            ps.setString(4, platformPlayer);
            ps.executeUpdate();
        } catch(SQLException ex) {
            logger.error(" tuple not inserted betbrainPlayer:" + betbrainPlayer + ", platformPlayer:" + platformPlayer + ", platformId:" + platformId, ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
//AMERICANFOOTBALL

    public String americanfootballTeamDecode(String team, int platformId, String championshipCountryId ) throws SQLException {
        String betbrainTeam = team;
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, team);
            ps.setString(2,championshipCountryId);
            ps.setInt(3, platformId);
            rs = ps.executeQuery();
            if(rs.next()) {
                betbrainTeam = rs.getString(1);
            } else {
                rs.close();
                rs = null;
                ps.close();
                ps = null;
                boolean found = false;
                ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_TEAM_DECODE_WITHOUT_PLATFORM);
                ps.setString(1, team);
                rs = ps.executeQuery();
                if(rs.next()) {
                    betbrainTeam = rs.getString(1);
                    found = true;
                }
                if(found) {
                    rs.close();
                    rs = null;
                    ps.close();
                    ps = null;
                    insertAmericanFootballTeamDecode(betbrainTeam, team, platformId,championshipCountryId);
                }
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return betbrainTeam;
    }
    public Map<String, ChampionshipDecode> americanfootballChampionshipDecodePinnacleMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_PINNACLE);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }
    public Map<String, ChampionshipDecode> americanfootballChampionshipDecodeMatchBookMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_MATCHBOOK);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<String, ChampionshipDecode> americanFootballChampionshipMollyBetMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if (connection == null) {
            getConnection();
        }
        // "select a.id_pilot,a.championship_platform,b.country,b.continent
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_MOLLYBET);
            rs = ps.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("championship_platform"), new ChampionshipDecode(rs.getString("id_pilot"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public void insertAmericanFootballTeamDecode(String betbrainTeam, String platformTeam, int platformId,String championshipCountryId) throws SQLException {
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(INSERT_AMERICANFOOTBALL_TEAM_DECODE_FOR_PLATFORM);
            ps.setString(1, betbrainTeam);
            ps.setString(2, platformTeam);
            ps.setString(3, championshipCountryId);
            ps.setInt(4, platformId);
            ps.setString(5, platformTeam);
            ps.executeUpdate();
        } catch(SQLException ex) {
            logger.error(" tuple not inserted betbrainTeam:" + betbrainTeam + ", platformTeam:" + platformTeam + ", championshipCountryId:" + championshipCountryId + ", platformId:" + platformId, ex);
        }
        finally {
            if(ps != null) {
                ps.close();
            }
        }
    }
    public Map<String, ChampionshipDecode> americanfootballChampionshipDecodeBetBrainMap() throws SQLException {
        Map<String, ChampionshipDecode> map = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_AMERICANFOOTBALL_CHAMPIONSHIP_DECODE_FOR_BETBRAIN);
            rs = ps.executeQuery();
            while(rs.next()) {
                map.put(rs.getString("championship") + "_" + rs.getString("country"), new ChampionshipDecode(rs.getString("id"), rs.getString("country"), rs.getString("continent")));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return map;
    }

    public Map<Integer, String> bookmakerMapString(Platforms platform) throws SQLException {
        Map<Integer, String> bookiesMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_BOOKMAKER);
            ps.setInt(1, platform.getNumVal());
            rs = ps.executeQuery();
            while(rs.next()) {
                bookiesMap.put(rs.getInt("bookmaker_id"), rs.getString("label"));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return bookiesMap;
    }

    public Map<String, Integer> bookmakerMapID(Platforms platform) throws SQLException {
        Map<String, Integer> bookiesMap = new HashMap<>();
        if(connection == null) {
            getConnection();
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(SELECT_BOOKMAKER);
            ps.setInt(1, platform.getNumVal());
            rs = ps.executeQuery();
            while(rs.next()) {
                bookiesMap.put(rs.getString("label"), rs.getInt("bookmaker_id"));
            }
        } finally {
            if(rs != null) {
                rs.close();
            }
            if(ps != null) {
                ps.close();
            }
        }
        return bookiesMap;
    }

}
