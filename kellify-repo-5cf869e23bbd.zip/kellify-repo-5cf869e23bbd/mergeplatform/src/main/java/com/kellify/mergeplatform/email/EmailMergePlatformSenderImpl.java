package com.kellify.mergeplatform.email;

import com.kellify.common.Platforms;
import com.kellify.common.email.EmailSenderAbstract;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.model.MatchWithContinent;
import com.kellify.mergeplatform.model.TennisMatch;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class EmailMergePlatformSenderImpl extends EmailSenderAbstract implements EmailMergePlatform {
    private static final Logger logger = LoggerFactory.getLogger(EmailMergePlatformSenderImpl.class);

    private DateTimeFormatter formatter = null;

    protected EmailMergePlatformSenderImpl(Properties config, Platforms platform) {
        super(config, platform);
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    }


    @Override
    public boolean sendEmailMatchesNotDecoded(List<EventFraction> betbrainMatches, List<?> providerMatches, String sport) throws UnsupportedEncodingException, MessagingException {
        if(providerMatches.isEmpty()) {
            return false;
        }
        String emailBody = null;
        try {
            emailBody = buildMatchesNotDecodedBodyAndWriteFiles(betbrainMatches, providerMatches,sport);
        } catch (IOException e) {
            e.printStackTrace();
        }
        MimeMessage message = buildMatchesNotDecodedMimeMessage();
        message.setContent(emailBody, "text/html");
        Transport.send(message);
        logger.info("match not decoded message was sent to " + config.getProperty("email.not.decoded"));

        return true;
    }

    @Override
    public boolean sendEmailTennisMatchesNotDecoded(List<EventFraction> betbrainMatches, List<?> providerMatches,String sport) throws UnsupportedEncodingException, MessagingException {
        if(providerMatches.isEmpty()) {
            return false;
        }
       // String emailBody = buildTennisMatchesNotDecodedBody(betbrainMatches, providerMatches);
        String emailBody = null;
        try {
            emailBody = buildTennisMatchesNotDecodedBodyAndWriteFiles(betbrainMatches, providerMatches,sport);
        } catch (IOException e) {
            e.printStackTrace();
        }
        MimeMessage message = buildMatchesNotDecodedMimeMessage();
        message.setContent(emailBody, "text/html");
        Transport.send(message);
        logger.info("match not decoded message was sent to " + config.getProperty("email.not.decoded"));

        return true;
    }

    private String buildTennisMatchesNotDecodedBody(List<TennisMatch> betbrainMatches, List<?> providerMatches) {
        StringBuilder sb = new StringBuilder();
        sb.append("Following matches have not been decoded:<br><p>");
        providerMatches.forEach(
                match->sb.append(((TennisMatch)match).getMatchDate().format(formatter)).append(" ").append(((TennisMatch)match).getHomeTeam()).append(" - ").append(((TennisMatch)match).getAwayTeam()).append("<br>")
        );
        sb.append("</p>");
        sb.append("They were compared with following matches from the same date:<br><p>");
        betbrainMatches.forEach(
                match->sb.append(match.getMatchDate().format(formatter)).append(" ").append(match.getHomeTeam()).append(" - ").append(match.getAwayTeam()).append("<br>")
        );
        return sb.toString();
    }

    private String buildTennisMatchesNotDecodedBodyAndWriteFiles(List<EventFraction> betbrainMatches, List<?> providerMatches, String sport) throws IOException {
        StringBuilder sb = new StringBuilder();
        StringBuilder sbname = new StringBuilder();
        StringBuilder sbhidden;
        StringBuilder sbfile;
        String filename;
        sb.append("Following matches have not been decoded:<br><p>");
        for (Object match:providerMatches) {
            sbname.append(((TennisMatch)match).getHomeTeam()).append(((TennisMatch)match).getAwayTeam());
            filename="/"+  DigestUtils.md5Hex(sbname.toString()).toUpperCase() +".php";
            sbhidden =  new StringBuilder();
            sbhidden.append(((TennisMatch)match).getHomeTeam()).append("|||").append(((TennisMatch)match).getAwayTeam());
            sb.append("<A HREF=").append("https://merge.kellify.se/").append(filename).append(">").append(((TennisMatch)match).getMatchDate().format(formatter)).append(" ").append(((TennisMatch)match).getHomeTeam()).append(" - ").append(((TennisMatch)match).getAwayTeam()).append("</a><br><p>\n");
            sbfile = new StringBuilder();
            sbfile.append("<html>\n<head>\n<meta charset=\"utf-8\">\n<title>Kellify Insert Page</title>\n<link rel=\"stylesheet\" href=\"/css/kellify.css\">\n</head>\n");
            sbfile.append("<body>\n<h3>Following matches have not been decoded:</h3>\n").append("<p>").append(((TennisMatch)match).getMatchDate().format(formatter)).append(" ").append(((TennisMatch)match).getHomeTeam()).append(" - ").append(((TennisMatch)match).getAwayTeam()).append("</p>\n");
            sbfile.append("<p>They were compared with following matches from the same date:</p>\n");
            sbfile.append("<form method=POST action=\"/insert_player.php\">\n");
            sbfile.append("<input type=\"hidden\" name=\"platform\" value=\""+platform.getNumVal()+"\">\n");
            sbfile.append("<input type=\"hidden\" name=\"sport\" value=\""+sport+"\">\n");
            sbfile.append("<input type=\"hidden\" name=\"unmatched\" value=\""+sbhidden.toString()+"\">\n");
            sbfile.append("<table class=\"TFtable\">");
            for (EventFraction bmatch:betbrainMatches) {
                sbfile.append("<tr><td><input type=\"radio\" name=\"teams\" value=\"").append(bmatch.getHomeTeam()).append("|||").append(bmatch.getAwayTeam()).append("\">").append(bmatch.getStartTime().format(formatter)).append(" ").append(bmatch.getHomeTeam()).append(" - ").append(bmatch.getAwayTeam()).append("<tr><td>\n");
            }
            sbfile.append("</table>");
            sbfile.append("<input type=\"submit\" value=\"Submit\">\n").append("</form>\n");
            sbfile.append("<hr>\n<form method=POST action=\"/delete_file.php\">\n<input type=\"submit\" value=\"Delete File\">\n</form></body>\n</html>");
           // logger.debug("path ------------ " + config.getProperty("web.folder")+filename);
            try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(config.getProperty("web.folder")+filename)))
            {
                writer.write(sbfile.toString());
            }
        }
        sb.append("</p>");
        sb.append("They were compared with following matches from the same date:<br><p>");
        for (EventFraction bmatch:betbrainMatches) {
            sb.append(bmatch.getStartTime().format(formatter)).append(" ").append(bmatch.getHomeTeam()).append(" - ").append(bmatch.getAwayTeam()).append("<br>");
        }
        return sb.toString();
    }

    public boolean sendEmailSportMatchesNotDecoded(List<EventFraction> betbrainMatches, List<?> providerMatches,String sport) throws UnsupportedEncodingException, MessagingException {
        if(providerMatches.isEmpty()) {
            return false;
        }
        String emailBody = null;
        try {
            emailBody = buildMatchesNotDecodedBodyAndWriteFiles(betbrainMatches, providerMatches,sport);
        } catch (IOException e) {
            e.printStackTrace();
        }
        MimeMessage message = buildMatchesNotDecodedMimeMessage();
        message.setContent(emailBody, "text/html");
        Transport.send(message);
        logger.info("match not decoded message was sent to " + config.getProperty("email.not.decoded"));

        return true;
    }

//    private String buildSportMatchesNotDecodedBody(List<MatchWithContinent> betbrainMatches, List<?> providerMatches) {
//        StringBuilder sb = new StringBuilder();
//        sb.append("Following matches have not been decoded:<br><p>");
//        providerMatches.forEach(
//                match->sb.append(((MatchWithContinent)match).getMatchDate().format(formatter)).append(" ").append(((MatchWithContinent)match).getHomeTeam()).append(" - ").append(((MatchWithContinent)match).getAwayTeam()).append("<br>")
//        );
//        sb.append("</p>");
//        sb.append("They were compared with following matches from the same date:<br><p>");
//        betbrainMatches.forEach(
//                match->sb.append(match.getMatchDate().format(formatter)).append(" ").append(match.getHomeTeam()).append(" - ").append(match.getAwayTeam()).append("<br>")
//        );
//        return sb.toString();
//    }

    private String buildMatchesNotDecodedBody(List<MatchWithContinent> betbrainMatches, List<?> providerMatches) {
        StringBuilder sb = new StringBuilder();
        sb.append("Following matches have not been decoded:<br><p>");
        providerMatches.forEach(
                match->sb.append(((MatchWithContinent)match).getMatchDate().format(formatter)).append(" ").append(((MatchWithContinent)match).getHomeTeam()).append(" - ").append(((MatchWithContinent)match).getAwayTeam()).append("<br>")
        );
        sb.append("</p>");
        sb.append("They were compared with following matches from the same date:<br><p>");
        betbrainMatches.forEach(
                match->sb.append(match.getMatchDate().format(formatter)).append(" ").append(match.getHomeTeam()).append(" - ").append(match.getAwayTeam()).append("<br>")
        );
        return sb.toString();
    }
    private String buildMatchesNotDecodedBodyAndWriteFiles(List<EventFraction> betbrainMatches, List<?> providerMatches,String sport) throws IOException {
        StringBuilder sb = new StringBuilder();
        StringBuilder sbname = new StringBuilder();
        StringBuilder sbhidden;
        StringBuilder sbfile;
        String filename;
        sb.append("Following matches have not been decoded:<br><p>");
        for (Object match:providerMatches) {

            sbname.append(((MatchWithContinent)match).getHomeTeam()).append(((MatchWithContinent)match).getAwayTeam());
            filename="/"+  DigestUtils.md5Hex(sbname.toString()).toUpperCase() +".php";
            sbhidden =  new StringBuilder();
            sbhidden.append(((MatchWithContinent)match).getHomeTeam()).append("|||").append(((MatchWithContinent)match).getAwayTeam());
            sb.append("<A HREF=").append("https://merge.kellify.se/").append(filename).append(">").append(((MatchWithContinent)match).getMatchDate().format(formatter)).append(" ").append(((MatchWithContinent)match).getHomeTeam()).append(" - ").append(((MatchWithContinent)match).getAwayTeam()).append("</a><br><p>\n");
            sbfile = new StringBuilder();
            sbfile.append("<html>\n<head>\n<meta charset=\"utf-8\">\n<title>Kellify Insert Page</title>\n<link rel=\"stylesheet\" href=\"/css/kellify.css\">\n</head>\n");
            sbfile.append("<body>\n<h3>Following matches have not been decoded:</h3>\n").append("<p>").append(((MatchWithContinent)match).getMatchDate().format(formatter)).append(" ").append(((MatchWithContinent)match).getHomeTeam()).append(" - ").append(((MatchWithContinent)match).getAwayTeam()).append("<br><p>\n");
            sbfile.append("<p>They were compared with following matches from the same date:</p>\n");
            sbfile.append("<form method=POST action=\"/insert_team.php\">\n");
            sbfile.append("<input type=\"hidden\" name=\"championship_country_id\" value=\""+((MatchWithContinent) match).getLeagueName()+"\">\n");
            sbfile.append("<input type=\"hidden\" name=\"platform\" value=\""+platform.getNumVal()+"\">\n");
            sbfile.append("<input type=\"hidden\" name=\"sport\" value=\""+sport+"\">\n");
            sbfile.append("<input type=\"hidden\" name=\"unmatched\" value=\""+sbhidden.toString()+"\">\n");
            sbfile.append("<table class=\"TFtable\">");
            for (EventFraction bmatch:betbrainMatches) {
                sbfile.append("<tr><td><input type=\"radio\" name=\"teams\" value=\"").append(bmatch.getHomeTeam()).append("|||").append(bmatch.getAwayTeam()).append("\">").append(bmatch.getStartTime().format(formatter)).append(" ").append(bmatch.getHomeTeam()).append(" - ").append(bmatch.getAwayTeam()).append("</td></tr>\n");
            }
            sbfile.append("</table>");
            sbfile.append("<input type=\"submit\" value=\"Submit\">\n").append("</form>\n");
            sbfile.append("<hr>\n<form method=POST action=\"/delete_file.php\">\n<input type=\"submit\" value=\"Delete File\">\n</form></body>\n</html>");
            //logger.debug("path ------------ " + config.getProperty("web.folder") + filename);
            try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(config.getProperty("web.folder")+filename)))
            {
                writer.write(sbfile.toString());
            }
        }
        sb.append("</p>");
        sb.append("They were compared with following matches from the same date:<br><p>");
        for (EventFraction bmatch:betbrainMatches) {
            sb.append(bmatch.getStartTime().format(formatter)).append(" ").append(bmatch.getHomeTeam()).append(" - ").append(bmatch.getAwayTeam()).append("<br>");
        }
        return sb.toString();
    }


    private MimeMessage buildMatchesNotDecodedMimeMessage() throws UnsupportedEncodingException, MessagingException {
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", config.getProperty("smtp.server.name"));
        properties.setProperty("mail.smtp.port", config.getProperty("smtp.server.port"));

        Session session = Session.getDefaultInstance(properties, null);
        MimeMessage message = new MimeMessage(session);
        message.setSentDate(new Date());
        message.setFrom(new InternetAddress(config.getProperty("email.from")));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(config.getProperty("email.not.decoded")));

        switch (platform) {
            case ASIANODDS88:
                message.setSubject(config.getProperty("email.asianodds88.notdecoded.subject"), "UTF-8");
                break;
            case MATCHBOOK:
                message.setSubject(config.getProperty("email.matchbook.notdecoded.subject"), "UTF-8");
                break;
            case MOLLYBET:
                message.setSubject(config.getProperty("email.mollybet.notdecoded.subject"), "UTF-8");
                break;
            case PINNACLE:
                message.setSubject(config.getProperty("email.pinnacle.notdecoded.subject"), "UTF-8");
                break;
            default:
                break;
        }

        return message;
    }
}
