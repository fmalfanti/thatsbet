package com.kellify.mergeplatform.matchbook;

import com.kellify.common.OddRole;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.matchbook.SportIds;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.MatchDecodeState;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.email.EmailMergePlatform;
import com.kellify.mergeplatform.matchbook.decoder.MatchDecodeWithCampionship;
import com.kellify.mergeplatform.matchbook.model.BasketMatchBookMatch;
import com.kellify.mergeplatform.matchbook.model.MatchBookHomeAwayOdd;
import com.kellify.mergeplatform.matchbook.model.MatchBookProviderResponse;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class BasketballMatchBookConnectorImpl implements BasketballMatchBookConnector{
    private static final Logger logger = LoggerFactory.getLogger(BasketballMatchBookConnectorImpl.class);

    private Properties config;
    private Map<String, ChampionshipDecode> championshipDecodeMap;
    private List<EventFraction> referMatches;
    private DbBookmakerBettingConnector bbConnector;
    private List<? super MatchWithContinent> notDecodedMatches;

    private BasketballMatchBookConnectorImpl(Properties config, Map<String, ChampionshipDecode> championshipDecodeMap, List<EventFraction> referMatches, DbBookmakerBettingConnector bbConnector) {
        this.config = config;
        this.referMatches = referMatches;
        this.championshipDecodeMap = championshipDecodeMap;
        this.bbConnector = bbConnector;
        notDecodedMatches = new ArrayList<>();
    }
    public static BasketballMatchBookConnector getInstance(Properties config, Map<String, ChampionshipDecode> championshipDecodeMap, List<EventFraction> referMatches, DbBookmakerBettingConnector bbConnector) {
        return new BasketballMatchBookConnectorImpl(config, championshipDecodeMap,referMatches, bbConnector);
    }

    @Override
    public List<EventFraction> basketOdds() throws Exception {
        MatchBookProtocol protocol = new MatchBookProtocol(config);
        MatchBookProviderResponse response = protocol.responseMatches(SportIds.BASKET);
        List<BasketMatchBookMatch> matches = (List<BasketMatchBookMatch> )response.getEventList();
        logger.info("matches count:" + matches.size());
        logger.debug("matches:" + matches);

        List<EventFraction> oddList = new ArrayList<>();

        MatchDecodeWithCampionship matchDecode = new MatchDecodeWithCampionship(referMatches, championshipDecodeMap,bbConnector);
        EventFraction decodedMatch;
        ImmutablePair<MatchDecodeState, EventFraction> decodedMatchWrap;
        int decoded = 0;
        int notDecoded = 0;
        for(BasketMatchBookMatch match : matches) {
            if(!championshipDecodeMap.containsKey(match.getLeagueName())){
                continue;
            }
            decodedMatchWrap = matchDecode.decodeBasket(match);
            if(decodedMatchWrap != null) {
                if(decodedMatchWrap.getLeft() == MatchDecodeState.OK) {
                    decodedMatch = decodedMatchWrap.getRight();
                    logger.debug(decodedMatch.toString());
                    oddList.add(decodedMatch);
                    decoded++;
                } else if(decodedMatchWrap.getLeft() == MatchDecodeState.NOT_DECODED) {
                    notDecodedMatches.add(match);
                    notDecoded++;
                }
            }
        }
        logger.info("decoded matches count:" + decoded);
        logger.info("NOT decoded matches count:" + notDecoded);
//        if(notDecoded > 0  & !referMatches.isEmpty()) {
//            // email not decoded matches
//            EmailMergePlatform emailSender = EmailMergePlatform.getSender(config, Platforms.MATCHBOOK);
//            boolean sent = emailSender.sendEmailMatchesNotDecoded(referMatches, notDecodedMatches, SportTypes.getStringEnum(3));
//        }


        return oddList;
    }

    private List<EventFraction> referMatchesFlattered() {
        List<EventFraction> matches = new ArrayList<>();
        for(EventFraction match : matches) {
            matches.add(match);
        }
        return matches;
    }


    private List<BasketBookmakerOdd> bookmakerOddsFromMatch(BasketMatchBookMatch match) {
        List<BasketBookmakerOdd> oddList = new ArrayList<>();
        BasketBookmakerOdd basketBookmakerOdd;
        MatchBookHomeAwayOdd matchOdd = match.getOdds();
        logger.debug("matchOdd:" + matchOdd);

        basketBookmakerOdd = new BasketBookmakerOdd(
                match.getId(),
                match.getReferrerId(),
                matchOdd.getIdHome(),
                Platforms.MATCHBOOK.getNumVal(),
                OddRole.HOME,
                matchOdd.getHome(),
                0,
                match.getHomeTeam(),
                match.getLeagueName(),
                match.getCountry(),
                match.getContinent(),
                match.getMatchDate(),
                match.getBettingType());
        basketBookmakerOdd.setBookmakerDescr(matchOdd.getName());
        oddList.add(basketBookmakerOdd);

        basketBookmakerOdd = new BasketBookmakerOdd(
                match.getId(),
                match.getReferrerId(),
                matchOdd.getIdAway(),
                Platforms.MATCHBOOK.getNumVal(),
                OddRole.AWAY,
                matchOdd.getAway(),
                0,
                match.getAwayTeam(),
                match.getLeagueName(),
                match.getCountry(),
                match.getContinent(),
                match.getMatchDate(),
                match.getBettingType());
        basketBookmakerOdd.setBookmakerDescr(matchOdd.getName());
        oddList.add(basketBookmakerOdd);

        return oddList;
    }
}
