package com.kellify.mergeplatform.email;

import com.kellify.common.Platforms;
import com.kellify.common.email.EmailSender;
import com.kellify.common.model.EventFraction;

import javax.mail.MessagingException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Properties;

public interface EmailMergePlatform extends EmailSender {
    boolean sendEmailMatchesNotDecoded(List<EventFraction> betbrainMatches, List<?> providerMatches, String sport) throws UnsupportedEncodingException, MessagingException;
    boolean sendEmailTennisMatchesNotDecoded(List<EventFraction> betbrainMatches, List<?> providerMatches, String sport) throws UnsupportedEncodingException, MessagingException;
    boolean sendEmailSportMatchesNotDecoded(List<EventFraction> betbrainMatches, List<?> providerMatches, String sport) throws UnsupportedEncodingException, MessagingException;

    static EmailMergePlatform getSender(Properties config, Platforms platform) {
        return new EmailMergePlatformSenderImpl(config, platform);
    }
}
