package com.kellify.mergeplatform.matchbook.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.mergeplatform.model.BasketMatch;

import java.time.LocalDateTime;
import java.util.List;

public class BasketMatchBookMatch extends BasketMatch {
    private MatchBookHomeAwayOdd odds;

    public BasketMatchBookMatch(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
    }

    public MatchBookHomeAwayOdd getOdds() {
        return odds;
    }

    public void setOdds(MatchBookHomeAwayOdd odds) {
        this.odds = odds;
    }

    @Override
    public String toString() {
        return "BasketMatchBookMatch{" +
                "odds=" + odds +
                ", continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType=" + bettingType +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
