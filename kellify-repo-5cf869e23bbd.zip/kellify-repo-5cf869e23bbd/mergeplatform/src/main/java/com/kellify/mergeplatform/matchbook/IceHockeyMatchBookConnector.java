package com.kellify.mergeplatform.matchbook;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.iceHockey.IceHockeyBookmakerOdd;

import java.util.List;

public interface IceHockeyMatchBookConnector {
    List<EventFraction> icehockeyOdds() throws Exception;
}
