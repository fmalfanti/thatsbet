package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderPilot;
import com.kellify.mergeplatform.executionproviders.ProviderSport;

import java.util.Properties;

public abstract class GenericProviderSport implements ProviderSport {
    protected ProviderPilot providerPilot;
    protected final Properties config;
    protected final DbBookmakerBettingConnector bbConnector;
    protected final DbBettingUserConnector bettingUserConnector;

    protected GenericProviderSport(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        this.config = config;
        this.bbConnector = bbConnector;
        this.bettingUserConnector = bettingUserConnector;
    }

    public void setPilot(ProviderPilot providerPilot) {
        this.providerPilot = providerPilot;
    }
}
