package com.kellify.mergeplatform.matchbook.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.mergeplatform.model.FootballMatch;

import java.time.LocalDateTime;

public class FootballMatchBookMatch extends FootballMatch {
    private MatchBookHomeAwayDrawOdd odds;

    public FootballMatchBookMatch(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
    }

    public MatchBookHomeAwayDrawOdd getOdds() {
        return odds;
    }

    public void setOdds(MatchBookHomeAwayDrawOdd odds) {
        this.odds = odds;
    }

    @Override
    public String toString() {
        return "FootballMatchBookMatch{" +
                "odds=" + odds +
                ", continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType=" + bettingType +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
