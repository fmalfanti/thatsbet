package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DBBetbrainConnector;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.mollybet.AmericanFootballMollyBetConnector;
import com.kellify.mergeplatform.mollybet.AmericanFootballMollyBetConnectorImpl;
import com.kellify.mergeplatform.mollybet.FootballMollyBetConnector;
import com.kellify.mergeplatform.mollybet.FootballMollyBetConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MollyBetFootball extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookBasket.class);
    protected DBBetbrainConnector dbBetbrainConnector;

    public MollyBetFootball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, DBBetbrainConnector dbBetbrainConnector) {
        super(config, bbConnector, bettingUserConnector);
        this.dbBetbrainConnector = dbBetbrainConnector;
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> footballChampionshipDecodeMollybetMap = bbConnector.footballChampionshipMollyBetMap();
        logger.debug("footballChampionshipDecodeMollybetMap -------");
        logger.debug(footballChampionshipDecodeMollybetMap.toString());
        List<EventFraction> footballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.FOOTBALL);
        List<EventFraction> footballBetbrainMatchesCleaned = Util.cleanFractionList(footballBetbrainMatches);

        FootballMollyBetConnector connector = FootballMollyBetConnectorImpl.getInstance(config, footballChampionshipDecodeMollybetMap, footballBetbrainMatchesCleaned, bbConnector, dbBetbrainConnector);
        List<EventFraction> footballBookmakerOdds = connector.footballOdds();

        logger.debug("FootballBookmakerOdds -------");
        logger.debug(footballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MOLLYBET);
        bettingUserConnector.insertEventFootballFraction(footballBookmakerOdds, bookmakerMap, Platforms.MOLLYBET);

    }
}
