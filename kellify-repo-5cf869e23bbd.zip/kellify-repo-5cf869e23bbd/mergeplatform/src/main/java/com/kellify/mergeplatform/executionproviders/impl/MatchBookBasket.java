package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.basket.BasketBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.matchbook.BasketballMatchBookConnector;
import com.kellify.mergeplatform.matchbook.BasketballMatchBookConnectorImpl;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MatchBookBasket extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookBasket.class);

    public MatchBookBasket(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> basketChampionshipDecodeMatchBookMap = bbConnector.basketChampionshipMatchBookMap();
        logger.debug("basketChampionshipDecodeMatchBookMap -------");
        logger.debug(basketChampionshipDecodeMatchBookMap.toString());

        List<EventFraction> basketBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.BASKET);
        logger.debug("Matchbook basketBetbrainMatches -------");
        List<EventFraction> basketBetbrainMatchesCleaned = Util.cleanFractionList(basketBetbrainMatches);
        logger.debug("Matchbook basketBetbrainMatchesCleaned -------");

        BasketballMatchBookConnector connector = BasketballMatchBookConnectorImpl.getInstance(config, basketChampionshipDecodeMatchBookMap, basketBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> basketBookmakerOdds = connector.basketOdds();
        logger.debug("basketBookmakerOdds -------");
        logger.debug(basketBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MATCHBOOK);
        logger.debug("MatchBook bookmakerMap -------" + bookmakerMap.toString());
        bettingUserConnector.insertEventBasketFraction(basketBookmakerOdds, bookmakerMap, Platforms.MATCHBOOK);
    }
}
