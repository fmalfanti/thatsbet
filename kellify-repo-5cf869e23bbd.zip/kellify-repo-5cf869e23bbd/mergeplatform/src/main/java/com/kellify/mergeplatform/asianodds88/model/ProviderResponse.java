package com.kellify.mergeplatform.asianodds88.model;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.BettingType;
import com.kellify.common.asianodds88.SportIds;
import com.kellify.mergeplatform.model.Match;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

public class ProviderResponse {
    private static final Logger logger = LoggerFactory.getLogger(ProviderResponse.class);
    private static final String[] DISCARDED_TOKENS = {"FANTASY", "-"};
    private static final String[] TENNIS_DISCARDED_TOKENS = {"HANDICAP"};

    private static final String DISCARDED_BOOK = "BEST=";
    public static final String PAR_HDP = "0.0";

    private final String response;
    private final SportIds sportId;
    private final ObjectMapper mapper;

    public ProviderResponse(String response, SportIds sportId) {
        this.response = response;
        this.sportId = sportId;
        mapper = new ObjectMapper();
    }

    public List<?> sportMatches() throws Exception {
        List<? super Match> matchList = new ArrayList<>();
        Map<Long, ? super Match> matchMap = new HashMap<>();
        JsonNode teamNode = null;
        JsonNode root = mapper.readTree(response);

        int code = root.get("Code").asInt();
        if(code != 0) {
            String message = root.get("Message").asText();
            if (code < 0) {
                throw new Exception(message);
            }
            if(code > 0) {
                logger.warn(message);
                return matchList;
            }
        }

        JsonNode result = root.get("Result");
        String leagueName = null;
        String leagueId = null;
        String bookieOdds = null;
        JsonNode sports = result.get("Sports");
        boolean discarded = false;
        boolean isActive = true;
        boolean isValid = false;
        boolean willBeRemoved = false;
        boolean isHdp = false;
        for (JsonNode matchGamesObj : sports) {
            JsonNode matchGames = matchGamesObj.get("MatchGames");
            if (matchGames != null) {
                for (JsonNode match : matchGames) {
                    isHdp = false;
                    discarded = false;
                    isValid = false;
                    if (sportId == SportIds.FOOTBALL) {

                        JsonNode FullTimeHdp = match.get("FullTimeHdp");
                        if (FullTimeHdp != null ) {
                            JsonNode bookieOddsNode = FullTimeHdp.get("BookieOdds");
                            if (bookieOddsNode != null) {
                                bookieOdds = bookieOddsNode.asText();
                                JsonNode asianHandicapOddsNode = FullTimeHdp.get("Handicap");
                                if (asianHandicapOddsNode != null) {
                                    String handicap = asianHandicapOddsNode.asText();
                                    if (!StringUtils.isBlank(bookieOdds) && !StringUtils.isBlank(handicap) && handicap.equals(PAR_HDP)) {
                                        leagueId = match.get("LeagueId").asText();
                                        leagueName = match.get("LeagueName").asText();
                                        for (String d : DISCARDED_TOKENS) {
                                            if (leagueName.contains(d)) {
                                                discarded = true;
                                                break;
                                            }
                                        }
                                        if (discarded) {
                                            continue;
                                        }
                                        isValid = true;
                                        isHdp = true;
                                    }
                                }
                            }
                        }
                        if(!isValid){
                            JsonNode FullTimeOneXTwo = match.get("FullTimeOneXTwo");
                            if (FullTimeOneXTwo != null ) {
                                JsonNode bookieOddsNode = FullTimeOneXTwo.get("BookieOdds");
                                if (bookieOddsNode != null) {
                                    bookieOdds = bookieOddsNode.asText();
                                    if (!StringUtils.isBlank(bookieOdds)) {
                                        leagueId = match.get("LeagueId").asText();
                                        leagueName = match.get("LeagueName").asText();
                                        for (String d : DISCARDED_TOKENS) {
                                            if (leagueName.contains(d)) {
                                                discarded = true;
                                                break;
                                            }
                                        }
                                        if (discarded) {
                                            continue;
                                        }
                                        isValid = true;
                                    }
                                }
                            }

                        }
                    }
                    else {
                        JsonNode fullTimeOneXTwoNode = match.get("FullTimeOneXTwo");
                        if (fullTimeOneXTwoNode != null) {
                            JsonNode bookieOddsNode = fullTimeOneXTwoNode.get("BookieOdds");
                            if (bookieOddsNode != null) {
                                bookieOdds = bookieOddsNode.asText();
                                if (!StringUtils.isBlank(bookieOdds)) {
                                    leagueId = match.get("LeagueId").asText();
                                    leagueName = match.get("LeagueName").asText();
                                    String[] discardedString = (sportId == SportIds.TENNIS ? TENNIS_DISCARDED_TOKENS : DISCARDED_TOKENS);
                                    for (String d : discardedString) {
                                        if (leagueName.contains(d)) {
                                            discarded = true;
                                            break;
                                        }
                                    }
                                    if (discarded) {
                                        continue;
                                    }
                                    isValid = true;
                                }
                            }
                        }
                    }
                    if (isValid) {
                        teamNode = match.get("AwayTeam");
                        String awayTeam = teamNode.get("Name").asText();
                        teamNode = match.get("HomeTeam");
                        String homeTeam = teamNode.get("Name").asText();

                        long matchId = match.get("MatchId").asLong();
                        long gameId = match.get("GameId").asLong();
                        Long matchDateLong = match.get("StartTime").asLong();

                        isActive = match.get("IsActive").asBoolean();
                        willBeRemoved = match.get("WillBeRemoved").asBoolean();
                        if (!isActive || willBeRemoved) {
                            logger.warn("matchId:" + matchId + ", homeTeam:" + homeTeam + ", awayTeam:" + awayTeam + " is no more active");
                            continue;
                        }

                        Instant fromUnixTimestamp = Instant.ofEpochSecond(matchDateLong / 1000);
                        LocalDateTime matchDate = LocalDateTime.ofInstant(fromUnixTimestamp, ZoneOffset.UTC);
                        switch (sportId) {
                            case BASKET:
                                BasketAsianOdds88Match basketAsian88OddsMatch = new BasketAsianOdds88Match("" + matchId, "", homeTeam, awayTeam, leagueName, matchDate, BettingType.HOME_AWAY, leagueId);
                                basketAsian88OddsMatch.setOdds(oddsReadBookmakers(gameId, bookieOdds));
                                matchMap.put(matchId, basketAsian88OddsMatch);
                                break;
                            case TENNIS:
                                TennisAsianOdds88Match tennisAsianOdds88Match = new TennisAsianOdds88Match("" + matchId, "", homeTeam, awayTeam, matchDate, BettingType.HOME_AWAY);
                                tennisAsianOdds88Match.setOdds(oddsReadBookmakers(gameId, bookieOdds));
                                matchMap.put(matchId, tennisAsianOdds88Match);
                                break;
                            case FOOTBALL:
                                if(isHdp){
                                    FootballAsianOdds88Match footballAsian88OddsMatch = new FootballAsianOdds88Match("" + matchId, "", homeTeam, awayTeam, leagueName, matchDate, BettingType.ASIAN_HDP, leagueId);
                                    footballAsian88OddsMatch.setOdds(oddsReadBookmakers(gameId, bookieOdds));
                                    if(matchMap.containsKey(matchId)){
                                        matchMap.replace(matchId, footballAsian88OddsMatch);
                                    }
                                    else{
                                        matchMap.put(matchId, footballAsian88OddsMatch);
                                    }
                                }
                                else{
                                    FootballAsianOdds88Match footballAsian88OddsMatch = new FootballAsianOdds88Match("" + matchId, "", homeTeam, awayTeam, leagueName, matchDate, BettingType.HOME_DRAW_AWAY, leagueId);
                                    footballAsian88OddsMatch.setOdds(oddsReadBookmakers(gameId, bookieOdds));
                                    matchMap.putIfAbsent(matchId, footballAsian88OddsMatch);
                                }
                                break;
                        }
                    }
                }
            }
        }
        return new ArrayList<>(matchMap.values());
    }

    private List<HomeAwayDrawAsianOdds88Odd> oddsReadBookmakers(long gameId, String bookieOdds) {
        //"PIN=1.363,3.44,;SIN=1.35,3.15,;BEST=PIN 1.363,PIN 3.44,SIN "
        List<HomeAwayDrawAsianOdds88Odd> homeAwayDrawBookmakerOddsList = new ArrayList<>();
        String[] tokens = bookieOdds.split(";");
        double oddsh = 0.0;
        double oddsa = 0.0;
        double oddsd = 0.0;
        String checkDrawOdd;
        for(String token : tokens) {
            if(token.startsWith(DISCARDED_BOOK)) {
                continue;
            }
            String[] tk = token.split("=");
            String name = tk[0];
            String oddsString = tk[1];
            String[] odds = oddsString.split(",");

            if(odds.length > 1) {
                oddsh = Double.parseDouble(odds[0]);
                oddsa = Double.parseDouble(odds[1]);
            }
            if(odds.length == 2) {
                try {
                    if(oddsa * oddsh > 0) {
                        homeAwayDrawBookmakerOddsList.add(new HomeAwayDrawAsianOdds88Odd("" + gameId, name, oddsa, oddsh, Double.NaN));
                    }
                } catch(Exception ex) {
                    logger.error("gameId:" + gameId + ", bookieOdds:" + bookieOdds, ex);
                }
            }
            else if(odds.length == 3) {
                try {
                    checkDrawOdd = odds[2];
                    if(checkDrawOdd.isEmpty()){
                        oddsd = Double.NaN;
                    }
                    else {
                        oddsd = Double.parseDouble(checkDrawOdd);
                    }
                    if(oddsa * oddsh > 0) {
                        homeAwayDrawBookmakerOddsList.add(new HomeAwayDrawAsianOdds88Odd("" + gameId, name, oddsa, oddsh, oddsd));
                    }
                } catch(Exception ex) {
                    logger.error("gameId:" + gameId + ", bookieOdds:" + bookieOdds, ex);
                }
            }
            else {
                logger.debug("skipped::" + Arrays.toString(odds));
                continue;
            }
        }
        return homeAwayDrawBookmakerOddsList;
    }
}
