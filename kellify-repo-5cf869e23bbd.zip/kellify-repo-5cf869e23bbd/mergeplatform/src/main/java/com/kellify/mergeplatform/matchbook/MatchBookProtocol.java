package com.kellify.mergeplatform.matchbook;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.matchbook.MatchBookLoginRequest;
import com.kellify.common.matchbook.MatchBookLoginResponse;
import com.kellify.common.matchbook.SportIds;
import com.kellify.common.matchbook.util.MatchBookLoginErrorHandler;
import com.kellify.mergeplatform.matchbook.model.MatchBookProviderResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class MatchBookProtocol {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookProtocol.class);

    private Properties config;
    private ObjectMapper mapper = null;
    private ClientHttpRequestFactory clientHttpRequestFactory = null;
    private int timeout = 5000; // default 5 seconds
    private int connectionRetry = 1;
    private int connectionRetryMilliSeconds = 5000; // default 5 seconds

    private MatchBookLoginResponse loginResponse;

    MatchBookProtocol(Properties config) {
        this.config = config;
        mapper = new ObjectMapper();
        clientHttpRequestFactory = getClientHttpRequestFactory();
        connectionRetry = getConnectionRetry();
        connectionRetryMilliSeconds = getConnectionRetryMilliSeconds();
    }

    MatchBookProviderResponse responseMatches(SportIds sportId) {
        String eventResponse;
        MatchBookProviderResponse matchBookProviderResponse = null;

        int perPage = config.getProperty("provider.matchbook.queryParam.perpage.value") != null ? Integer.parseInt(config.getProperty("provider.matchbook.queryParam.perpage.value")) : 50;
        double oddLimitUpper = config.getProperty("placebet.threshold.odd.upper") != null ? Double.parseDouble(config.getProperty("placebet.threshold.odd.upper")) : 1.5;
        double oddLimit = config.getProperty("placebet.threshold.odd") != null ? Double.parseDouble(config.getProperty("placebet.threshold.odd")) : 1.2;

        int rounds = 0;
        int offset = 0;

        int counter = 1;
        for(; counter <= connectionRetry; counter++) {
            try {
                if(!isLoggedIn()) {
                    login();
                }
                eventResponse = getEvents(sportId, offset);
                matchBookProviderResponse = new MatchBookProviderResponse(eventResponse, sportId, mapper, perPage, oddLimit, oddLimitUpper);

                matchBookProviderResponse = matchBookProviderResponse.sport(sportId);
                offset = perPage;
                logger.debug("matchBookProviderResponse.getTotal():" + matchBookProviderResponse.getTotal() + ", perPage:" + perPage);
                rounds = matchBookProviderResponse.getTotal() / perPage;
                logger.debug("rounds:" + rounds);

                for(int i=0; i<rounds; i++) {
                    logger.debug("offset:" + offset);
                    matchBookProviderResponse.setOffset(offset);
                    eventResponse = getEvents(sportId, offset);
                    matchBookProviderResponse.setResponse(eventResponse);
                    matchBookProviderResponse.setOffset(offset);
                    matchBookProviderResponse = matchBookProviderResponse.sport(sportId);
                    offset += perPage;
                }

                logger.debug("communication successful at attempt:" + counter);
                break;
            } catch (Exception e) {
                logger.warn("communication failed:" + e.getMessage());
                logger.warn("retry ..");
                if (counter == connectionRetry) {
                    throw new RuntimeException("communication reached max attempts cause:" + e.getMessage());
                }
                try {
                    Thread.sleep(connectionRetryMilliSeconds);
                } catch (InterruptedException e1) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        return matchBookProviderResponse;
    }

    private String getEvents(SportIds sportId, int offset) throws Exception {
        String url = config.getProperty("provider.matchbook.serverUrl") + config.getProperty("provider.matchbook.eventsUrlService");
        logger.info("get events at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);

        headers.set(config.getProperty("provider.matchbook.tokenHeader"), loginResponse.getToken());

        String sportTypeUrlParam;
        switch(sportId) {
            case FOOTBALL:
                sportTypeUrlParam = config.getProperty("provider.matchbook.queryParam.sportids.football.value");
                break;
            case BASKET:
                sportTypeUrlParam = config.getProperty("provider.matchbook.queryParam.sportids.basket.value");
                break;
            case BASEBALL:
                sportTypeUrlParam = config.getProperty("provider.matchbook.queryParam.sportids.baseball.value");
                break;
            case TENNIS:
                sportTypeUrlParam = config.getProperty("provider.matchbook.queryParam.sportids.tennis.value");
                break;
            case ICE_HOCKEY:
                sportTypeUrlParam = config.getProperty("provider.matchbook.queryParam.sportids.icehokey.value");
                break;
            case AMERICAN_FOOTBALL:
                sportTypeUrlParam = config.getProperty("provider.matchbook.queryParam.sportids.americanfootball.value");
                break;
            default:
                throw new Exception("Sport type " + sportId + " not allowed");
        }

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam(config.getProperty("provider.matchbook.queryParam.sportids"), sportTypeUrlParam)
                .queryParam(config.getProperty("provider.matchbook.queryParam.side"), config.getProperty("provider.matchbook.queryParam.side.value"))
                .queryParam(config.getProperty("provider.matchbook.queryParam.perpage"), config.getProperty("provider.matchbook.queryParam.perpage.value"))
                .queryParam(config.getProperty("provider.matchbook.queryParam.offset"), offset);

        HttpEntity<?> entity = new HttpEntity<>(headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                entity,
                String.class);

        if(logger.isDebugEnabled()) {
            logger.debug("get events response:" + response.getBody());
        }

        return response.getBody();
    }

    private void login() throws Exception {
        String url = config.getProperty("provider.matchbook.serverUrl") + config.getProperty("provider.matchbook.loginUrlService");
        logger.info("login at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        restTemplate.setErrorHandler(new MatchBookLoginErrorHandler());
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

        MatchBookLoginRequest loginRequest = new MatchBookLoginRequest(config.getProperty("provider.matchbook.username"), config.getProperty("provider.matchbook.password"));

        HttpEntity<?> entity = new HttpEntity<>(loginRequest, headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.POST,
                entity,
                String.class);

        int responseCode = ((ResponseEntity<String>) response).getStatusCodeValue();
        if(logger.isDebugEnabled()) {
            logger.debug("login response code:" + responseCode);
            logger.debug("login response:" + response.getBody());
        }
        String sessionToken = "";

        JsonNode root = mapper.readTree(response.getBody());
        if(responseCode != HttpStatus.OK.value()) {
            JsonNode errorNode = root.get("errors");
            if(errorNode != null) {
                StringBuilder sb = new StringBuilder();
                for(JsonNode error : errorNode) {
                    JsonNode messageNode = error.get("messages");
                    if(messageNode != null) {
                        for (JsonNode message : messageNode) {
                            sb.append(message.asText()).append(" ");
                        }
                    }
                }
                throw new Exception("response code:" + responseCode + ", message:" + sb.toString());
            }
        }

        sessionToken =  root.get("session-token").asText();

        loginResponse = new MatchBookLoginResponse(sessionToken);
    }

    private boolean isLoggedIn() throws IOException {
        if (loginResponse == null) {
            return false;
        }
        String url = config.getProperty("provider.matchbook.serverUrl") + config.getProperty("provider.matchbook.loginUrlService");
        logger.info("verify if is logged in at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        restTemplate.setErrorHandler(new MatchBookLoginErrorHandler());
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

        HttpEntity<?> entity = new HttpEntity<>(headers);

        HttpEntity<String> response = response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                entity,
                String.class);

        if( ((ResponseEntity<String>) response).getStatusCode().is4xxClientError() ) {
            return false;
        }

        if(logger.isDebugEnabled()) {
            logger.debug("login response:" + response.getBody());
        }

        JsonNode root = mapper.readTree(response.getBody());
        String sessionToken =  root.get("session-token").asText();

        if(sessionToken.equals(loginResponse.getToken())) {
            return true;
        }

        return false;
    }

    private int getConnectionRetry() {
        int connectionRetry = 1;
        try {
            connectionRetry = Integer.parseInt(config.getProperty("provider.matchbook.http.timeout.retry"));
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.matchbook.http.timeout.retry was invalid, using default:" + connectionRetry);
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection retry:" + connectionRetry);
        }
        return connectionRetry;
    }
    private int getConnectionRetryMilliSeconds() {
        int connectionRetryMilliSeconds = 5000;
        try {
            int confConnectionRetrySeconds = Integer.parseInt(config.getProperty("provider.matchbook.http.timeout.retry.wait.seconds"));
            connectionRetryMilliSeconds = (int) TimeUnit.SECONDS.toMillis(confConnectionRetrySeconds);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.matchbook.http.timeout.retry.wait.seconds was invalid, using default:" + connectionRetryMilliSeconds + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection retry wait:" + connectionRetryMilliSeconds + " ms");
        }
        return connectionRetryMilliSeconds;
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        try {
            int confTimeout = Integer.parseInt(config.getProperty("provider.matchbook.http.timeout.seconds"));
            timeout = (int) TimeUnit.SECONDS.toMillis(confTimeout);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.matchbook.http.timeout.seconds was invalid, using default:" + timeout + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection timeout:" + timeout + " ms");
        }

        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return clientHttpRequestFactory;
    }
}
