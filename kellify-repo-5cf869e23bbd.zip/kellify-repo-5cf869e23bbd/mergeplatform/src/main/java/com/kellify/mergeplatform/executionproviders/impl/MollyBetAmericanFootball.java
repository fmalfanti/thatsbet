package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DBBetbrainConnector;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.mollybet.AmericanFootballMollyBetConnector;
import com.kellify.mergeplatform.mollybet.AmericanFootballMollyBetConnectorImpl;
import com.kellify.mergeplatform.mollybet.BasketMollyBetConnector;
import com.kellify.mergeplatform.mollybet.BasketMollyBetConnectorImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MollyBetAmericanFootball extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookBasket.class);
    protected DBBetbrainConnector dbBetbrainConnector;

    public MollyBetAmericanFootball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector, DBBetbrainConnector dbBetbrainConnector) {
        super(config, bbConnector, bettingUserConnector);
        this.dbBetbrainConnector = dbBetbrainConnector;
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        Map<String, ChampionshipDecode> americanFootballChampionshipDecodeMollybetMap = bbConnector.americanFootballChampionshipMollyBetMap();
        logger.debug("americanFootballChampionshipDecodeMollybetMap -------");
        logger.debug(americanFootballChampionshipDecodeMollybetMap.toString());
        List<EventFraction> americanFootballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.AMERICAN_FOOTBALL);
        List<EventFraction> americanFootballBetbrainMatchesCleaned = Util.cleanFractionList(americanFootballBetbrainMatches);

        AmericanFootballMollyBetConnector connector = AmericanFootballMollyBetConnectorImpl.getInstance(config, americanFootballChampionshipDecodeMollybetMap, americanFootballBetbrainMatchesCleaned, bbConnector, dbBetbrainConnector);
        List<EventFraction> americanFootballBookmakerOdds = connector.americanFootballOdds();

        logger.debug("americanFootballBookmakerOdds -------");
        logger.debug(americanFootballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MOLLYBET);
        bettingUserConnector.insertEventBasketFraction(americanFootballBookmakerOdds, bookmakerMap, Platforms.MOLLYBET);

    }
}
