package com.kellify.mergeplatform.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

public class IceHockeyMatch extends MatchWithContinent  {
    public IceHockeyMatch(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
    }

    public IceHockeyMatch(String id, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, String referrerId, String country, BettingType bettingType) {
        super(id, homeTeam, awayTeam, leagueName, matchDate, referrerId, country, bettingType);
    }

    @Override
    public String toString() {
        return "IceHockeyMatch{" +
                "continent='" + continent + '\'' +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType='" + bettingType + '\'' +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
