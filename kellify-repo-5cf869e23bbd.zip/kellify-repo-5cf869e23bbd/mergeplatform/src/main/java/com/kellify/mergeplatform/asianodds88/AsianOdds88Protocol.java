package com.kellify.mergeplatform.asianodds88;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.asianodds88.LoginResponse;
import com.kellify.mergeplatform.email.EmailMergePlatform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class AsianOdds88Protocol {
    private static final Logger logger = LoggerFactory.getLogger(AsianOdds88Protocol.class);

    private Properties config;
    private ObjectMapper mapper = null;
    private ClientHttpRequestFactory clientHttpRequestFactory = null;
    private int timeout = 5000; // default 5 seconds
    private int connectionRetry = 1;
    private int connectionRetryMilliSeconds = 5000; // default 5 seconds

    private LoginResponse loginResponse;

    AsianOdds88Protocol(Properties config) {
        this.config = config;
        mapper = new ObjectMapper();
        clientHttpRequestFactory = getClientHttpRequestFactory();
        connectionRetry = getConnectionRetry();
        connectionRetryMilliSeconds = getConnectionRetryMilliSeconds();
    }

    String responseBody(SportTypes sportType) throws IOException {
        String feedsResponse = null;
        int counter = 1;
        for(; counter <= connectionRetry; counter++) {
            try {
                if(!isLoggedIn()) {
                    login();
                    register();
                }
                feedsResponse = getFeeds(sportType);
                logger.debug("communication successful at attempt:" + counter);
                break;
            } catch (Exception e) {
                logger.warn("communication failed:" + e.getMessage());
                logger.warn("retry ..");
                if (counter == connectionRetry) {
                    throw new RuntimeException("communication reached max attempts");
                }
                try {
                    Thread.sleep(connectionRetryMilliSeconds);
                } catch (InterruptedException e1) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        return feedsResponse;
    }

    private int getConnectionRetry() {
        int connectionRetry = 1;
        try {
            connectionRetry = Integer.parseInt(config.getProperty("provider.asianodds88.http.timeout.retry"));
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.asianodds88.http.timeout.retry was invalid, using default:" + connectionRetry);
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection retry:" + connectionRetry);
        }
        return connectionRetry;
    }
    private int getConnectionRetryMilliSeconds() {
        int connectionRetryMilliSeconds = 5000;
        try {
            int confConnectionRetrySeconds = Integer.parseInt(config.getProperty("provider.asianodds88.http.timeout.retry.wait.seconds"));
            connectionRetryMilliSeconds = (int)TimeUnit.SECONDS.toMillis(confConnectionRetrySeconds);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.asianodds88.http.timeout.retry.wait.seconds was invalid, using default:" + connectionRetryMilliSeconds + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection retry wait:" + connectionRetryMilliSeconds + " ms");
        }
        return connectionRetryMilliSeconds;
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        try {
            int confTimeout = Integer.parseInt(config.getProperty("provider.asianodds88.http.timeout.seconds"));
            timeout = (int)TimeUnit.SECONDS.toMillis(confTimeout);
        } catch(NumberFormatException ex) {
            logger.warn("configured value for provider.asianodds88.http.timeout.seconds was invalid, using default:" + timeout + " ms");
        }
        if(logger.isDebugEnabled()) {
            logger.debug("connection timeout:" + timeout + " ms");
        }

        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return clientHttpRequestFactory;
    }

    private String getFeeds(SportTypes sportType) throws Exception {
        String url = loginResponse.getServiceUrl() + config.getProperty("provider.asianodds88.getfeedsUrlService");
        logger.info("get feeds at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(config.getProperty("provider.asianodds88.keyHeader"), loginResponse.getKey());
        headers.set(config.getProperty("provider.asianodds88.tokenHeader"), loginResponse.getToken());

        String sportTypeUrlParam;
        switch(sportType) {
            case FOOTBALL:
                sportTypeUrlParam = config.getProperty("provider.asianodds88.queryParam.sportsType.football.value");
                break;
            case BASKET:
                sportTypeUrlParam = config.getProperty("provider.asianodds88.queryParam.sportsType.basket.value");
                break;
            case TENNIS:
                sportTypeUrlParam = config.getProperty("provider.asianodds88.queryParam.sportsType.tennis.value");
                break;
            default:
                throw new Exception("Sport type " + sportType + " not allowed");
        }

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam(config.getProperty("provider.asianodds88.queryParam.sportsType"), sportTypeUrlParam)
                .queryParam(config.getProperty("provider.asianodds88.queryParam.oddsFormat"), config.getProperty("provider.asianodds88.queryParam.oddsFormat.value"))
                .queryParam(config.getProperty("provider.asianodds88.queryParam.marketTypeId"), config.getProperty("provider.asianodds88.queryParam.marketTypeId.value"));

        HttpEntity<?> entity = new HttpEntity<>(headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                entity,
                String.class);

        if(logger.isDebugEnabled()) {
            logger.debug("getFeeds response:" + response.getBody());
        }

        JsonNode root = mapper.readTree(response.getBody());
        int code = root.get("Code").asInt();

        if(code != 0) {
            throw new Exception("Error while reading feeds");
        }

        return response.getBody();
    }

    private void login() throws Exception {
        String url = config.getProperty("provider.asianodds88.loginUrl");
        logger.info("login at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("username", config.getProperty("provider.asianodds88.username"))
                .queryParam("password", config.getProperty("provider.asianodds88.password"));

        HttpEntity<?> entity = new HttpEntity<>(headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                entity,
                String.class);

        if(logger.isDebugEnabled()) {
            logger.debug("login response:" + response.getBody());
        }
        JsonNode root = mapper.readTree(response.getBody());
        int code = root.get("Code").asInt();
        JsonNode result = root.get("Result");
        boolean successfulLogin = result.get("SuccessfulLogin").asBoolean();

        if(code != 0 && !successfulLogin) {
            String message = result.get("TextMessage").asText();
            logger.error(config.getProperty("email.asianodds88.connect.subject") + " - code:" + code + " - result:" + mapper.writeValueAsString(result));
//            // email error
//            EmailMergePlatform emailSender = EmailMergePlatform.getSender(config, Platforms.ASIANODDS88);
//            boolean sent = emailSender.sendEmailGenericMessage(config.getProperty("email.asianodds88.connect.subject"), message, logger);
            throw new Exception(message);
        }

        String key = result.get("Key").asText();
        String token = result.get("Token").asText();
        String serviceUrl = result.get("Url").asText();

        loginResponse = new LoginResponse(key, token, serviceUrl);
    }

    private void register() throws Exception {
        String url = loginResponse.getServiceUrl() + config.getProperty("provider.asianodds88.registerUrlService");
        logger.info("registering at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(config.getProperty("provider.asianodds88.keyHeader"), loginResponse.getKey());
        headers.set(config.getProperty("provider.asianodds88.tokenHeader"), loginResponse.getToken());

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("username", config.getProperty("provider.asianodds88.username"));

        HttpEntity<?> entity = new HttpEntity<>(headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                entity,
                String.class);

        if(logger.isDebugEnabled()) {
            logger.debug("register response:" + response.getBody());
        }

        JsonNode root = mapper.readTree(response.getBody());
        int code = root.get("Code").asInt();
        JsonNode result = root.get("Result");
        boolean successfulRegistration = result.get("Success").asBoolean();

        if(code != 0 && !successfulRegistration) {
            String message = result.get("TextMessage").asText();
            logger.error(config.getProperty("email.asianodds88.connect.subject") + " - code:" + code + " - result:" + mapper.writeValueAsString(result));
//            // email error
//            EmailMergePlatform emailSender = EmailMergePlatform.getSender(config, Platforms.ASIANODDS88);
//            boolean sent = emailSender.sendEmailGenericMessage(config.getProperty("email.asianodds88.connect.subject"), message, logger);
            throw new Exception(message);
        }
    }

    private boolean isLoggedIn() throws IOException {
        if(loginResponse == null) {
            return false;
        }
        String url = loginResponse.getServiceUrl() + config.getProperty("provider.asianodds88.isloggedinUrlService");
        logger.info("verify if is logged in at url " + url + " .......");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(config.getProperty("provider.asianodds88.tokenHeader"), loginResponse.getToken());

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("username", config.getProperty("provider.asianodds88.username"));

        HttpEntity<?> entity = new HttpEntity<>(headers);

        HttpEntity<String> response = restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.GET,
                entity,
                String.class);

        if(logger.isDebugEnabled()) {
            logger.debug("register response:" + response.getBody());
        }

        JsonNode root = mapper.readTree(response.getBody());
        JsonNode result = root.get("Result");

        return result.get("CurrentlyLoggedIn").asBoolean();
    }
}
