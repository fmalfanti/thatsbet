package com.kellify.mergeplatform.executionproviders;

import java.sql.SQLException;

public interface Provider {
    void execute() throws Exception;
    String name();
}
