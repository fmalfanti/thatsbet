package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.tennis.TennisBookmakerOdd;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.matchbook.TennisMatchBookConnector;
import com.kellify.mergeplatform.matchbook.TennisMatchBookConnectorImpl;
import com.kellify.mergeplatform.model.TennisMatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MatchBookTennis extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookTennis.class);

    public MatchBookTennis(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {
        List<EventFraction> tennisBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.TENNIS);
        List<EventFraction> tennisBetbrainMatchesCleaned = Util.cleanFractionList(tennisBetbrainMatches);

        TennisMatchBookConnector connector = TennisMatchBookConnectorImpl.getInstance(config, tennisBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> tennisBookmakerOdds = connector.tennisOdds();
        logger.debug("tennisBookmakerOdds -------");
        logger.debug(tennisBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MATCHBOOK);
        bettingUserConnector.insertEventTennisFraction(tennisBookmakerOdds, bookmakerMap, Platforms.MATCHBOOK);
    }
}
