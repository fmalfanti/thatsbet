package com.kellify.mergeplatform.matchbook;

import com.kellify.common.model.EventFraction;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;

import java.util.List;

public interface BaseballMatchBookConnector {
    List<EventFraction> baseballOdds() throws Exception;
}
