package com.kellify.mergeplatform.matchbook.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.mergeplatform.model.TennisMatch;

import java.time.LocalDateTime;
import java.util.List;

public class TennisMatchBookMatch extends TennisMatch {
    private MatchBookHomeAwayOdd odds;

    public TennisMatchBookMatch(String id, String referrerId, String homeTeam, String awayTeam, LocalDateTime matchDate, BettingType bettingType) {
        super(id, referrerId, homeTeam, awayTeam, matchDate, bettingType);
    }

    public MatchBookHomeAwayOdd getOdds() {
        return odds;
    }

    public void setOdds(MatchBookHomeAwayOdd odds) {
        this.odds = odds;
    }

    @Override
    public String toString() {
        return "TennisMatchBookMatch{" +
                "odds=" + odds +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType=" + bettingType +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
