package com.kellify.mergeplatform.executionproviders.impl;

import com.kellify.common.Platforms;
import com.kellify.common.SportTypes;
import com.kellify.common.model.BookmakerAttributes;
import com.kellify.common.model.EventFraction;
import com.kellify.common.model.baseball.BaseballBookmakerOdd;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBettingUserConnector;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.executionproviders.ProviderSport;
import com.kellify.mergeplatform.matchbook.BaseballMatchBookConnector;
import com.kellify.mergeplatform.matchbook.BaseballMatchBookConnectorImpl;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MatchBookBaseball extends GenericProviderSport implements ProviderSport {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookBaseball.class);

    public MatchBookBaseball(Properties config, DbBookmakerBettingConnector bbConnector, DbBettingUserConnector bettingUserConnector) {
        super(config, bbConnector, bettingUserConnector);
    }

    @Override
    public boolean needPilot() {
        return true;
    }

    @Override
    public void execute() throws SQLException, Exception {

        Map<String, ChampionshipDecode> baseballChampionshipDecodeMatchBookMap = bbConnector.baseballChampionshipDecodeMatchBookMap();
        logger.debug("baseballChampionshipDecodeMatchBookMap -------");
        logger.debug(baseballChampionshipDecodeMatchBookMap.toString());

        List<EventFraction> baseballBetbrainMatches = (List<EventFraction>)providerPilot.pilotMatches(SportTypes.BASEBALL);
        List<EventFraction> baseballBetbrainMatchesCleaned = Util.cleanFractionList(baseballBetbrainMatches);

        BaseballMatchBookConnector connector = BaseballMatchBookConnectorImpl.getInstance(config, baseballChampionshipDecodeMatchBookMap, baseballBetbrainMatchesCleaned, bbConnector);
        List<EventFraction> baseballBookmakerOdds = connector.baseballOdds();
        logger.debug("baseballBookmakerOdds -------");
        logger.debug(baseballBookmakerOdds.toString());

        Map<String, BookmakerAttributes> bookmakerMap = bbConnector.bookmakerMap(Platforms.MATCHBOOK);
        logger.debug("MatchBook bookmakerMap -------" + bookmakerMap.toString());
        bettingUserConnector.insertEventBaseballFraction(baseballBookmakerOdds, bookmakerMap, Platforms.MATCHBOOK);
    }
}
