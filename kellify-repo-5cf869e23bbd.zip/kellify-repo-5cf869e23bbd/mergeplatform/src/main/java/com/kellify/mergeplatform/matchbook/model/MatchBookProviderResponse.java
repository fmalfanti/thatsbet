package com.kellify.mergeplatform.matchbook.model;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kellify.common.BettingType;
import com.kellify.common.matchbook.SportIds;
import com.kellify.mergeplatform.model.Match;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class MatchBookProviderResponse {
    private static final Logger logger = LoggerFactory.getLogger(MatchBookProviderResponse.class);

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[yyyy-MM-dd'T'HH:mm:ss'Z'][yyyy-MM-dd'T'HH:mm:ss.SS'Z'][yyyy-MM-dd'T'HH:mm:ss.SSS'Z']");
    private static final String MARKET_TYPE_1X2 = "one_x_two";
    private static final String MARKET_TYPE_MONEY_LINE = "money_line";
    private static final String COMPETITION = "COMPETITION";


    private String response;
    private int offset = 0;
    private final int perPage;
    private int total = 0;
    private final double oddLimit;
    private final double oddLimitUpper;

    private List<? super Match> homeAwayEventList;
    private List<? super Match> homeAwayDrawEventList;


    private final SportIds sportId;
    private final ObjectMapper mapper;


    public MatchBookProviderResponse(String response, SportIds sportId, ObjectMapper mapper, int perPage, double oddLimit, double oddLimitUpper) {
        this.response = response;
        this.sportId = sportId;
        this.mapper = mapper;
        this.perPage = perPage;
        this.oddLimit = oddLimit;
        this.oddLimitUpper = oddLimitUpper;
    }

    public MatchBookProviderResponse sport(SportIds sportId) throws Exception {
        switch (sportId) {
            case FOOTBALL:
                return sportHomeAwayDrawOdds();
            case BASEBALL:
                return sportHomeAwayOdds();
            case BASKET:
                return sportHomeAwayOdds();
            case TENNIS:
                return sportHomeAwayOdds();
            case AMERICAN_FOOTBALL:
                return sportHomeAwayOdds();
            case ICE_HOCKEY:
                return sportHomeAwayOdds();
            default:
                return sportHomeAwayOdds();
        }
    }

    public List<?> getEventList() {
        switch (sportId) {
            case FOOTBALL:
                return getHomeAwayDrawEventList();
            case BASEBALL:
                return getHomeAwayEventList();
            case BASKET:
                return getHomeAwayEventList();
            case TENNIS:
                return getHomeAwayEventList();
            case AMERICAN_FOOTBALL:
                return getHomeAwayEventList();
            case ICE_HOCKEY:
                return getHomeAwayEventList();
            default:
                return getHomeAwayEventList();
        }
    }

    private MatchBookProviderResponse sportHomeAwayOdds() throws Exception {
        if(response == null) {
            return null;
        }

        JsonNode root = mapper.readTree(response);
        total = root.get("total").asInt();
        offset = root.get("offset").asInt();

        if(offset == 0) {
            homeAwayEventList = new ArrayList<>();
        }
        if(homeAwayEventList == null) {
            throw new Exception("Call was never made with offset = 0. Actual offset:" + offset);
        }

        String eventId = null;
        String matchDateString = null;
        String championship = null;
        String homeTeam = null;
        String awayTeam = null;
        MatchBookHomeAwayOdd odds = null;
        JsonNode runners = null;
        String refferedId = null;
        boolean foundMarket = false;
        JsonNode markets;

        JsonNode eventList = root.get("events");
        for (JsonNode eventObj : eventList) {
            foundMarket = false;
            eventId = eventObj.get("id").asText();
            matchDateString = eventObj.get("start").asText();
            LocalDateTime matchDate = LocalDateTime.parse(matchDateString, formatter);

            markets = eventObj.get("markets");
            for(JsonNode marketObj : markets) {
                boolean isLive = marketObj.get("live").asBoolean();
                if(isLive) {
                    continue;
                }
                String marketType = marketObj.get("market-type").asText();
               // refferedId = marketObj.get("market-id").asText();
                if(marketType.equals(MARKET_TYPE_MONEY_LINE)) {
                    runners = marketObj.get("runners");
                    homeTeam = runners.get(0).get("name").asText();
                    awayTeam = runners.get(1).get("name").asText();

                    odds = getHomeWayOdds(runners);
                    if(odds.isValid()) {
                        foundMarket = true;
                    }
                    break;
                }

            }

            if(foundMarket)  {
                JsonNode metaTags = eventObj.get("meta-tags");
                for(JsonNode tag : metaTags) {
                    if(tag.get("type").asText().equals(COMPETITION)) {
                        championship = tag.get("id").asText();
                        break;
                    }
//                    if((sportId.equals(SportIds.BASKET) || championship.equals("406202315670010")) ||  (sportId.equals(SportIds.ICE_HOCKEY) || championship.equals("375897168890027"))){
//                        awayTeam = runners.get(0).get("name").asText();
//                        homeTeam = runners.get(1).get("name").asText();
//                    }

                }

                switch(sportId) {
                    case BASKET:
                        BasketMatchBookMatch basketMatch = new BasketMatchBookMatch(eventId, "", homeTeam, awayTeam, championship, matchDate, BettingType.HOME_AWAY);
                        basketMatch.setOdds(odds);
                        homeAwayEventList.add(basketMatch);
                        break;
                    case BASEBALL:
                        BaseballMatchBookMatch baseballMatch = new BaseballMatchBookMatch(eventId, "", homeTeam, awayTeam, championship, matchDate, BettingType.HOME_AWAY);
                        baseballMatch.setOdds(odds);
                        homeAwayEventList.add(baseballMatch);
                        break;
                    case TENNIS:
                        TennisMatchBookMatch tennisMatch = new TennisMatchBookMatch(eventId, "", homeTeam, awayTeam, matchDate, BettingType.HOME_AWAY);
                        tennisMatch.setOdds(odds);
                        homeAwayEventList.add(tennisMatch);
                        break;
                    case ICE_HOCKEY:
                        IceHockeyMatchBookMatch iceHockeyMatch = new IceHockeyMatchBookMatch(eventId, "", homeTeam, awayTeam, championship, matchDate, BettingType.HOME_AWAY);
                        iceHockeyMatch.setOdds(odds);
                        homeAwayEventList.add(iceHockeyMatch);
                        break;
                }

            }

           // logger.info(eventId + ", matchDate: " + matchDate + ", championship: " + championship + ", homeTeam: " + homeTeam + ", awayTeam: " + awayTeam);
        }

        return this;
    }

    private MatchBookProviderResponse sportHomeAwayDrawOdds() throws Exception {
        if(response == null) {
            return null;
        }
        JsonNode root = mapper.readTree(response);
        logger.debug(" root" + root );

        total = root.get("total").asInt();
        offset = root.get("offset").asInt();

        if(offset == 0) {
            homeAwayDrawEventList = new ArrayList<>();
        }
        if(homeAwayDrawEventList == null) {
            throw new Exception("Call was never made with offset = 0. Actual offset:" + offset);
        }

        String eventId = null;
        String matchDateString = null;
        String championship = null;
        String homeTeam = null;
        String awayTeam = null;
        MatchBookHomeAwayDrawOdd odds = null;
        JsonNode runners = null;
        boolean foundMarket = false;
        JsonNode markets;
        JsonNode eventList = root.get("events");
        for (JsonNode eventObj : eventList) {
            foundMarket = false;

            eventId = eventObj.get("id").asText();
            matchDateString = eventObj.get("start").asText();
            LocalDateTime matchDate = LocalDateTime.parse(matchDateString, formatter);

            markets = eventObj.get("markets");
            for(JsonNode marketObj : markets) {
                boolean isLive = marketObj.get("live").asBoolean();
                if(isLive) {
                    continue;
                }
                String marketType = marketObj.get("market-type").asText();
                if(marketType.equals(MARKET_TYPE_1X2)) {
                    runners = marketObj.get("runners");
                    homeTeam = runners.get(0).get("name").asText();
                    awayTeam = runners.get(1).get("name").asText();
                    odds = getHomeWayDrawOdds(runners);
                    if(odds.isValid()) {
                        foundMarket = true;
                    }
                    break;
                }

            }

            if(foundMarket)  {
                JsonNode metaTags = eventObj.get("meta-tags");
                for(JsonNode tag : metaTags) {
                    if(tag.get("type").asText().equals(COMPETITION)) {
                        championship = tag.get("id").asText();
                        break;
                    }
                }
                FootballMatchBookMatch match = new FootballMatchBookMatch(eventId, null, homeTeam, awayTeam, championship, matchDate, BettingType.HOME_DRAW_AWAY);
                match.setOdds(odds);
                homeAwayDrawEventList.add(match);
            }

        //   logger.info("Foootball eventtt" + eventId + ", mactchId " + mactchId + ", matchDate: " + matchDate + ", championship: " + championship + ", homeTeam: " + homeTeam + ", awayTeam: " + awayTeam);
        }

        return this;
    }

    private MatchBookHomeAwayDrawOdd getHomeWayDrawOdds(JsonNode runners) {
        JsonNode homeRunner = runners.get(0);
        String idHome = homeRunner.get("id").asText();
        JsonNode awayRunner = runners.get(1);
        String idAway = awayRunner.get("id").asText();
        JsonNode drawRunner = runners.get(2);
        String idDraw = drawRunner.get("id").asText();

        return new MatchBookHomeAwayDrawOdd(idHome, idAway, idDraw, getBestOdd(homeRunner), getBestOdd(awayRunner), getBestOdd(drawRunner));
    }

    private MatchBookHomeAwayOdd getHomeWayOdds(JsonNode runners) {
        JsonNode homeRunner = runners.get(0);
        String idHome = homeRunner.get("id").asText();
        JsonNode awayRunner = runners.get(1);
        String idAway = awayRunner.get("id").asText();

        return new MatchBookHomeAwayOdd(idHome, idAway, getBestOdd(homeRunner), getBestOdd(awayRunner));
    }

    private double getBestOdd(JsonNode runner) {
        JsonNode prices = runner.get("prices");
        double bestOdd = 0.0;
        double prod = 0.0;

        for(JsonNode price : prices) {
            double amount = price.get("available-amount").asDouble();
            double odd = price.get("decimal-odds").asDouble();
            double currProd = (int)amount * odd;
            if(odd < oddLimit || odd > oddLimitUpper ) {
                continue;
            }
            if(currProd > prod ) {
                prod = currProd;
                bestOdd = odd;
            } else if(currProd == prod ) {
                if(odd > bestOdd) {
                    bestOdd = odd;
                }
            }
        }

        return bestOdd;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getPerPage() {
        return perPage;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public int getTotal() {
        return total;
    }

    private List<?> getHomeAwayEventList() {
        return homeAwayEventList;
    }

    private List<?> getHomeAwayDrawEventList() {
        return homeAwayDrawEventList;
    }
}
