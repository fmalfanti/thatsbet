package com.kellify.mergeplatform.asianodds88.decoder;


import com.kellify.common.Platforms;
import com.kellify.common.model.EventFraction;
import com.kellify.mergeplatform.asianodds88.model.BasketAsianOdds88Match;
import com.kellify.mergeplatform.asianodds88.model.FootballAsianOdds88Match;
import com.kellify.mergeplatform.asianodds88.model.HomeAwayDrawAsianOdds88Odd;
import com.kellify.mergeplatform.asianodds88.model.TennisAsianOdds88Match;
import com.kellify.mergeplatform.common.ChampionshipDecode;
import com.kellify.mergeplatform.common.MatchDecodeState;
import com.kellify.mergeplatform.common.Util;
import com.kellify.mergeplatform.db.DbBookmakerBettingConnector;
import com.kellify.mergeplatform.model.MatchWithContinent;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatchDecode {
    private static final Logger logger = LoggerFactory.getLogger(MatchDecode.class);

    private final  List<EventFraction> betbrainMatchesMap;
    private final Map<String, ChampionshipDecode> championshipLocationMap;
    private final DbBookmakerBettingConnector bbConnector;
    private static Pattern pattern = Pattern.compile("(?:[\\(\\)\\{\\}\\[\\]])");
    private static Pattern patternWord = Pattern.compile("\\bgame\\b|\\bset\\b", Pattern.CASE_INSENSITIVE);


    public MatchDecode(List<EventFraction> footballBetbrainMatchesMap, Map<String, ChampionshipDecode> championshipLocationMap, DbBookmakerBettingConnector bbConnector) {
        this.betbrainMatchesMap = footballBetbrainMatchesMap;
        this.championshipLocationMap = championshipLocationMap;
        this.bbConnector = bbConnector;
    }
    // FOOTBALL
    public ImmutablePair<MatchDecodeState, List<EventFraction>> decodeFootball(FootballAsianOdds88Match providerMatch, Map<String, Integer> bookmakerMapID) throws SQLException {
        if(betbrainMatchesMap == null || championshipLocationMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }

        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();
        providerHomeTeam = bbConnector.footballTeamDecode(providerHomeTeam, Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.footballTeamDecode(providerAwayTeam, Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");
        logger.info("bbmatch : " + betbrainMatchesMap.toString());


        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
                        //betbrainMatch.remove(bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.OK, buildFootballMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decodeFootball
                    String homeAndAwayBetBrain =bbMatch.getHomeTeam() + " " + bbMatch.getAwayTeam();
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");
                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        //betbrainMatch.remove(bbMatch);
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertFootballTokensDecodedTeam(bbMatch, providerMatch);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildFootballMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }

    // BASKET
    public ImmutablePair<MatchDecodeState, List<EventFraction>> decodeBasket(BasketAsianOdds88Match providerMatch, Map<String, Integer> bookmakerMapID) throws SQLException {
        if(championshipLocationMap == null || betbrainMatchesMap == null) {
            return null;
        }
        ChampionshipDecode campionatoLocation = championshipLocationMap.get(providerMatch.getLeagueName());
        if(campionatoLocation != null) {
            providerMatch.setLeagueName(campionatoLocation.getChampionship());
            providerMatch.setCountry(campionatoLocation.getLocation());
            providerMatch.setContinent(campionatoLocation.getContinent());
        }

        String providerHomeTeam = providerMatch.getHomeTeam();
        String providerAwayTeam = providerMatch.getAwayTeam();
        providerHomeTeam = bbConnector.basketTeamDecode(providerHomeTeam, Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
        providerAwayTeam = bbConnector.basketTeamDecode(providerAwayTeam, Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());

        String homeAndAwayProvider = providerHomeTeam + " " + providerAwayTeam;
        String[] tokensProvider = homeAndAwayProvider.split(" ");

        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                String betbrainHomeTeam = Util.cleanUp(bbMatch.getHomeTeam());
                String betbrainAwayTeam = Util.cleanUp(bbMatch.getAwayTeam());
                if (matchesSameLeagueSameDate(bbMatch, providerMatch)) {
                    if (bbMatch.getAwayTeam().equalsIgnoreCase(providerAwayTeam) && bbMatch.getHomeTeam().equalsIgnoreCase(providerHomeTeam)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildBasketMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                    if(betbrainHomeTeam.equalsIgnoreCase(providerAwayTeam) && betbrainAwayTeam.equalsIgnoreCase(providerHomeTeam)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decodeFootball
                    String homeAndAwayBetBrain = betbrainHomeTeam + " " + betbrainAwayTeam;
                    String[] tokensBetBrain = homeAndAwayBetBrain.split(" ");
                    if (matchMatch(tokensBetBrain, tokensProvider)) {
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertBasketTokensDecodedTeam(bbMatch, providerMatch);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildBasketMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }

    //TENNIS

    public ImmutablePair<MatchDecodeState, List<EventFraction>> decodeTennis(TennisAsianOdds88Match providerMatch,  Map<String, Integer> bookmakerMapID) throws SQLException {
        if(betbrainMatchesMap == null) {
            return null;
        }
        String providerHomePlayer = providerMatch.getHomeTeam();
        String providerAwayPlayer = providerMatch.getAwayTeam();
        providerHomePlayer = bbConnector.tennisPlayerDecode(providerHomePlayer, Platforms.ASIANODDS88.getNumVal());
        providerAwayPlayer = bbConnector.tennisPlayerDecode(providerAwayPlayer, Platforms.ASIANODDS88.getNumVal());
        if(!playerSanitize(providerHomePlayer) || !playerSanitize(providerAwayPlayer)) {
            logger.warn("match has not allowed characters:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        providerHomePlayer = stripSlashesAndDot(providerHomePlayer);
        providerAwayPlayer = stripSlashesAndDot(providerAwayPlayer);

        String[] tokensHomeProvider = providerHomePlayer.split("\\s+");
        String[] tokensAwayProvider = providerAwayPlayer.split("\\s+");


        String bbHomeTeam;
        String bbAwayTeam;
        if(betbrainMatchesMap != null) {
            for (EventFraction bbMatch : betbrainMatchesMap) {
                bbHomeTeam = stripSlashesAndDot(bbMatch.getHomeTeam());
                bbAwayTeam = stripSlashesAndDot(bbMatch.getAwayTeam());

                if (matchesSameDateOneDayMore(bbMatch, providerMatch)) {
                    if (bbAwayTeam.equalsIgnoreCase(providerAwayPlayer) && bbHomeTeam.equalsIgnoreCase(providerHomePlayer)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildTennisMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                }
                if (matchesSameDate(bbMatch, providerMatch)) {
                    if (bbAwayTeam.equalsIgnoreCase(providerAwayPlayer) && bbHomeTeam.equalsIgnoreCase(providerHomePlayer)) {
                        return new ImmutablePair<>(MatchDecodeState.OK, buildTennisMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                    if(bbMatch.getHomeTeam().equalsIgnoreCase(providerAwayPlayer) && bbMatch.getAwayTeam().equalsIgnoreCase(providerHomePlayer)){
                        logger.warn("not same role providerMatch: " + providerMatch + ", bbMatch: " +bbMatch);
                        return new ImmutablePair<>(MatchDecodeState.NOT_SAME_ROLE, null);
                    }
                    // try a tokens decode
                    String[] tokensHomeBetBrain = bbHomeTeam.split("\\s+");
                    String[] tokensAwayBetBrain = bbAwayTeam.split("\\s+");
                    if (matchMatch(tokensHomeBetBrain, tokensHomeProvider) && matchMatch(tokensAwayBetBrain, tokensAwayProvider)) {
                        logger.debug("match successful decoded:" + providerMatch);
                        try {
                            insertTokensDecodedTeam(bbMatch, providerMatch);
                        } catch (SQLException ex) {
                            logger.error(bbMatch + " -> " + providerMatch + ": " + ex.getMessage(), ex);
                        }
                        return new ImmutablePair<>(MatchDecodeState.OK, buildTennisMatch(bbMatch, providerMatch, bookmakerMapID));
                    }
                }
            }
            logger.warn("match not decoded:" + providerMatch);
            return new ImmutablePair<>(MatchDecodeState.NOT_DECODED, null);
        }
        logger.warn("match has not entry in map:" + providerMatch);
        return new ImmutablePair<>(MatchDecodeState.NOT_IN_MAP, null);
    }

    private void insertTokensDecodedTeam(EventFraction bbMatch, TennisAsianOdds88Match providerMatch) throws SQLException {
        //logger.debug("bbMatch.getHomeTeam():" + bbMatch.getHomeTeam() + ", bbMatch.getAwayTeam():" + bbMatch.getAwayTeam() + ", providerMatch.getHomeTeam():" + providerMatch.getHomeTeam() + ", providerMatch.getAwayTeam():" + providerMatch.getAwayTeam());
        if(!bbMatch.getAwayTeam().equalsIgnoreCase(providerMatch.getAwayTeam())) {
            bbConnector.insertTennisPlayerDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.ASIANODDS88.getNumVal());
        }
        if(!bbMatch.getHomeTeam().equalsIgnoreCase(providerMatch.getHomeTeam())) {
            bbConnector.insertTennisPlayerDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.ASIANODDS88.getNumVal());
        }
    }

    private List<EventFraction>  buildTennisMatch(EventFraction bbMatch, TennisAsianOdds88Match providerMatch,  Map<String, Integer> bookmakerMapID) {
        List<EventFraction> eventFractions = new ArrayList<>();
        for(HomeAwayDrawAsianOdds88Odd odd: providerMatch.getOdds()){
            EventFraction fraction = new EventFraction();
            fraction.setReferrerId(bbMatch.getReferrerId());
            fraction.setEventId(providerMatch.getId());
            fraction.setOddId(odd.getId());
            fraction.setPlatformId(Platforms.ASIANODDS88.getNumVal());
            fraction.setHomeTeam(bbMatch.getHomeTeam());
            fraction.setAwayTeam(bbMatch.getAwayTeam());
            fraction.setChampionship(bbMatch.getChampionship());
            fraction.setCountry(bbMatch.getCountry());
            fraction.setBookmakerId(bookmakerMapID.get(odd.getName()));
            fraction.setBookmakerLabel(odd.getName());
            fraction.setStartTime(  bbMatch.getStartTime());
            fraction.setFa(bbMatch.getFa());
            fraction.setFh(bbMatch.getFh());
            fraction.setPh(bbMatch.getPh());
            fraction.setPa(bbMatch.getPa());
            fraction.setPbh(bbMatch.getPbh());
            fraction.setPba(bbMatch.getPba());
            fraction.setDelta(bbMatch.getDelta());
            fraction.setBettingOfferIdH(odd.getId());
            fraction.setBettingOfferIdA(odd.getId());
            fraction.setBettingType( bbMatch.getBettingType());
            fraction.setSportType( bbMatch.getSportType());
            eventFractions.add(fraction);
        }
        return eventFractions;
    }


    private void insertFootballTokensDecodedTeam(EventFraction bbMatch, FootballAsianOdds88Match providerMatch) throws SQLException {
        //logger.debug("bbMatch.getHomeTeam():" + bbMatch.getHomeTeam() + ", bbMatch.getAwayTeam():" + bbMatch.getAwayTeam() + ", providerMatch.getHomeTeam():" + providerMatch.getHomeTeam() + ", providerMatch.getAwayTeam():" + providerMatch.getAwayTeam());
        if(!bbMatch.getAwayTeam().equalsIgnoreCase(providerMatch.getAwayTeam())) {
            bbConnector.insertFootballTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
        }
        if(!bbMatch.getHomeTeam().equalsIgnoreCase(providerMatch.getHomeTeam())) {
            bbConnector.insertFootballTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.ASIANODDS88.getNumVal(), providerMatch.getLeagueName());
        }
    }

    private List<EventFraction> buildFootballMatch(EventFraction bbMatch, FootballAsianOdds88Match providerMatch, Map<String, Integer> bookmakerMapID) {
        List<EventFraction> eventFractions = new ArrayList<>();

        for(HomeAwayDrawAsianOdds88Odd odd: providerMatch.getOdds()){
            EventFraction fraction = new EventFraction();
            fraction.setReferrerId(bbMatch.getReferrerId());
            fraction.setEventId(providerMatch.getId());
            fraction.setOddId(odd.getId());
            fraction.setPlatformId(Platforms.ASIANODDS88.getNumVal());
            fraction.setHomeTeam(bbMatch.getHomeTeam());
            fraction.setAwayTeam(bbMatch.getAwayTeam());
            fraction.setChampionship(providerMatch.getLeagueId());
            fraction.setCountry(bbMatch.getCountry());
            fraction.setContinent(bbMatch.getContinent());
            fraction.setBookmakerId(bookmakerMapID.get(odd.getName()));
            fraction.setBookmakerLabel(odd.getName());
            fraction.setStartTime(bbMatch.getStartTime());
            fraction.setFa(bbMatch.getFa());
            fraction.setFh(bbMatch.getFh());
            fraction.setFd(bbMatch.getFd());
            fraction.setPh(bbMatch.getPh());
            fraction.setPd(bbMatch.getPd());
            fraction.setPa(bbMatch.getPa());
            fraction.setPbh(bbMatch.getPbh());
            fraction.setPbd(bbMatch.getPbd());
            fraction.setPba(bbMatch.getPba());
            fraction.setDelta(bbMatch.getDelta());
            fraction.setBettingOfferIdH(odd.getId());
            fraction.setBettingOfferIdA(odd.getId());
            fraction.setBettingOfferIdD(odd.getId());
            fraction.setBettingType( providerMatch.getBettingType());
            fraction.setSportType( bbMatch.getSportType());
            eventFractions.add(fraction);
        }

        return eventFractions;
    }

    private List<EventFraction> buildBasketMatch(EventFraction bbMatch, BasketAsianOdds88Match providerMatch, Map<String, Integer> bookmakerMapID) {
        List<EventFraction> eventFractions = new ArrayList<>();

        for(HomeAwayDrawAsianOdds88Odd odd: providerMatch.getOdds()){
            EventFraction fraction = new EventFraction();
            fraction.setReferrerId(bbMatch.getReferrerId());
            fraction.setEventId(providerMatch.getId());
            fraction.setOddId(odd.getId());
            fraction.setPlatformId(Platforms.ASIANODDS88.getNumVal());
            fraction.setHomeTeam(bbMatch.getHomeTeam());
            fraction.setAwayTeam(bbMatch.getAwayTeam());
            fraction.setChampionship(providerMatch.getLeagueId());
            fraction.setCountry(bbMatch.getCountry());
            fraction.setContinent(bbMatch.getContinent());
            fraction.setBookmakerId(bookmakerMapID.get(odd.getName()));
            fraction.setBookmakerLabel(odd.getName());
            fraction.setStartTime(bbMatch.getStartTime());
            fraction.setFa(bbMatch.getFa());
            fraction.setFh(bbMatch.getFh());
            fraction.setPh(bbMatch.getPh());
            fraction.setPa(bbMatch.getPa());
            fraction.setPbh(bbMatch.getPbh());
            fraction.setPba(bbMatch.getPba());
            fraction.setDelta(bbMatch.getDelta());
            fraction.setBettingOfferIdH(odd.getId());
            fraction.setBettingOfferIdA(odd.getId());
            fraction.setBettingType(bbMatch.getBettingType());
            fraction.setSportType(bbMatch.getSportType());
            eventFractions.add(fraction);
        }

        return eventFractions;
    }

    private void insertBasketTokensDecodedTeam(EventFraction bbMatch, BasketAsianOdds88Match providerMatch) throws SQLException {
       // logger.debug("bbMatch.getHomeTeam():" + bbMatch.getHomeTeam() + ", bbMatch.getAwayTeam():" + bbMatch.getAwayTeam() + ", providerMatch.getHomeTeam():" + providerMatch.getHomeTeam() + ", providerMatch.getAwayTeam():" + providerMatch.getAwayTeam());
        if(!bbMatch.getAwayTeam().equalsIgnoreCase(providerMatch.getAwayTeam())) {
            bbConnector.insertBasketTeamDecode(bbMatch.getAwayTeam(), providerMatch.getAwayTeam(), Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
        }
        if(!bbMatch.getHomeTeam().equalsIgnoreCase(providerMatch.getHomeTeam())) {
            bbConnector.insertBasketTeamDecode(bbMatch.getHomeTeam(), providerMatch.getHomeTeam(), Platforms.ASIANODDS88.getNumVal(),providerMatch.getLeagueName());
        }
    }

    private boolean matchesSameLeagueSameDate(EventFraction bbMatch, MatchWithContinent providerMatch) {
        LocalDateTime providerMatchDate = providerMatch.getMatchDate();
        LocalDateTime bbMatchDate = bbMatch.getStartTime();

        return bbMatch.getChampionship().equalsIgnoreCase(providerMatch.getLeagueName()) &&
                bbMatchDate.truncatedTo(ChronoUnit.DAYS).isEqual(providerMatchDate.truncatedTo(ChronoUnit.DAYS));
    }

    private boolean matchMatch(String[] tokensBetBrain, String[] tokensProvider) {
        // 0.30 = n/100*60/2
        int minLengthToken = 2;
        int realNumToken = 0;
        String tk1;
        String tk2;
        for(int i=0; i<tokensBetBrain.length; i++) {
            tk1 = tokensBetBrain[i];
            if(tk1.length() <= minLengthToken) {
                continue;
            }
            realNumToken++;
        }
        for(int i=0; i<tokensProvider.length; i++) {
            tk2 = tokensProvider[i];
            if(tk2.length() <= minLengthToken) {
                continue;
            }
            realNumToken++;
        }

        int quorum = (int)((double)(realNumToken)*0.3)+1;

        int counterMatch = 0;

        for(int i=0; i<tokensBetBrain.length; i++) {
            tk1 = tokensBetBrain[i];
            if(tk1.length() <= minLengthToken) {
                continue;
            }
            for(int j=0; j<tokensProvider.length; j++) {
                tk2 = tokensProvider[j];
                if(tk2.length() <= minLengthToken) {
                    continue;
                }
                if(tk1.equalsIgnoreCase(tk2)) {
                    counterMatch++;
                    if(counterMatch == quorum) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean matchesSameDate(EventFraction bbMatch, TennisAsianOdds88Match providerMatch) {
        LocalDateTime providerMatchDate = providerMatch.getMatchDate();
        LocalDateTime bbMatchDate = bbMatch.getStartTime();

        return bbMatchDate.truncatedTo(ChronoUnit.DAYS).isEqual(providerMatchDate.truncatedTo(ChronoUnit.DAYS));
    }
    private boolean matchesSameDateOneDayMore(EventFraction bbMatch, TennisAsianOdds88Match providerMatch) {
        LocalDateTime providerMatchDate = providerMatch.getMatchDate().truncatedTo(ChronoUnit.DAYS).plusDays(1);
        LocalDateTime bbMatchDate = bbMatch.getStartTime().truncatedTo(ChronoUnit.DAYS);

        return bbMatchDate.isEqual(providerMatchDate);
    }


    private boolean playerSanitize(String tennisPlayer) {
        Matcher matcher = pattern.matcher(tennisPlayer);
        if(matcher.find()) {
            return false;
        }
        matcher = patternWord.matcher(tennisPlayer);
        if(matcher.find()) {
            return false;
        }
        return true;
    }

    private String stripSlashesAndDot(String tennisPlayer) {
        String slashesStripped = tennisPlayer.replaceAll("/", " ").replaceAll("\\.", " ");
        return slashesStripped;
    }
}
