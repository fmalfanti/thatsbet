package com.kellify.mergeplatform.asianodds88.model;

import com.kellify.common.BettingType;
import com.kellify.common.OddRole;
import com.kellify.mergeplatform.model.MatchWithContinent;

import java.time.LocalDateTime;
import java.util.List;

public class FootballAsianOdds88Match extends MatchWithContinent {
    private List<HomeAwayDrawAsianOdds88Odd> odds;
    private final String leagueId;

    public FootballAsianOdds88Match(String id, String referrerId, String homeTeam, String awayTeam, String leagueName, LocalDateTime matchDate, BettingType bettingType, String leagueId) {
        super(id, referrerId, homeTeam, awayTeam, leagueName, matchDate, bettingType);
        this.leagueId = leagueId;
    }

    public String getLeagueId() {
        return leagueId;
    }

    public List<HomeAwayDrawAsianOdds88Odd> getOdds() {
        return odds;
    }

    public void setOdds(List<HomeAwayDrawAsianOdds88Odd> odds) {
        this.odds = odds;
    }

    @Override
    public String toString() {
        return "FootballAsianOdds88Match{" +
                "odds=" + odds +
                ", id='" + id + '\'' +
                ", referrerId='" + referrerId + '\'' +
                ", homeTeam='" + homeTeam + '\'' +
                ", awayTeam='" + awayTeam + '\'' +
                ", matchDate=" + matchDate +
                ", bettingType=" + bettingType +
                ", leagueName='" + leagueName + '\'' +
                ", country='" + country + '\'' +
                ", leagueId='" + leagueId + '\'' +
                '}';
    }
}
