package com.kellify.mergeplatform.mollybet;

import com.kellify.common.model.EventFraction;

import java.util.List;

public interface AmericanFootballMollyBetConnector {
    public List<EventFraction> americanFootballOdds() throws Exception;
}
