package com.kellify.mergeplatform.executionproviders;

import com.kellify.common.SportTypes;
import com.kellify.mergeplatform.common.ChampionshipDecode;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface ProviderPilot {
    void init() throws SQLException;
    List < ?> pilotMatches(SportTypes sportType) throws SQLException;
    Map<String, Integer> bettingTypeDecodeMap();
    Map<String, ChampionshipDecode> championshipDecodeMap(SportTypes sportType) throws SQLException;
    void createOddsSnapshot() throws SQLException;
}
