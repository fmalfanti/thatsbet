package com.kellify.mergeplatform.matchbook.model;

import java.util.Objects;

public class MatchBookHomeAwayOdd {
    private final String idHome;
    private final String idAway;
    private final String name = "MATCHBOOK";
    private final double home;
    private final double away;

    public MatchBookHomeAwayOdd(String idHome, String idAway, double home, double away) {
        this.idHome = idHome;
        this.idAway = idAway;
        this.home = home;
        this.away = away;
    }

    public String getIdHome() {
        return idHome;
    }

    public String getIdAway() {
        return idAway;
    }

    public String getName() {
        return name;
    }

    public double getHome() {
        return home;
    }

    public double getAway() {
        return away;
    }

    public boolean isValid() {
        return home > 0 || away > 0;
    }

    @Override
    public String toString() {
        return "MatchBookHomeAwayOdd{" +
                "name='" + name + '\'' +
                ", idHome='" + idHome + '\'' +
                ", idAway='" + idAway + '\'' +
                ", home=" + home +
                ", away=" + away +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MatchBookHomeAwayOdd that = (MatchBookHomeAwayOdd) o;
        return Double.compare(that.home, home) == 0 &&
                Double.compare(that.away, away) == 0 &&
                Objects.equals(idHome, that.idHome) &&
                Objects.equals(idAway, that.idAway) &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHome, idAway, name, home, away);
    }
}
