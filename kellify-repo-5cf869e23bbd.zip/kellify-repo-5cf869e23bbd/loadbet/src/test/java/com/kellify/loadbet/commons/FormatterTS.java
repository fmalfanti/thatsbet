package com.kellify.loadbet.commons;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;

public class FormatterTS {
    public static void main(String[] args) {
        DateTimeFormatter mdy = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");
// parser for both patterns
        DateTimeFormatter parser = new DateTimeFormatterBuilder()
                // optional MM/dd/yyyy
                .appendOptional(mdy)
                // optional yyyy-MM-dd'T'HH:mm:ss (use built-in formatter)
                .appendOptional(formatter)
                // create formatter
                .toFormatter();

        LocalDate d1 = LocalDate.parse("08/06/06", parser);
        LocalDate d2 = LocalDate.parse("06/08/2006", parser);

        //System.out.println(d1);
        //System.out.println(d2);
    }
}
