package com.kellify.loadbet.matrixFiller;

import com.kellify.common.util.Matrici;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class HAMatrixFiller {
    private static final Logger logger = LoggerFactory.getLogger(HAMatrixFiller.class);

    public Map<Integer,Matrici.HAMatrix> fillMatrixHAOdds(PreparedStatement psQuotas, String[] bms) throws IOException, SQLException {

        Map<Integer,Matrici.HAMatrix> MappaHA=new HashMap();
        ResultSet rs=null;

        Matrici.HAMatrix punto;
        double tH, tA;
        String ftr;
        double pH,pA,pNorm;
        int ipH;
        rs = psQuotas.executeQuery();
        try {
            while (rs.next()) {
                ftr=rs.getString(1);
                for (int i=0;i<bms.length;i++) {
                    tH=rs.getDouble(i*2+2);
                    tA=rs.getDouble(i*2+3);
                    if((tH!=-1)&&(tA!=-1)&&(tH!=0)&&(tA!=0)){
                        pH = 1 / tH;
                        pA = 1 / tA;
                        pNorm = pH + pA;
                        pH /= pNorm;
                        ipH = (int) Math.floor(pH * 100);
                        punto = MappaHA.get(ipH);
                        if (punto == null) {
                            punto = new Matrici.HAMatrix();
                        }
                        punto.add(ftr);
                        MappaHA.put(ipH, punto);
                    }
                }
            }
            rs.close();



        } catch (Exception e) {

            logger.error(e.getMessage(), e);
        } finally {
            if (rs != null) rs.close();

        }
        return MappaHA;
    }
    public Map<String,Map<Integer,Matrici.HAMatrix>> fillMatrixContNazOdds(PreparedStatement psNazioni, PreparedStatement psContinenti, PreparedStatement psQuotas, String[] bms) throws IOException {

        ResultSet rs=null;
        String nazione="";
        String continente="";
        Map<String,Map<Integer,Matrici.HAMatrix>> MappaHA=new HashMap<>();
        try {

            Map<Integer,Matrici.HAMatrix> useNationMap;
            Map<Integer,Matrici.HAMatrix> useContinentMap;
            Map<Integer,Matrici.HAMatrix> useWorldMap;
            Matrici.HAMatrix punto;
            double tH, tA;
            String ftr;
            double pH,pA,pNorm;
            int ipH;
            useWorldMap = MappaHA.computeIfAbsent("World", k -> new HashMap<>());
            rs = psContinenti.executeQuery();
            while (rs.next()) {
                continente = rs.getString(1);
                MappaHA.computeIfAbsent(continente, k -> new HashMap<>());
            }
            rs.close();
            rs = psNazioni.executeQuery();
            while (rs.next()) {
                nazione = rs.getString(1);
                MappaHA.computeIfAbsent(nazione, k -> new HashMap<>());
            }
            rs.close();

            //System.out.println(MappaHA.keySet());
            rs = psQuotas.executeQuery();
            while (rs.next()) {
                nazione = rs.getString(1);
                continente = rs.getString(2);
                useContinentMap=MappaHA.get(continente);
                useNationMap=MappaHA.get(nazione);

                ftr=rs.getString(3);

                for (int i=0;i<bms.length;i++) {
                    tA=rs.getDouble(i*2+4);
                    tH=rs.getDouble(i*2+5);

                    if((tH!=-1)&&(tA!=-1)&&(tH!=0)&&(tA!=0)){
                        pH = 1 / tH;
                        pA = 1 / tA;
                        pNorm = pH + pA;
                        pH /= pNorm;

                        ipH = (int) Math.round(pH * 100);

                        punto = useNationMap.get(ipH);
                        if (punto == null) {
                            punto = new Matrici.HAMatrix();
                        }
                        punto.add(ftr);
                        useNationMap.put(ipH, punto);
                        punto = useContinentMap.get(ipH);
                        if (punto == null) {
                            punto = new Matrici.HAMatrix();
                        }
                        punto.add(ftr);
                        useContinentMap.put(ipH, punto);
                        punto = useWorldMap.get(ipH);
                        if (punto == null) {
                            punto = new Matrici.HAMatrix();
                        }
                        punto.add(ftr);
                        //System.out.println(punto.toString());
                        useWorldMap.put(ipH, punto);
                    }
                }
            }
            rs.close();

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
        }
        return MappaHA;
    }
}
