package com.kellify.loadbet.load;

import com.kellify.loadbet.commons.DbConnector;
import com.kellify.loadbet.commons.ExcelToCSV;
import com.kellify.loadbet.commons.LoadBetType;
import com.kellify.loadbet.commons.Unzipper;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class TennisLoader {
    private static final Logger logger = LoggerFactory.getLogger(TennisLoader.class);
    private static DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("dd/MM/yy");
    private static DateTimeFormatter formatter_2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DateTimeFormatter parserLungo;
    private DateTimeFormatter parserCorto;
    
    public TennisLoader() {
        parserCorto = new DateTimeFormatterBuilder()
                .appendOptional(formatter_1)
                .toFormatter();
        parserLungo = new DateTimeFormatterBuilder()
                .appendOptional(formatter_2)
                .toFormatter();
    }

    public int[] loadBetTennisOdds(File file, PreparedStatement psOdds, PreparedStatement psMeanOdds, PreparedStatement psMeanProbs) throws IOException {
        int[] ret = null;
        Reader in = null;
        int counter = 0;
        int emptyCount = 0;
        try {
            Map<String, String> dataMap = null;
            String dateString = null;
            LocalDate dateTime;

            in = new FileReader(file);
            Iterable<CSVRecord> records = CSVFormat.EXCEL.withHeader().parse(in);
            String oddw = "";
            String oddl = "";
            double MW = 0.0;
            double ML = 0.0;
            double tw = 0.0;
            double tl = 0.0;
            double minW = 0.0;
            double minL = 0.0;
            double maxW = 0.0;
            double maxL = 0.0;
            double probW = 0.0;
            double probL = 0.0;
            double norm = 0.0;
            int NM=0;
            String sRank = "";

            CalculateTennisMeansInput calculateTennisMeansInput;
            CalculateTennisMeansOutput calculateTennisMeansOutput;
            for (CSVRecord record : records) {
                try {
                    dateString = record.get("Date");
                    if(dateString == null || dateString.length() == 0) {
                        emptyCount++;
                        continue;
                    }
                    //System.out.println(dateString);
                    if (dateString.length() == 8) {
                        dateTime = LocalDate.parse(record.get("Date"), parserCorto);
                    } else {
                        dateTime = LocalDate.parse(record.get("Date"), parserLungo);
                    }
                    //System.out.println(dateString+" "+dateTime.toString());
                    dataMap = record.toMap();

                    String winner = dataMap.get("Winner");
                    String loser = dataMap.get("Loser");

                    sRank = dataMap.get("WRank");
                    int wrank = -1;
                    try {
                        wrank = (int)Double.parseDouble(sRank);
                    } catch(NumberFormatException e) {
                        wrank = -1;
                    }
                    sRank = dataMap.get("LRank");
                    int lrank = -1;
                    try {
                        lrank = (int)Double.parseDouble(sRank);
                    } catch(NumberFormatException e) {
                        lrank = -1;
                    }

                    String location = dataMap.get("Location");
                    String tournament = dataMap.get("Tournament");
                    String series = dataMap.get("Series");
                    String surface = dataMap.get("Surface");
                    String round = dataMap.get("Round");

                    psOdds.setDate(1, java.sql.Date.valueOf(dateTime));
                    psOdds.setString(2, winner);
                    psOdds.setString(3, loser);
                    psOdds.setInt(4, wrank);
                    psOdds.setInt(5, lrank);
                    psOdds.setString(28, location);
                    psOdds.setString(29, tournament);
                    psOdds.setString(30, series);
                    psOdds.setString(31, surface);
                    psOdds.setString(32, round);

                    oddw = dataMap.get("B365W");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("B365L");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(6, tw);
                    psOdds.setDouble(7, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("EXW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("EXL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(8, tw);
                    psOdds.setDouble(9, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("LBW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("LBL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(10, tw);
                    psOdds.setDouble(11, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("PSW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("PSL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(12, tw);
                    psOdds.setDouble(13, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("SJW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("SJL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(14, tw);
                    psOdds.setDouble(15, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("UBW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("UBL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(16, tw);
                    psOdds.setDouble(17, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("IWW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("IWL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(18, tw);
                    psOdds.setDouble(19, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("CBW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("CBL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(20, tw);
                    psOdds.setDouble(21, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("SBW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("SBL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(22, tw);
                    psOdds.setDouble(23, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("BEWW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("BEWL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(24, tw);
                    psOdds.setDouble(25, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    oddw = dataMap.get("GBW");
                    oddw = StringUtils.isBlank(oddw) ? "-1" : oddw;
                    oddl = dataMap.get("GBL");
                    oddl = StringUtils.isBlank(oddl) ? "-1" : oddl;
                    tw = Double.parseDouble(oddw);
                    tl = Double.parseDouble(oddl);
                    psOdds.setDouble(26, tw);
                    psOdds.setDouble(27, tl);
                    if ((tw+tl) != -2){
                        calculateTennisMeansInput = new CalculateTennisMeansInput(tw, tl, minW, minL, maxW, maxL, MW, ML, NM);
                        calculateTennisMeansOutput = calculateMeans(calculateTennisMeansInput);
                        MW = calculateTennisMeansOutput.getGlobalW();
                        ML = calculateTennisMeansOutput.getGlobalL();
                        NM = calculateTennisMeansOutput.getGlobalNM();
                        minW = calculateTennisMeansOutput.getMinW();
                        minL = calculateTennisMeansOutput.getMinL();
                        maxW = calculateTennisMeansOutput.getMaxW();
                        maxL = calculateTennisMeansOutput.getMaxL();
                    }

                    if (NM>0){
                        MW /= NM;
                        ML /= NM;
                    }

                    psMeanOdds.setDate(1, java.sql.Date.valueOf(dateTime));
                    psMeanOdds.setString(2, winner);
                    psMeanOdds.setString(3, loser);
                    psMeanOdds.setInt(4, wrank);
                    psMeanOdds.setInt(5, lrank);
                    psMeanOdds.setDouble(6, maxW);
                    psMeanOdds.setDouble(7, MW);
                    psMeanOdds.setDouble(8, minW);
                    psMeanOdds.setDouble(9, maxL);
                    psMeanOdds.setDouble(10, ML);
                    psMeanOdds.setDouble(11, minL);
                    psMeanOdds.setInt(12, NM);
                    psMeanOdds.setString(13, location);
                    psMeanOdds.setString(14, tournament);
                    psMeanOdds.setString(15, series);
                    psMeanOdds.setString(16, surface);
                    psMeanOdds.setString(17, round);
                    psMeanOdds.executeUpdate();

                    if (MW*ML != 0.0) {
                        probW=1.0/MW;
                        probL=1.0/ML;
                        norm=probW+probL;
                        probW/=norm;
                        probL/=norm;
                        psMeanProbs.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbs.setString(2, winner);
                        psMeanProbs.setString(3, loser);
                        psMeanProbs.setInt(4, wrank);
                        psMeanProbs.setInt(5, lrank);
                        psMeanProbs.setDouble(6, probW);
                        psMeanProbs.setDouble(7, probL);
                        psMeanProbs.setInt(8, NM);
                        psMeanProbs.setString(9, location);
                        psMeanProbs.setString(10, tournament);
                        psMeanProbs.setString(11, series);
                        psMeanProbs.setString(12, surface);
                        psMeanProbs.setString(13, round);
                        psMeanProbs.executeUpdate();
                    }

                    psOdds.executeUpdate();
                    counter++;
                } catch(Exception ex) {
                    logger.error("record:" + record.toString(), ex);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if(in != null) {
                in.close();
            }

        }
        ret = new int[] {counter,  emptyCount};
        return ret;
    }

    public static void LoadTennisData(DbConnector dbConnector, Properties config) throws SQLException, IOException {
        logger.info("LoadTennisData process start");
        Unzipper unzipper = new Unzipper(config, LoadBetType.TENNIS);
        unzipper.unzip();
        Connection conn;
        ExcelToCSV excelToCSV;

        File folder = new File(config.getProperty("tennis.data.folder"));
        PreparedStatement psQuotas = null;
        PreparedStatement psMeanQuotas = null;
        PreparedStatement psMeanProbs = null;
        File[] files = folder.listFiles();
        int counter = 0;
        int emptyCounter = 0;
        try {

            conn = dbConnector.getConnection();
            psQuotas = conn.prepareStatement(DbConnector.INSERT_TENNIS_ODDS);
            psMeanQuotas = conn.prepareStatement(DbConnector.INSERT_BET_TENNIS_MEANS_ODDS);
            psMeanProbs = conn.prepareStatement(DbConnector.INSERT_BET_TENNIS_CLUSTERS);
            TennisLoader tennisLoader = new TennisLoader();
            assert files != null;
            for (File f : files) {
                List<File> listFiles = null;
                try {
                    logger.info("file:" + f.getName());
                    excelToCSV = new ExcelToCSV(f);
                    listFiles = excelToCSV.writeCSV();
                    for(File csvFile : listFiles) {
                        logger.info("csvFile:" + csvFile.getName());
                        int[] localCounter = tennisLoader.loadBetTennisOdds(csvFile, psQuotas, psMeanQuotas, psMeanProbs);
                        logger.info("file rows:" + localCounter[0] + ", file empty rows:" + localCounter[1]);
                        counter += localCounter[0];
                        emptyCounter += localCounter[1];
                        try {
                            csvFile.delete();
                        } catch (Exception ex) {
                            logger.error(ex.getMessage(), ex);
                        }
                    }
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                } finally {
                    f.delete();
                }
            }
            logger.info("total rows:" + counter + ", total empty rows:" + emptyCounter);
        } finally {
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psMeanQuotas != null) {
                psMeanQuotas.close();
            }
            if (psMeanProbs != null) {
                psMeanProbs.close();
            }
        }
        logger.info("LoadTennisData process end");
    }


    private CalculateTennisMeansOutput calculateMeans(CalculateTennisMeansInput params) {
        double globalW = params.getGlobalW() + params.getOddW();
        double globalL = params.getGlobalL() + params.getOddL();
        int globalNM = params.getGlobalNM()+1;
        double minW = Math.min(params.getMinW(), params.getOddW());
        double minL = Math.min(params.getMinL(), params.getOddL());
        double maxW = Math.max(params.getMaxW(), params.getOddW());
        double maxL = Math.max(params.getMaxL(), params.getOddL());
        return new CalculateTennisMeansOutput(minW, minL, maxW, maxL, globalNM, globalW, globalL);
    }

    private class CalculateTennisMeansInput {
        private final double oddW;
        private final double oddL;
        private final double minW;
        private final double minL;
        private final double maxW;
        private final double maxL;
        private final double globalW;
        private final double globalL;
        private final int globalNM;

        public CalculateTennisMeansInput(double oddW, double oddL, double minW, double minL, double maxW, double maxL, double globalW, double globalL, int globalNM) {
            this.oddW = oddW;
            this.oddL = oddL;
            this.minW = minW;
            this.minL = minL;
            this.maxW = maxW;
            this.maxL = maxL;
            this.globalW = globalW;
            this.globalL = globalL;
            this.globalNM = globalNM;
        }

        public double getOddW() {
            return oddW;
        }

        public double getOddL() {
            return oddL;
        }

        public double getMinW() {
            return minW;
        }

        public double getMinL() {
            return minL;
        }

        public double getMaxW() {
            return maxW;
        }

        public double getMaxL() {
            return maxL;
        }

        public double getGlobalW() {
            return globalW;
        }

        public double getGlobalL() {
            return globalL;
        }

        public int getGlobalNM() {
            return globalNM;
        }
    }

    private class CalculateTennisMeansOutput {
        private final double minW;
        private final double minL;
        private final double maxW;
        private final double maxL;
        private final int globalNM;
        private final double globalW;
        private final double globalL;

        public CalculateTennisMeansOutput(double minW, double minL, double maxW, double maxL, int globalNM, double globalW, double globalL) {
            this.minW = minW;
            this.minL = minL;
            this.maxW = maxW;
            this.maxL = maxL;
            this.globalNM = globalNM;
            this.globalW = globalW;
            this.globalL = globalL;
        }

        public double getMinW() {
            return minW;
        }

        public double getMinL() {
            return minL;
        }

        public double getMaxW() {
            return maxW;
        }

        public double getMaxL() {
            return maxL;
        }

        public int getGlobalNM() {
            return globalNM;
        }

        public double getGlobalW() {
            return globalW;
        }

        public double getGlobalL() {
            return globalL;
        }
    }
}
