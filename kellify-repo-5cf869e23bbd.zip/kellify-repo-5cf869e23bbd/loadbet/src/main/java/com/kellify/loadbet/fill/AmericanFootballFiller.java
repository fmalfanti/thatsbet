package com.kellify.loadbet.fill;

import com.kellify.common.util.BmsBySports;
import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.DbConnector;
import com.kellify.loadbet.matrixFiller.HAMatrixFiller;
import org.slf4j.Logger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;

public class AmericanFootballFiller {
    public static void FillAmericanFootballMatrix(DbConnector dbConnector, Properties config,Logger logger) throws SQLException, IOException {
        logger.info("FillAmericanFootballMatrix process start");
        PreparedStatement psMatrici = null;
        PreparedStatement psQuotas = null;
        //PreparedStatement psResults = null;
        String [] bms = BmsBySports.AmericanFootballBms;
        //{"bet-at-home_op_ha_","10bet_op_ha_","marathon_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","bwin_op_ha_","unibet_op_ha_"};

        Map<Integer,Matrici.HAMatrix> MappaHA;
        HAMatrixFiller filler = new HAMatrixFiller();
        try {
            Connection conn=dbConnector.getConnection();
            psMatrici = conn.prepareStatement(DbConnector.INSERT_AMERICANFOOTBALL_MATRICI);
            psQuotas = conn.prepareStatement(DbConnector.GET_AMERICANFOOTBALL_ODDS);
            //psResults = conn.prepareStatement(DbConnector.GET_BASKET_RESULTS);

            MappaHA=filler.fillMatrixHAOdds(psQuotas,bms);



            psMatrici.setString(1, "mappa");
            psMatrici.setString(2, Matrici.MapToDbHA(MappaHA));
            psMatrici.setString(3, Matrici.MapToDbHA(MappaHA));
            psMatrici.executeUpdate();

        } finally {
            if (psMatrici != null) {
                psMatrici.close();
            }
            if (psQuotas != null) {
                psQuotas.close();
            }


        }
        logger.info("FillAmericanFootballMatrix process end");
    }

}
