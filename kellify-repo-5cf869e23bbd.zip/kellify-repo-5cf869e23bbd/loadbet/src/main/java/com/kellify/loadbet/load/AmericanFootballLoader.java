package com.kellify.loadbet.load;

import com.kellify.loadbet.commons.DbConnector;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

public class AmericanFootballLoader {
    private static final Logger logger = LoggerFactory.getLogger(AmericanFootballLoader.class);

    DateTimeFormatter formatter;




    public AmericanFootballLoader() {
        formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
    }

    public int[] loadAmericanFootballOdds(File file,  PreparedStatement psQuotas, PreparedStatement psMeanQuotas, PreparedStatement psMeanProbs) throws IOException {
        int[] ret;
        Reader in = null;
        int counter = 0;
        int emptyCount = 0;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy",Locale.US);

        String [] bms = {"bet-at-home_op_ha_","10bet_op_ha_","marathon_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","bwin_op_ha_","unibet_op_ha_"};




        try {
            double[] tAtH;
            Map<String, String> dataMap;
            String dateString;
            String nazione,continente;
            in = new FileReader(file);
            Iterable<CSVRecord> records = CSVFormat.DEFAULT.withDelimiter(';').withHeader().parse(in);
            LocalDate dateTime;
            double MH,MA;
            double tH, tA ;
            double minA,minH;
            double maxA,maxH;
            double probA,probH;
            double norm;
            String Fthg ,Ftag ;
            int fthg,ftag;
            int NM;


            CalculateMeansOutput calculateMeansOutput;

            for (CSVRecord record : records) {
                MH = 0.0;
                MA = 0.0;
                minA = 100.0;
                minH = 100.0;
                maxA = 0.0;
                maxH = 0.0;
                NM=0;


                try {
                    dateString = record.get("dd")+"-"+record.get("mm")+"-"+record.get("yy");
                    if(dateString == null || dateString.length() == 0) {
                        emptyCount++;
                        continue;
                    }
                    dateTime = LocalDate.parse(dateString, formatter);
                    dataMap = record.toMap();

                    String campionato = dataMap.get("league");


                    String homeTeam = dataMap.get("home_team");
                    String awayTeam = dataMap.get("away_team");
                    Fthg = dataMap.get("ft_score_home");
                    Ftag = dataMap.get("ft_score_away");
                    String ftr = dataMap.get("ft_score_result");
                    nazione=dataMap.get("country");
                    continente="NorthAmerica";
                    fthg = Integer.parseInt(Fthg);
                    ftag = Integer.parseInt(Ftag);


                    psQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psQuotas.setString(2, campionato);
                    psQuotas.setString(3, nazione);
                    psQuotas.setString(4, continente);
                    psQuotas.setString(5, homeTeam);
                    psQuotas.setString(6, awayTeam);
                    psQuotas.setInt(7, fthg);
                    psQuotas.setInt(8, ftag);
                    psQuotas.setString(9, ftr);

                    psMeanQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psMeanQuotas.setString(2, campionato);
                    psMeanQuotas.setString(3, nazione);
                    psMeanQuotas.setString(4, continente);
                    psMeanQuotas.setString(5, homeTeam);
                    psMeanQuotas.setString(6, awayTeam);
                    psMeanQuotas.setInt(7, fthg);
                    psMeanQuotas.setInt(8, ftag);
                    psMeanQuotas.setString(9, ftr);





                    for (int i=0;i<bms.length;i++){

                        tAtH=CalculatetAtH(bms[i], i, dataMap, psQuotas);
                        tA=tAtH[0];
                        tH=tAtH[1];
                        if ((tA+tH)!=-2){
                            calculateMeansOutput = calculateMeans(tH, tA, minH, minA,  maxH, maxA, MH, MA,  NM);
                            MA = calculateMeansOutput.getGlobalA();
                            MH = calculateMeansOutput.getGlobalH();
                            NM = calculateMeansOutput.getGlobalNM();
                            minA = calculateMeansOutput.getMinA();
                            minH = calculateMeansOutput.getMinH();
                            maxA = calculateMeansOutput.getMaxA();
                            maxH = calculateMeansOutput.getMaxH();
                        }
                    }




                    if (NM>0){
                        MA /= NM;
                        MH /= NM;
                    }

                    psMeanQuotas.setDouble(10, minA);
                    psMeanQuotas.setDouble(11, MA);
                    psMeanQuotas.setDouble(12, maxA);
                    psMeanQuotas.setDouble(13, minH);
                    psMeanQuotas.setDouble(14, MH);
                    psMeanQuotas.setDouble(15, maxH);
                    psMeanQuotas.setInt(16, NM);
                    psMeanQuotas.executeUpdate();

                    if (MA*MH!=0.0) {
                        probA=1.0/MA;
                        probH=1.0/MH;

                        norm=probA+probH;
                        probA/=norm;
                        probH/=norm;

                        psMeanProbs.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbs.setString(2, campionato);
                        psMeanProbs.setString(3, nazione);
                        psMeanProbs.setString(4, continente);
                        psMeanProbs.setString(5, homeTeam);
                        psMeanProbs.setString(6, awayTeam);
                        psMeanProbs.setInt(7, fthg);
                        psMeanProbs.setInt(8, ftag);
                        psMeanProbs.setString(9, ftr);
                        psMeanProbs.setDouble(10, probA);
                        psMeanProbs.setDouble(11, probH);
                        psMeanProbs.setInt(12, NM);
                        psMeanProbs.executeUpdate();
                    }

                    psQuotas.executeUpdate();

                    counter++;

                } catch(Exception ex) {
                    logger.error("record:" + record.toString(), ex);


                }
            }


        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if(in != null) {
                in.close();
            }
        }
        ret = new int[] {counter,  emptyCount};
        return ret;
    }

    public static void LoadAmericanFootballData(DbConnector dbConnector, Properties config) throws SQLException, IOException {
        logger.info("LoadAmericanFootballData process start");
        //Unzipper unzipper = new Unzipper(config, LoadBetType.FOOTBALL);
        //unzipper.unzip();

        File folder = new File(config.getProperty("americanfootball.data.folder"));
        PreparedStatement psQuotas = null;

        PreparedStatement psMeanQuotas = null;
        PreparedStatement psMeanProbs = null;

        File[] files = folder.listFiles();
        int counter = 0;
        int emptyCounter = 0;
        AmericanFootballLoader loader = new AmericanFootballLoader();
        String fileName = null;

        try {
            Connection conn=dbConnector.getConnection();
            psQuotas = conn.prepareStatement(DbConnector.INSERT_AMERICANFOOTBALL_ODDS);
            psMeanQuotas = conn.prepareStatement(DbConnector.INSERT_BET_AMERICANFOOTBALL_MEANS_ODDS);
            psMeanProbs = conn.prepareStatement(DbConnector.INSERT_BET_AMERICANFOOTBALL_CLUSTERS);


            for (File f : files) {
                try {
                    fileName = f.getName();
                    //System.out.println("fileName="+fileName);
                    int localCounter[] =  loader.loadAmericanFootballOdds(f,psQuotas, psMeanQuotas,psMeanProbs);

                    logger.info("file rows:" + localCounter[0] + ", file empty rows:" + localCounter[1]);
                    counter += localCounter[0];
                    emptyCounter += localCounter[1];
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                } finally {
                    //f.delete();
                }
            }


            logger.info("total rows:" + counter + ", total empty rows:" + emptyCounter);
        } finally {
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psMeanQuotas != null) {
                psMeanQuotas.close();
            }
            if (psMeanProbs != null) {
                psMeanProbs.close();
            }
        }
        logger.info("LoadAmericanFootballData process end");
    }


    private double[] CalculatetAtH(String bm,int psInt,Map <String,String> dataMap,PreparedStatement psQuotas) throws SQLException {



        String oddh,odda;
        double tH,tA;


        oddh = dataMap.get(bm+"h");
        oddh = StringUtils.isBlank(oddh) ? "-1" : oddh;
        tH = Double.parseDouble(oddh.replace(',','.'));

        odda = dataMap.get(bm+"a");
        odda = StringUtils.isBlank(odda) ? "-1" : odda;
        tA = Double.parseDouble(odda.replace(',','.'));
        psQuotas.setDouble(10+2*psInt, tA);

        psQuotas.setDouble(11+2*psInt, tH);

        return new double[]{tA,tH};
    }

    private CalculateMeansOutput calculateMeans(double oddH, double oddA,  double minH, double minA, double maxH, double maxA,  double globalH, double globalA,  int globalNM) {
        double iGlobalA = globalA + oddA;
        double iGlobalH = globalH + oddH;

        int iGlobalNM = globalNM+1;
        double iMinA = Math.min(minA, oddA);
        double iMinH = Math.min(minH, oddH);

        double iMaxA = Math.max(maxA, oddA);
        double iMaxH = Math.max(maxH, oddH);

        return new CalculateMeansOutput(iMinH, iMinA,  iMaxH, iMaxA, iGlobalNM, iGlobalH, iGlobalA);
    }

    private class CalculateMeansOutput {
        private final double minH;
        private final double minA;

        private final double maxH;
        private final double maxA;

        private final int globalNM;
        private final double globalH;
        private final double globalA;


        CalculateMeansOutput(double minH, double minA,double maxH, double maxA,  int globalNM, double globalH, double globalA) {
            this.minH = minH;
            this.minA = minA;

            this.maxH = maxH;
            this.maxA = maxA;

            this.globalNM = globalNM;
            this.globalH = globalH;
            this.globalA = globalA;

        }

        double getMinH() {
            return minH;
        }

        double getMinA() {
            return minA;
        }



        double getMaxH() {
            return maxH;
        }

        double getMaxA() {
            return maxA;
        }



        int getGlobalNM() {
            return globalNM;
        }

        double getGlobalH() {
            return globalH;
        }

        double getGlobalA() {
            return globalA;
        }


    }
}
