package com.kellify.loadbet.commons;

public enum LoadBetType {
    FOOTBALL,
    TENNIS
}
