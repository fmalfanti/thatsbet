package com.kellify.loadbet.matrixFiller;

import com.kellify.common.util.Matrici;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class WLMatrixFiller {
    private static final Logger logger = LoggerFactory.getLogger(WLMatrixFiller.class);
    public Map<Integer,Matrici.WLMatrix> fillMatrixWLOdds(PreparedStatement psQuotas, String [] bms) throws IOException, SQLException {

        ResultSet rs=null;
        Map<Integer,Matrici.WLMatrix> MappaWL=new HashMap();
        Matrici.WLMatrix punto;
        double tW, tL ;

        double pW,pL,pNorm;
        int ipW,ipL,indice,WW,LL;
        try {

            rs = psQuotas.executeQuery();
            while (rs.next()) {
                for (int i=0;i<bms.length;i++) {
                    tW=rs.getDouble(i*2+1);
                    tL=rs.getDouble(i*2+2);
                    if((tW!=-1)&&(tL!=-1)&&(tW!=0)&&(tL!=0)){
                        pW = 1 / tW;
                        pL = 1 / tL;
                        pNorm = pW + pL;
                        pW /= pNorm;
                        pL /= pNorm;
                        ipW = (int) Math.round(pW * 100);
                        ipL = (int) Math.round(pL * 100);
                        indice=Math.max(ipW,ipL);
                        punto = MappaWL.get(indice);
                        if (punto == null) {
                            punto = new Matrici.WLMatrix();
                        }
                        punto.add(ipW,ipL);
                        MappaWL.put(indice, punto);
                    }
                }
            }
            rs.close();
            for (int i=51;i<101;i++){
                if(MappaWL.get(i)!=null) {
                    WW=MappaWL.get(i).getW();
                    LL=MappaWL.get(i).getL();

                    punto = MappaWL.get(100-i);
                    if (punto == null) {
                        punto = new Matrici.WLMatrix();
                    }

                    punto.setL(WW);
                    punto.setW(LL);

                    MappaWL.put(100-i, punto);

                }

            }

        } catch (Exception e) {

            logger.error(e.getMessage(), e);
        } finally {
            if (rs != null) rs.close();

        }
        return MappaWL;
    }
}
