package com.kellify.loadbet.matrixFiller;

import com.kellify.common.util.Matrici;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class HDAMatrixFillerWeight {
    private static final Logger logger = LoggerFactory.getLogger(HDAMatrixFillerWeight.class);
    public Map<String,Map<Integer,Matrici.HdaMatrix>> fillMatrixOddsWeight(PreparedStatement psNazioni, PreparedStatement psContinenti, PreparedStatement psQuotas, String [] bms ) throws IOException {

        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeFootball  = new HashMap<>();
        ResultSet rs=null;
        String nazione;
        String continente;
        try {

            Map<Integer,Matrici.HdaMatrix> useNationMap;
            Map<Integer,Matrici.HdaMatrix> useContinentMap;
            Map<Integer,Matrici.HdaMatrix> useWorldMap;
            Matrici.HdaMatrix punto;
            double tH, tA , tD;
            String ftr;
            double pA,pD,pH,pNorm;
            int ipA,ipH;
            int yearmatch,weight;

            MappeFootball.computeIfAbsent("World", k -> new HashMap<>());
            useWorldMap=MappeFootball.get("World");
            rs = psContinenti.executeQuery();
            while (rs.next()) {
                continente = rs.getString(1);
                MappeFootball.computeIfAbsent(continente, k -> new HashMap<>());
            }
            rs.close();
            rs = psNazioni.executeQuery();
            while (rs.next()) {
                nazione = rs.getString(1);
                MappeFootball.computeIfAbsent(nazione, k -> new HashMap<>());
            }
            rs.close();

            rs = psQuotas.executeQuery();

            while (rs.next()) {
                nazione = rs.getString(1);
                continente = rs.getString(2);
                useContinentMap=MappeFootball.get(continente);
                useNationMap=MappeFootball.get(nazione);

                ftr=rs.getString(3);
                yearmatch=rs.getInt(4);
                weight=yearmatch-2000;
                //System.out.println("weight"+weight);
                for (int i=0;i<bms.length;i++) {
                    tA=rs.getDouble(3*i+5);
                    tD=rs.getDouble(3*i+6);
                    tH=rs.getDouble(3*i+7);
                    if((tA!=-1)&&(tD!=-1)&&(tH!=-1)){
                        pA = 1 / tA;
                        pD = 1 / tD;
                        pH = 1 / tH;
                        pNorm = pA + pD + pH;
                        pA /= pNorm;
                        pH /= pNorm;
                        ipA = (int) Math.round(pA * 100);
                        ipH = (int) Math.round(pH * 100);

                        Integer indice = 101 * ipH + ipA;
                        punto = useNationMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.addweight(ftr,(weight+1));
                        useNationMap.put(indice, punto);

                        punto = useContinentMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.addweight(ftr,(weight+1));
                        useContinentMap.put(indice, punto);

                        punto = useWorldMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.addweight(ftr,(weight+1));
                        useWorldMap.put(indice, punto);

                    }

                }

            }

            rs.close();


        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {

        }
        return MappeFootball;

    }

    private HDAMatrixFillerWeight.CalculateMeansOutput calculateMeans(double oddH, double oddA, double oddD, double minH, double minA, double minD, double maxH, double maxA, double maxD, double globalH, double globalA, double globalD, int globalNM) {
        double iGlobalA = globalA + oddA;
        double iGlobalH = globalH + oddH;
        double iGlobalD = globalD + oddD;
        int iGlobalNM = globalNM+1;
        double iMinA = Math.min(minA, oddA);
        double iMinH = Math.min(minH, oddH);
        double iMinD = Math.min(minD, oddD);
        double iMaxA = Math.max(maxA, oddA);
        double iMaxH = Math.max(maxH, oddH);
        double iMaxD = Math.max(maxD, oddD);
        return new HDAMatrixFillerWeight.CalculateMeansOutput(iMinH, iMinA, iMinD, iMaxH, iMaxA, iMaxD, iGlobalNM, iGlobalH, iGlobalA, iGlobalD);
    }

    private class CalculateMeansOutput {
        private final double minH;
        private final double minA;
        private final double minD;
        private final double maxH;
        private final double maxA;
        private final double maxD;
        private final int globalNM;
        private final double globalH;
        private final double globalA;
        private final double globalD;

        CalculateMeansOutput(double minH, double minA, double minD, double maxH, double maxA, double maxD, int globalNM, double globalH, double globalA, double globalD) {
            this.minH = minH;
            this.minA = minA;
            this.minD = minD;
            this.maxH = maxH;
            this.maxA = maxA;
            this.maxD = maxD;
            this.globalNM = globalNM;
            this.globalH = globalH;
            this.globalA = globalA;
            this.globalD = globalD;
        }

        double getMinH() {
            return minH;
        }

        double getMinA() {
            return minA;
        }

        double getMinD() {
            return minD;
        }

        double getMaxH() {
            return maxH;
        }

        double getMaxA() {
            return maxA;
        }

        double getMaxD() {
            return maxD;
        }

        int getGlobalNM() {
            return globalNM;
        }

        double getGlobalH() {
            return globalH;
        }

        double getGlobalA() {
            return globalA;
        }

        double getGlobalD() {
            return globalD;
        }
    }
}
