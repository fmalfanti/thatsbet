package com.kellify.loadbet.load;

import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.bytedeco.javacpp.presets.opencv_core;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Map;
import java.util.Properties;

public class FootballLoaderUnderOver {
    private static final Logger logger = LoggerFactory.getLogger(FootballLoaderUnderOver.class);

    private static DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("dd/MM/yy");
    private static DateTimeFormatter formatter_2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DateTimeFormatter parserLungo;
    private DateTimeFormatter parserCorto;
    public FootballLoaderUnderOver() {
        parserCorto = new DateTimeFormatterBuilder().appendOptional(formatter_1).toFormatter();
        parserLungo = new DateTimeFormatterBuilder().appendOptional(formatter_2).toFormatter();
    }

    public int[] loadBetFootOdds(File file, String nazione, String continente, PreparedStatement psQuotas, PreparedStatement psMeanProbs, PreparedStatement psMeanProbsMaxMin) throws IOException {
        int[] ret;
        Reader in = null;
        int counter = 0;
        int emptyCount = 0;
        try {
            Map<String, String> dataMap;
            String dateString;
            Map<Integer,Matrici.HdaMatrix> useNationMap;
            Map<Integer,Matrici.HdaMatrix> useContinentMap;
            Map<Integer,Matrici.HdaMatrix> useWorldMap;

            in = new FileReader(file);
            Iterable<CSVRecord> records = CSVFormat.EXCEL.withHeader().parse(in);
            LocalDate dateTime;
            String Fthg ,Ftag ;
            double probAvMagg,probAvgMin;
            double greaterMin, LowerMin;
            double probLowerMin, probLowerMax,probGreaterMin,probGreaterMax;
            int fthg,ftag;
            String GreaterB365, LowerB365, GreaterPinnacle, LowerPinnacle, GreaterGamebookers, LowerGamebookers;
            String LowerAvgPortal, GreaterAvgPortal;
            String GreaterMax, GreaterAvg, LooserMax, LooserAvg;
            String underOver=null;

            for (CSVRecord record : records) {

                //System.out.println(record.toString());
                try {
                    dateString = record.get("Date");
                    if(dateString == null || dateString.length() == 0) {
                        emptyCount++;
                        continue;
                    }

                    //System.out.println(record.get("Date"));
                    if (dateString.length() == 8) {
                        dateTime = LocalDate.parse(record.get("Date"), parserCorto);
                    } else {
                        dateTime = LocalDate.parse(record.get("Date"), parserLungo);
                    }
                    //System.out.println(dateString+" "+dateTime.toString());
                    dataMap = record.toMap();
                    logger.debug("dataMap " + dataMap);
                    String campionato = dataMap.get("Div");
                    if (campionato==null) {
                        campionato = dataMap.get("League");
                    }

                    String homeTeam = dataMap.get("HomeTeam");
                    if (homeTeam==null) {
                        homeTeam = dataMap.get("HT");
                    }
                    if (homeTeam==null) {
                        homeTeam = dataMap.get("Home");
                    }
                    String awayTeam = dataMap.get("AwayTeam");
                    if (awayTeam==null) {
                        awayTeam = dataMap.get("AT");
                    }
                    if (awayTeam==null) {
                        awayTeam = dataMap.get("Away");
                    }
                    Fthg = dataMap.get("FTHG");
                    if (Fthg==null) {
                        fthg = Integer.parseInt(dataMap.get("HG"));
                    }
                     else {
                        fthg = Integer.parseInt(Fthg);
                    }
                    Ftag = dataMap.get("FTAG");
                    if (Ftag==null) {
                        ftag = Integer.parseInt(dataMap.get("AG"));
                    } else {
                        ftag = Integer.parseInt(Ftag);
                    }
                    String ftr = dataMap.get("FTR");
                    if (ftr==null) {
                        ftr = dataMap.get("Res");
                    }

                    GreaterMax = dataMap.get("BbMx>2.5");
                    GreaterMax = StringUtils.isBlank(GreaterMax) ? "-1" : GreaterMax;
                    Double bbMxGreater = Double.parseDouble(GreaterMax);

                    GreaterAvg = dataMap.get("BbAv>2.5");
                    GreaterAvg = StringUtils.isBlank(GreaterAvg) ? "-1" : GreaterAvg;
                    Double bbAvGreater = Double.parseDouble(GreaterAvg);

                    LooserMax = dataMap.get("BbMx<2.5");
                    LooserMax = StringUtils.isBlank(LooserMax) ? "-1" : LooserMax;
                    Double bbMxLower = Double.parseDouble(LooserMax);

                    LooserAvg = dataMap.get("BbAv<2.5");
                    LooserAvg = StringUtils.isBlank(LooserAvg) ? "-1" : LooserAvg;
                    Double bbAvLower = Double.parseDouble(LooserAvg);
                    greaterMin = 2 * bbAvGreater - bbMxGreater;
                    LowerMin = 2 * bbAvLower - bbMxLower;

                    GreaterB365 = dataMap.get("B365>2.5");
                    GreaterB365 = StringUtils.isBlank(GreaterB365) ? "-1" : GreaterB365;
                    Double bbGreaterB365 = Double.parseDouble(GreaterB365);

                    LowerB365 = dataMap.get("B365<2.5");
                    LowerB365 = StringUtils.isBlank(LowerB365) ? "-1" : LowerB365;
                    Double bbLowerB365 = Double.parseDouble(LowerB365);

                    GreaterAvgPortal = dataMap.get("Avg>2.5");
                    GreaterAvgPortal = StringUtils.isBlank(GreaterAvgPortal) ? "-1" : GreaterAvgPortal;
                    Double bbGreaterAvgPortal = Double.parseDouble(GreaterAvgPortal);

                    LowerAvgPortal = dataMap.get("Avg<2.5");
                    LowerAvgPortal = StringUtils.isBlank(LowerAvgPortal) ? "-1" : LowerAvgPortal;
                    Double bbLowerAvgPortal = Double.parseDouble(LowerAvgPortal);

                    GreaterPinnacle = dataMap.get("P>2.5");
                    GreaterPinnacle = StringUtils.isBlank(GreaterPinnacle) ? "-1" : GreaterPinnacle;
                    Double bbGreaterPinnacle = Double.parseDouble(GreaterPinnacle);

                    LowerPinnacle = dataMap.get("P<2.5");
                    LowerPinnacle = StringUtils.isBlank(LowerPinnacle) ? "-1" : LowerPinnacle;
                    Double bbLowerPinnacle = Double.parseDouble(LowerPinnacle);

                    GreaterGamebookers = dataMap.get("GB>2.5");
                    GreaterGamebookers = StringUtils.isBlank(GreaterGamebookers) ? "-1" : GreaterGamebookers;
                    Double bbGreaterGamebookers = Double.parseDouble(GreaterGamebookers);

                    LowerGamebookers = dataMap.get("GB<2.5");
                    LowerGamebookers = StringUtils.isBlank(LowerGamebookers) ? "-1" : LowerGamebookers;
                    Double bbLowerGamebookers = Double.parseDouble(LowerGamebookers);

                    if( fthg+ftag>2 ){
                        underOver="O";
                    }
                    else { underOver="U";}
                    System.out.println("underOver "+ underOver);
                    //System.out.println(" greaterMin "+ greaterMin + " LowerMin" + LowerMin + " bbMxGreater " + bbMxGreater + " bbMxLower " + bbMxLower);
                    psQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psQuotas.setString(2, campionato);
                    psQuotas.setString(3, nazione);
                    psQuotas.setString(4, continente);
                    psQuotas.setString(5, homeTeam);
                    psQuotas.setString(6, awayTeam);
                    psQuotas.setInt(7, fthg);
                    psQuotas.setInt(8, ftag);
                    psQuotas.setString(9, ftr);
                    psQuotas.setString(10, underOver);
                    psQuotas.setDouble(11, bbMxGreater);
                    psQuotas.setDouble(12, bbAvGreater);
                    psQuotas.setDouble(13, bbMxLower);
                    psQuotas.setDouble(14, bbAvLower);
                    psQuotas.setDouble(15, bbGreaterB365);
                    psQuotas.setDouble(16, bbLowerB365);
                    psQuotas.setDouble(17, bbGreaterAvgPortal);
                    psQuotas.setDouble(18, bbLowerAvgPortal);
                    psQuotas.setDouble(19, bbGreaterGamebookers);
                    psQuotas.setDouble(20, bbLowerGamebookers);
                    psQuotas.setDouble(21, bbGreaterPinnacle);
                    psQuotas.setDouble(22, bbLowerPinnacle);

                    if (bbAvLower+bbAvGreater!=-2.0) {
                        probAvgMin = 1.0 / bbAvLower;
                        probAvMagg = 1.0 / bbAvGreater;

                        psMeanProbs.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbs.setString(2, campionato);
                        psMeanProbs.setString(3, nazione);
                        psMeanProbs.setString(4, continente);
                        psMeanProbs.setString(5, homeTeam);
                        psMeanProbs.setString(6, awayTeam);
                        psMeanProbs.setInt(7, fthg);
                        psMeanProbs.setInt(8, ftag);
                        psMeanProbs.setString(9, ftr);
                        psMeanProbs.setString(10, underOver);
                        psMeanProbs.setDouble(11, probAvgMin);
                        psMeanProbs.setDouble(12, probAvMagg);
                        psMeanProbs.executeUpdate();

                        probLowerMin = 1.0 / bbMxLower;
                        probLowerMax= 1.0 / LowerMin;
                        probGreaterMin = 1.0 / bbMxGreater;
                        probGreaterMax= 1.0/ greaterMin;
                        //System.out.println("probLowerMin:  "+ probLowerMin + " probLowerMax: " + probLowerMax+ "probGreaterMin:  "+ probGreaterMin + "probGreaterMax: " + probGreaterMax);
                        psMeanProbsMaxMin.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbsMaxMin.setString(2, campionato);
                        psMeanProbsMaxMin.setString(3, nazione);
                        psMeanProbsMaxMin.setString(4, continente);
                        psMeanProbsMaxMin.setString(5, homeTeam);
                        psMeanProbsMaxMin.setString(6, awayTeam);
                        psMeanProbsMaxMin.setInt(7, fthg);
                        psMeanProbsMaxMin.setInt(8, ftag);
                        psMeanProbsMaxMin.setString(9, ftr);
                        psMeanProbsMaxMin.setString(10, underOver);
                        psMeanProbsMaxMin.setDouble(11, probGreaterMin);
                        psMeanProbsMaxMin.setDouble(12, probAvMagg);
                        psMeanProbsMaxMin.setDouble(13, probGreaterMax);
                        psMeanProbsMaxMin.setDouble(14, probLowerMin);
                        psMeanProbsMaxMin.setDouble(15, probAvgMin);
                        psMeanProbsMaxMin.setDouble(16, probLowerMax);
                        psMeanProbsMaxMin.executeUpdate();

                    }
                    psQuotas.executeUpdate();

                    counter++;

                } catch(Exception ex) {
                    logger.error("record:" + record.toString(), ex);

                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if(in != null) {
                in.close();
            }
        }
        ret = new int[] {counter,  emptyCount};
        return ret;
    }

    public static void LoadFootballData(DbConnector dbConnector, Properties config) throws SQLException, IOException {
        logger.info("LoadFootballDataUnderOver process start");
        Unzipper unzipper = new Unzipper(config, LoadBetType.FOOTBALL);
        unzipper.unzip();

        File folder = new File(config.getProperty("football.data.folder"));
        PreparedStatement psQuotas = null;
        PreparedStatement psMeanProbsMaxMin = null;
        PreparedStatement psNazione = null;
        PreparedStatement psMeanProbs = null;
        PreparedStatement psContinente = null;
        File[] files = folder.listFiles();
        int counter = 0;
        int emptyCounter = 0;
        FootballLoaderUnderOver loader = new FootballLoaderUnderOver();
        String fileName;

        try {
            Connection conn=dbConnector.getConnection();
            psQuotas = conn.prepareStatement(DbConnector.INSERT_FOOT_ODDS_UNDER_OVER);
            psMeanProbs = conn.prepareStatement(DbConnector.INSERT_BET_FOOTBALL_CLUSTERS_UNDER_OVER);
            psMeanProbsMaxMin = conn.prepareStatement(DbConnector.INSERT_FOOT_PROB_UNDER_OVER);
            psNazione = conn.prepareStatement(DbConnector.SELECT_NAZIONE);
            psContinente = conn.prepareStatement(DbConnector.SELECT_CONTINENTE);

            for (File f : files) {
                try {
                    fileName = f.getName();
                    String nazione = Nazione.getNazione(psNazione, fileName.substring(fileName.indexOf("_")+1));
                    String continente = Continente.getContinente(psContinente, fileName.substring(fileName.indexOf("_")+1));
                    logger.info("file:" + f.getName() + ", nazione:" + nazione+", continente:" + continente);
                    int localCounter[] =  loader.loadBetFootOdds(f, nazione, continente,  psQuotas,psMeanProbs,psMeanProbsMaxMin);

                    logger.info("file rows:" + localCounter[0] + ", file empty rows:" + localCounter[1]);
                    counter += localCounter[0];
                    emptyCounter += localCounter[1];
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                } finally {
                    //f.delete();
                }
            }

            logger.info("total rows:" + counter + ", total empty rows:" + emptyCounter);
        } finally {
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psNazione != null) {
                psNazione.close();
            }
            if (psMeanProbs != null) {
                psMeanProbs.close();
            }
            if (psMeanProbsMaxMin != null) {
                psMeanProbsMaxMin.close();
            }
            if (psContinente != null) {
                psContinente.close();
            }
        }
        logger.info("LoadFootballDataUnderOver process end");
    }
}

