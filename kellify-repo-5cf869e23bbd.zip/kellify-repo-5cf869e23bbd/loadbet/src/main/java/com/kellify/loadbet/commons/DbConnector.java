package com.kellify.loadbet.commons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbConnector {
    public static final String INSERT_FOOT_MATRICI = "insert ignore into football_matrici (Nazione,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_FOOT_MATRICI_WEIGHT = "insert ignore into football_matrici_weight (Nazione,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_TENNIS_MATRICI = "insert ignore into tennis_matrici (Surface,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_TENNIS_MATRICI_WEIGHT = "insert ignore into tennis_matrici_weight (Surface,Valori) values (?,?) on duplicate key update Valori=?";

    public static final String INSERT_BASKET_MATRICI = "insert ignore into basket_matrici (Nazione,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_BASEBALL_MATRICI = "insert ignore into baseball_matrici (Nazione,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_AMERICANFOOTBALL_MATRICI = "insert ignore into americanfootball_matrici (Nazione,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_ICEHOCKEY_HA_MATRICI = "insert ignore into icehockey_ha_matrici (Nazione,Valori) values (?,?) on duplicate key update Valori=?";
    public static final String INSERT_ICEHOCKEY_HDA_MATRICI = "insert ignore into icehockey_hda_matrici (Nazione,Valori) values (?,?) on duplicate key update Valori=?";

    public static final String SELECT_DISTINCT_NAZIONE ="select distinct nazione from football_history_odds";

    public static final String SELECT_DISTINCT_CONTINENTE ="select distinct continente from football_history_odds";
    public static final String SELECT_DISTINCT_NAZIONE_BASKET ="select distinct nazione from basket_history_odds";

    public static final String SELECT_DISTINCT_CONTINENTE_BASKET ="select distinct continente from basket_history_odds";

    public static final String SELECT_DISTINCT_NAZIONE_BASEBALL ="select distinct nazione from baseball_history_odds";

    public static final String SELECT_DISTINCT_CONTINENTE_BASEBALL ="select distinct continente from baseball_history_odds";

    public static final String SELECT_DISTINCT_NAZIONE_ICEHOCKEY ="select distinct nazione from icehockey_ha_history_odds";

    public static final String SELECT_DISTINCT_CONTINENTE_ICEHOCKEY ="select distinct continente from icehockey_ha_history_odds";

    public static final String SELECT_DISTINCT_NAZIONE_ICEHOCKEY_HDA ="select distinct nazione from icehockey_hda_history_odds";

    public static final String SELECT_DISTINCT_CONTINENTE_ICEHOCKEY_HDA ="select distinct continente from icehockey_hda_history_odds";


    public static final String GET_FOOT_ODDS = " select " +
            "Nazione," +
            "Continente," +
            "FTR," +
            "B365A," +
            "B365D," +
            "B365H," +
            "BSA," +
            "BSD," +
            "BSH," +
            "BWA," +
            "BWD," +
            "BWH," +
            "GBA," +
            "GBD," +
            "GBH," +
            "IWA," +
            "IWD," +
            "IWH," +
            "LBA," +
            "LBD," +
            "LBH," +
            "PSCA," +
            "PSCD," +
            "PSCH," +
            "PSA," +
            "PSD," +
            "PSH," +
            "SBA," +
            "SBD," +
            "SBH," +
            "SJA," +
            "SJD," +
            "SJH," +
            "SOA," +
            "SOD," +
            "SOH," +
            "SYA," +
            "SYD," +
            "SYH," +
            "VCA," +
            "VCD," +
            "VCH," +
            "WHA," +
            "WHD," +
            "WHH " +
            "from football_history_odds";
    public static final String GET_FOOT_ODDS_YEAR = " select " +
            "Nazione," +
            "Continente," +
            "FTR," +
            "YEAR(MatchDate),"+
            "B365A," +
            "B365D," +
            "B365H," +
            "BSA," +
            "BSD," +
            "BSH," +
            "BWA," +
            "BWD," +
            "BWH," +
            "GBA," +
            "GBD," +
            "GBH," +
            "IWA," +
            "IWD," +
            "IWH," +
            "LBA," +
            "LBD," +
            "LBH," +
            "PSCA," +
            "PSCD," +
            "PSCH," +
            "PSA," +
            "PSD," +
            "PSH," +
            "SBA," +
            "SBD," +
            "SBH," +
            "SJA," +
            "SJD," +
            "SJH," +
            "SOA," +
            "SOD," +
            "SOH," +
            "SYA," +
            "SYD," +
            "SYH," +
            "VCA," +
            "VCD," +
            "VCH," +
            "WHA," +
            "WHD," +
            "WHH " +
            "from football_history_odds";

    public static final String INSERT_FOOT_ODDS = "insert ignore into football_history_odds_2 (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "B365A," +
            "B365D," +
            "B365H," +
            "BSA," +
            "BSD," +
            "BSH," +
            "BWA," +
            "BWD," +
            "BWH," +
            "GBA," +
            "GBD," +
            "GBH," +
            "IWA," +
            "IWD," +
            "IWH," +
            "LBA," +
            "LBD," +
            "LBH," +
            "PSCA," +
            "PSCD," +
            "PSCH," +
            "PSA," +
            "PSD," +
            "PSH," +
            "SBA," +
            "SBD," +
            "SBH," +
            "SJA," +
            "SJD," +
            "SJH," +
            "SOA," +
            "SOD," +
            "SOH," +
            "SYA," +
            "SYD," +
            "SYH," +
            "VCA," +
            "VCD," +
            "VCH," +
            "WHA," +
            "WHD," +
            "WHH," +
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String INSERT_FOOT_ODDS_UNDER_OVER = "insert ignore into football_history_odds_under_over (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "`U/O`,"+
            "`BbMx>2.5`,"+
            "`BbAv>2.5`,"+
            "`BbMx<2.5`,"+
            "`BbAv<2.5`,"+
            "`B365>2.5`,"+
            "`B365<2.5`,"+
            "`AVG>2.5`,"+
            "`AVG<2.5`,"+
            "`GB>2.5`,"+
            "`GB<2.5`,"+
            "`P>2.5`,"+
            "`P<2.5`,"+
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String INSERT_FOOT_PROB_UNDER_OVER = "insert ignore into football_history_cluster_under_over(" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "`U/O`,"+
            "`Mingreater2.5`,"+
            "`Mgreater2.5`,"+
            "`Maxgreater2.5`,"+
            "`Minlower2.5`,"+
            "`Mlower2.5`,"+
            "`Maxlower2.5`,"+
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";


    public static final String INSERT_FOOT_ODDS_ASIAN_HANDICAP= "insert ignore into football_history_odds_asian_handicap (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "BbAHh,"+
            "BbMxAHH,"+
            "BbAvAHH,"+
            "BbMxAHA,"+
            "BbAvAHA,"+
            "GBAHH,"+
            "GBAHA,"+
            "LBAHH,"+
            "LBAHA,"+
            "B365AHH,"+
            "B365AHA,"+
            "PAHH,"+
            "PAHA,"+
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String INSERT_FOOT_PROB_ASIAN_HANDICAP= "insert ignore into football_history_cluster_asian_handicap (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "TypeAHH,"+
            "MinAHH,"+
            "MAHH,"+
            "MaxAHH,"+
            "MinAHA,"+
            "MAHA,"+
            "MaxAHA,"+
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String GET_BASKET_ODDS = " select " +
            "Nazione,"+
            "Continente,"+
            "FTR,"+
            "matchbook_op_ha_a," +
            "matchbook_op_ha_h," +
            "tonybet_op_ha_a," +
            "tonybet_op_ha_h," +
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h," +
            "`bet-at-home_op_ha_a`," +
            "`bet-at-home_op_ha_h`" +
            "from basket_history_odds";
    //public static final String GET_BASKET_RESULTS = " select ftr from basket_history_odds";

    public static final String INSERT_BASKET_ODDS = "insert ignore into basket_history_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "matchbook_op_ha_a," +
            "matchbook_op_ha_h," +
            "tonybet_op_ha_a," +
            "tonybet_op_ha_h," +
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h," +
            "`bet-at-home_op_ha_a`," +
            "`bet-at-home_op_ha_h`)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String GET_BASEBALL_ODDS = " select " +
            "Nazione,"+
            "Continente,"+
            "FTR,"+
            "10bet_op_ha_a," +
            "10bet_op_ha_h," +
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h " +
            "from baseball_history_odds";
    public static final String INSERT_BASEBALL_ODDS = "insert ignore into baseball_history_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "10bet_op_ha_a," +
            "10bet_op_ha_h," +
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String GET_ICEHOCKEY_HA_ODDS = " select " +
            "Nazione," +
            "Continente," +
            "FTR,"+
            "matchbook_op_ha_h,"+
            "matchbook_op_ha_a,"+
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "tonybet_op_ha_h,"+
            "tonybet_op_ha_a,"+
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "10bet_op_ha_a," +
            "10bet_op_ha_h " +
            "from icehockey_ha_history_odds";
    public static final String INSERT_ICEHOCKEY_HA_ODDS = "insert ignore into icehockey_ha_history_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "matchbook_op_ha_h,"+
            "matchbook_op_ha_a,"+
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "tonybet_op_ha_h,"+
            "tonybet_op_ha_a,"+
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "10bet_op_ha_a," +
            "10bet_op_ha_h)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String GET_ICEHOCKEY_HDA_ODDS = " select " +
            "Nazione," +
            "Continente," +
            "FTR," +
            "marathon_op_ml_h,"+
            "marathon_op_ml_d,"+
            "marathon_op_ml_a,"+
            "tonybet_op_ml_h,"+
            "tonybet_op_ml_d,"+
            "tonybet_op_ml_a,"+
            "unibet_op_ml_h,"+
            "unibet_op_ml_d,"+
            "unibet_op_ml_a,"+
            "bet365_op_ml_h,"+
            "bet365_op_ml_d,"+
            "bet365_op_ml_a,"+
            "bwin_op_ml_h,"+
            "bwin_op_ml_d,"+
            "bwin_op_ml_a,"+
            "`bet-at-home_op_ml_h`,"+
            "`bet-at-home_op_ml_d`,"+
            "`bet-at-home_op_ml_a`,"+
            "10bet_op_ml_h,"+
            "10bet_op_ml_d,"+
            "10bet_op_ml_a," +
            "pinn_op_ml_h," +
            "pinn_op_ml_d," +
            "pinn_op_ml_a " +
            "from icehockey_hda_history_odds";
    public static final String INSERT_ICEHOCKEY_HDA_ODDS = "insert ignore into icehockey_hda_history_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "marathon_op_ml_h,"+
            "marathon_op_ml_d,"+
            "marathon_op_ml_a,"+
            "tonybet_op_ml_h,"+
            "tonybet_op_ml_d,"+
            "tonybet_op_ml_a,"+
            "unibet_op_ml_h,"+
            "unibet_op_ml_d,"+
            "unibet_op_ml_a,"+
            "bet365_op_ml_h,"+
            "bet365_op_ml_d,"+
            "bet365_op_ml_a,"+
            "bwin_op_ml_h,"+
            "bwin_op_ml_d,"+
            "bwin_op_ml_a,"+
            "`bet-at-home_op_ml_h`,"+
            "`bet-at-home_op_ml_d`,"+
            "`bet-at-home_op_ml_a`,"+
            "10bet_op_ml_h,"+
            "10bet_op_ml_d,"+
            "10bet_op_ml_a,"+
            "pinn_op_ml_h,"+
            "pinn_op_ml_d,"+
            "pinn_op_ml_a)"+
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String INSERT_ICEHOCKEY_ODDS = "insert ignore into icehockey_history_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "marathon_op_ml_h,"+
            "marathon_op_ml_a,"+
            "marathon_op_ha_h,"+
            "marathon_op_ha_a,"+
            "tonybet_op_ml_h,"+
            "tonybet_op_ml_a,"+
            "tonybet_op_ha_h,"+
            "tonybet_op_ha_a,"+
            "unibet_op_ml_h,"+
            "unibet_op_ml_a,"+
            "unibet_op_ha_h,"+
            "unibet_op_ha_a,"+
            "bet365_op_ml_h,"+
            "bet365_op_ml_a,"+
            "bet365_op_ha_h,"+
            "bet365_op_ha_a,"+
            "bwin_op_ml_h,"+
            "bwin_op_ml_a,"+
            "bwin_op_ha_h,"+
            "bwin_op_ha_a,"+
            "`bet-at-home_op_ml_h`,"+
            "`bet-at-home_op_ml_a`,"+
            "5dimes_op_ha_h," +
            "5dimes_op_ha_h," +
            "10bet_op_ml_h,"+
            "10bet_op_ml_a,"+
            "10bet_op_ha_h,"+
            "10bet_op_ha_a,"+
            "pinn_op_ml_h,"+
            "pinn_op_ml_a,"+
            "pinnacle_op_ha_h,"+
            "pinnacle_op_ha_a)"+
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String GET_AMERICANFOOTBALL_ODDS = " select " +
            "FTR,"+
            "`bet-at-home_op_ha_h`,"+
            "`bet-at-home_op_ha_a`,"+
            "10bet_op_ha_a," +
            "10bet_op_ha_h," +
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h " +
            "from americanfootball_history_odds";

    public static final String INSERT_AMERICANFOOTBALL_ODDS = "insert ignore into americanfootball_history_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "`bet-at-home_op_ha_h`,"+
            "`bet-at-home_op_ha_a`,"+
            "10bet_op_ha_a," +
            "10bet_op_ha_h," +
            "marathon_op_ha_a," +
            "marathon_op_ha_h," +
            "5dimes_op_ha_a," +
            "5dimes_op_ha_h," +
            "pinnacle_op_ha_a," +
            "pinnacle_op_ha_h," +
            "bet365_op_ha_a," +
            "bet365_op_ha_h," +
            "bwin_op_ha_a," +
            "bwin_op_ha_h," +
            "unibet_op_ha_a," +
            "unibet_op_ha_h)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";


    public static final String INSERT_BET_FOOTBALL_MEANS_ODDS = "insert ignore into football_means_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "AMIN," +
            "MA," +
            "AMAX," +
            "HMIN," +
            "MH," +
            "HMAX," +
            "DMIN," +
            "MD," +
            "DMAX," +
            "NM," +
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";
    public static final String INSERT_BET_FOOTBALL_CLUSTERS = "insert ignore into football_cluster (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "MA," +
            "MH," +
            "MD," +
            "NM," +
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String INSERT_BET_FOOTBALL_CLUSTERS_UNDER_OVER = "insert ignore into football_cluster_under_over (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "`U/O`,"+
            "`Mgreater2.5`," +
            "`Mlower2.5`," +
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String INSERT_BET_FOOTBALL_CLUSTERS_UO_HDA = "insert ignore into football_cluster_uo_hda (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "`U/O`,"+
            "`Mgreater2.5`," +
            "`Mlower2.5`," +
            "MA,"+
            "MD,"+
            "MH,"+
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";

    public static final String INSERT_PROB_FOOTBALL_CLUSTERS_UO_HDA = "insert ignore into football_history_cluster_uo_hda (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "`U/O`,"+
            "`Mingreater2.5`,"+
            "`Mgreater2.5`,"+
            "`Maxgreater2.5`,"+
            "`Minlower2.5`,"+
            "`Mlower2.5`,"+
            "`Maxlower2.5`,"+
            "MaxA,"+
            "MA,"+
            "MinA,"+
            "MaxD,"+
            "MD,"+
            "MinD,"+
            "MaxH,"+
            "MH,"+
            "MinH,"+
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'y')";
    public static final String INSERT_BET_FOOTBALL_CLUSTERS_ASIAN_HANDICAP = "insert ignore into football_cluster_asian_handicap (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "TypeAHH,"+
            "MAHH," +
            "MAHA," +
            "PrimiTreMesi)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,'y')";


    public static final String INSERT_BET_BASKET_MEANS_ODDS = "insert ignore into basket_means_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "AMIN," +
            "MA," +
            "AMAX," +
            "HMIN," +
            "MH," +
            "HMAX," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_BASKET_CLUSTERS = "insert ignore into basket_cluster (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "MA," +
            "MH," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_AMERICANFOOTBALL_MEANS_ODDS = "insert ignore into americanfootball_means_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "AMIN," +
            "MA," +
            "AMAX," +
            "HMIN," +
            "MH," +
            "HMAX," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_AMERICANFOOTBALL_CLUSTERS = "insert ignore into americanfootball_cluster (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "MA," +
            "MH," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?)";


    public static final String INSERT_BET_BASEBALL_MEANS_ODDS = "insert ignore into baseball_means_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "AMIN," +
            "MA," +
            "AMAX," +
            "HMIN," +
            "MH," +
            "HMAX," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_BASEBALL_CLUSTERS = "insert ignore into baseball_cluster (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "MA," +
            "MH," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?)";


    public static final String INSERT_BET_ICEHOCKEY_HDA_MEANS_ODDS = "insert ignore into icehockey_hda_means_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "AMIN," +
            "MA," +
            "AMAX," +
            "HMIN," +
            "MH," +
            "HMAX," +
            "DMIN," +
            "MD," +
            "DMAX," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_ICEHOCKEY_HA_MEANS_ODDS = "insert ignore into icehockey_ha_means_odds (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "AMIN," +
            "MA," +
            "AMAX," +
            "HMIN," +
            "MH," +
            "HMAX," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_ICEHOCKEY_HDA_CLUSTERS = "insert ignore into icehockey_hda_cluster (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "MA," +
            "MH," +
            "MD," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?)";


    public static final String INSERT_BET_ICEHOCKEY_HA_CLUSTERS = "insert ignore into icehockey_ha_cluster (" +
            "MatchDate," +
            "Campionato," +
            "Nazione," +
            "Continente," +
            "HomeTeam," +
            "AwayTeam," +
            "FTHG," +
            "FTAG," +
            "FTR," +
            "MA," +
            "MH," +
            "NM)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?)";


    public static final String GET_TENNIS_ODDS = " select " +
            "B365W," +
            "B365L," +
            "EXW," +
            "EXL," +
            "LBW," +
            "LBL," +
            "PSW," +
            "PSL," +
            "SJW," +
            "SJL," +
            "UBW," +
            "UBL," +
            "IWW," +
            "IWL," +
            "CBW," +
            "CBL," +
            "SBW," +
            "SBL," +
            "BEWW," +
            "BEWL," +
            "GBW," +
            "GBL " +
            "from tennis_history_odds";
    public static final String GET_TENNIS_ODDS_YEAR = " select " +
            "YEAR(MatchDate),"+
            "B365W," +
            "B365L," +
            "EXW," +
            "EXL," +
            "LBW," +
            "LBL," +
            "PSW," +
            "PSL," +
            "SJW," +
            "SJL," +
            "UBW," +
            "UBL," +
            "IWW," +
            "IWL," +
            "CBW," +
            "CBL," +
            "SBW," +
            "SBL," +
            "BEWW," +
            "BEWL," +
            "GBW," +
            "GBL " +
            "from tennis_history_odds";
    public static final String INSERT_BET_TENNIS_MEANS_ODDS = "insert ignore into tennis_means_odds (" +
            "MatchDate," +
            "Winner," +
            "Loser," +
            "WRank," +
            "LRank," +
            "WMAX," +
            "MW," +
            "WMIN," +
            "LMAX," +
            "ML," +
            "LMIN," +
            "NM," +
            "Location," +
            "Tournament," +
            "Series," +
            "Surface," +
            "Round)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_BET_TENNIS_CLUSTERS = "insert ignore into tennis_cluster (" +
            "MatchDate," +
            "Winner," +
            "Loser," +
            "WRank," +
            "LRank," +
            "MW," +
            "ML," +
            "NM," +
            "Location," +
            "Tournament," +
            "Series," +
            "Surface," +
            "Round)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_TENNIS_ODDS = "insert ignore into tennis_history_odds (MatchDate," +
            "Winner," +
            "Loser," +
            "WRank," +
            "LRank," +
            "B365W," +
            "B365L," +
            "EXW," +
            "EXL," +
            "LBW," +
            "LBL," +
            "PSW," +
            "PSL," +
            "SJW," +
            "SJL," +
            "UBW," +
            "UBL," +
            "IWW," +
            "IWL," +
            "CBW," +
            "CBL," +
            "SBW," +
            "SBL," +
            "BEWW," +
            "BEWL," +
            "GBW," +
            "GBL," +
            "Location," +
            "Tournament," +
            "Series," +
            "Surface," +
            "Round)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String SELECT_NAZIONE = "select locationBetBrain from championshipDecode where Campionato=UPPER(?)";
    public static final String SELECT_CONTINENTE = "select Continente from championshipDecode where Campionato=UPPER(?)";
    public static final String SELECT_CONTINENTE_FROM_NAZIONE = "select Continente from championshipDecode where locationBetbrain=?";

    private final Properties config;

    public DbConnector(Properties config) {
        this.config = config;
    }

    public Connection getConnection() {
        Connection connection;
        try {
            config.getProperty("jdbcUrl");
            connection = DriverManager.getConnection(config.getProperty("jdbcUrl"), config.getProperty("dataSource.user"), config.getProperty("dataSource.password"));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }
        return connection;
    }
}
