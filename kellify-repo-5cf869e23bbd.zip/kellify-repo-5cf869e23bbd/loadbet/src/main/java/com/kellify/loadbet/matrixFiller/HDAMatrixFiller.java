package com.kellify.loadbet.matrixFiller;


import com.kellify.common.util.Matrici;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class HDAMatrixFiller {
    private static final Logger logger = LoggerFactory.getLogger(HDAMatrixFiller.class);

    public Map<String,Map<Integer,Matrici.HdaMatrix>> fillMatrixFootOdds(PreparedStatement psNazioni, PreparedStatement psContinenti, PreparedStatement psQuotas, String [] bms ) throws IOException {

        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeFootball  = new HashMap<>();
        ResultSet rs=null;
        String nazione;
        String continente;
        try {

            Map<Integer,Matrici.HdaMatrix> useNationMap;
            Map<Integer,Matrici.HdaMatrix> useContinentMap;
            Map<Integer,Matrici.HdaMatrix> useWorldMap;
            Matrici.HdaMatrix punto;
            double tH, tA , tD;
            String ftr;
            double pA,pD,pH,pNorm;
            int ipA,ipH;

            MappeFootball.computeIfAbsent("World", k -> new HashMap<>());
            useWorldMap=MappeFootball.get("World");
            rs = psContinenti.executeQuery();
            while (rs.next()) {
                continente = rs.getString(1);
                MappeFootball.computeIfAbsent(continente, k -> new HashMap<>());
            }
            rs.close();
            rs = psNazioni.executeQuery();
            while (rs.next()) {
                nazione = rs.getString(1);
                MappeFootball.computeIfAbsent(nazione, k -> new HashMap<>());
            }
            rs.close();

            rs = psQuotas.executeQuery();

            while (rs.next()) {
                nazione = rs.getString(1);
                continente = rs.getString(2);
                useContinentMap=MappeFootball.get(continente);
                useNationMap=MappeFootball.get(nazione);
                ftr=rs.getString(3);

                for (int i=0;i<bms.length;i++) {
                    tA=rs.getDouble(3*i+4);
                    tD=rs.getDouble(3*i+5);
                    tH=rs.getDouble(3*i+6);
                    if((tA!=-1)&&(tD!=-1)&&(tH!=-1)){
                        pA = 1 / tA;
                        pD = 1 / tD;
                        pH = 1 / tH;
                        pNorm = pA + pD + pH;
                        pA /= pNorm;
                        pH /= pNorm;
                        ipA = (int) Math.round(pA * 100);
                        ipH = (int) Math.round(pH * 100);

                        Integer indice = 101 * ipH + ipA;

                        punto = useNationMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.add(ftr);
                        useNationMap.put(indice, punto);

                        punto = useContinentMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.add(ftr);
                        useContinentMap.put(indice, punto);

                        punto = useWorldMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.add(ftr);
                        useWorldMap.put(indice, punto);

                    }

                }

            }

            rs.close();


        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {

        }
        return MappeFootball;
    }
    public Map<String,Map<Integer,Matrici.HdaMatrix>> fillMatrixIceHockeyHDAOdds(PreparedStatement psNazioni, PreparedStatement psContinenti, PreparedStatement psQuotas, String [] bms ) throws IOException {
        Map<String,Map<Integer,Matrici.HdaMatrix>> MappaHDA  = new HashMap<>();
        ResultSet rs=null;
        String nazione;
        String continente;
        try {

            Map<Integer,Matrici.HdaMatrix> useNationMap;
            Map<Integer,Matrici.HdaMatrix> useContinentMap;
            Map<Integer,Matrici.HdaMatrix> useWorldMap;
            Matrici.HdaMatrix punto;
            double tH, tA , tD;
            String ftr;
            double pA,pD,pH,pNorm;
            int ipA,ipH;

            MappaHDA.computeIfAbsent("World", k -> new HashMap<>());
            useWorldMap=MappaHDA.get("World");
            rs = psContinenti.executeQuery();
            while (rs.next()) {
                continente = rs.getString(1);
                MappaHDA.computeIfAbsent(continente, k -> new HashMap<>());
            }
            rs.close();
            rs = psNazioni.executeQuery();
            while (rs.next()) {
                nazione = rs.getString(1);
                MappaHDA.computeIfAbsent(nazione, k -> new HashMap<>());
            }
            rs.close();

            rs = psQuotas.executeQuery();

            while (rs.next()) {
                nazione = rs.getString(1);
                continente = rs.getString(2);
                useContinentMap=MappaHDA.get(continente);
                useNationMap=MappaHDA.get(nazione);
                ftr=rs.getString(3);

                for (int i=0;i<bms.length;i++) {
                    tA=rs.getDouble(3*i+4);
                    tD=rs.getDouble(3*i+5);
                    tH=rs.getDouble(3*i+6);
                    if((tA!=-1)&&(tD!=-1)&&(tH!=-1)){
                        pA = 1 / tA;
                        pD = 1 / tD;
                        pH = 1 / tH;
                        pNorm = pA + pD + pH;
                        pA /= pNorm;
                        pH /= pNorm;
                        ipA = (int) Math.round(pA * 100);
                        ipH = (int) Math.round(pH * 100);

                        Integer indice = 101 * ipH + ipA;

                        punto = useNationMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.add(ftr);
                        useNationMap.put(indice, punto);

                        punto = useContinentMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.add(ftr);
                        useContinentMap.put(indice, punto);

                        punto = useWorldMap.get(indice);
                        if (punto == null) {
                            punto = new Matrici.HdaMatrix();
                        }
                        punto.add(ftr);
                        useWorldMap.put(indice, punto);

                    }

                }

            }

            rs.close();


        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {

        }
        return MappaHDA;
    }
    private boolean isWorldRecord(Map<String, String> dataMap) {
        boolean hasAvg;
        String oddh = dataMap.get("AvgH");
        String oddd = dataMap.get("AvgD");
        String odda = dataMap.get("AvgA");
        hasAvg = oddh != null && oddh.length() > 0 && oddd != null && oddd.length() > 0 && odda != null && odda.length() > 0;
        boolean hasMax;
        oddh = dataMap.get("MaxH");
        oddd = dataMap.get("MaxD");
        odda = dataMap.get("MaxA");
        hasMax = oddh != null && oddh.length() > 0 && oddd != null && oddd.length() > 0 && odda != null && odda.length() > 0;
        return hasAvg && hasMax;
    }

    private double[] CalculatetAtDtH(String bm, int psInt, String ftr, Map <String,String> dataMap, PreparedStatement psQuotas, Map<Integer,Matrici.HdaMatrix> useNationMap, Map<Integer,Matrici.HdaMatrix> useContinentMap, Map<Integer,Matrici.HdaMatrix> useWorldMap) throws SQLException {


        Matrici.HdaMatrix punto;
        String oddh,odda,oddd;
        double tH,tD,tA;
        double pA,pD,pH,pNorm;
        int ipA,ipH;

        oddh = dataMap.get(bm+"H");
        oddh = StringUtils.isBlank(oddh) ? "-1" : oddh;
        tH = Double.parseDouble(oddh);
        oddd = dataMap.get(bm+"D");
        oddd = StringUtils.isBlank(oddd) ? "-1" : oddd;
        tD = Double.parseDouble(oddd);
        odda = dataMap.get(bm+"A");
        odda = StringUtils.isBlank(odda) ? "-1" : odda;
        tA = Double.parseDouble(odda);

        if(((tA+tD+tH) == -3) && bm.equals("PS")) {
            oddh = dataMap.get("PH");
            oddh = StringUtils.isBlank(oddh) ? "-1" : oddh;
            tH = Double.parseDouble(oddh);
            oddd = dataMap.get("PD");
            oddd = StringUtils.isBlank(oddd) ? "-1" : oddd;
            tD = Double.parseDouble(oddd);
            odda = dataMap.get("PA");
            odda = StringUtils.isBlank(odda) ? "-1" : odda;
            tA = Double.parseDouble(odda);
        }

        psQuotas.setDouble(10+3*psInt, tA);
        psQuotas.setDouble(11+3*psInt, tD);
        psQuotas.setDouble(12+3*psInt, tH);
        if ((tA!=-1)&&(tH!=-1)&&(tD!=-1)) {
            pA = 1 / tA;
            pD = 1 / tD;
            pH = 1 / tH;
            pNorm = pA + pD + pH;
            pA /= pNorm;
            pH /= pNorm;
            ipA = (int) Math.floor(pA * 100);
            ipH = (int) Math.floor(pH * 100);
            //System.out.println("pA=" + pA + ",pH=" + pH + ",ipA=" + ipA + ",ipH=" + ipH);
            Integer indice = 101 * ipH + ipA;
            punto = useNationMap.get(indice);
            if (punto == null) {
                punto = new Matrici.HdaMatrix();
            }
            punto.add(ftr);
            useNationMap.put(indice, punto);
            punto = useContinentMap.get(indice);
            if (punto == null) {
                punto = new Matrici.HdaMatrix();
            }
            punto.add(ftr);
            useContinentMap.put(indice, punto);
            punto = useWorldMap.get(indice);
            if (punto == null) {
                punto = new Matrici.HdaMatrix();
            }
            punto.add(ftr);
            useWorldMap.put(indice, punto);
        }
        return new double[]{tA,tD,tH};
    }
    
    private CalculateMeansOutput calculateMeans(double oddH, double oddA, double oddD, double minH, double minA, double minD, double maxH, double maxA, double maxD, double globalH, double globalA, double globalD, int globalNM) {
        double iGlobalA = globalA + oddA;
        double iGlobalH = globalH + oddH;
        double iGlobalD = globalD + oddD;
        int iGlobalNM = globalNM+1;
        double iMinA = Math.min(minA, oddA);
        double iMinH = Math.min(minH, oddH);
        double iMinD = Math.min(minD, oddD);
        double iMaxA = Math.max(maxA, oddA);
        double iMaxH = Math.max(maxH, oddH);
        double iMaxD = Math.max(maxD, oddD);
        return new CalculateMeansOutput(iMinH, iMinA, iMinD, iMaxH, iMaxA, iMaxD, iGlobalNM, iGlobalH, iGlobalA, iGlobalD);
    }

    private class CalculateMeansOutput {
        private final double minH;
        private final double minA;
        private final double minD;
        private final double maxH;
        private final double maxA;
        private final double maxD;
        private final int globalNM;
        private final double globalH;
        private final double globalA;
        private final double globalD;

        CalculateMeansOutput(double minH, double minA, double minD, double maxH, double maxA, double maxD, int globalNM, double globalH, double globalA, double globalD) {
            this.minH = minH;
            this.minA = minA;
            this.minD = minD;
            this.maxH = maxH;
            this.maxA = maxA;
            this.maxD = maxD;
            this.globalNM = globalNM;
            this.globalH = globalH;
            this.globalA = globalA;
            this.globalD = globalD;
        }

        double getMinH() {
            return minH;
        }

        double getMinA() {
            return minA;
        }

        double getMinD() {
            return minD;
        }

        double getMaxH() {
            return maxH;
        }

        double getMaxA() {
            return maxA;
        }

        double getMaxD() {
            return maxD;
        }

        int getGlobalNM() {
            return globalNM;
        }

        double getGlobalH() {
            return globalH;
        }

        double getGlobalA() {
            return globalA;
        }

        double getGlobalD() {
            return globalD;
        }
    }
}
