package com.kellify.loadbet.load;

import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.DbConnector;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

public class IceHockeyHDALoader {
    private static final Logger logger = LoggerFactory.getLogger(IceHockeyHDALoader.class);

    DateTimeFormatter formatter;




    public IceHockeyHDALoader() {
        formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
    }

    public int[] loadIceHockeyOdds(File file, PreparedStatement psContinente, PreparedStatement psQuotas, PreparedStatement psMeanQuotas, PreparedStatement psMeanProbs) throws IOException {
        int[] ret;
        Reader in = null;
        int counter = 0;
        int emptyCount = 0;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy",Locale.US);

        String [] bms = {"marathon_op_ml_","tonybet_op_ml_","unibet_op_ml_","bet365_op_ml_","bwin_op_ml_","bet-at-home_op_ml_","10bet_op_ml_","pinn_op_ml_"};





        try {
            double[] tAtDtH;
            Map<String, String> dataMap;
            String dateString;
            String nazione,continente;
            in = new FileReader(file);
            Iterable<CSVRecord> records = CSVFormat.RFC4180.withDelimiter(';').withHeader().parse(in);
            LocalDate dateTime;
            double MH,MA,MD;
            double tH, tA,tD ;
            double minA,minH,minD;
            double maxA,maxH,maxD;
            double probA,probH,probD;
            double norm;
            String Fthg ,Ftag ;
            int fthg,ftag;
            int NM;


            CalculateMeansOutput calculateMeansOutput;

            for (CSVRecord record : records) {

                MH = 0.0;
                MA = 0.0;
                MD = 0.0;
                minA = 100.0;
                minH = 100.0;
                minD = 100.0;
                maxA = 0.0;
                maxH = 0.0;
                maxD = 0.0;
                NM=0;


                try {

                    dateString = record.get("dd")+"-"+record.get("mm")+"-"+record.get("yy");

                    if(dateString == null || dateString.length() == 0) {
                        emptyCount++;
                        continue;
                    }
                    dateTime = LocalDate.parse(dateString, formatter);
                    dataMap = record.toMap();

                    String campionato = dataMap.get("league");


                    String homeTeam = dataMap.get("home_team");
                    String awayTeam = dataMap.get("away_team");
                    Fthg = dataMap.get("ft_score_home");
                    Ftag = dataMap.get("ft_score_away");
                    String ftr = dataMap.get("ft_score_result");
                    nazione=dataMap.get("country");
                    continente = getContinente(psContinente, nazione);
                    //continente="NorthAmerica";
                    fthg = Integer.parseInt(Fthg);
                    ftag = Integer.parseInt(Ftag);


                    psQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psQuotas.setString(2, campionato);
                    psQuotas.setString(3, nazione);
                    psQuotas.setString(4, continente);
                    psQuotas.setString(5, homeTeam);
                    psQuotas.setString(6, awayTeam);
                    psQuotas.setInt(7, fthg);
                    psQuotas.setInt(8, ftag);
                    psQuotas.setString(9, ftr);

                    psMeanQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psMeanQuotas.setString(2, campionato);
                    psMeanQuotas.setString(3, nazione);
                    psMeanQuotas.setString(4, continente);
                    psMeanQuotas.setString(5, homeTeam);
                    psMeanQuotas.setString(6, awayTeam);
                    psMeanQuotas.setInt(7, fthg);
                    psMeanQuotas.setInt(8, ftag);
                    psMeanQuotas.setString(9, ftr);



                    for (int i=0;i<bms.length;i++){

                        tAtDtH=CalculatetAtDtH(bms[i], i, dataMap, psQuotas);
                        tA=tAtDtH[0];
                        tD=tAtDtH[1];
                        tH=tAtDtH[2];
                        if ((tA+tD+tH)!=-3){
                            calculateMeansOutput = calculateMeans(tH, tA, tD, minH, minA, minD, maxH, maxA, maxD, MH, MA, MD, NM);
                            MA = calculateMeansOutput.getGlobalA();
                            MH = calculateMeansOutput.getGlobalH();
                            MD = calculateMeansOutput.getGlobalD();
                            NM = calculateMeansOutput.getGlobalNM();
                            minA = calculateMeansOutput.getMinA();
                            minD = calculateMeansOutput.getMinD();
                            minH = calculateMeansOutput.getMinH();
                            maxA = calculateMeansOutput.getMaxA();
                            maxD = calculateMeansOutput.getMaxD();
                            maxH = calculateMeansOutput.getMaxH();
                        }
                    }




                    if (NM>0){
                        MA /= NM;
                        MD /= NM;
                        MH /= NM;
                    }

                    psMeanQuotas.setDouble(10, minA);
                    psMeanQuotas.setDouble(11, MA);
                    psMeanQuotas.setDouble(12, maxA);
                    psMeanQuotas.setDouble(13, minH);
                    psMeanQuotas.setDouble(14, MH);
                    psMeanQuotas.setDouble(15, maxH);
                    psMeanQuotas.setDouble(16, minD);
                    psMeanQuotas.setDouble(17, MD);
                    psMeanQuotas.setDouble(18, maxD);
                    psMeanQuotas.setInt(19, NM);
                    psMeanQuotas.executeUpdate();

                    if (MA*MD*MH!=0.0) {
                        probA=1.0/MA;
                        probH=1.0/MH;
                        probD=1.0/MD;
                        norm=probA+probH+probD;
                        probA/=norm;
                        probH/=norm;
                        probD/=norm;
                        psMeanProbs.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbs.setString(2, campionato);
                        psMeanProbs.setString(3, nazione);
                        psMeanProbs.setString(4, continente);
                        psMeanProbs.setString(5, homeTeam);
                        psMeanProbs.setString(6, awayTeam);
                        psMeanProbs.setInt(7, fthg);
                        psMeanProbs.setInt(8, ftag);
                        psMeanProbs.setString(9, ftr);
                        psMeanProbs.setDouble(10, probA);
                        psMeanProbs.setDouble(11, probH);
                        psMeanProbs.setDouble(12, probD);
                        psMeanProbs.setInt(13, NM);
                        psMeanProbs.executeUpdate();
                    }
                    //System.out.println(psQuotas.toString());
                    psQuotas.executeUpdate();

                    counter++;

                } catch(Exception ex) {
                    logger.error("record:" + record.toString(), ex);


                }
            }


        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if(in != null) {
                in.close();
            }
        }
        ret = new int[] {counter,  emptyCount};
        return ret;
    }

     public static void LoadIceHockeyHDAData(DbConnector dbConnector, Properties config) throws SQLException, IOException {
        logger.info("LoadIceHockeyHDAData process start");
        //Unzipper unzipper = new Unzipper(config, LoadBetType.FOOTBALL);
        //unzipper.unzip();

        File folder = new File(config.getProperty("icehockey.data.folder"));
        PreparedStatement psQuotas = null;
        PreparedStatement psContinente = null;
        PreparedStatement psMeanQuotas = null;
        PreparedStatement psMeanProbs = null;

        File[] files = folder.listFiles();
        int counter = 0;
        int emptyCounter = 0;
        IceHockeyHDALoader loader = new IceHockeyHDALoader();
        String fileName;

        try {
            Connection conn=dbConnector.getConnection();
            psQuotas = conn.prepareStatement(DbConnector.INSERT_ICEHOCKEY_HDA_ODDS);
            psMeanQuotas = conn.prepareStatement(DbConnector.INSERT_BET_ICEHOCKEY_HDA_MEANS_ODDS);
            psMeanProbs = conn.prepareStatement(DbConnector.INSERT_BET_ICEHOCKEY_HDA_CLUSTERS);
            psContinente = conn.prepareStatement(DbConnector.SELECT_CONTINENTE);

            for (File f : files) {
                try {
                    fileName = f.getName();

                    String continente = getContinente(psContinente, fileName.substring(fileName.indexOf("_")+1));
                    logger.info("file:" + f.getName() + ", continente:" + continente);
                    int localCounter[] =  loader.loadIceHockeyOdds(f,psContinente,  psQuotas, psMeanQuotas,psMeanProbs);

                    logger.info("file rows:" + localCounter[0] + ", file empty rows:" + localCounter[1]);
                    counter += localCounter[0];
                    emptyCounter += localCounter[1];
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                } finally {
                    f.delete();
                }
            }


            logger.info("total rows:" + counter + ", total empty rows:" + emptyCounter);
        } finally {
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psMeanQuotas != null) {
                psMeanQuotas.close();
            }
            if (psMeanProbs != null) {
                psMeanProbs.close();
            }

            if (psContinente != null) {
                psContinente.close();
            }
        }
        logger.info("LoadIceHockeyHDAData process end");
    }


    private double[] CalculatetAtDtH(String bm,int psInt,Map <String,String> dataMap,PreparedStatement psQuotas) throws SQLException {



        String oddh,odda,oddd;
        double tH,tD,tA;


        oddh = dataMap.get(bm+"h");
        oddh = StringUtils.isBlank(oddh) ? "-1" : oddh;
        tH = Double.parseDouble(oddh.replace(',','.'));

        odda = dataMap.get(bm+"a");
        odda = StringUtils.isBlank(odda) ? "-1" : odda;
        tA = Double.parseDouble(odda.replace(',','.'));
        oddd = dataMap.get(bm+"d");
        oddd = StringUtils.isBlank(oddd) ? "-1" : oddd;
        tD = Double.parseDouble(oddd.replace(',','.'));

        psQuotas.setDouble(10+3*psInt, tA);
        psQuotas.setDouble(11+3*psInt, tD);
        psQuotas.setDouble(12+3*psInt, tH);

        return new double[]{tA,tD,tH};
    }

    private IceHockeyHDALoader.CalculateMeansOutput calculateMeans(double oddH, double oddA, double oddD, double minH, double minA, double minD, double maxH, double maxA, double maxD, double globalH, double globalA, double globalD, int globalNM) {
        double iGlobalA = globalA + oddA;
        double iGlobalH = globalH + oddH;
        double iGlobalD = globalD + oddD;
        int iGlobalNM = globalNM+1;
        double iMinA = Math.min(minA, oddA);
        double iMinH = Math.min(minH, oddH);
        double iMinD = Math.min(minD, oddD);
        double iMaxA = Math.max(maxA, oddA);
        double iMaxH = Math.max(maxH, oddH);
        double iMaxD = Math.max(maxD, oddD);
        return new IceHockeyHDALoader.CalculateMeansOutput(iMinH, iMinA, iMinD, iMaxH, iMaxA, iMaxD, iGlobalNM, iGlobalH, iGlobalA, iGlobalD);
    }

    private class CalculateMeansOutput {
        private final double minH;
        private final double minA;
        private final double minD;
        private final double maxH;
        private final double maxA;
        private final double maxD;
        private final int globalNM;
        private final double globalH;
        private final double globalA;
        private final double globalD;

        CalculateMeansOutput(double minH, double minA, double minD, double maxH, double maxA, double maxD, int globalNM, double globalH, double globalA, double globalD) {
            this.minH = minH;
            this.minA = minA;
            this.minD = minD;
            this.maxH = maxH;
            this.maxA = maxA;
            this.maxD = maxD;
            this.globalNM = globalNM;
            this.globalH = globalH;
            this.globalA = globalA;
            this.globalD = globalD;
        }

        double getMinH() {
            return minH;
        }

        double getMinA() {
            return minA;
        }

        double getMinD() {
            return minD;
        }

        double getMaxH() {
            return maxH;
        }

        double getMaxA() {
            return maxA;
        }

        double getMaxD() {
            return maxD;
        }

        int getGlobalNM() {
            return globalNM;
        }

        double getGlobalH() {
            return globalH;
        }

        double getGlobalA() {
            return globalA;
        }

        double getGlobalD() {
            return globalD;
        }
    }
    private static String getContinente(PreparedStatement ps, String nazione) throws SQLException {
        String continente="";
        ResultSet rs = null;
        try {
            ps.setString(1, nazione);
            rs = ps.executeQuery();
            if(rs.next()) {
                continente = rs.getString(1);
            }
        } finally {
            if (rs != null) {
                rs.close();;
            }
        }
        return continente;
    }
}
