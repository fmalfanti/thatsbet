package com.kellify.loadbet.load;

import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Map;
import java.util.Properties;

public class FootballLoaderAsianHandicap {
    private static final Logger logger = LoggerFactory.getLogger(FootballLoaderAsianHandicap.class);

    private static DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("dd/MM/yy");
    private static DateTimeFormatter formatter_2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DateTimeFormatter parserLungo;
    private DateTimeFormatter parserCorto;
    public FootballLoaderAsianHandicap() {
        parserCorto = new DateTimeFormatterBuilder().appendOptional(formatter_1).toFormatter();
        parserLungo = new DateTimeFormatterBuilder().appendOptional(formatter_2).toFormatter();
    }

    public int[] loadBetFootOdds(File file, String nazione, String continente, PreparedStatement psQuotas,PreparedStatement psMeanProbs,PreparedStatement psMeanProbsMaxMin) throws IOException {
        int[] ret;
        Reader in = null;
        int counter = 0;
        int emptyCount = 0;
        try {
            Map<String, String> dataMap;
            String dateString;
            Map<Integer,Matrici.HdaMatrix> useNationMap;
            Map<Integer,Matrici.HdaMatrix> useContinentMap;
            Map<Integer,Matrici.HdaMatrix> useWorldMap;

            in = new FileReader(file);
            Iterable<CSVRecord> records = CSVFormat.EXCEL.withHeader().parse(in);
            LocalDate dateTime;
            String Fthg ,Ftag ;
            int fthg,ftag;
            double minAHhome, minAHaway;
            double norm;
            String PAHHhome, PAHAaway;
            String B365Hhome, B365Haway;
            String GBAHhome, GBAHaway;
            String LBAHhome, LBAHaway;
            String NumberAHhome, MaxAHhome, AvgAHhome, MaxAHaway,AvgAHaway;
            double probAvgAHhome,probAvgAHaway;
            double probAHHMin, probAHHMax, probAHAMax, probAHAMin;

            for (CSVRecord record : records) {

                //System.out.println(record.toString());
                try {
                    dateString = record.get("Date");
                    if(dateString == null || dateString.length() == 0) {
                        emptyCount++;
                        continue;
                    }

                    //System.out.println(record.get("Date"));
                    if (dateString.length() == 8) {
                        dateTime = LocalDate.parse(record.get("Date"), parserCorto);
                    } else {
                        dateTime = LocalDate.parse(record.get("Date"), parserLungo);
                    }
                    //System.out.println(dateString+" "+dateTime.toString());

                    dataMap = record.toMap();
                    logger.debug("dataMap " + dataMap);
                    String campionato = dataMap.get("Div");
                    if (campionato==null) {
                        campionato = dataMap.get("League");
                    }

                    String homeTeam = dataMap.get("HomeTeam");
                    if (homeTeam==null) {
                        homeTeam = dataMap.get("HT");
                    }
                    if (homeTeam==null) {
                        homeTeam = dataMap.get("Home");
                    }
                    String awayTeam = dataMap.get("AwayTeam");
                    if (awayTeam==null) {
                        awayTeam = dataMap.get("AT");
                    }
                    if (awayTeam==null) {
                        awayTeam = dataMap.get("Away");
                    }
                    Fthg = dataMap.get("FTHG");
                    if (Fthg==null) {
                        fthg = Integer.parseInt(dataMap.get("HG"));
                    }
                    else {
                        fthg = Integer.parseInt(Fthg);
                    }
                    Ftag = dataMap.get("FTAG");
                    if (Ftag==null) {
                        ftag = Integer.parseInt(dataMap.get("AG"));
                    } else {
                        ftag = Integer.parseInt(Ftag);
                    }
                    String ftr = dataMap.get("FTR");
                    if (ftr==null) {
                        ftr = dataMap.get("Res");
                    }
                    if (ftr==null) {
                       continue;
                    }
                    NumberAHhome = dataMap.get("BbAHh");
                    NumberAHhome = StringUtils.isBlank(NumberAHhome) ? "-3" : NumberAHhome;
                    String bbNumberAHhome = NumberAHhome;
                    System.out.println("bbNumberAHhome "+ bbNumberAHhome+" NumberAHhome " + NumberAHhome);
                    MaxAHhome = dataMap.get("BbMxAHH");
                    MaxAHhome = StringUtils.isBlank(MaxAHhome) ? "-3" : MaxAHhome;
                    Double bbMaxAHhome = Double.parseDouble(MaxAHhome);

                    AvgAHhome = dataMap.get("BbAvAHH");
                    AvgAHhome = StringUtils.isBlank(AvgAHhome) ? "-3" : AvgAHhome;
                    Double bbAvgAHhome = Double.parseDouble(AvgAHhome);

                    MaxAHaway = dataMap.get("BbMxAHA");
                    MaxAHaway = StringUtils.isBlank(MaxAHaway) ? "-3" : MaxAHaway;
                    Double bbMaxAHaway = Double.parseDouble(MaxAHaway);

                    AvgAHaway = dataMap.get("BbAvAHA");
                    AvgAHaway = StringUtils.isBlank(AvgAHaway) ? "-3" : AvgAHaway;
                    Double bbAvgAHaway = Double.parseDouble(AvgAHaway);
                    minAHhome = 2 * bbAvgAHhome - bbMaxAHhome;
                    minAHaway = 2 * bbAvgAHaway - bbMaxAHaway;

                    GBAHhome = dataMap.get("GBAHH");
                    GBAHhome = StringUtils.isBlank(GBAHhome) ? "-3" : GBAHhome;
                    Double bbGBAHhome = Double.parseDouble(GBAHhome);

                    GBAHaway = dataMap.get("GBAHA");
                    GBAHaway = StringUtils.isBlank(GBAHaway) ? "-3" : GBAHaway;
                    Double bbGBAHaway = Double.parseDouble(GBAHaway);

                    LBAHhome = dataMap.get("LBAHH");
                    LBAHhome = StringUtils.isBlank(LBAHhome) ? "-3" : LBAHhome;
                    Double bbLBAHhome = Double.parseDouble(LBAHhome);

                    LBAHaway = dataMap.get("LBAHH");
                    LBAHaway = StringUtils.isBlank(LBAHaway) ? "-3" : LBAHaway;
                    Double bbLBAHaway = Double.parseDouble(LBAHaway);

                    B365Hhome = dataMap.get("B365AHH");
                    B365Hhome = StringUtils.isBlank(B365Hhome) ? "-3" : B365Hhome;
                    Double bbB365Hhome = Double.parseDouble(B365Hhome);

                    B365Haway = dataMap.get("B365AHA");
                    B365Haway = StringUtils.isBlank(B365Haway) ? "-3" : B365Haway;
                    Double bbB365Haway = Double.parseDouble(B365Haway);

                    PAHHhome = dataMap.get("PAHH");
                    PAHHhome = StringUtils.isBlank(PAHHhome) ? "-3" : PAHHhome;
                    Double bbPAHHhome = Double.parseDouble(PAHHhome);

                    PAHAaway = dataMap.get("PAHA");
                    PAHAaway = StringUtils.isBlank(PAHAaway) ? "-3" : PAHAaway;
                    Double bbPAHAaway = Double.parseDouble(PAHAaway);


                    //logger.info("Ciao!"+ bbMxGreater + "bbMxGreater" + bbAvGreater+ "bbAvGreater"+ bbMxLower+ "bbMxLower" + bbAvLower + "bbAvLower");
                    psQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psQuotas.setString(2, campionato);
                    psQuotas.setString(3, nazione);
                    psQuotas.setString(4, continente);
                    psQuotas.setString(5, homeTeam);
                    psQuotas.setString(6, awayTeam);
                    psQuotas.setInt(7, fthg);
                    psQuotas.setInt(8, ftag);
                    psQuotas.setString(9, ftr);
                    psQuotas.setString(10, bbNumberAHhome);
                    psQuotas.setDouble(11, bbMaxAHhome);
                    psQuotas.setDouble(12, bbAvgAHhome);
                    psQuotas.setDouble(13, bbMaxAHaway);
                    psQuotas.setDouble(14, bbAvgAHaway);
                    psQuotas.setDouble(15, bbGBAHhome);
                    psQuotas.setDouble(16, bbGBAHaway);
                    psQuotas.setDouble(17, bbLBAHhome);
                    psQuotas.setDouble(18, bbLBAHaway);
                    psQuotas.setDouble(19, bbB365Hhome);
                    psQuotas.setDouble(20, bbB365Haway);
                    psQuotas.setDouble(21, bbPAHHhome);
                    psQuotas.setDouble(22, bbPAHAaway);
                    if (bbAvgAHhome+bbAvgAHaway!=-2.0) {
                        probAvgAHhome = 1.0 / bbAvgAHhome;
                        probAvgAHaway = 1.0 / bbAvgAHaway;
                        norm=probAvgAHhome+probAvgAHaway;
                        probAvgAHhome /= norm;
                        probAvgAHaway /= norm;

                        psMeanProbs.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbs.setString(2, campionato);
                        psMeanProbs.setString(3, nazione);
                        psMeanProbs.setString(4, continente);
                        psMeanProbs.setString(5, homeTeam);
                        psMeanProbs.setString(6, awayTeam);
                        psMeanProbs.setInt(7, fthg);
                        psMeanProbs.setInt(8, ftag);
                        psMeanProbs.setString(9, ftr);
                        psMeanProbs.setString(10, bbNumberAHhome);
                        psMeanProbs.setDouble(11, probAvgAHhome);
                        psMeanProbs.setDouble(12, probAvgAHaway);
                        psMeanProbs.executeUpdate();

                        probAHHMin = 1.0 /bbMaxAHhome;
                        probAHHMax = 1.0 /minAHhome ;
                        norm=probAHHMin+probAHHMax;
                        probAHHMin /= norm;
                        probAHHMax /= norm;

                        probAHAMax = 1.0 / minAHaway;
                        probAHAMin = 1.0 / bbMaxAHaway;
                        norm=probAHAMax+probAHAMin;
                        probAHAMax /= norm;
                        probAHAMin /= norm;
                        //System.out.println("probLowerMin:  "+ probLowerMin + " probLowerMax: " + probLowerMax+ "probGreaterMin:  "+ probGreaterMin + "probGreaterMax: " + probGreaterMax);
                        psMeanProbsMaxMin.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbsMaxMin.setString(2, campionato);
                        psMeanProbsMaxMin.setString(3, nazione);
                        psMeanProbsMaxMin.setString(4, continente);
                        psMeanProbsMaxMin.setString(5, homeTeam);
                        psMeanProbsMaxMin.setString(6, awayTeam);
                        psMeanProbsMaxMin.setInt(7, fthg);
                        psMeanProbsMaxMin.setInt(8, ftag);
                        psMeanProbsMaxMin.setString(9, ftr);
                        psMeanProbsMaxMin.setString(10, bbNumberAHhome);
                        psMeanProbsMaxMin.setDouble(11, probAHHMin);
                        psMeanProbsMaxMin.setDouble(12, probAvgAHhome);
                        psMeanProbsMaxMin.setDouble(13, probAHHMax);
                        psMeanProbsMaxMin.setDouble(14, probAHAMin);
                        psMeanProbsMaxMin.setDouble(15, probAvgAHaway);
                        psMeanProbsMaxMin.setDouble(16, probAHAMax);
                        psMeanProbsMaxMin.executeUpdate();

                    }
                    psQuotas.executeUpdate();

                    counter++;

                } catch(Exception ex) {
                    logger.error("record:" + record.toString(), ex);

                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if(in != null) {
                in.close();
            }
        }
        ret = new int[] {counter,  emptyCount};
        return ret;
    }

    public static void LoadFootballData(DbConnector dbConnector, Properties config) throws SQLException, IOException {
        logger.info("FootballLoaderAsianHandicap process start");
//        Unzipper unzipper = new Unzipper(config, LoadBetType.FOOTBALL);
//        unzipper.unzip();

        File folder = new File(config.getProperty("football.data.folder"));
        PreparedStatement psQuotas = null;
        PreparedStatement psNazione = null;
        PreparedStatement psContinente = null;
        PreparedStatement psMeanProbs=null;
        PreparedStatement psMeanProbsMaxMin=null;
        File[] files = folder.listFiles();
        int counter = 0;
        int emptyCounter = 0;
        FootballLoaderAsianHandicap loader = new FootballLoaderAsianHandicap();
        String fileName;

        try {
            Connection conn=dbConnector.getConnection();
            psQuotas = conn.prepareStatement(DbConnector.INSERT_FOOT_ODDS_ASIAN_HANDICAP);
            psMeanProbs = conn.prepareStatement(DbConnector.INSERT_BET_FOOTBALL_CLUSTERS_ASIAN_HANDICAP);
            psMeanProbsMaxMin = conn.prepareStatement(DbConnector.INSERT_FOOT_PROB_ASIAN_HANDICAP);
            psNazione = conn.prepareStatement(DbConnector.SELECT_NAZIONE);
            psContinente = conn.prepareStatement(DbConnector.SELECT_CONTINENTE);

            for (File f : files) {
                try {
                    fileName = f.getName();
                    String nazione = Nazione.getNazione(psNazione, fileName.substring(fileName.indexOf("_")+1));
                    String continente = Continente.getContinente(psContinente, fileName.substring(fileName.indexOf("_")+1));
                    logger.info("file:" + f.getName() + ", nazione:" + nazione+", continente:" + continente);
                    int localCounter[] =  loader.loadBetFootOdds(f, nazione, continente,  psQuotas,psMeanProbs,psMeanProbsMaxMin);

                    logger.info("file rows:" + localCounter[0] + ", file empty rows:" + localCounter[1]);
                    counter += localCounter[0];
                    emptyCounter += localCounter[1];
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                } finally {
                    f.delete();
                }
            }


            logger.info("total rows:" + counter + ", total empty rows:" + emptyCounter);
        } finally {
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psNazione != null) {
                psNazione.close();
            }
            if (psContinente != null) {
                psContinente.close();
            }
            if (psMeanProbs != null) {
                psMeanProbs.close();
            }
            if (psMeanProbsMaxMin != null) {
                psMeanProbsMaxMin.close();
            }
        }
        logger.info("FootballLoaderAsianHandicap process end");
    }


}
