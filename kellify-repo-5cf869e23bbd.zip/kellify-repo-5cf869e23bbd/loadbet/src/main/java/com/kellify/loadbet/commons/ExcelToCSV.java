package com.kellify.loadbet.commons;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ExcelToCSV {
    private static final Logger logger = LoggerFactory.getLogger(ExcelToCSV.class);

    private static final String XLS = ".xls";
    private static final String XLSX = ".xlsx";
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy");

    private final File file;

    public ExcelToCSV(File file) {
        this.file = file;
    }

    public List<File> writeCSV() throws IOException {
        String fileAbsolutePath = file.getAbsolutePath();
        logger.info("file path:" + fileAbsolutePath);
        String extension = fileAbsolutePath.substring(fileAbsolutePath.lastIndexOf("."));

        if(extension.equals(XLSX)) {
            return writeXLSX_CSV();
        } else {
            return writeXLS_CSV();
        }
    }

    public List<File> writeXLSX_CSV() throws IOException {
        List<File> fileList = new ArrayList<File>();
        Path filePath = Paths.get(file.getAbsolutePath());
        String fileName = filePath.getFileName().toString();
        String fileNameNoExtension = fileName.substring(0, fileName.indexOf("."));
        Path csvFile = null;

        CSVPrinter csvFilePrinter = null;
        CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator("\n");

        InputStream excelFileToRead = null;
        BufferedWriter writer = null;
        OutputStreamWriter fstream = null;

        List<Object> header = new ArrayList<>();
        List<String> record = new ArrayList<>();
        boolean first = true;
        String cellValue;

        try {
            excelFileToRead = new FileInputStream(file.getAbsolutePath());
            XSSFWorkbook wb = new XSSFWorkbook(excelFileToRead);

            //XSSFWorkbook test = new XSSFWorkbook();

            //XSSFSheet sheet = wb.getSheetAt(0);
            int numSheets = wb.getNumberOfSheets();
            for(int i=0; i<numSheets; i++) {
                csvFile = Paths.get(filePath.getParent() + File.separator + fileNameNoExtension + "_" + i + ".csv");
                try {
                    XSSFSheet sheet = wb.getSheetAt(i);
                    XSSFRow row;
                    XSSFCell cell;

                    Iterator rows = sheet.rowIterator();

                    writer = Files.newBufferedWriter(csvFile);
                    csvFilePrinter = new CSVPrinter(writer, csvFileFormat);

                    while (rows.hasNext()) {
                        record.clear();
                        row = (XSSFRow) rows.next();
                        for (int colNum = 0; colNum < row.getLastCellNum(); colNum++) {
                            cell = (XSSFCell) row.getCell(colNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                            if (cell.getCellTypeEnum() == CellType.STRING) {
                                if (first) {
                                    header.add(cell.getStringCellValue());
                                } else {
                                    record.add(cell.getStringCellValue());
                                }
                                //sb.append(cell.getStringCellValue()).append(",");
                            } else if (cell.getCellTypeEnum() == CellType.NUMERIC) {
                                if (DateUtil.isCellDateFormatted(cell)) {
                                    //sb.append(dateToString(cell.getDateCellValue()));
                                    cellValue = dateToString(cell.getDateCellValue());
                                } else {
                                    //sb.append(cell.getNumericCellValue());
                                    cellValue = "" + cell.getNumericCellValue();
                                }
                                //sb.append(",");
                                record.add(cellValue);
                            } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                //sb.append(",");
                                record.add("");
                            }
                        }
                        if (first) {
                            csvFilePrinter.printRecord(header);
                        } else {
                            csvFilePrinter.printRecord(record);
                        }
                        first = false;
//                sb.delete(sb.length() - 1, sb.length());
//                writer.write(sb.toString());
//                writer.newLine();
                    }
                } finally {
                    if (writer != null) {
                        writer.flush();
                        writer.close();
                        csvFilePrinter.close();
                    }
                }
                fileList.add(csvFile.toFile());
            }
        } finally {
            if(excelFileToRead != null) {
                excelFileToRead.close();
            }
        }
        return fileList;
    }

    public List<File> writeXLS_CSV() throws IOException {
        List<File> fileList = new ArrayList<File>();
        Path filePath = Paths.get(file.getAbsolutePath());
        String fileName = filePath.getFileName().toString();
        String fileNameNoExtension = fileName.substring(0, fileName.indexOf("."));
        Path csvFile = null;

        CSVPrinter csvFilePrinter = null;
        CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator("\n");

        InputStream excelFileToRead = null;
        BufferedWriter writer = null;

        List<Object> header = new ArrayList<>();
        List<String> record = new ArrayList<>();
        boolean first = true;
        String cellValue;

        try {
            excelFileToRead = new FileInputStream(file.getAbsolutePath());
            HSSFWorkbook wb = new HSSFWorkbook(excelFileToRead);

            int numSheets = wb.getNumberOfSheets();
            for(int i=0; i<numSheets; i++) {
                csvFile = Paths.get(filePath.getParent() + File.separator + fileNameNoExtension + "_" + i + ".csv");
                try {
                    //HSSFSheet sheet = wb.getSheet(fileNameNoExtension.substring(fileNameNoExtension.lastIndexOf("_") + 1));
                    HSSFSheet sheet = wb.getSheetAt(i);
                    HSSFRow row;
                    HSSFCell cell;

                    Iterator rows = sheet.rowIterator();

                    writer = Files.newBufferedWriter(csvFile);
                    csvFilePrinter = new CSVPrinter(writer, csvFileFormat);

                    while (rows.hasNext()) {
                        record.clear();
                        row = (HSSFRow) rows.next();
                        for (int colNum = 0; colNum < row.getLastCellNum(); colNum++) {
                            cell = (HSSFCell) row.getCell(colNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                            if (cell.getCellTypeEnum() == CellType.STRING) {
                                if (first) {
                                    header.add(cell.getStringCellValue());
                                } else {
                                    record.add(cell.getStringCellValue());
                                }
                                //sb.append(cell.getStringCellValue()).append(",");
                            } else if (cell.getCellTypeEnum() == CellType.NUMERIC) {
                                if (DateUtil.isCellDateFormatted(cell)) {
                                    //sb.append(dateToString(cell.getDateCellValue()));
                                    cellValue = dateToString(cell.getDateCellValue());
                                } else {
                                    //sb.append(cell.getNumericCellValue());
                                    cellValue = "" + cell.getNumericCellValue();
                                }
                                //sb.append(",");
                                record.add(cellValue);
                            } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                //sb.append(",");
                                record.add("");
                            }
                        }
                        if (first) {
                            csvFilePrinter.printRecord(header);
                        } else {
                            csvFilePrinter.printRecord(record);
                        }
                        first = false;
                    }
                } finally {
                    if (writer != null) {
                        writer.flush();
                        writer.close();
                        csvFilePrinter.close();
                    }
                }
                fileList.add(csvFile.toFile());
            }
        } finally {
            if(excelFileToRead != null) {
                excelFileToRead.close();
            }
        }
        return fileList;
    }

    private String dateToString(Date date) {
        return simpleDateFormat.format(date);
    }
}
