package com.kellify.loadbet.dl4j_training;

import com.kellify.loadbet.LoadBet;
import com.kellify.loadbet.commons.DbConnector;
import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.split.FileSplit;
import org.datavec.api.util.ClassPathResource;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.deeplearning4j.util.ModelSerializer;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.learning.config.Sgd;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class BaseballTrainer { private static final Logger logger = LoggerFactory.getLogger(LoadBet.class);
    static String jdbcUrl="jdbc:mysql://kellify.vshosting.cz:3306/bookmaker_betting?useSSL=false&noAccessToProcedureBodies=true";
    static String user="ubibetter";
    static String password="R0t0l0n!";

    public static void main(String[] args) throws  Exception {
        List vector;
        List<double[]> listaFeatures= new ArrayList<>();
        List<double[]> listaValues= new ArrayList<>();
        List<double[]> listaFeaturesTest= new ArrayList<>();
        List<double[]> listaValuesTest= new ArrayList<>();
        double[] rigaFeatures;
        double[] rigaValues;
        double[] rigaFeaturesTest;
        double[] rigaValuesTest;
        boolean saveUpdater = true;
        double min,max;
        double elem;
        int numLinesToSkip=0;
        char delimiter=',';

        Properties config = new Properties();
        config.put("jdbcUrl",jdbcUrl);
        config.put("dataSource.user",user);
        config.put("dataSource.password",password);
        DbConnector dbConnector = new DbConnector(config);
        Connection conn = null;
        String INSERT_MODEL = "insert ignore into sports_model (sport,model) values (?,?) on duplicate key update model=?";

        String RETRIEVE_MODEL = "select model from sports_model where sport=?";

        RecordReader recordTrainingReader=new CSVRecordReader(numLinesToSkip, delimiter);
        recordTrainingReader.initialize(new FileSplit(new ClassPathResource("baseball_training.txt").getFile()));
        while (recordTrainingReader.hasNext()) {
            min=1;
            max=0;
            vector = recordTrainingReader.next();
            for (int i=0; i<vector.size()-1;i++){
                elem=Double.parseDouble(vector.get(i).toString());
                if (min>elem) min=elem;
                if (max<elem) max=elem;
            }
            if (!((min<0.5)&&(max>0.5))) {
                rigaFeatures= new double[vector.size()-1];
                rigaValues = new double[2];
                for (int i=0; i<vector.size()-1;i++) {
                    rigaFeatures[i]=Double.parseDouble(vector.get(i).toString());
                }
                rigaValues[0]=rigaValues[1]=0;
                rigaValues[Integer.parseInt(vector.get(vector.size()-1).toString())]=1.00;
                listaFeatures.add(rigaFeatures);
                listaValues.add(rigaValues);
            }

        }
        System.out.println("Training: "+ listaFeatures.size());
        double[][] trainingFeatures =listaFeatures.toArray(new double[listaFeatures.size()][]);
        double[][] trainingValues =listaValues.toArray(new double[listaValues.size()][]);
        DataSet trainingData = new DataSet(Nd4j.create(trainingFeatures),Nd4j.create(trainingValues));
        //System.out.println(allData);
        RecordReader recordTestReader=new CSVRecordReader(numLinesToSkip, delimiter);
        recordTestReader.initialize(new FileSplit(new ClassPathResource("baseball_test.txt").getFile()));
        int count=0;
        while (recordTestReader.hasNext()) {
            min=1;
            max=0;
            vector = recordTestReader.next();
            for (int i=0; i<vector.size()-1;i++){
                elem=Double.parseDouble(vector.get(i).toString());
                if (min>elem) min=elem;
                if (max<elem) max=elem;
            }
            if (!((min<0.5)&&(max>0.5))) {
                count++;
                rigaFeaturesTest= new double[vector.size()-1];
                rigaValuesTest = new double[2];
                for (int i=0; i<vector.size()-1;i++) {
                    rigaFeaturesTest[i]=Double.parseDouble(vector.get(i).toString());
                }
                rigaValuesTest[0]=rigaValuesTest[1]=0;
                rigaValuesTest[Integer.parseInt(vector.get(vector.size()-1).toString())]=1.00;
                listaFeaturesTest.add(rigaFeaturesTest);
                listaValuesTest.add(rigaValuesTest);
            }
        }
        System.out.println("Test: "+ listaFeaturesTest.size() + " Count="+count);
        double[][] testFeatures =listaFeaturesTest.toArray(new double[listaFeaturesTest.size()][]);
        double[][] testValues =listaValuesTest.toArray(new double[listaValuesTest.size()][]);
        DataSet testData = new DataSet(Nd4j.create(testFeatures),Nd4j.create(testValues));
        //We need to normalize our data. We'll use NormalizeStandardize (which gives us mean 0, unit variance):
        //DataNormalization normalizer = new NormalizerStandardize();
        //normalizer.fit(trainingData);           //Collect the statistics (mean/stdev) from the training data. This does not modify the input data
        //normalizer.transform(trainingData);     //Apply normalization to the training data
        //normalizer.transform(testData);         //Apply normalization to the test data. This is using statistics calculated from the *training* set


        final int numInputs = 9;
        int outputNum = 2;
        long seed = 6;



        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .activation(Activation.TANH)
                .weightInit(WeightInit.XAVIER)
                .updater(new Sgd(0.1))
                .l2(1e-4)
                .list()
                .layer(0, new DenseLayer.Builder().nIn(numInputs).nOut(numInputs)
                        .build())
                .layer(1, new DenseLayer.Builder().nIn(numInputs).nOut(numInputs)
                        .build())
                .layer(2, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .activation(Activation.SOFTMAX)
                        .nIn(numInputs).nOut(outputNum).build())
                .backprop(true).pretrain(false)
                .build();
        //run the model
        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();
        model.setListeners(new ScoreIterationListener(100));

        for(int i=0; i<1000; i++ ) {
            model.fit(trainingData);
        }

        try {
            conn=dbConnector.getConnection();
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            PreparedStatement pstmt = conn.prepareStatement(INSERT_MODEL);
            ModelSerializer.writeModel(model, outStream, saveUpdater);

            pstmt.setInt(1, 3);
            pstmt.setBinaryStream(2, new ByteArrayInputStream(outStream.toByteArray()));
            pstmt.setBinaryStream(3, new ByteArrayInputStream(outStream.toByteArray()));
            pstmt.executeUpdate();
        } finally {
            if (conn != null) {
                conn.close();
            }
        }

        MultiLayerNetwork restored =null;

        try {
            conn=dbConnector.getConnection();
            InputStream inStream = null;
            PreparedStatement pstmt = conn.prepareStatement(RETRIEVE_MODEL);


            pstmt.setInt(1, 5);
            ResultSet rs=pstmt.executeQuery();
            while (rs.next()){

                inStream=rs.getBinaryStream(1);
            }
            restored = ModelSerializer.restoreMultiLayerNetwork(inStream,saveUpdater);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }




        Evaluation eval = new Evaluation(2);
        double[][] evalFeatures =  new double[][] { new double[] { 0.51,0.52,0.53,0.54,0.55,0.56,0.57,0.58,0.59 }};

        INDArray evaluation = Nd4j.create(evalFeatures);
        INDArray output = restored.output(evaluation);

        System.out.println("----------------");
        System.out.println(output);
        System.out.println("----------------");


    }


}
