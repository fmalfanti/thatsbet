package com.kellify.loadbet.fill;

import com.kellify.common.util.BmsBySports;
import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.DbConnector;
import com.kellify.loadbet.matrixFiller.HAMatrixFiller;
import org.slf4j.Logger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;

public class IceHockeyHAFiller {
    public static void FillIceHockeyHAMatrix(DbConnector dbConnector, Properties config,Logger logger) throws SQLException, IOException {
        logger.info("FillIceHockeyMatrix process start");
        PreparedStatement psMatrici = null;
        PreparedStatement psQuotas = null;
        PreparedStatement psNazioni = null;
        PreparedStatement psContinenti = null;
        //PreparedStatement psResults = null;
        String [] bms = BmsBySports.IceHockeyHABms;
        //{"matchbook_op_ha_","marathon_op_ha_","tonybet_op_ha_","5dimes_op_ha_","pinnacle_op_ha_","bet365_op_ha_","unibet_op_ha_","bwin_op_ha_","10bet_op_ha_"};
        Map<String,Map<Integer,Matrici.HAMatrix>> MappaHA  ;
        HAMatrixFiller filler = new HAMatrixFiller();
        try {
            Connection conn=dbConnector.getConnection();
            psMatrici = conn.prepareStatement(DbConnector.INSERT_ICEHOCKEY_HA_MATRICI);
            psQuotas = conn.prepareStatement(DbConnector.GET_ICEHOCKEY_HA_ODDS);
            psNazioni = conn.prepareStatement(DbConnector.SELECT_DISTINCT_NAZIONE_ICEHOCKEY);
            psContinenti = conn.prepareStatement(DbConnector.SELECT_DISTINCT_CONTINENTE_ICEHOCKEY);
            MappaHA=filler.fillMatrixContNazOdds(psNazioni, psContinenti,psQuotas,bms);

            for (String naz:MappaHA.keySet()) {

                psMatrici.setString(1, naz);
                psMatrici.setString(2, Matrici.MapToDbHA(MappaHA.get(naz)));
                psMatrici.setString(3, Matrici.MapToDbHA(MappaHA.get(naz)));
                psMatrici.executeUpdate();
            }
        } finally {
            if (psMatrici != null) {
                psMatrici.close();
            }
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psNazioni != null) {
                psNazioni.close();
            }
            if (psContinenti != null) {
                psContinenti.close();
            }
        }
        logger.info("FillIceHockeyMatrix process end");
    }

}
