package com.kellify.loadbet.fill;

import com.kellify.common.util.BmsBySports;
import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.DbConnector;
import com.kellify.loadbet.matrixFiller.HDAMatrixFiller;
import com.kellify.loadbet.matrixFiller.HDAMatrixFillerWeight;
import org.slf4j.Logger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

public class FootballFiller {
    public static void FillFootballMatrix(DbConnector dbConnector,Logger logger) throws SQLException, IOException {
        logger.info("FillFootballMatrix process start");
        PreparedStatement psMatrici = null;
        PreparedStatement psQuotas = null;
        PreparedStatement psNazioni = null;
        PreparedStatement psContinenti = null;
        PreparedStatement psMatriciWeight=null;
        PreparedStatement psQuotasWeight=null;
        String [] bms = BmsBySports.FootballBms;
        String [] year = BmsBySports.MatchYear;
        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeFootball ;
        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeYear ;
        HDAMatrixFiller filler = new HDAMatrixFiller();
        HDAMatrixFillerWeight fillerWeight= new HDAMatrixFillerWeight();
        try {
            Connection conn=dbConnector.getConnection();
            psMatrici = conn.prepareStatement(DbConnector.INSERT_FOOT_MATRICI);
            psMatriciWeight = conn.prepareStatement(DbConnector.INSERT_FOOT_MATRICI_WEIGHT);
            psQuotas = conn.prepareStatement(DbConnector.GET_FOOT_ODDS);
            psQuotasWeight = conn.prepareStatement(DbConnector.GET_FOOT_ODDS_YEAR);
            psNazioni = conn.prepareStatement(DbConnector.SELECT_DISTINCT_NAZIONE);
            psContinenti = conn.prepareStatement(DbConnector.SELECT_DISTINCT_CONTINENTE);
            MappeFootball=filler.fillMatrixFootOdds(psNazioni, psContinenti,psQuotas,bms);
            MappeYear=fillerWeight.fillMatrixOddsWeight(psNazioni, psContinenti,psQuotasWeight,bms);

            for (String naz:MappeFootball.keySet()) {

                psMatrici.setString(1, naz);
                psMatrici.setString(2, Matrici.MapToDbHDA(MappeFootball.get(naz)));
                psMatrici.setString(3, Matrici.MapToDbHDA(MappeFootball.get(naz)));
                psMatrici.executeUpdate();
            }
            for (String naz:MappeYear.keySet()) {

                psMatriciWeight.setString(1, naz);
                psMatriciWeight.setString(2, Matrici.MapToDbHDA(MappeYear.get(naz)));
                psMatriciWeight.setString(3, Matrici.MapToDbHDA(MappeYear.get(naz)));
                psMatriciWeight.executeUpdate();
            }
        } finally {
            if (psMatrici != null) {
                psMatrici.close();
            }
            if (psMatriciWeight != null) {
                psMatriciWeight.close();
            }
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psQuotasWeight != null) {
                psQuotasWeight.close();
            }
            if (psNazioni != null) {
                psNazioni.close();
            }
            if (psContinenti != null) {
                psContinenti.close();
            }

        }
        logger.info("FillFootballMatrix process end");
    }

}
