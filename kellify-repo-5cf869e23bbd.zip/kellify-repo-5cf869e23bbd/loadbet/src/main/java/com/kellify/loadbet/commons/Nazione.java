package com.kellify.loadbet.commons;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Nazione {
    public static String getNazione(PreparedStatement ps, String fileName) throws SQLException {
        String nazione = null;
        String campionato = fileName.substring(0, fileName.indexOf("."));
        ResultSet rs = null;
        try {
            ps.setString(1, campionato.toUpperCase());
            rs = ps.executeQuery();
            if(rs.next()) {
                nazione = rs.getString(1);
            }
        } finally {
            if (rs != null) {
                rs.close();;
            }
        }
        return nazione;
    }
}
