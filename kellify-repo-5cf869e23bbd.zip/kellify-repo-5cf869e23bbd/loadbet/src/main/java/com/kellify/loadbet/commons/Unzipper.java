package com.kellify.loadbet.commons;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Unzipper {
    private static final Logger logger = LoggerFactory.getLogger(Unzipper.class);

    private final Properties config;
    private final LoadBetType type;
    private List<Path> zipFilesToProcess;

    public Unzipper(Properties config, LoadBetType type) {
        this.config = config;
        this.type = type;
        this.zipFilesToProcess = new ArrayList<Path>();
    }

    public void unzip() throws IOException {
        File[] zips = null;

        String zipFolder = null;
        String dataFolder = null;
        switch(type) {
            case FOOTBALL:
                zipFolder = config.getProperty("football.zip.folder");
                dataFolder = config.getProperty("football.data.folder");
                break;
            case TENNIS:
                zipFolder = config.getProperty("tennis.zip.folder");
                dataFolder = config.getProperty("tennis.data.folder");
                break;
        }

        logger.info("zipFolder:" + zipFolder);

        DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(zipFolder), new DirectoryStream.Filter<Path>() {
            @Override
            public boolean accept(Path entry) throws IOException
            {
                return entry.getFileName().toString().endsWith(".zip");
            }
        });
        int progressive = 0;
        for (Path entry: stream) {
            logger.info("unzip file:" + entry.getFileName());
            extractFiles(entry, dataFolder, progressive);
            //renameZipFile(entry);
            progressive++;
        }
    }

    private void extractFiles(Path fileZip, String dataFolder, int progressive) throws FileNotFoundException, IOException {
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip.toFile()));
        ZipEntry zipEntry = zis.getNextEntry();
        while(zipEntry != null){
            String fileName = zipEntry.getName();
            File newFile = new File(dataFolder + "/" + progressive + "_" + fileName);
            FileOutputStream fos = new FileOutputStream(newFile);
            int len;
            while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }

    private void renameZipFile(Path fileZip) throws IOException {
        Path renamed = Paths.get(fileZip.toAbsolutePath().toString() + ".bkp");
        Files.move(fileZip, renamed);
    }
}
