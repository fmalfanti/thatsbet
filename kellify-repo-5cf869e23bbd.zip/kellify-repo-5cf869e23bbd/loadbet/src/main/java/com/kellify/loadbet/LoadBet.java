package com.kellify.loadbet;

import com.kellify.common.util.*;

import com.kellify.loadbet.commons.*;
import com.kellify.loadbet.load.*;
import com.kellify.loadbet.fill.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.sql.*;
//import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class LoadBet {
    private static final Logger logger = LoggerFactory.getLogger(LoadBet.class);

    //private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");

    public static void main(String[] args) throws Exception {
        String CONF_FILE_PATH;

        if(args.length == 0) {
            logger.warn("Not <conf_file_path> provided, using default");
            CONF_FILE_PATH = LoadBet.class.getResource("/application.properties").getFile();
        } else {
            CONF_FILE_PATH = args[0];
            if(!new File(CONF_FILE_PATH).exists()) {
                logger.warn("Config file" + CONF_FILE_PATH + " does not exists or is not readable, using default");
                CONF_FILE_PATH = LoadBet.class.getResource("/application.properties").getFile();
            } else {
                logger.info("Config file " + CONF_FILE_PATH + " found");
            }

        }
        Properties config = new Properties();
        config.load(new FileInputStream(CONF_FILE_PATH));
        DbConnector dbConnector = new DbConnector(config);
        Connection conn = null;
        try {
            conn = dbConnector.getConnection();
            //FootballLoader.LoadFootballData(dbConnector, config);
//            TennisLoader.LoadTennisData(dbConnector, config);
//            BasketLoader.LoadBasketData(dbConnector, config);
//            BaseballLoader.LoadBaseballData(dbConnector, config);
//            IceHockeyHALoader.LoadIceHockeyHAData(dbConnector, config);
//            IceHockeyHDALoader.LoadIceHockeyHDAData(dbConnector, config);
//            AmericanFootballLoader.LoadAmericanFootballData(dbConnector, config);
            FootballLoaderUnderOver.LoadFootballData(dbConnector, config);
            FootballLoaderAsianHandicap.LoadFootballData(dbConnector, config);
//            FootballFiller.FillFootballMatrix(dbConnector,logger);
//            TennisFiller.FillTennisMatrix(dbConnector,logger);
//            BasketFiller.FillBasketMatrix(dbConnector, config,logger);
//            BaseballFiller.FillBaseballMatrix(dbConnector, config,logger);
//            AmericanFootballFiller.FillAmericanFootballMatrix(dbConnector, config,logger);
//            IceHockeyHDAFiller.FillIceHockeyHDAMatrix(dbConnector,logger);
//            IceHockeyHAFiller.FillIceHockeyHAMatrix(dbConnector, config,logger);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }



















}
