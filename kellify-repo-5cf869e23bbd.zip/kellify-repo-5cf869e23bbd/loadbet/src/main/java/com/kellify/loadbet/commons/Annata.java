package com.kellify.loadbet.commons;

import java.time.LocalDate;

public class Annata {
    private LocalDate date;
    private int JULY = 7;

    public Annata(LocalDate date) {
        this.date = date;
    }

    public String makeAnnata() {
        String annata = null;
        int prevYear = 0;
        int nextYear = 0;
        int year = date.getYear();
        int month = date.getMonth().getValue();
        prevYear = year;
        nextYear = year + 1;
        if(month < JULY) {
            prevYear = year -1;
            nextYear = year;
        }
        annata = (prevYear-2000) + "-" + (nextYear-2000);
        return annata;
    }
}
