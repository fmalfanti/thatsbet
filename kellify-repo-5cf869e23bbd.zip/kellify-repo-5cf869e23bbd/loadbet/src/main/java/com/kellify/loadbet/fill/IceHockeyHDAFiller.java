package com.kellify.loadbet.fill;

import com.kellify.common.util.BmsBySports;
import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.DbConnector;
import com.kellify.loadbet.matrixFiller.HAMatrixFiller;
import com.kellify.loadbet.matrixFiller.HDAMatrixFiller;
import org.slf4j.Logger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;

public class IceHockeyHDAFiller {
    public static void FillIceHockeyHDAMatrix(DbConnector dbConnector,Logger logger) throws SQLException, IOException {
        logger.info("FillIceHockeyMatrix process start");
        PreparedStatement psMatrici = null;
        PreparedStatement psQuotas = null;
        PreparedStatement psNazioni = null;
        PreparedStatement psContinenti = null;
        String [] bms = BmsBySports.IceHockeyHDABms;
        Map<String,Map<Integer,Matrici.HdaMatrix>> MappeFootball ;
        HDAMatrixFiller filler = new HDAMatrixFiller();
        try {
            Connection conn=dbConnector.getConnection();
            psMatrici = conn.prepareStatement(DbConnector.INSERT_ICEHOCKEY_HDA_MATRICI);
            psQuotas = conn.prepareStatement(DbConnector.GET_ICEHOCKEY_HDA_ODDS);
            psNazioni = conn.prepareStatement(DbConnector.SELECT_DISTINCT_NAZIONE_ICEHOCKEY_HDA);
            psContinenti = conn.prepareStatement(DbConnector.SELECT_DISTINCT_CONTINENTE_ICEHOCKEY_HDA);
            MappeFootball=filler.fillMatrixFootOdds(psNazioni, psContinenti,psQuotas,bms);

            for (String naz:MappeFootball.keySet()) {

                psMatrici.setString(1, naz);
                psMatrici.setString(2, Matrici.MapToDbHDA(MappeFootball.get(naz)));
                psMatrici.setString(3, Matrici.MapToDbHDA(MappeFootball.get(naz)));
                psMatrici.executeUpdate();
            }
        } finally {
            if (psMatrici != null) {
                psMatrici.close();
            }
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psNazioni != null) {
                psNazioni.close();
            }
            if (psContinenti != null) {
                psContinenti.close();
            }

        }
        logger.info("FillIceHockeyMatrix process end");
    }

}
