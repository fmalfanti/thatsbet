package com.kellify.loadbet.fill;

import com.kellify.common.util.BmsBySports;
import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.DbConnector;
import com.kellify.loadbet.matrixFiller.WLMatrixFiller;
import com.kellify.loadbet.matrixFiller.WLMatrixFillerWeight;
import org.slf4j.Logger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

public class TennisFiller {
    public static void FillTennisMatrix(DbConnector dbConnector,Logger logger) throws SQLException, IOException {
        logger.info("FillTennisMatrix process start");
        PreparedStatement psMatrici = null;
        PreparedStatement psQuotas = null;
        PreparedStatement psQuotasWeight = null;
        PreparedStatement psMatriciWeight=null;
        Map<Integer,Matrici.WLMatrix> MappaWL;
        Map<Integer,Matrici.WLMatrix> MappaWLWeight;
        String [] bms = BmsBySports.TennisBms;

        WLMatrixFiller filler = new WLMatrixFiller();
        WLMatrixFillerWeight fillerWeight = new WLMatrixFillerWeight();
        try {
            Connection conn=dbConnector.getConnection();
            psMatrici = conn.prepareStatement(DbConnector.INSERT_TENNIS_MATRICI);
            psMatriciWeight = conn.prepareStatement(DbConnector.INSERT_TENNIS_MATRICI_WEIGHT);
            psQuotas = conn.prepareStatement(DbConnector.GET_TENNIS_ODDS);
            psQuotasWeight = conn.prepareStatement(DbConnector.GET_TENNIS_ODDS_YEAR);


            MappaWL=filler.fillMatrixWLOdds(psQuotas,bms);
            MappaWLWeight=fillerWeight.fillMatrixWLOddsWeight(psQuotasWeight,bms);


            psMatrici.setString(1, "mappa");
            psMatrici.setString(2, Matrici.MapToDbWL(MappaWL));
            psMatrici.setString(3, Matrici.MapToDbWL(MappaWL));
            psMatrici.executeUpdate();

            psMatriciWeight.setString(1, "mappa");
            psMatriciWeight.setString(2, Matrici.MapToDbWL(MappaWLWeight));
            psMatriciWeight.setString(3, Matrici.MapToDbWL(MappaWLWeight));
            psMatriciWeight.executeUpdate();

        } finally {
            if (psMatrici != null) {
                psMatrici.close();
            }
            if (psQuotas != null) {
                psQuotas.close();
            }
            if (psMatriciWeight != null) {
                psMatrici.close();
            }
            if (psQuotasWeight != null) {
                psQuotas.close();
            }
        }
        logger.info("FillTennisMatrix process end");
    }

}
