package com.kellify.loadbet.load;

import com.kellify.common.util.Matrici;
import com.kellify.loadbet.commons.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Map;
import java.util.Properties;

public class FootballLoaderAsianOddsHda {
    private static final Logger logger = LoggerFactory.getLogger(FootballLoaderUnderOver.class);

    private static DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("dd/MM/yy");
    private static DateTimeFormatter formatter_2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private DateTimeFormatter parserLungo;
    private DateTimeFormatter parserCorto;

    public FootballLoaderAsianOddsHda() {
        parserCorto = new DateTimeFormatterBuilder().appendOptional(formatter_1).toFormatter();
        parserLungo = new DateTimeFormatterBuilder().appendOptional(formatter_2).toFormatter();
    }
    public int[] loadBetFootOdds(File file, String nazione, String continente, PreparedStatement psMeanProbs, PreparedStatement psMeanProbsMaxMin) throws IOException {
        int[] ret;
        Reader in = null;
        int counter = 0;
        int emptyCount = 0;
        try {
            String [] bms = {"BbMx>2.5","BbAv>2.5","BbMx<2.5","BbAv<2.5"};
            Map<String, String> dataMap;
            String dateString;
            Map<Integer,Matrici.HdaMatrix> useNationMap;
            Map<Integer,Matrici.HdaMatrix> useContinentMap;
            Map<Integer,Matrici.HdaMatrix> useWorldMap;

            in = new FileReader(file);
            Iterable<CSVRecord> records = CSVFormat.EXCEL.withHeader().parse(in);
            LocalDate dateTime;
            String Fthg ,Ftag ;
            double greaterMin, LowerMin;
            double probLowerMin, probLowerMax,probGreaterMin,probGreaterMax;
            double probAvMagg,probAvgMin;
            String AwayAvg, HomeAvg, DrawAvg;
            double probHome, probAway,probDraw;
            String HomeMax, DrawMax, AwayMax,HomeMin, DrawMin, AwayMin;
            double normUO;
            double normHAD;
            int fthg,ftag;
            String GreaterMax, GreaterAvg, LooserMax, LooserAvg;
            String underOver=null;

            for (CSVRecord record : records) {

                //System.out.println(record.toString());
                try {
                    dateString = record.get("Date");
                    if(dateString == null || dateString.length() == 0) {
                        emptyCount++;
                        continue;
                    }

                    //System.out.println(record.get("Date"));
                    if (dateString.length() == 8) {
                        dateTime = LocalDate.parse(record.get("Date"), parserCorto);
                    } else {
                        dateTime = LocalDate.parse(record.get("Date"), parserLungo);
                    }
                    //System.out.println(dateString+" "+dateTime.toString());
                    dataMap = record.toMap();
                    logger.debug("dataMap " + dataMap);
                    String campionato = dataMap.get("Div");
                    if (campionato==null) {
                        campionato = dataMap.get("League");
                    }

                    String homeTeam = dataMap.get("HomeTeam");
                    if (homeTeam==null) {
                        homeTeam = dataMap.get("HT");
                    }
                    if (homeTeam==null) {
                        homeTeam = dataMap.get("Home");
                    }
                    String awayTeam = dataMap.get("AwayTeam");
                    if (awayTeam==null) {
                        awayTeam = dataMap.get("AT");
                    }
                    if (awayTeam==null) {
                        awayTeam = dataMap.get("Away");
                    }
                    Fthg = dataMap.get("FTHG");
                    if (Fthg==null) {
                        fthg = Integer.parseInt(dataMap.get("HG"));
                    }
                    else {
                        fthg = Integer.parseInt(Fthg);
                    }
                    Ftag = dataMap.get("FTAG");
                    if (Ftag==null) {
                        ftag = Integer.parseInt(dataMap.get("AG"));
                    } else {
                        ftag = Integer.parseInt(Ftag);
                    }
                    String ftr = dataMap.get("FTR");
                    if (ftr==null) {
                        ftr = dataMap.get("Res");
                    }

                    GreaterMax = dataMap.get("BbMx>2.5");
                    GreaterMax = StringUtils.isBlank(GreaterMax) ? "-1" : GreaterMax;
                    Double bbMxGreater = Double.parseDouble(GreaterMax);

                    GreaterAvg = dataMap.get("BbAv>2.5");
                    GreaterAvg = StringUtils.isBlank(GreaterAvg) ? "-1" : GreaterAvg;
                    Double bbAvGreater = Double.parseDouble(GreaterAvg);

                    LooserMax = dataMap.get("BbMx<2.5");
                    LooserMax = StringUtils.isBlank(LooserMax) ? "-1" : LooserMax;
                    Double bbMxLower = Double.parseDouble(LooserMax);

                    LooserAvg = dataMap.get("BbAv<2.5");
                    LooserAvg = StringUtils.isBlank(LooserAvg) ? "-1" : LooserAvg;
                    Double bbAvLower = Double.parseDouble(LooserAvg);

                    HomeAvg = dataMap.get("BbAvH");
                    HomeAvg = StringUtils.isBlank(HomeAvg) ? "-1" : HomeAvg;
                    Double bbHomeAvg = Double.parseDouble(HomeAvg);

                    DrawAvg = dataMap.get("BbAvD");
                    DrawAvg = StringUtils.isBlank(DrawAvg) ? "-1" : DrawAvg;
                    Double bbDrawAvg = Double.parseDouble(DrawAvg);

                    AwayAvg = dataMap.get("BbAvA");
                    AwayAvg = StringUtils.isBlank(AwayAvg) ? "-1" : AwayAvg;
                    Double bbAwayAvg= Double.parseDouble(AwayAvg);

                    HomeMax = dataMap.get("BbMxH");
                    HomeMax = StringUtils.isBlank(HomeMax) ? "-1" : HomeMax;
                    Double bbHomeMax = Double.parseDouble(HomeMax);

                    AwayMax = dataMap.get("BbMxD");
                    AwayMax = StringUtils.isBlank(AwayMax) ? "-1" : AwayMax;
                    Double bbAwayMax = Double.parseDouble(AwayMax);

                    DrawMax = dataMap.get("BbMxA");
                    DrawMax = StringUtils.isBlank(DrawMax) ? "-1" : DrawMax;
                    Double bbDrawMax= Double.parseDouble(DrawMax);

                    Double bbHomeMin = Math.abs(2 * bbHomeAvg - bbHomeMax) ;
                    Double bbAwayMin = Math.abs(2 * bbAwayAvg -bbAwayMax) ;
                    Double bbDrawMin = Math.abs(2 * bbDrawAvg - bbDrawMax) ;
                 //   System.out.println("bbHomeMin "+ bbHomeMin+ "bbHomeAvg" + bbHomeAvg + "bbHomeMax"+ bbHomeMax  );
                  //  System.out.println( "bbAwayMin" + bbAwayMin + "bbAwayAvg" + bbAwayAvg + "bbAwayMax"+ bbAwayMax );
                  //  System.out.println("bbDrawMin"+ bbDrawMin + "bbDrawAvg" + bbDrawAvg + "bbDrawMax"+ bbDrawMax );

                    greaterMin = 2 * bbAvGreater - bbMxGreater;
                    LowerMin = 2 * bbAvLower - bbMxLower;

                    if( fthg+ftag>2 ){
                        underOver="O";
                    }
                    else { underOver="U";}

                    //System.out.println(" greaterMin "+ greaterMin + " LowerMin" + LowerMin + " bbMxGreater " + bbMxGreater + " bbMxLower " + bbMxLower);
                 /*   psQuotas.setDate(1, java.sql.Date.valueOf(dateTime));
                    psQuotas.setString(2, campionato);
                    psQuotas.setString(3, nazione);
                    psQuotas.setString(4, continente);
                    psQuotas.setString(5, homeTeam);
                    psQuotas.setString(6, awayTeam);
                    psQuotas.setInt(7, fthg);
                    psQuotas.setInt(8, ftag);
                    psQuotas.setString(9, ftr);
                    psQuotas.setString(10, underOver);
                    psQuotas.setDouble(11, bbAvGreater);
                    psQuotas.setDouble(12, bbAvLower);
                    psQuotas.setDouble(13, bbHomeAvg);
                    psQuotas.setDouble(14, bbDrawAvg);
                    psQuotas.setDouble(15, bbAwayAvg);*/

                    if (bbAvLower+bbAvGreater!=-2.0) {
                        probAvgMin = 1.0 / bbAvLower;
                        probAvMagg = 1.0 / bbAvGreater;
                        normUO=probAvgMin+probAvMagg;
                        probAvgMin /=normUO;
                        probAvMagg/=normUO;

                        probHome = 1.0 / bbHomeAvg;
                        probDraw= 1.0 / bbDrawAvg;
                        probAway = 1.0 / bbAwayAvg;
                        normHAD=probHome+probDraw+probAway;
                        probHome/=normHAD;
                        probDraw/=normHAD;
                        probAway/=normHAD;

                        psMeanProbs.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbs.setString(2, campionato);
                        psMeanProbs.setString(3, nazione);
                        psMeanProbs.setString(4, continente);
                        psMeanProbs.setString(5, homeTeam);
                        psMeanProbs.setString(6, awayTeam);
                        psMeanProbs.setInt(7, fthg);
                        psMeanProbs.setInt(8, ftag);
                        psMeanProbs.setString(9, ftr);
                        psMeanProbs.setString(10, underOver);
                        psMeanProbs.setDouble(11, probAvgMin);
                        psMeanProbs.setDouble(12, probAvMagg);
                        psMeanProbs.setDouble(13, probHome);
                        psMeanProbs.setDouble(14, probDraw);
                        psMeanProbs.setDouble(15, probAway);
                        psMeanProbs.executeUpdate();

                        probLowerMin = 1.0 / bbMxLower;
                        probLowerMax= 1.0 / LowerMin;
                        normUO=probLowerMin+probLowerMax;
                        probLowerMin /= normUO;
                        probLowerMax /= normUO;

                        probGreaterMin = 1.0 / bbMxGreater;
                        probGreaterMax= 1.0/ greaterMin;
                        normUO=probGreaterMin+probGreaterMax;
                        probGreaterMin /= normUO;
                        probGreaterMax /= normUO;

                        bbHomeMin = 1.0 / bbHomeMin;
                        bbAwayMin = 1.0 / bbAwayMin;
                        bbDrawMin= 1.0 / bbDrawMin;
                        normHAD=bbHomeMin+bbAwayMin+bbDrawMin;
                        bbHomeMin /= normHAD;
                        bbAwayMin /= normHAD;
                        bbDrawMin /= normHAD;

                        bbHomeMax = 1.0 / bbHomeMax;
                        bbAwayMax = 1.0 / bbAwayMax;
                        bbDrawMax= 1.0 / bbDrawMax;
                        normHAD=bbHomeMax+bbAwayMax+bbDrawMax;
                        bbHomeMax /= normHAD;
                        bbAwayMax /= normHAD;
                        bbDrawMax /= normHAD;

                        psMeanProbsMaxMin.setDate(1, java.sql.Date.valueOf(dateTime));
                        psMeanProbsMaxMin.setString(2, campionato);
                        psMeanProbsMaxMin.setString(3, nazione);
                        psMeanProbsMaxMin.setString(4, continente);
                        psMeanProbsMaxMin.setString(5, homeTeam);
                        psMeanProbsMaxMin.setString(6, awayTeam);
                        psMeanProbsMaxMin.setInt(7, fthg);
                        psMeanProbsMaxMin.setInt(8, ftag);
                        psMeanProbsMaxMin.setString(9, ftr);
                        psMeanProbsMaxMin.setString(10, underOver);
                        psMeanProbsMaxMin.setDouble(11, probGreaterMin);
                        psMeanProbsMaxMin.setDouble(12, probAvMagg);
                        psMeanProbsMaxMin.setDouble(13, probGreaterMax);
                        psMeanProbsMaxMin.setDouble(14, probLowerMin);
                        psMeanProbsMaxMin.setDouble(15, probAvgMin);
                        psMeanProbsMaxMin.setDouble(16, probLowerMax);
                        psMeanProbsMaxMin.setDouble(17, bbAwayMax);
                        psMeanProbsMaxMin.setDouble(18, bbAwayAvg);
                        psMeanProbsMaxMin.setDouble(19, bbAwayMin);
                        psMeanProbsMaxMin.setDouble(20, bbDrawMax);
                        psMeanProbsMaxMin.setDouble(21, bbDrawAvg);
                        psMeanProbsMaxMin.setDouble(22, bbDrawMin);
                        psMeanProbsMaxMin.setDouble(23, bbHomeMax);
                        psMeanProbsMaxMin.setDouble(24, bbHomeAvg);
                        psMeanProbsMaxMin.setDouble(25, bbHomeMin);
                        psMeanProbsMaxMin.executeUpdate();
                    }
                    counter++;

                } catch(Exception ex) {
                    logger.error("record:" + record.toString(), ex);

                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if(in != null) {
                in.close();
            }
        }
        ret = new int[] {counter,  emptyCount};
        return ret;
    }

    public static void LoadFootballData(DbConnector dbConnector, Properties config) throws SQLException, IOException {
        logger.info("LoadFootballDataUnderOver process start");
        Unzipper unzipper = new Unzipper(config, LoadBetType.FOOTBALL);
        unzipper.unzip();

        File folder = new File(config.getProperty("football.data.folder"));
        PreparedStatement psQuotas = null;
        PreparedStatement psMeanProbsMaxMin = null;
        PreparedStatement psNazione = null;
        PreparedStatement psMeanProbs = null;
        PreparedStatement psContinente = null;
        File[] files = folder.listFiles();
        int counter = 0;
        int emptyCounter = 0;
        FootballLoaderAsianOddsHda loader = new FootballLoaderAsianOddsHda();
        String fileName;

        try {
            Connection conn=dbConnector.getConnection();
            //psQuotas = conn.prepareStatement(DbConnector.INSERT_FOOT_ODDS_UNDER_OVER);
            psMeanProbs = conn.prepareStatement(DbConnector.INSERT_BET_FOOTBALL_CLUSTERS_UO_HDA);
            psMeanProbsMaxMin = conn.prepareStatement(DbConnector.INSERT_PROB_FOOTBALL_CLUSTERS_UO_HDA);
            psNazione = conn.prepareStatement(DbConnector.SELECT_NAZIONE);
            psContinente = conn.prepareStatement(DbConnector.SELECT_CONTINENTE);

            for (File f : files) {
                try {
                    fileName = f.getName();
                    String nazione = Nazione.getNazione(psNazione, fileName.substring(fileName.indexOf("_")+1));
                    String continente = Continente.getContinente(psContinente, fileName.substring(fileName.indexOf("_")+1));
                    logger.info("file:" + f.getName() + ", nazione:" + nazione+", continente:" + continente);
                    int localCounter[] =  loader.loadBetFootOdds(f, nazione, continente,psMeanProbs,psMeanProbsMaxMin);

                    logger.info("file rows:" + localCounter[0] + ", file empty rows:" + localCounter[1]);
                    counter += localCounter[0];
                    emptyCounter += localCounter[1];
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                } finally {
                    f.delete();
                }
            }

            logger.info("total rows:" + counter + ", total empty rows:" + emptyCounter);
        } finally {
            if (psMeanProbsMaxMin != null) {
                psMeanProbsMaxMin.close();
            }
            if (psNazione != null) {
                psNazione.close();
            }
            if (psMeanProbs != null) {
                psMeanProbs.close();
            }
            if (psContinente != null) {
                psContinente.close();
            }
        }
        logger.info("LoadFootballDataUnderOver process end");
    }
}
