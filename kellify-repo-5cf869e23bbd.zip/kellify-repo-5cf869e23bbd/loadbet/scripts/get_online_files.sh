#!/bin/sh
# football
FOOTBALL_ZIP_DIR='/opt/betbrain/loadbetfootballzips'
FOOTBALL_FILES_DIR='/opt/betbrain/loadbetfootballfiles'
wget --output-document=$FOOTBALL_ZIP_DIR/2017.zip http://www.football-data.co.uk/mmz4281/1718/data.zip
wget --output-document=$FOOTBALL_FILES_DIR/ARG.csv http://www.football-data.co.uk/new/ARG.csv
wget --output-document=$FOOTBALL_FILES_DIR/AUT.csv http://www.football-data.co.uk/new/AUT.csv
wget --output-document=$FOOTBALL_FILES_DIR/BRA.csv http://www.football-data.co.uk/new/BRA.csv
wget --output-document=$FOOTBALL_FILES_DIR/CHN.csv http://www.football-data.co.uk/new/CHN.csv
wget --output-document=$FOOTBALL_FILES_DIR/DNK.csv http://www.football-data.co.uk/new/DNK.csv
wget --output-document=$FOOTBALL_FILES_DIR/FIN.csv http://www.football-data.co.uk/new/FIN.csv
wget --output-document=$FOOTBALL_FILES_DIR/IRL.csv http://www.football-data.co.uk/new/IRL.csv
wget --output-document=$FOOTBALL_FILES_DIR/JPN.csv http://www.football-data.co.uk/new/JPN.csv
wget --output-document=$FOOTBALL_FILES_DIR/MEX.csv http://www.football-data.co.uk/new/MEX.csv
wget --output-document=$FOOTBALL_FILES_DIR/NOR.csv http://www.football-data.co.uk/new/NOR.csv
wget --output-document=$FOOTBALL_FILES_DIR/POL.csv http://www.football-data.co.uk/new/POL.csv
wget --output-document=$FOOTBALL_FILES_DIR/ROU.csv http://www.football-data.co.uk/new/ROU.csv
wget --output-document=$FOOTBALL_FILES_DIR/RUS.csv http://www.football-data.co.uk/new/RUS.csv
wget --output-document=$FOOTBALL_FILES_DIR/SWE.csv http://www.football-data.co.uk/new/SWE.csv
wget --output-document=$FOOTBALL_FILES_DIR/SWZ.csv http://www.football-data.co.uk/new/SWZ.csv
wget --output-document=$FOOTBALL_FILES_DIR/USA.csv http://www.football-data.co.uk/new/USA.csv
# tennis
TENNIS_ZIP_DIR='/opt/betbrain/loadbettenniszips'
wget --output-document=$TENNIS_ZIP_DIR/m_2017.zip http://www.tennis-data.co.uk/2017/2017.zip
wget --output-document=$TENNIS_ZIP_DIR/w_2017.zip http://www.tennis-data.co.uk/2017w/2017zip