source /root/projects/ubibetter/ubipy/env/bin/activate
ipython /root/projects/ubibetter/ubipy/scripts/icehockey/python/update_forecast.py
deactivate
