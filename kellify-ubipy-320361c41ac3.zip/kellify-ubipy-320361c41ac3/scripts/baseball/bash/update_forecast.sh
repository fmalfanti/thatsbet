source /root/projects/ubibetter/ubipy/env/bin/activate
ipython /root/projects/ubibetter/ubipy/scripts/baseball/python/update_forecast.py
deactivate
