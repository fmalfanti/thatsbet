from betting_kings.utils.db.execute_list_of_queries import execute_list_of_queries
from betting_kings.config.queries import update_forec, clear_old_forec
from bookmakers.manager.data_manager import data_manager as bkmr_dm
from betbrain.utils.db.read_query_as_df import read_query_as_df
from betbrain.config.queries import query_tennis_insert
from betbrain.manager.data_manager import data_manager
from betting_kings.config.database import Tables as BKTables
from betbrain.config.database import Tables
import pandas as pd

def update_records(df):
    if isinstance(df, pd.DataFrame):
        df['home_team'] = df['home_team'].str.replace("'", r"\'")
        df['away_team'] = df['away_team'].str.replace("'", r"\'")
        df['championship'] = df['championship'].str.replace("'", r"\'")
        df['country'] = df['country'].str.replace("'", r"\'")

        df[['pa', 'ph', 'pba', 'pbh']] = (df[['pa', 'ph', 'pba', 'pbh']] * 100).round(0)

        dictin = {'reftable': BKTables['tennis_fraction']}
        qlist  = [clear_old_forec.format(**dictin)]
        qlist += [update_forec.format(**{**dictin, **row.to_dict()})
                  for _, row in df.iterrows()]
        execute_list_of_queries(qlist)

def get_bookmaker_id(x, bmap): return bmap.loc[x['bkms']].bookmaker_id

def get_complete_data(df):
    outlist = []
    for _, row in df.reset_index().iterrows():
        try:
            dictin = {**{'reftable':Tables['TennisOdds']}, **row.to_dict()}
            query  = query_tennis_insert.format(**dictin)
            outlist.append(read_query_as_df(query))
        except:
            pass
    return pd.concat(outlist, axis=0)

def get_forecast(min_odd_cutoff=1.75):
    dm = data_manager(sport='Tennis')

    frac = dm.kelly_frac
    frac = frac[frac.sum(axis=1) > 0]
    frac = frac.rename(columns={0:'f0', 1:'f1'})

    bpro = dm.last_prob['last_prob'].rename(columns={0:'pb0', 1:'pb1'})
    bodd = dm.last_odds['last_odds'].rename(columns={0:'od0', 1:'od1'})
    prob = dm.ubi_prob['ubibet'].rename(columns={0:'p0', 1:'p1'})

    out = pd.concat([frac, prob, bpro, bodd], axis=1, join='inner')
    selection0 = (out.f0 > 0) & (out.od0 >= min_odd_cutoff)
    selection1 = (out.f1 > 0) & (out.od1 >= min_odd_cutoff)

    return out[selection0 | selection1]

def format_forec(x):
    if x['home_odds'] >= x['away_odds']:
         npattern = {'p0':'ph', 'p1':'pa',
                     'pb0':'pbh', 'pb1':'pba',
                     'f0':'fh', 'f1':'fa'}
    elif x.loc['home_odds'] < x.loc['away_odds']:
         npattern = {'p1':'ph', 'p0':'pa',
                     'pb1':'pbh', 'pb0':'pba',
                     'f1':'fh', 'f0':'fa'}
    return x[['p1', 'p0', 'pb1', 'pb0', 'f1', 'f0']].rename(index=npattern)

def format_forec_on_consensus(x):
    if x['favourite'] == 'Away':
         npattern = {'p0':'ph', 'p1':'pa',
                     'pb0':'pbh', 'pb1':'pba',
                     'f0':'fh', 'f1':'fa'}
    elif x['favourite'] == 'Home':
         npattern = {'p1':'ph', 'p0':'pa',
                     'pb1':'pbh', 'pb0':'pba',
                     'f1':'fh', 'f0':'fa'}
    return x[['p1', 'p0', 'pb1', 'pb0', 'f1', 'f0']].rename(index=npattern)

def get_favourite(data, index_names):
    funct = lambda x: sum(x['home_odds'] < x['away_odds']) / len(x)
    consensus = data.groupby(by=index_names).apply(funct)
    funct = lambda x: 'Home' if x > 0.5 else 'Away' if x < 0.5 else None
    favourite = consensus.apply(funct)
    return pd.concat([consensus.rename('consensus'),
                      favourite.rename('favourite')], axis=1)

def get_updates():
    index_names = ['match_date','home_team','away_team','bkms']
    fore = get_forecast()
    fore.index = fore.index.rename(index_names)
    if isinstance(fore, pd.DataFrame):
        data = get_complete_data(fore)
        data = data.merge(get_favourite(data, index_names),
                          left_on=index_names, right_index=True,)

        data = data.merge(fore, left_on=index_names, right_index=True,)
        pred = data.apply(lambda x: format_forec_on_consensus(x), axis=1)

        data = pd.concat([data.drop(['p0', 'p1', 'f0', 'f1'], 1), pred], axis=1)
        data['bookmaker_id'] = data.apply(get_bookmaker_id, axis=1,
                                          args=[bkmr_dm().bookmakers_map])
        return data[data.favourite.isna() == False]
    else:
        return None

def main(): update_records(get_updates())

if __name__ == '__main__':
    main()
