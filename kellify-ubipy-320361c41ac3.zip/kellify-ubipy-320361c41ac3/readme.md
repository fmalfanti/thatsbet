### DOCKER build COMMAND

docker build --tag ubibetter-fraction-maker .


### CRONTAB scheduling COMMAND

0 * * * * docker run -d --rm ubibetter-fraction-maker python /ubipy/scripts/tennis/python/update_forecast.py

3 * * * * docker run -d --rm ubibetter-fraction-maker python /ubipy/scripts/baseball/python/update_forecast.py

4 * * * * docker run -d --rm ubibetter-fraction-maker python /ubipy/scripts/basket/python/update_forecast.py

5 * * * * docker run -d --rm ubibetter-fraction-maker python /ubipy/scripts/icehockey/python/update_forecast.py
