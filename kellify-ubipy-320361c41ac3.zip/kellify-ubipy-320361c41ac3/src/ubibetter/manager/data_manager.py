from ubibetter.manager.manager_utils.ftr_functions import ftr_functions
from ubibetter.manager.manager_utils.format_data import format_data
from ubibetter.models.compute_matrix import compute_matrix
from ubibetter.config.database import Tables
import pandas as pd

class data_manager(format_data, compute_matrix):

    def __init__(self, sport=None):
        self.ftr_fucntions = ftr_functions()
        if sport == 'Tennis':           self.__init__tennis__()
        if sport == 'Football':         self.__init__football__()
        if sport == 'Basket':           self.__init__basket__()
        if sport == 'Baseball':         self.__init__baseball__()
        if sport == 'AmericanFootball': self.__init__american_football__()
        if sport == 'Icehockey':        self.__init__icehockey__()
        if sport == 'Football_uo':      self.__init__football__uo()
        pass

    def __init__football__(self):
        from ubibetter.config.fields.football import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None#("SELECT * FROM {football_prob} order by MatchDate;").format(**Tables)
        self.odds_query = ("SELECT * FROM {football_odds} order by MatchDate;").format(**Tables)
        self.camp_query = ("SELECT MatchDate, HomeTeam, AwayTeam, Campionato "+
                           "FROM {football_odds} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_football

    def __init__tennis__(self):
        from ubibetter.config.fields.tennis import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None#("SELECT * FROM {tennis_prob} order by MatchDate;").format(**Tables)
        self.odds_query = ("SELECT * FROM {tennis_odds} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_tennis

    def __init__basket__(self):
        from ubibetter.config.fields.basket import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = ("SELECT * FROM {basket_prob} order by MatchDate;").format(**Tables)
        self.odds_query = ("SELECT * FROM {basket_odds} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_basket

    def __init__baseball__(self):
        from ubibetter.config.fields.baseball import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = ("SELECT * FROM {baseball_prob} order by MatchDate;").format(**Tables)
        self.odds_query = ("SELECT * FROM {baseball_odds} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_baseball

    def __init__american_football__(self):
        from ubibetter.config.fields.afootball import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None
        self.odds_query = ("SELECT * FROM {afootball_odds} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_americanfootball

    def __init__icehockey__(self):
        from ubibetter.config.fields.icehockey import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None
        self.odds_query = ("SELECT * FROM {icehockey_odds} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_icehockey

    def __init__football__uo(self):
        from ubibetter.config.fields.football import index_list, bookmakers_uo
        self.index_list = index_list
        self.bookmakers = bookmakers_uo
        self.prob_query = None  # ("SELECT * FROM {football_prob} order by MatchDate;").format(**Tables)
        self.odds_query = ("SELECT * FROM {football_odds_uo} order by MatchDate;").format(**Tables)
        self.camp_query = ("SELECT MatchDate, HomeTeam, AwayTeam, Campionato " +
                           "FROM {football_odds_uo} order by MatchDate;").format(**Tables)
        self.ftr = self.ftr_fucntions.ftr_football_uo

    @property
    def data_complete(self):
        data = self.data.reset_index(level=3).rename(columns={'level_3':'bkms'})
        ftr  = self.ftr()
        ftr.columns = pd.MultiIndex.from_tuples([(c, '') for c in ftr.columns])
        return data.merge(ftr, right_index=True, left_index=True)
