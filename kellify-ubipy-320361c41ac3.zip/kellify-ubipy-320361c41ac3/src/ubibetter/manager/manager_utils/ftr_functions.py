from ubibetter.manager.manager_utils.format_data import format_data
from ubibetter.utils.db.read_query_as_df import read_query_as_df
from ubibetter.config.database import Tables
import pandas as pd

class ftr_functions(format_data):

    def __init_football__(self):
        from ubibetter.config.fields.football import index_list
        self.index_list = index_list

    def __init_basket__(self):
        from ubibetter.config.fields.basket import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None
        self.odds_query = ("SELECT * FROM {basket_odds} order by MatchDate;").format(**Tables)

    def __init_baseball__(self):
        from ubibetter.config.fields.baseball import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None
        self.odds_query = ("SELECT * FROM {baseball_odds} order by MatchDate;").format(**Tables)

    def __init_american_football__(self):
        from ubibetter.config.fields.afootball import index_list
        self.index_list = index_list
        self.bookmakers = bookmakers

    def __init_icehockey__(self):
        from ubibetter.config.fields.icehockey import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None
        self.odds_query = ("SELECT * FROM {icehockey_odds} order by MatchDate;").format(**Tables)

    def __init_tennis__(self):
        from ubibetter.config.fields.tennis import index_list, bookmakers
        self.index_list = index_list
        self.bookmakers = bookmakers
        self.prob_query = None#"SELECT * FROM {tennis_prob};".format(**Tables)
        self.odds_query = ("SELECT * FROM {tennis_odds} order by MatchDate;").format(**Tables)

    def ftr_football(self):
        self.__init_football__()
        ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, FTR " +
                      "FROM {football_odds};").format(**Tables)
        ftr = read_query_as_df(ftr_query, chunk=10000)
        return self.__set_index__(ftr)

    def ftr_football_uo(self):
        self.__init_football__()
        ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, `U/O` as FTR " +
                      "FROM {football_odds_uo};").format(**Tables)
        ftr = read_query_as_df(ftr_query, chunk=10000)
        return self.__set_index__(ftr)


    def ftr_tennis(self):
        self.__init_tennis__()
        probs = self.probs.prob.idxmax(axis=1)
        probs = probs.groupby(level=[0,1,2]).value_counts().unstack(level=3)
        probs['FTR']  = probs[probs.L != probs.W].idxmax(axis=1)
        probs['FTR']  = probs['FTR'].apply(lambda x: int(x == 'W'))
        #probs['Tot'] = probs[probs.L != probs.W].sum(axis=1)
        return probs[['FTR']].dropna(axis=0)

    def ftr_basket(self):
        self.__init_basket__()
        ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, FTR " +
                      "FROM {basket_odds};").format(**Tables)
        ftr = read_query_as_df(ftr_query, chunk=10000)
        ftr = self.__set_index__(ftr)

        ## get PROBS
        probs = self.probs.prob.idxmax(axis=1)
        probs = probs.groupby(level=[0,1,2]).value_counts().unstack(level=3)
        probs = probs.idxmax(axis=1).rename('PTR').to_frame()
        probs = pd.concat([probs, ftr], axis=1, join='inner')

        return (probs.PTR == probs.FTR).astype(int).to_frame()


    # def ftr_baseball(self):
    #     self.__init_baseball__()
    #     ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, FTR " +
    #                   "FROM {baseball_odds};").format(**Tables)
    #     ftr = read_query_as_df(ftr_query, chunk=10000)
    #     return self.__set_index__(ftr)

    def ftr_baseball(self):
        self.__init_baseball__()
        ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, FTR " +
                      "FROM {baseball_odds};").format(**Tables)
        ftr = read_query_as_df(ftr_query, chunk=10000)
        ftr = self.__set_index__(ftr)

        ## get PROBS
        probs = self.probs.prob.idxmax(axis=1)
        probs = probs.groupby(level=[0,1,2]).value_counts().unstack(level=3)
        probs = probs.idxmax(axis=1).rename('PTR').to_frame()
        probs = pd.concat([probs, ftr], axis=1, join='inner')

        return (probs.PTR == probs.FTR).astype(int).to_frame()


    def ftr_americanfootball(self):
        self.__init_american_football__()
        ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, FTR " +
                      "FROM {afootball_odds};").format(**Tables)
        ftr = read_query_as_df(ftr_query, chunk=10000)
        return self.__set_index__(ftr)

    def ftr_icehockey(self):
        self.__init_icehockey__()
        ## get FTR
        ftr_query  = ("SELECT MatchDate, HomeTeam, AwayTeam, FTR " +
                      "FROM {icehockey_odds};").format(**Tables)
        ftr = read_query_as_df(ftr_query, chunk=10000)
        ftr = self.__set_index__(ftr)

        ## get PROBS
        probs = self.probs.prob.idxmax(axis=1)
        probs = probs.groupby(level=[0,1,2]).value_counts().unstack(level=3)
        probs = probs.idxmax(axis=1).rename('PTR').to_frame()
        probs = pd.concat([probs, ftr], axis=1, join='inner')

        return (probs.PTR == probs.FTR).astype(int).to_frame()
