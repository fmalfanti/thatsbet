from ubibetter.utils.db.read_query_as_df import read_query_as_df
import pandas as pd

class format_data():

    def __set_index__(self, df): return df.set_index(self.index_list)

    def __rename_bkrs__(self, df, field):
        new_names = [(field, c[:-1], c[-1].upper()) for c in self.bookmakers]
        df.columns = pd.MultiIndex.from_tuples(new_names)
        return df

    def __check_validity__(self, df): return df[(df != -1).all(axis=1)]

    def format_dataframe(self, df, field='prob'):
        df = self.__set_index__(df)
        df = self.__rename_bkrs__(df[self.bookmakers], field)
        df = self.__check_validity__(df.stack(level=1))
        return df

    def compute_probs(self, df):
        inverse = 1 / df['odds']
        probs = inverse.divide(inverse.sum(axis=1), axis=0)
        new_cols = [('prob', c) for c in probs.columns]
        probs.columns = pd.MultiIndex.from_tuples(new_cols)
        return probs.round(2)

    def compute_books(self, df):
        out = ((1 / df['odds']).sum(axis=1) - 1).to_frame()
        out.columns = pd.MultiIndex.from_tuples([('books', '')])
        return out.round(2)

    @property
    def campionato(self):
        camp = read_query_as_df(self.camp_query)
        camp = self.__set_index__(camp)
        return camp

    @property
    def probs(self):
        if self.prob_query:
            probs = read_query_as_df(self.prob_query)
            return self.format_dataframe(probs, field='prob')
        else:
            return self.compute_probs(self.odds)

    @property
    def odds(self):
        odds = read_query_as_df(self.odds_query)
        odds = self.format_dataframe(odds, field='odds')
        return odds[(odds > 1).all(axis=1)]

    @property
    def books(self): return self.compute_books(self.odds)

    @property
    def data(self):
        return pd.concat([self.probs, self.odds, self.books],
                          axis=1, join='inner')
