from itertools import product
import numpy as np

def get_passetti(coord, passo=0.01):
    deltas  = product([-2*passo, -passo , 0, passo, 2*passo], repeat=2)
    pvicini = [(np.round(coord[0] + i, decimals=2),
                np.round(coord[1] + j, decimals=2)) for i, j in deltas]
    if (not np.isnan(pvicini[0][0])) and (not np.isnan(pvicini[0][1])):
        return pvicini

def get_neighbours(x):
    return get_passetti((x[x.index[0]], x[x.index[1]]))


