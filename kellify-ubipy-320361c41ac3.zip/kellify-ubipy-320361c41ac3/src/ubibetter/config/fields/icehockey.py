index_list     = [ "MatchDate", "HomeTeam", "AwayTeam" ]
bookmakers     = ['matchbook_op_ha_h','matchbook_op_ha_a',
                  'tonybet_op_ha_h','tonybet_op_ha_a',
                  '10bet_op_ha_a','10bet_op_ha_h',
                  'marathon_op_ha_a','marathon_op_ha_h',
                  '5dimes_op_ha_a','5dimes_op_ha_h',
                  'pinnacle_op_ha_a','pinnacle_op_ha_h',
                  'bet365_op_ha_a','bet365_op_ha_h',
                  'bwin_op_ha_a','bwin_op_ha_h',
                  'unibet_op_ha_a','unibet_op_ha_h']
