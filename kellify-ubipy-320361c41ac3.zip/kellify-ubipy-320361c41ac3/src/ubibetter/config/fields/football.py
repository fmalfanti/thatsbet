index_list     = [ "MatchDate", "HomeTeam", "AwayTeam" ]
bookmakers     = ['B365A', 'B365D', 'B365H',
                  'BSA', 'BSD', 'BSH',
                  'BWA', 'BWD', 'BWH',
                  'GBA', 'GBD', 'GBH',
                  'IWA','IWD', 'IWH',
                  'LBA', 'LBD', 'LBH',
                  #'PSCA', 'PSCD', 'PSCH', # Pinnacle Closure
                  'PSA', 'PSD', 'PSH',
                  'SBA', 'SBD', 'SBH',
                  'SJA', 'SJD', 'SJH',
                  #'SOA', 'SOD', 'SOH',
                  #'SYA', 'SYD', 'SYH',
                  'VCA', 'VCD', 'VCH',
                  'WHA', 'WHD', 'WHH']

bookmakers_uo     = ['BbAv>2.5', 'BbAv<2.5',
                  'B365>2.5', 'B365<2.5',
                  'Avg>2.5', 'Avg<2.5',
                  'GB>2.5', 'GB<2.5',
                  'P>2.5','P<2.5']
