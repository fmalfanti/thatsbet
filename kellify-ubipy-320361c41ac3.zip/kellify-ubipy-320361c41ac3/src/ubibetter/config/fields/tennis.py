index_list     = [ "MatchDate", "Winner", "Loser"]
bookmakers     = ['B365W', 'B365L',
                  'EXW', 'EXL',
                  'LBW', 'LBL',
                  'PSW', 'PSL',
                  'SJW', 'SJL',
                  'UBW', 'UBL',
                  'IWW', 'IWL',
                  'CBW', 'CBL',
                  'SBW', 'SBL',
                  'BEWW', 'BEWL',
                  'GBW', 'GBL']
