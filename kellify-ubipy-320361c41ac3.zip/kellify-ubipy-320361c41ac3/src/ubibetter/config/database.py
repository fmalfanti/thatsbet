config = {
            'user': 'ubibetter',
            'password': 'R0t0l0n!',
            'host': 'sweden.kellify.com',
            'database': 'ubibetter',
            'raise_on_warnings': True,
          }

Tables = {'tennis_prob':'tennis_history_probabilities',
          'tennis_odds':'tennis_history_odds',
          'football_prob':'football_history_probabilities',
          'football_odds':'football_history_odds',
          'football_odds_uo':'football_history_odds_under_over',
          'basket_prob':'basket_history_probabilities',
          'basket_odds':'basket_history_odds',
          'baseball_prob':'baseball_history_probabilities',
          'baseball_odds':'baseball_history_odds',
          'afootball_odds':'americanfootball_history_odds',
          'icehockey_odds':'icehockey_ha_history_odds'
          }
