import cvxpy as cvx
import pandas as pd

def compute_fraction(df):

    indices      = df.index.get_level_values(4)
    indices_name = df.index.names

    df = df.reset_index()

    f = cvx.Variable(len(df), nonneg=True)
    objective = cvx.sum([(row.prob * cvx.log(1 + (f[i] * (row.odd - 1)))) +
                         ((1 - row.prob) * cvx.log(1 - f[i]))
                         for i, row in df.iterrows()])

    objective = cvx.Maximize(objective)
    prob = cvx.Problem(objective)

    try:
        result = prob.solve()
        out = pd.Series({k:v for k, v in zip(indices, f.value)})
    except:
        out = pd.Series({k:v for k, v in zip(indices, [0]*len(df))})
    #out.index = out.index.rename(indices_name)
    return out

# def compute_fraction(df):
#     df = df.reset_index()
#     f = cvx.Variable(len(df), nonneg=True)
#     indices   = [row.level_4 for i, row in df.iterrows()]
#     objective = cvx.sum([(row.prob * cvx.log(1 + (f[i] * (row.odd - 1)))) +
#                          ((1 - row.prob) * cvx.log(1 - f[i]))
#                          for i, row in df.iterrows()])
#     objective = cvx.Maximize(objective)
#     prob = cvx.Problem(objective)
#     try:
#         result = prob.solve()
#         return pd.Series({k:v for k, v in zip(indices, f.value)})
#     except:
#         return pd.Series({k:v for k, v in zip(indices, [0]*len(df))})
