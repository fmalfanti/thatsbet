import pandas as pd

class compute_matrix():

    def get_matrix(self, df, fields=[('probs', 'A'), ('probs', 'H'), 'FTR']):
        matrix = df.groupby(by=fields).count()
        matrix = matrix[matrix.columns[0]].squeeze().rename('freq')
        return matrix.unstack(level=2).fillna(0)

    def __compute_probs__(self, x, matrix):

        index = matrix.index.get_level_values(2).unique()
        empty = pd.Series(data=[0]*len(index), index=index).rename('FTR')

        if x.name[3] in matrix.columns:
            mm = matrix[x.name[3]].unstack(level=2).dropna(axis=0)

            mod_indx_set = set(mm.index)
            row_indx_set = set(x['NN'])
            index = list(mod_indx_set.intersection(row_indx_set))
            if len(index)>0:
                aux = mm.loc[index].sum(axis=0)
                norm = aux.sum()
                return aux / norm
            else:
                return empty
        else:
            return empty

    def __compute_probs_avg__(self, x, matrix):
        empty = pd.Series(data=[0]*len(matrix.columns), index=matrix.columns).rename('FTR')
        mod_indx_set = set(matrix.index)
        row_indx_set = set(x['NN'])
        index = list(mod_indx_set.intersection(row_indx_set))
        if len(index)>0:
            aux = matrix.loc[index].sum(axis=0)
            norm = aux.sum()
            return aux / norm
        else:
            return empty
