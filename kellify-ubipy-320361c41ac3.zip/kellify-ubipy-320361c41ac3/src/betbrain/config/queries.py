query = (
            "SELECT  a.date, a.participantName as Home, "+
            "b.participantName as Away, a.bookmaker as bkms, "+
            "a.odds as H, b.odds as A FROM "+
            "{reftable} as a INNER JOIN {reftable} as b " +
            "ON a.eventId=b.eventId and a.providerId=b.providerId "+
            "WHERE a.role='Home' and b.role='Away' and "+
            "a.bookmaker!='Matchbook';"
        )

query_football = (
            "SELECT     "+
            "   a.DATE, "+
            "	a.participantName AS Home, "+
            "	b.participantName AS Away, "+
            "	a.bookmaker AS bkms, "+
            "	a.odds AS H, "+
            "	c.odds AS D, "+
            "	b.odds AS A  "+
            " FROM "+
            "	(SELECT * FROM {reftable}) AS a, "+
            "	(SELECT * FROM {reftable}) AS b, "+
            "	(SELECT * FROM {reftable}) AS c "+
            " where  "+
            "	a.eventId = b.eventId AND "+
            "	a.providerId = b.providerId AND "+
            "	c.eventId = b.eventId AND "+
            "	c.providerId = b.providerId AND "+
            "	c.role = 'Draw' AND "+
            "	a.role = 'Home' AND "+
            "	b.role = 'Away' AND  "+
            "	a.bookmaker != 'Matchbook'; "
        )

# query_current = (
#                     "SELECT  a.date, a.participantName as Home, "+
#                     "b.participantName as Away, a.bookmaker as bkms, "+
#                     "a.odds as H, b.odds as A FROM "+
#                     "{reftable} as a INNER JOIN {reftable} as b " +
#                     "ON a.eventId=b.eventId and a.providerId=b.providerId "+
#                     "WHERE a.role='Home' and b.role='Away' and "+
#                     "a.bookmaker!='Matchbook';"
#                 )

# query_first  = (
#                     "SELECT  a.date, a.participantName as Home, "+
#                     "b.participantName as Away, a.bookmaker as bkms, "+
#                     "a.odds as H, b.odds as A FROM "+
#                     "{reftable} as a INNER JOIN {reftable} as b " +
#                     "ON a.eventId=b.eventId and a.providerId=b.providerId "+
#                     "WHERE a.role='Home' and b.role='Away' and "+
#                     "a.bookmaker!='Matchbook';"
#                )


# query_current_football = (
#                     "SELECT     "+
#                     "   a.DATE, "+
#                     "	a.participantName AS Home, "+
#                     "	b.participantName AS Away, "+
#                     "	a.bookmaker AS bkms, "+
#                     "	a.odds AS H, "+
#                     "	c.odds AS D, "+
#                     "	b.odds AS A  "+
#                     " FROM "+
#                     "	(SELECT * FROM {reftable}) AS a, "+
#                     "	(SELECT * FROM {reftable}) AS b, "+
#                     "	(SELECT * FROM {reftable}) AS c "+
#                     " where  "+
#                     "	a.eventId = b.eventId AND "+
#                     "	a.providerId = b.providerId AND "+
#                     "	c.eventId = b.eventId AND "+
#                     "	c.providerId = b.providerId AND "+
#                     "	c.role = 'Draw' AND "+
#                     "	a.role = 'Home' AND "+
#                     "	b.role = 'Away' AND  "+
#                     "	a.bookmaker != 'Matchbook'; "
#                      )

# query_first_football = (
#                     "SELECT     "+
#                     "   a.DATE, "+
#                     "	a.participantName AS Home, "+
#                     "	b.participantName AS Away, "+
#                     "	a.bookmaker AS bkms, "+
#                     "	a.odds AS H, "+
#                     "	c.odds AS D, "+
#                     "	b.odds AS A  "+
#                     " FROM "+
#                     "	(SELECT * FROM {reftable}) AS a, "+
#                     "	(SELECT * FROM {reftable}) AS b, "+
#                     "	(SELECT * FROM {reftable}) AS c "+
#                     " where  "+
#                     "	a.eventId = b.eventId AND "+
#                     "	a.providerId = b.providerId AND "+
#                     "	c.eventId = b.eventId AND "+
#                     "	c.providerId = b.providerId AND "+
#                     "	c.role = 'Draw' AND "+
#                     "	a.role = 'Home' AND "+
#                     "	b.role = 'Away' AND  "+
#                     "	a.bookmaker != 'Matchbook'; "
#                      )


query_tennis_insert = (
                "SELECT "+
                " a.eventId, "+
 	            " a.participantName AS home_team, "+
	            " b.participantName AS away_team, "+
            	" a.eventName AS championship, "+
            	" a.location AS country, "+
            	" a.date AS match_date, "+
            	" a.odds AS home_odds, "+
            	" b.odds AS away_odds, "+
                " a.bookmaker AS bkms, "+
            	" a.bettingTypeId AS betting_type "+
                " FROM "+
                "	("+
                "		SELECT "+
                "			* "+
                "		FROM "+
                "   		{reftable} "+
                "		WHERE "+
                "			role = 'Home' "+
                "			AND participantName = '{home_team}' "+
                "			AND DATE = '{match_date}' "+
                "			AND bookmaker = '{bkms}'"+
                "	) a, "+
                "	("+
                "		SELECT "+
                "			* "+
                "		FROM "+
                "			{reftable} "+
                "		WHERE "+
                "			role = 'Away' "+
                "			AND participantName = '{away_team}' "+
                "			AND DATE = '{match_date}' "+
                "			AND bookmaker = '{bkms}' "+
                "	) b;"
                )

query_football_insert = (
                "SELECT "+
                " a.eventId, "+
 	            " a.participantName AS home_team, "+
	            " b.participantName AS away_team, "+
            	" a.eventName AS championship, "+
            	" a.location AS country, "+
            	" a.date AS match_date, "+
            	" a.odds AS home_odds, "+
            	" b.odds AS away_odds, "+
                " a.bookmaker AS bkms, "+
            	" a.bettingTypeId AS betting_type "+
                " FROM "+
                "	("+
                "		SELECT "+
                "			* "+
                "		FROM "+
                "   		{reftable} "+
                "		WHERE "+
                "			role = 'Home' "+
                "			AND participantName = '{Home}' "+
                "			AND DATE = '{date}' "+
                "			AND bookmaker = '{bkms}'"+
                "	) a, "+
                "	("+
                "		SELECT "+
                "			* "+
                "		FROM "+
                "			{reftable} "+
                "		WHERE "+
                "			role = 'Away' "+
                "			AND participantName = '{Away}' "+
                "			AND DATE = '{date}' "+
                "			AND bookmaker = '{bkms}' "+
                "	) b;"
                )
