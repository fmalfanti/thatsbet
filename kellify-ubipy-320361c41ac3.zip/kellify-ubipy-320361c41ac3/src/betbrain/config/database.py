config = {
             'user': 'ubibetter',
             'password': 'R0t0l0n!',
             'host': 'sweden.kellify.com',
             'database': 'betbrain',
             'raise_on_warnings': True,
          }


Tables = {
            'TennisOdds':'TennisOdds',
            'TennisOdds_Updated':'TennisOdds_Updated',

            'BaseballOdds':'BaseballOdds',
            'BaseballOdds_Updated':'BaseballOdds_Updated',

            'BasketOdds':'BasketOdds',
            'BasketOdds_Updated':'BasketOdds_Updated',

            'IceHockeyOddsHA':'IceHockeyOddsHA',
            'IceHockeyOddsHA_Updated':'IceHockeyOddsHA_Updated',

            'FootballOdds':'FootballOdds',
            'FootballOdds_Updated':'FootballOdds',
        }
