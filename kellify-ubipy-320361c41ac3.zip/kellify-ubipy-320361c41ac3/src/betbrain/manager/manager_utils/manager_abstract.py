from betbrain.utils.db.read_query_as_df import read_query_as_df
from ubibetter.utils.data.get_neigbours import get_neighbours
from ubibetter.models.compute_fraction import compute_fraction
import pandas as pd

class format_data():

    def __set_index__(self, df):
        return df.set_index(['date', 'Home', 'Away', 'bkms'])

    def __set_colnames__(self, df, field):
        colnames = [(field, c) for c in df.columns]
        df.columns = pd.MultiIndex.from_tuples(colnames)
        return df

    def format_data(self, df, field):
        df = self.__set_index__(df)
        df = self.__set_colnames__(df, field)
        return df

    def oranize_mutually_exclusive(self, df):
        dflist = [df.max(axis=1).rename(0), df.min(axis=1).rename(1)]
        return pd.concat(dflist, axis=1)

    def format_mutually_exclusive(self, df, field):
        df = self.__set_index__(df)
        outdf = self.oranize_mutually_exclusive(df)
        outdf = self.__set_colnames__(outdf, field)
        return outdf

class manager_abstract(format_data):

    def compute_books(self, df):
        return ((1 / df).sum(axis=1) - 1).round(decimals=3).rename('books').to_frame()

    def compute_probs(self, df):
        fract = 1 / df
        probs = fract.divide(fract.sum(axis=1), axis=0)
        return probs.round(decimals=2)


    ## ODDS
    @property
    def first_odds(self):
        odds = read_query_as_df(self.odds_query)
        formatter = self.format_mutually_exclusive if self.sport != 'Football' else self.format_data
        return formatter(odds, 'first_odds')

    @property
    def last_odds(self):
        odds = read_query_as_df(self.curr_query)
        formatter = self.format_mutually_exclusive if self.sport != 'Football' else self.format_data
        return formatter(odds, 'last_odds')


    ## BOOKS
    @property
    def first_books(self):
        odds = read_query_as_df(self.odds_query)
        formatter = self.format_mutually_exclusive if self.sport != 'Football' else self.format_data
        return self.compute_books(self.__set_index__(odds)).reset_index()

    @property
    def last_books(self):
        odds = read_query_as_df(self.odds_query)
        formatter = self.format_mutually_exclusive if self.sport != 'Football' else self.format_data
        return self.compute_books(self.__set_index__(odds)).reset_index()


    ## PROBS
    @property
    def first_prob(self):
        prob = self.compute_probs(self.first_odds['first_odds'])
        return self.__set_colnames__(prob, 'first_prob')

    @property
    def last_prob(self):
        prob = self.compute_probs(self.last_odds['last_odds'])
        return self.__set_colnames__(prob, 'last_prob')

    @property
    def matrix(self):
        data = self.__get_data__() if self.sport != 'Football' else self.ubibetter.data_complete
        if self.sport != 'Football':
            flds = [('prob', 0), ('prob', 1), 'FTR']
        else:
            flds = [('prob', 'A'), ('prob', 'H'), 'FTR']
        matrix = self.ubibetter.get_matrix(data, fields=flds)
        if self.sport != 'Football':
            i0 = matrix.index.get_level_values(0)
            i1 = matrix.index.get_level_values(1)
            matrix = matrix.loc[(i0 != 0.5) & (i1 != 0.5)]

            matrix = matrix.stack().unstack(level=2)
            matrix = matrix[matrix.sum(axis=1) > 100].stack()
            matrix = matrix.unstack(level=2).fillna(0)
            return matrix
        else:
            football_tresh = 500
            matrix = matrix[matrix.sum(axis=1) > football_tresh]
            return matrix

    @property
    def ubi_prob(self):
        if self.sport == 'Football':
            probs = self.first_prob[[('first_prob', 'A'), ('first_prob', 'H')]]
        else:
            probs = self.first_prob[[('first_prob', 0), ('first_prob', 1)]]

        vicini = probs.apply(get_neighbours, axis=1).rename('NN').to_frame()
        vicini = vicini.dropna(axis=0)
        matrix = self.matrix # ->  TODO: load matrix from file
        prob = vicini.apply(self.ubibetter.__compute_probs_avg__,
                            axis=1, args=[matrix])
        return self.__set_colnames__(prob, 'ubibet')

    @property
    def kelly_frac(self):
        odds = self.last_odds.stack(level=1).rename(columns={'last_odds':'odd'})

        if self.sport != 'Football':
            odds = odds.unstack(level=4)
            odds = odds[odds[('odd', 0)] != odds[('odd', 1)]].stack(level=1)
        else:
            pass

        prob = self.ubi_prob.stack(level=1).rename(columns={'ubibet':'prob'})
        data = pd.concat([odds, prob], axis=1, join='inner', sort=True)

        frac = data.groupby(level=self.levels).apply(compute_fraction)
        return frac.round(4)

    def __get_data__(self):

        if self.sport != 'Football':
            odds = self.oranize_mutually_exclusive(self.ubibetter.odds,)
        else:
            odds = self.ubibetter.odds['odds']

        prob = self.compute_probs(odds)
        book = self.compute_books(odds)

        odds = self.__set_colnames__(odds, 'odds')
        prob = self.__set_colnames__(prob, 'prob')

        book.columns = pd.MultiIndex.from_tuples([('book' ,'')])

        data = pd.concat([odds, prob, book], axis=1).reset_index(level=3)

        ftr  = self.ubibetter.ftr()
        ftr.columns  = pd.MultiIndex.from_tuples([('FTR', '')])

        data = data.merge(ftr, right_index=True, left_index=True)
        data = data.rename(columns={'level_3':'bkmr'})

        data = data.set_index('bkmr', append=True)

        return data
