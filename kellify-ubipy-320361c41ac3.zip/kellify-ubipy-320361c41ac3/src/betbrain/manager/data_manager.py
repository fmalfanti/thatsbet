from ubibetter.manager.data_manager import data_manager as ubibetter_data_manager
from betbrain.manager.manager_utils.manager_abstract import manager_abstract
from betbrain.config.database import Tables
from betbrain.config.queries import *
import pandas as pd

class data_manager(manager_abstract):

    def __init__(self, sport=None):
        self.sport      = sport
        self.ubibetter  = ubibetter_data_manager(sport=sport)
        if sport == 'Tennis':    self.__init__tennis__()
        if sport == 'Baseball':  self.__init__baseball__()
        if sport == 'Basket':    self.__init__basket__()
        if sport == 'Icehockey': self.__init__icehockey__()
        if sport == 'Football':  self.__init__football__()

        # if sport == 'AmericanFootball': self.__init__american_football__()
        pass


    def __init__tennis__(self):
        self.levels = [0,1,2,3] # 0:date, 1:HoneTeam, 2:AwayTeam, 3:Bookmaker
        self.curr_query = query.format(**{'reftable':Tables['TennisOdds']})
        self.odds_query = query.format(**{'reftable':Tables['TennisOdds']})

    def __init__baseball__(self):
        self.levels = [0,1,2,3]
        self.curr_query = query.format(**{'reftable':Tables['BaseballOdds']})
        self.odds_query = query.format(**{'reftable':Tables['BaseballOdds']})

    def __init__basket__(self):
        self.levels = [0,1,2,3]
        self.curr_query = query.format(**{'reftable':Tables['BasketOdds']})
        self.odds_query = query.format(**{'reftable':Tables['BasketOdds']})

    def __init__icehockey__(self):
        self.levels = [0,1,2,3]
        self.curr_query = query.format(**{'reftable':Tables['IceHockeyOddsHA']})
        self.odds_query = query.format(**{'reftable':Tables['IceHockeyOddsHA']})

    def __init__football__(self):
        self.levels = [0,1,2,3]
        self.curr_query = query_football.format(**{'reftable':Tables['FootballOdds']})
        self.odds_query = query_football.format(**{'reftable':Tables['FootballOdds']})
