query_bookmaker_encode = ("SELECT * FROM {bookmaker_platform} WHERE platform_id = {platform_id};")
