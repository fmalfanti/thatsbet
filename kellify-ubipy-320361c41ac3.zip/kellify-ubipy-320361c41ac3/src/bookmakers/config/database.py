config = {
             'user': 'ubibetter',
             'password': 'R0t0l0n!',
             'host': 'sweden.kellify.com',
             'database': 'bookmaker_betting',
             'raise_on_warnings': True,
          }


Tables = {
            'bookmaker_platform':'bookmaker_platform',
        }
