from bookmakers.config.database import config
from mysql import connector
import pandas as pd


def read_query_as_df(query=None, chunk=None):
    if query:
        con = connector.connect(**config)
        df = pd.read_sql_query(query, con=con, chunksize=chunk)
        if chunk: df = pd.concat([i for i in df], axis=0).reset_index(drop=True)
        con.close()
        return df
    else:
        return None
