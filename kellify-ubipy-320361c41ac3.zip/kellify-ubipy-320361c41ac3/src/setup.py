from setuptools import setup, find_packages

setup(
    name='ubibetter',

    version='0.1',
    description=("Sports Betting Forecasting Method."),

    author='Gabriele Torre',
    author_email='gabriele.torre@kellify.com',
    license='KELLIFY',
    packages=find_packages(),
)
