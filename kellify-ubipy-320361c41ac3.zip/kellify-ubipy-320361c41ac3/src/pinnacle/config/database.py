config = {
            'user': 'ubibetter',
            'password': 'R0t0l0n!',
            'host': 'sweden.kellify.com',
            'database': 'betting_kings',
            'raise_on_warnings': True,
          }


