from betting_kings.config.database import config
from mysql import connector

def execute_list_of_queries(queries):
    con = connector.connect(**config)
    cur = con.cursor()
    for query in queries: cur.execute(query)
    con.commit()
    cur.close()
    con.close()
