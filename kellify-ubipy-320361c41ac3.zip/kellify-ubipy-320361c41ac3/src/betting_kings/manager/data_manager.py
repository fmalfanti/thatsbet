from bookmakers.utils.db.read_query_as_df import read_query_as_df
from bookmakers.config.queries import query_bookmaker_encode
from bookmakers.config.database import Tables
import pandas as pd

class data_manager():
    def __init__(self, platform_id = 1):
        self.platform_id = platform_id
        pass

    @property
    def bookmakers_map(self):
        p_id = {'platform_id':self.platform_id}
        query = query_bookmaker_encode.format(**{**Tables, **p_id})
        out = read_query_as_df(query).set_index('label')
        return out
