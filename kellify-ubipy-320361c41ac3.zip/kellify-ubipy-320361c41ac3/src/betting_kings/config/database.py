config = {
             'user': 'ubibetter',
             'password': 'R0t0l0n!',
             'host': 'sweden.kellify.com',
             'database': 'betting_kings',
             'raise_on_warnings': True,
          }


Tables = {
            'bookmaker_platform':'bookmaker_platform',

            'football_fraction' : 'football_fraction',
            'tennis_fraction'   : 'tennis_fraction',
            'baseball_fraction' : 'baseball_fraction',
            'basket_fraction'   : 'basket_fraction',
            'icehockey_fraction': 'icehockeyHA_fraction',
        }
