update_forec = (
        "INSERT INTO {reftable} (referrer_id, event_id, odd_id, platform_id, " +
        "home_team, away_team, country, championship, bookmaker_id, match_date, fh, " +
        "fa, ph, pa, pbh, pba, delta) VALUES ('{eventId}', '{eventId}', '{eventId}', " +
        "1, '{home_team}', '{away_team}', '{country}', '{championship}', " +
        "{bookmaker_id},'{match_date}', {fh}, {fa}, {ph}, {pa}, {pbh}, {pba}, -1) " +
        "ON DUPLICATE KEY UPDATE fh={fh}, fa={fa}, ph={ph}, pa={pa}, " +
        "pbh={pbh}, pba={pba}, timestamp=CURRENT_TIMESTAMP();"
        )

update_forec_football = (
        "INSERT INTO {reftable} (referrer_id, event_id, odd_id, platform_id, " +
        "home_team, away_team, country, championship, bookmaker_id, match_date, fh, fd, " +
        "fa, ph, pd, pa, pbh, pbd, pba, delta) VALUES ('{eventId}', '{eventId}', '{eventId}', " +
        "1, '{home_team}', '{away_team}', '{country}', '{championship}', " +
        "{bookmaker_id},'{match_date}', {fh}, {fd}, {fa}, {ph}, {pd}, {pa}, "  +
        "{pbh}, {pbd}, {pba}, -1) ON DUPLICATE KEY UPDATE fh={fh}, fd={fd}, " +
        "fa={fa}, ph={ph}, pd={pd}, pa={pa}, pbh={pbh}, pbd={pbd}, pba={pba}, " +
        "timestamp=CURRENT_TIMESTAMP();"
        )

clear_old_forec = ('TRUNCATE TABLE {reftable};')
